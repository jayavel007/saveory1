<?php

class Subscriber_model extends CI_Model{


    public function getsubscriberList()
	{
		// $data['status'] = 1;
        // $id != 0 ?$data['category_id'] = $id:"";

		   $this->db->select('*');
    $this->db->from('users_login');
    $this->db->join('subscriber','users_login.user_id=subscriber.user_id');
    $query = $this->db->get();
		return $query->result_array();
	}

    public function saveCategory()
    {
       $data['category_name'] = $this->input->post('category_name');
       $config['upload_path'] = 'file_folder/category/';
       $config['allowed_types'] = '*'; 

				if(!empty($_FILES['category_image']['name'])){
					$this->load->library('upload', $config);
				if (!$this->upload->do_upload('category_image')) {
					$error = array('error' => $this->upload->display_errors());
					$data['category_image'] = $error;
				} else {
					$file_info = $this->upload->data();
					$data['category_image'] = 'file_folder/category/'.$file_info['file_name'];
				}

			}
            $uid = $this->input->post('update_id');
            if($uid == ""){
              $this->db->insert('category',$data);
              echo 'ins';
            print_r($data);

            }else{
                $this->db->where('category_id',$uid);
                $this->db->update('category',$data);
            echo "update";
            print_r($data);
            }
    }

}

?>