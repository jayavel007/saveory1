<?php

class Video_model extends CI_Model{
	
	public function getCategory()
	{
		$data['status'] = 1;
		 $query = $this->db->get_where('category',$data);
		return $query->result_array();
	}


	public function getMovieType()
	{
		$data['status'] = 1;
		 $query = $this->db->get_where('movie_type',$data);
		return $query->result_array();
	}
	
	public function getGenre()
	{
		$data['status'] = 1;
		 $query = $this->db->get_where('genre_list',$data);
		return $query->result_array();
	}

	public function getLanguage()
	{
		$data['status'] = 1;
		$query = $this->db->get_where('languages',$data);
		return $query->result_array();
	}

	public function addCastCrew()
	{
		$data['cc_name'] = $this->input->post('name');
		$data['cc_description'] = $this->input->post('description');

		$updateid = $this->input->post('update_id');

		$config['upload_path'] = 'file_folder/cast_crew/';
		$config['allowed_types'] = '*'; 
		if(!empty($_FILES['image']['name'])){
			$this->load->library('upload', $config);
		if (!$this->upload->do_upload('image')) {
			$error = array('error' => $this->upload->display_errors());
			$data['cc_image'] = ""; 
		} else {
			$file_info = $this->upload->data();
			$data['cc_image'] = 'file_folder/cast_crew/'.$file_info['file_name'];
		}
	
	}
		if($updateid == ""){

			$this->db->insert('cast_crew',$data);

		}else{

			$this->db->where('cast_crew_id',$updateid);
			$this->db->update('cast_crew',$data);

		}
		// print_r($this->db->last_query());
		// exit;
	}

	public function uploadVideo()
	{
 // print_r('idgfhesdiygf6egre');
	  $data['title'] = $_POST['title'];
	  $data['year_of_release'] =$_POST['year_of_release'];
	  $data['trailer_duration'] =$_POST['trailer_duration'];
	  $data['video_duration'] =$_POST['duration']; 
	  $data['category_id'] =$_POST['category_id'];
	  $movie_type_id =  $_POST['movie_type_id'];
	  $genre_id = $_POST['genre_id'];
	  $data['ratings'] = $_POST['ratings'];
	  $data['status'] = $_POST['publish_type'];
	  $data['publish_time'] = $_POST['publish_time'];
	  $data['description'] = $_POST['description'];
	  $cast_crew_id = $_POST['cast_crew_id'];
	  $language_id = $_POST['language_id'];
	  // $videoFile = $_POST['trailer_video'];
	  $video = $_POST['video'];
	  $config['upload_path'] = 'file_folder/movies/';
	  $config['allowed_types'] = '*'; 
      $banner_link= $_POST['trailer_video'];
	  // print_r($banner_link);
	   // exit;
	  $query = $this->db->insert('video_list',$data);
	  // print_r($this->db->last_query());
	 // exit;

        $insertId = $this->db->insert_id();    



				if(!empty($_FILES['video']['name'])){
					$this->load->library('upload', $config);

				if (!$this->upload->do_upload('video')) {
					$error = array('error' => $this->upload->display_errors());
					print_r($error);
					exit;
					$mainimg = ""; 
				} else {

					$file_info = $this->upload->data();
					$video_file['file_name'] = 'file_folder/movies/'.$file_info['file_name'];


                    }

				$video_file['video_list_id'] = $insertId;
				$video_file['thumbnail'] = $_POST['default_image'];
				
            	$insQuery=$this->db->insert('video_file',$video_file);

				 $insertId1 = $this->db->insert_id();    
				if($insQuery){

			

					echo 1;
				}else{
					echo $insQuery;
				}


			}
	}


}
?>