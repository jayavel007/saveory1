<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/userguide3/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes with
| underscores in the controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'Login';
$route['home'] = 'Home';
$route['moderator'] = 'Moderator';
$route['view_moderator'] = 'Moderator/view';
$route['add_sub_admin'] = 'Sub_admin';
$route['view_sub_admin'] = 'Sub_admin/view';
$route['add_category'] = 'Category';
$route['view_category'] = 'Category/view';
$route['add_cast_crew'] = 'Cast_crew';
$route['view_cast_crew'] = 'Cast_crew/view';
$route['add_movie_type'] = 'Cast_crew/add_movie_type';
$route['view_movie_type'] = 'Cast_crew/view_movie_type';
$route['upload_video'] = 'Video';
$route['view_video'] = 'Video/view';

$route['subscription_pay'] = 'Payment/subscription_pay';
$route['ppv_payment'] = 'Payment/ppv_payment';
$route['view_subscriptions'] = 'Subscriptions/view';
$route['add_subscriptions'] = 'Subscriptions';
$route['view_coupon'] = 'Coupon/view';
$route['add_coupon'] = 'Coupon';
$route['redeems'] = 'Redeems';
$route['site_settings'] = 'Settings';
$route['home_page_settings'] = 'Settings/home_page_settings';
$route['custom_push'] = 'Custom_push';
$route['add_page'] = 'Pages';
$route['view_page'] = 'Pages/view';
$route['mail_camp'] = 'Mail_camp';
$route['my_account'] = 'My_account';
$route['user_report'] = 'Report/user_report';
$route['movie_tv_series'] = 'Report/movie_tv_series';
$route['revenue_report'] = 'Report/revenue_report';
$route['user_view'] = 'User/view';
$route['subscriber_view'] = 'Subscriber/view';



$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
