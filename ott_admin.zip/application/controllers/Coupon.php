<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Coupon extends CI_Controller {

public function index()
	{
		$this->load->view('include/header');
		$this->load->view('add_coupon');
	    // $this->load->view('include/footer');
	}

public function view()
	{
		$this->load->view('include/header');
		$this->load->view('view_coupon');
	    // $this->load->view('include/footer');
	}


}

