<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Report extends CI_Controller {

public function user_report()
	{
		$this->load->view('include/header');
		$this->load->view('user_report');
	    // $this->load->view('include/footer');
	}

public function movie_tv_series()
	{
		$this->load->view('include/header');
		$this->load->view('movie_tv_series');
	    // $this->load->view('include/footer');
	}

	public function revenue_report()
	{
		$this->load->view('include/header');
		$this->load->view('revenue_report');
	    // $this->load->view('include/footer');
	}




}

