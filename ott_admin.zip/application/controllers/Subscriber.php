<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subscriber extends CI_Controller {

public function __construct()
	{
			parent::__construct();
			// Your own constructor code
			$this->load->model('Subscriber_model');
	}

public function view()
	{
		$data['subscribersList'] = $this->Subscriber_model->getsubscriberList();
		$this->load->view('include/header');
		$this->load->view('view_subscriber',$data);
	    
	}




}

