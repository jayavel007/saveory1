<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Moderator extends CI_Controller {

public function index()
	{
		$this->load->view('include/header');
		$this->load->view('moderator');
	    // $this->load->view('include/footer');
	}

public function view()
	{
		$this->load->view('include/header');
		$this->load->view('view_moderator');
	    // $this->load->view('include/footer');
	}




}

