<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mail_camp extends CI_Controller {

public function index()
	{
		$this->load->view('include/header');
		$this->load->view('mail_camp');
	    // $this->load->view('include/footer');
	}



}

