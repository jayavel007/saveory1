<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sub_admin extends CI_Controller {

public function index()
	{
		$this->load->view('include/header');
		$this->load->view('add_sub_admin');
	    // $this->load->view('include/footer');
	}

public function view()
	{
		$this->load->view('include/header');
		$this->load->view('view_sub_admin');
	    // $this->load->view('include/footer');
	}




}

