<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

public function __construct()
	{
			parent::__construct();
			// Your own constructor code
			$this->load->model('User_model');
	}

public function view()
	{
		$data['usersList'] = $this->User_model->getusersList();
		$this->load->view('include/header');
		$this->load->view('view_user',$data);
	    
	}




}

