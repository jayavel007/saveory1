<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pages extends CI_Controller {

public function index()
	{
		$this->load->view('include/header');
		$this->load->view('add_page');
	    // $this->load->view('include/footer');
	}

public function view()
	{
		$this->load->view('include/header');
		$this->load->view('view_page');
	    // $this->load->view('include/footer');
	}



}

