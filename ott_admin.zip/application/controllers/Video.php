<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Video extends CI_Controller {
	public function __construct()
	{
			parent::__construct();
			// Your own constructor code
			$this->load->model('Video_model');
	}


public function index()
	{
		$data['languageList'] = $this->Video_model->getLanguage();
         $data['categoryList'] = $this->Video_model->getCategory();
         $data['movieTypeList'] = $this->Video_model->getMovieType();
         $data['genreList'] = $this->Video_model->getGenre();
		//  print_r($data);
		//  exit;
		$this->load->view('include/header');
		$this->load->view('upload_video',$data);
	    // $this->load->view('include/footer');
	}

	public function view()
	{
         
		$this->load->view('include/header');
		$this->load->view('view_video');
	    // $this->load->view('include/footer');
	}

	public function uploadVideo()
	{
		$this->Video_model->uploadVideo();
	}




}

