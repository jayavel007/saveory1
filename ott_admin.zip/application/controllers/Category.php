<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Category extends CI_Controller {

	public function __construct()
	{
			parent::__construct();
			// Your own constructor code
			$this->load->model('Category_model');
	}

public function index($id = 0)
	{
		
		$data['edit'] =	$id != 0?$this->Category_model->getCategoryList($id):"";

		$this->load->view('include/header');
		$this->load->view('add_category',$data);
	}
	public function delete($id = 0)
	{
		
		$this->Category_model->getCategoryList_delete($id);
     
	}
public function addCategory()
{
	$this->Category_model->saveCategory();
	redirect('Category/index');
}
public function view()
	{
		$data['categoryList'] = $this->Category_model->getCategoryList();
		$this->load->view('include/header');
		$this->load->view('view_category',$data);
	    
	}




}

