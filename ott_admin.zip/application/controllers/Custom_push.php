<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Custom_push extends CI_Controller {

public function index()
	{
		$this->load->view('include/header');
		$this->load->view('custom_push_notification');
	    // $this->load->view('include/footer');
	}


}
