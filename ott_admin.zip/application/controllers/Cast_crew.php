<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cast_crew extends CI_Controller {

	public function __construct()
	{
			parent::__construct();
			// Your own constructor code
			$this->load->library('pagination');
			$this->load->model('Video_model');
	}

public function index()
	{
		$this->load->view('include/header');
		$this->load->view('add_cast_crew');
	    // $this->load->view('include/footer');
	}

public function view()
	{
		$this->load->view('include/header');
		$this->load->view('view_cast_crew');
	}

	function addCastCrew()
	{
		$this->Video_model->addCastCrew();
		redirect('Cast_crew/view');
	}

	public function loadCrewList($rowno=0){
		   
		// $count['bidding_id'] = $id=$this->input->post('bidId');
		// $unique=$this->input->post('unique');
	 
		 $rowperpage = 50;
		 if($rowno != 0){
		   $rowno = ($rowno-1) * $rowperpage;
		 }
		 $c_count=$this->db->get_where('cast_crew');
		 $allcount = $c_count->num_rows(); 
		 
		 $this->db->limit($rowperpage, $rowno);
		 $this->db->select('*');         
		 $this->db->from('cast_crew');
		 $this->db->where('status',1);
 
		 $users_record = $this->db->get()->result_array();
		 
		 $config['base_url'] = base_url().'App_users/loadRecord';
		 $config['use_page_numbers'] = TRUE;
		 $config['total_rows'] = $allcount;
		 $config['per_page'] = $rowperpage;
		 $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
		 $config['full_tag_close']   = '</ul></nav></div>';
		 $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
		 $config['num_tag_close']    = '</span></li>';
		 $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
		 $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
		 $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
		 $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
		 $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
		 $config['prev_tag_close']  = '</span></li>';
		 $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
		 $config['first_tag_close'] = '</span></li>';
		 $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
		 $config['last_tag_close']  = '</span></li>';
		 $this->pagination->initialize($config); 
		 $data['pagination'] = $this->pagination->create_links();
		 $data['result'] = $users_record;
		 $data['row'] = $rowno;
		echo json_encode($data);
	 }
 



}

