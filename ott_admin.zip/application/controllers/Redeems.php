<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Redeems extends CI_Controller {

public function index()
	{
		$this->load->view('include/header');
		$this->load->view('redeems');
	    // $this->load->view('include/footer');
	}



}

