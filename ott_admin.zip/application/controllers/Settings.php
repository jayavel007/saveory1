<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Settings extends CI_Controller {

public function index()
	{
		$this->load->view('include/header');
		$this->load->view('site_settings');
	    // $this->load->view('include/footer');
	}
	public function home_page_settings()
	{
		$this->load->view('include/header');
		$this->load->view('home_page_settings');
	    // $this->load->view('include/footer');
	}



}

