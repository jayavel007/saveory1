<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Payment extends CI_Controller {

	public function __construct()
	{
			parent::__construct();
			// Your own constructor code
			$this->load->model('Payments_model');
	}


public function subscription_pay()
	{
		$data['usersList'] = $this->Payments_model->subscription_pay_List();
		$this->load->view('include/header');
		$this->load->view('subscription_pay',$data);
	}

public function ppv_payment()
	{
		$this->load->view('include/header');
		$this->load->view('ppv_payment');
	    // $this->load->view('include/footer');
	}




}

