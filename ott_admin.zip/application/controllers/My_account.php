<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class My_account extends CI_Controller {

public function index()
	{
		$this->load->view('include/header');
		$this->load->view('my_account');
	    // $this->load->view('include/footer');
	}



}

