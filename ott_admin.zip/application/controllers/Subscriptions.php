<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subscriptions extends CI_Controller {

public function index()
	{
		$this->load->view('include/header');
		$this->load->view('add_subscriptions');
	    // $this->load->view('include/footer');
	}

public function view()
	{
		$this->load->view('include/header');
		$this->load->view('view_subscriptions');
	    // $this->load->view('include/footer');
	}


}

