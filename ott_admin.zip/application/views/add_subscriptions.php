    
        <div class="content-wrapper" style="min-height: 1217px;">

            <section class="content-header">
                <h1>Add Subscription<small></small></h1>
                <ol class="breadcrumb">    <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
    <li><a href="#"><i class="fa fa-key"></i> Subscriptions</a></li>
    <li class="active">Add Subscription</li>
</ol>
            </section>

            <!-- Main content -->
            <section class="content">
                
                
                
    <div class="row">

        <div class="col-md-10 ">

            <div class="box box-primary">

                <div class="box-header label-primary">
                    <b>Add Subscription</b>
                    <a href="#" style="float:right" class="btn btn-default">View Subscriptions</a>
                </div>

                <form class="form-horizontal" action="#" method="POST" enctype="multipart/form-data" role="form">

    <input type="hidden" name="subscription_id" value="">

    <div class="box-body">

        <div class="form-group">
            <label for="title" class="col-sm-2 control-label">*Title</label>

            <div class="col-sm-10">
                <input type="text" required="" name="title" class="form-control" id="title" value="" placeholder="Title" pattern="[a-zA-Z,0-9\s\-\.]{2,100}">
            </div>
        </div>

        <div class="form-group">
            <label for="description" class="col-sm-2 control-label">*Description</label>

            <div class="col-sm-10">
                <textarea class="form-control" name="description" required="" placeholder="Description"></textarea>
            </div>

        </div>

        <div class="form-group">
            <label for="plan" class="col-sm-2 control-label">*No of months</label>

            <div class="col-sm-10">
                <input type="number" min="1" max="12" pattern="[0-9][0-2]{2}" required="" name="plan" class="form-control" id="plan" value="" title="Please enter the plan months. Max : 12 months" placeholder="No of months">
            </div>
        </div>
        
        <div class="form-group">
            <label for="amount" class="col-sm-2 control-label">*No of account</label>

            <div class="col-sm-10">
                <input type="text" required="" name="no_of_account" class="form-control" id="manage_account_count" placeholder="Based on this count, the subscribed user can add the sub accounts or profiles" pattern="[0-9]{1,}" value="">
            </div>
        </div>

        <div class="form-group">
            <label for="amount" class="col-sm-2 control-label">*Amount</label>

            <div class="col-sm-10">
                <input type="number" required="" value="" name="amount" class="form-control" id="amount" placeholder="Amount" step="any">
            </div>
        </div>

    </div>

    <div class="box-footer">
        <button type="reset" class="btn btn-danger">Cancel</button>
        
        <button type="submit" class="btn btn-success pull-right" )="">Submit</button>        
    </div>
</form>              
            </div>

        </div>

    </div>

                
            </section>

        </div>

        <!-- include('layouts.admin.footer') -->

        <!-- include('layouts.admin.left-side-bar') -->

    </div>


    <!-- jQuery 2.2.0 -->
    <script src="admin-css/plugins/jQuery/jQuery-2.2.0.min.js"></script>
    <!-- Bootstrap 3.3.6 -->
    <script src="admin-css/bootstrap/js/bootstrap.min.js"></script>

    <script src="admin-css/plugins/datatables/jquery.dataTables.min.js"></script>

    <script src="admin-css/plugins/datatables/dataTables.bootstrap.min.js"></script>

    <!-- Select2 -->
    <script src="admin-css/plugins/select2/select2.full.min.js"></script>
    <!-- InputMask -->
    <script src="admin-css/plugins/input-mask/jquery.inputmask.js"></script>
    <script src="admin-css/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>

    <script src="admin-css/plugins/input-mask/jquery.inputmask.extensions.js"></script>

    <!-- SlimScroll -->
    <script src="admin-css/plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="admin-css/plugins/fastclick/fastclick.js"></script>
    <!-- AdminLTE App -->
    <script src="admin-css/dist/js/app.min.js"></script>

    <!-- jvectormap -->
    <script src="admin-css/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>

    <script src="admin-css/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>

    <script src="admin-css/plugins/chartjs/Chart.min.js"></script>

    <!-- Datapicker -->
    <script src="admin-css/plugins/datepicker/bootstrap-datepicker.js"></script> 

    <script src="admin-css/plugins/tokenize2-1.1-dist/tokenize2.min.js"></script>

    <script src="admin-css/plugins/iCheck/icheck.min.js"></script>

    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <!-- <script src="https://apistream.ulademos.com/admin-css/dist/js/pages/dashboard2.js"></script> -->

    <script src="admin-css/dist/js/demo.js"></script>

    <!-- page script -->
    <script type="text/javascript">

        function loadFile(event,id){

            $('#'+id).show();

            var reader = new FileReader();

            reader.onload = function(){

                var output = document.getElementById(id);

                output.src = reader.result;
            };

            reader.readAsDataURL(event.files[0]);
        }

        $(document).ready(function(){
            $('#help-popover').popover({
                html : true, 
                content: function() {
                    return $('#help-content').html();
                } 
            });  
        });
        
        $(function () {

            $("#example1").DataTable();

            $("#datatable-withoutpagination").DataTable({
                 "paging": false,
                 "lengthChange": false,
                 "language": {
                       "info": ""
                }
            });
            
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false
            });
        });
    </script>

    
    <script type="text/javascript">
         $("#subscriptions").addClass("active"); 
         $("#subscriptions-create").addClass("active");     </script>

    <script type="text/javascript">
        
        $(document).ready(function() {
            
            $('#expiry_date').datepicker({
                autoclose:true,
                format : 'dd-mm-yyyy',
                startDate: 'today',
            });
            
        });

    </script>
    <script type="text/javascript">
        
        $(function () {
            //Initialize Select2 Elements
            $(".select2").select2();

            //Datemask dd/mm/yyyy
            $("#datemask").inputmask("dd:mm:yyyy", {"placeholder": "hh:mm:ss"});
            //Datemask2 mm/dd/yyyy
            // $("#datemask2").inputmask("hh:mm:ss", {"placeholder": "hh:mm:ss"});
            //Money Euro
            $("[data-mask]").inputmask();

             //iCheck for checkbox and radio inputs
            $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
              checkboxClass: 'icheckbox_minimal-blue',
              radioClass: 'iradio_minimal-blue',
               increaseArea : '20%'
            });
            //Red color scheme for iCheck
            $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
              checkboxClass: 'icheckbox_minimal-red',
              radioClass: 'iradio_minimal-red',
               increaseArea : '20%'
            });
            //Flat red color scheme for iCheck
            $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
              checkboxClass: 'icheckbox_flat-green',
              radioClass: 'iradio_flat-green',
              increaseArea : '20%'

            });

             //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass: 'iradio_flat-green'
    });

        });
    </script>

</body>
</html>