   
        <div class="content-wrapper" style="min-height: 1180px;">

            <section class="content-header">
                <h1>
 	Redeems 

 	
<small></small></h1>
                <ol class="breadcrumb">
    <li><a href=""><i class="fa fa-dashboard"></i>Home</a></li>

    <li><a href=""><i class="fa fa-users"></i> Moderators</a></li>

        
    <li class="active"><i class="fa fa-trophy"></i> Redeems</li>
</ol>
            </section>

            <!-- Main content -->
            <section class="content">
                
                
                
	<div class="row">

        <div class="col-xs-12">

          	<div class="box box-primary">

	          	<div class="box-header label-primary">

	                <b style="font-size:18px;">Redeems</b>

	                <a href="" class="btn btn-default pull-right">View Moderators</a>

	            </div>
            	
            	<div class="box-body">

					<div id="example1_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer"><div class="row">
                      <!--   <div class="col-sm-6"><div class="dataTables_length" id="example1_length"><label>Show <select name="example1_length" aria-controls="example1" class="form-control input-sm"><option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select> entries</label></div></div>

                    <div class="col-sm-6"><div id="example1_filter" class="dataTables_filter"><label>Search:<input type="search" class="form-control input-sm" placeholder="" aria-controls="example1"></label></div></div> -->
                </div><div class="row"><div class="col-sm-12"><table id="example1" class="table table-bordered table-striped dataTable no-footer" role="grid" aria-describedby="example1_info">

						<thead>
						    <tr role="row"><th class="sorting_asc" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" aria-sort="ascending" aria-label="ID: activate to sort column descending" style="width: 15px;">ID</th><th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" aria-label="Moderator: activate to sort column ascending" style="width: 123px;">Moderator</th><th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" aria-label="Redeem Amount: activate to sort column ascending" style="width: 108px;">Redeem Amount</th><th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" aria-label="Paid Amount: activate to sort column ascending" style="width: 83px;">Paid Amount</th><th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" aria-label="Payment Mode: activate to sort column ascending" style="width: 97px;">Payment Mode</th><th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" aria-label="Sent Date: activate to sort column ascending" style="width: 63px;">Sent Date</th><th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" aria-label="Paid Date: activate to sort column ascending" style="width: 106px;">Paid Date</th><th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" aria-label="Status: activate to sort column ascending" style="width: 68px;">Status</th><th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1" aria-label="Action: activate to sort column ascending" style="width: 45px;">Action</th></tr>						
						</thead>

						<tbody>

							
							    
							    
													
						<tr role="row" class="odd">

							      	<td class="sorting_1">1</td>

							      	<td>
							      		<a href="">
							      			Moderator not Available
							      		</a>
							      	</td>

							      	<td><b>$17.00</b></td>

							      	<td><b>$0.00</b></td>

							      	<td class="text-uppercase"><b></b></td>

							      	<td>1 month ago</td>

							      	<td>07 Oct 2021 01:11 PM</td>

							      	<td><b>Sent to admin</b></td>
							 
							      	<td>

							      		
								      		<form action="https://apistream.ulademos.com/admin/moderators/payout/invoice" method="get">

								      			<input type="hidden" name="redeem_request_id" value="1">

								      			<input type="hidden" name="paid_amount" value="17">

								      			<input type="hidden" name="moderator_id" value="1">

								      			
								      			<button type="submit" class="btn btn-success btn-sm">Pay now</button>
								      		</form>

								      	
							      	</td>

							    </tr></tbody>

					</table></div></div>
                 <!--    <div class="row"><div class="col-sm-5"><div class="dataTables_info" id="example1_info" role="status" aria-live="polite">Showing 1 to 1 of 1 entries</div></div><div class="col-sm-7"><div class="dataTables_paginate paging_simple_numbers" id="example1_paginate"><ul class="pagination"><li class="paginate_button previous disabled" id="example1_previous"><a href="#" aria-controls="example1" data-dt-idx="0" tabindex="0">Previous</a></li><li class="paginate_button active"><a href="#" aria-controls="example1" data-dt-idx="1" tabindex="0">1</a></li><li class="paginate_button next disabled" id="example1_next"><a href="#" aria-controls="example1" data-dt-idx="2" tabindex="0">Next</a></li></ul></div></div></div> --></div>

				</div>

			</div>

		</div>

	</div>

                
            </section>

        </div>

        <!-- include('layouts.admin.footer') -->

        <!-- include('layouts.admin.left-side-bar') -->

    </div>


    <!-- jQuery 2.2.0 -->
    <script src="admin-css/plugins/jQuery/jQuery-2.2.0.min.js"></script>
    <!-- Bootstrap 3.3.6 -->
    <script src="admin-css/bootstrap/js/bootstrap.min.js"></script>

    <script src="admin-css/plugins/datatables/jquery.dataTables.min.js"></script>

    <script src="admin-css/plugins/datatables/dataTables.bootstrap.min.js"></script>

    <!-- Select2 -->
    <script src="plugins/select2/select2.full.min.js"></script>
    <!-- InputMask -->
    <script src="admin-css/plugins/input-mask/jquery.inputmask.js"></script>
    <script src="admin-css/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>

    <script src="admin-css/plugins/input-mask/jquery.inputmask.extensions.js"></script>

    <!-- SlimScroll -->
    <script src="admin-css/plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="admin-css/plugins/fastclick/fastclick.js"></script>
    <!-- AdminLTE App -->
    <script src="admin-css/dist/js/app.min.js"></script>

    <!-- jvectormap -->
    <script src="admin-css/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>

    <script src="admin-css/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>

    <script src="admin-css/plugins/chartjs/Chart.min.js"></script>

    <!-- Datapicker -->
    <script src="admin-css/plugins/datepicker/bootstrap-datepicker.js"></script> 

    <script src="admin-css/plugins/tokenize2-1.1-dist/tokenize2.min.js"></script>

    <script src="admin-css/plugins/iCheck/icheck.min.js"></script>

    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <!-- <script src="https://apistream.ulademos.com/admin-css/dist/js/pages/dashboard2.js"></script> -->

    <script src="admin-css/dist/js/demo.js"></script>

    <!-- page script -->
    <script type="text/javascript">

        function loadFile(event,id){

            $('#'+id).show();

            var reader = new FileReader();

            reader.onload = function(){

                var output = document.getElementById(id);

                output.src = reader.result;
            };

            reader.readAsDataURL(event.files[0]);
        }

        $(document).ready(function(){
            $('#help-popover').popover({
                html : true, 
                content: function() {
                    return $('#help-content').html();
                } 
            });  
        });
        
        $(function () {

            $("#example1").DataTable();

            $("#datatable-withoutpagination").DataTable({
                 "paging": false,
                 "lengthChange": false,
                 "language": {
                       "info": ""
                }
            });
            
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false
            });
        });
    </script>

    
    <script type="text/javascript">
         $("#redeems").addClass("active"); 
         $("#redeems").addClass("active");     </script>

    <script type="text/javascript">
        
        $(document).ready(function() {
            
            $('#expiry_date').datepicker({
                autoclose:true,
                format : 'dd-mm-yyyy',
                startDate: 'today',
            });
            
        });

    </script>
    <script type="text/javascript">
        
        $(function () {
            //Initialize Select2 Elements
            $(".select2").select2();

            //Datemask dd/mm/yyyy
            $("#datemask").inputmask("dd:mm:yyyy", {"placeholder": "hh:mm:ss"});
            //Datemask2 mm/dd/yyyy
            // $("#datemask2").inputmask("hh:mm:ss", {"placeholder": "hh:mm:ss"});
            //Money Euro
            $("[data-mask]").inputmask();

             //iCheck for checkbox and radio inputs
            $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
              checkboxClass: 'icheckbox_minimal-blue',
              radioClass: 'iradio_minimal-blue',
               increaseArea : '20%'
            });
            //Red color scheme for iCheck
            $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
              checkboxClass: 'icheckbox_minimal-red',
              radioClass: 'iradio_minimal-red',
               increaseArea : '20%'
            });
            //Flat red color scheme for iCheck
            $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
              checkboxClass: 'icheckbox_flat-green',
              radioClass: 'iradio_flat-green',
              increaseArea : '20%'

            });

             //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass: 'iradio_flat-green'
    });

        });
    </script>

    




</body></html>