<div class="content-wrapper" style="min-height: 1277px;">
	<section class="content-header">
		<h1>
View Videos

<small></small></h1>
		<ol class="breadcrumb">
			<li><a href=""><i class="fa fa-dashboard"></i>Home</a></li>
			<li class="active"><i class="fa fa-video-camera"></i> View Videos</li>
		</ol>
	</section>
	<!-- Main content -->
	<section class="content">
		<div class="row">
			<div class="col-xs-12"> </div>
		</div>
		<div class="row">
			<div class="col-xs-12">
				<div class="box box-primary">
					<div class="box-header label-primary"> <b style="font-size:18px;">View Videos</b> <a href="" class="btn btn-default pull-right">Upload Video</a>
						<!-- EXPORT OPTION START -->
						<ul class="admin-action btn btn-default pull-right" style="margin-right: 20px">
							<li class="dropdown"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">
			                  Export <span class="caret"></span>
			                </a>
								<ul class="dropdown-menu">
									<li role="presentation">
										<a role="menuitem" tabindex="-1" href=""> <span class="text-red"><b>Excel Sheet</b></span> </a>
									</li>
									<li role="presentation">
										<a role="menuitem" tabindex="-1" href=""> <span class="text-blue"><b>CSV</b></span> </a>
									</li>
								</ul>
							</li>
						</ul>
						<!-- EXPORT OPTION END -->
					</div>
					<div class="box-body">
						<div class=" table-responsive">
							<div id="331" class="modal fade" role="dialog">
								<div class="modal-dialog">
									<form action="" method="POST"></form>
									<!-- Modal content-->
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal">×</button>
											<h4 class="modal-title text-uppercase">

										        		<b>PayPerView</b>

										        		
										        	</h4> </div>
										<div class="modal-body">
											<div class="row">
												<input type="hidden" name="ppv_created_by" id="ppv_created_by" value="Admin">
												<div class="col-lg-12">
													<label class="text-uppercase">Video</label>
												</div>
												<div class="col-lg-12">
													<p>Finding Agnes</p>
												</div>
												<div class="col-lg-12">
													<label class="text-uppercase">User Type *</label>
												</div>
												<div class="col-lg-12">
													<div class="input-group">
														<input type="radio" name="type_of_user" value="1" checked="">&nbsp;
														<label class="text-normal">Normal Users</label>&nbsp;
														<input type="radio" name="type_of_user" value="2">&nbsp;
														<label class="text-normal">Paid Users</label>&nbsp;
														<input type="radio" name="type_of_user" value="3">&nbsp;
														<label class="text-normal">Both Users</label>
													</div>
													<!-- /input-group -->
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-lg-12">
													<label class="text-uppercase">Subscription Type *</label>
												</div>
												<div class="col-lg-12">
													<div class="input-group">
														<input type="radio" name="type_of_subscription" value="1" checked="">&nbsp;
														<label class="text-normal">One Time Payment</label>&nbsp;
														<input type="radio" name="type_of_subscription" value="2">&nbsp;
														<label class="text-normal">Recurring Payment</label>
													</div>
													<!-- /input-group -->
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-lg-12">
													<label class="text-uppercase">Amount *</label>
												</div>
												<div class="col-lg-12">
													<input type="number" required="" value="0" name="amount" class="form-control" id="amount" placeholder="Amount" step="any"> </div>
											</div>
										</div>
										<div class="modal-footer">
											<div class="pull-left"> </div>
											<div class="pull-right">
												<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
												<button type="submit" class="btn btn-primary" onclick="return confirm(&quot;Are you sure?&quot;);">Submit</button>
											</div>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
							</div>
							<div id="banner_331" class="modal fade" role="dialog">
								<div class="modal-dialog">
									<form action="https://apistream.ulademos.com/admin/videos/banner/set?admin_video_id=331" method="POST" enctype="multipart/form-data"></form>
									<!-- Modal content-->
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal">×</button>
											<h4 class="modal-title">Set/Change Mobile Banner Video</h4> </div>
										<div class="modal-body">
											<div class="row">
												<div class="col-lg-12">
													<p class="text-blue text-uppercase"> Only one banner video you can set. When you updating this video as "Banner Video", the other banner videos will be update as normal video </p>
												</div>
												<div class="col-lg-12">
													<p>Finding Agnes</p>
												</div>
												<div class="col-lg-12">
													<label>Picture *</label>
													<p class="help-block">Please enter .png .jpeg .jpg images only. Upload Rectangle images 4:3 Ratio Ex: 400 * 300</p>
												</div>
												<div class="col-lg-12">
													<div class="input-group">
														<input type="file" id="banner_image_file_331" accept="image/png,image/jpeg" name="banner_image" placeholder="Banner image" style="display:none" onchange="loadFile(this,'banner_image_331')">
														<div> <img src="https://apistream.ulademos.com/images/320x150.png" style="width:300px;height:150px;cursor: pointer" onclick="$('#banner_image_file_331').click();return false;" id="banner_image_331"> </div>
													</div>
													<!-- /input-group -->
												</div>
											</div>
											<br> </div>
										<div class="modal-footer">
											<div class="pull-right">
												<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
												<button type="submit" class="btn btn-primary" onclick="return confirm(&quot;Are you sure?&quot;);">Submit</button>
											</div>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
							</div>
							<div id="330" class="modal fade" role="dialog">
								<div class="modal-dialog">
									<form action="https://apistream.ulademos.com/admin/videos/ppv/add/330" method="POST"></form>
									<!-- Modal content-->
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal">×</button>
											<h4 class="modal-title text-uppercase">

										        		<b>PayPerView</b>

										        		
										        	</h4> </div>
										<div class="modal-body">
											<div class="row">
												<input type="hidden" name="ppv_created_by" id="ppv_created_by" value="Admin">
												<div class="col-lg-12">
													<label class="text-uppercase">Video</label>
												</div>
												<div class="col-lg-12">
													<p>U Turn</p>
												</div>
												<div class="col-lg-12">
													<label class="text-uppercase">User Type *</label>
												</div>
												<div class="col-lg-12">
													<div class="input-group">
														<input type="radio" name="type_of_user" value="1" checked="">&nbsp;
														<label class="text-normal">Normal Users</label>&nbsp;
														<input type="radio" name="type_of_user" value="2">&nbsp;
														<label class="text-normal">Paid Users</label>&nbsp;
														<input type="radio" name="type_of_user" value="3">&nbsp;
														<label class="text-normal">Both Users</label>
													</div>
													<!-- /input-group -->
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-lg-12">
													<label class="text-uppercase">Subscription Type *</label>
												</div>
												<div class="col-lg-12">
													<div class="input-group">
														<input type="radio" name="type_of_subscription" value="1" checked="">&nbsp;
														<label class="text-normal">One Time Payment</label>&nbsp;
														<input type="radio" name="type_of_subscription" value="2">&nbsp;
														<label class="text-normal">Recurring Payment</label>
													</div>
													<!-- /input-group -->
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-lg-12">
													<label class="text-uppercase">Amount *</label>
												</div>
												<div class="col-lg-12">
													<input type="number" required="" value="0" name="amount" class="form-control" id="amount" placeholder="Amount" step="any"> </div>
											</div>
										</div>
										<div class="modal-footer">
											<div class="pull-left"> </div>
											<div class="pull-right">
												<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
												<button type="submit" class="btn btn-primary" onclick="return confirm(&quot;Are you sure?&quot;);">Submit</button>
											</div>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
							</div>
							<div id="banner_330" class="modal fade" role="dialog">
								<div class="modal-dialog">
									<form action="https://apistream.ulademos.com/admin/videos/banner/set?admin_video_id=330" method="POST" enctype="multipart/form-data"></form>
									<!-- Modal content-->
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal">×</button>
											<h4 class="modal-title">Set/Change Mobile Banner Video</h4> </div>
										<div class="modal-body">
											<div class="row">
												<div class="col-lg-12">
													<p class="text-blue text-uppercase"> Only one banner video you can set. When you updating this video as "Banner Video", the other banner videos will be update as normal video </p>
												</div>
												<div class="col-lg-12">
													<p>U Turn</p>
												</div>
												<div class="col-lg-12">
													<label>Picture *</label>
													<p class="help-block">Please enter .png .jpeg .jpg images only. Upload Rectangle images 4:3 Ratio Ex: 400 * 300</p>
												</div>
												<div class="col-lg-12">
													<div class="input-group">
														<input type="file" id="banner_image_file_330" accept="image/png,image/jpeg" name="banner_image" placeholder="Banner image" style="display:none" onchange="loadFile(this,'banner_image_330')">
														<div> <img src="https://apistream.ulademos.com/images/320x150.png" style="width:300px;height:150px;cursor: pointer" onclick="$('#banner_image_file_330').click();return false;" id="banner_image_330"> </div>
													</div>
													<!-- /input-group -->
												</div>
											</div>
											<br> </div>
										<div class="modal-footer">
											<div class="pull-right">
												<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
												<button type="submit" class="btn btn-primary" onclick="return confirm(&quot;Are you sure?&quot;);">Submit</button>
											</div>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
							</div>
							<div id="329" class="modal fade" role="dialog">
								<div class="modal-dialog">
									<form action="https://apistream.ulademos.com/admin/videos/ppv/add/329" method="POST"></form>
									<!-- Modal content-->
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal">×</button>
											<h4 class="modal-title text-uppercase">

										        		<b>PayPerView</b>

										        		
										        	</h4> </div>
										<div class="modal-body">
											<div class="row">
												<input type="hidden" name="ppv_created_by" id="ppv_created_by" value="Admin">
												<div class="col-lg-12">
													<label class="text-uppercase">Video</label>
												</div>
												<div class="col-lg-12">
													<p>I Love You Hater</p>
												</div>
												<div class="col-lg-12">
													<label class="text-uppercase">User Type *</label>
												</div>
												<div class="col-lg-12">
													<div class="input-group">
														<input type="radio" name="type_of_user" value="1" checked="">&nbsp;
														<label class="text-normal">Normal Users</label>&nbsp;
														<input type="radio" name="type_of_user" value="2">&nbsp;
														<label class="text-normal">Paid Users</label>&nbsp;
														<input type="radio" name="type_of_user" value="3">&nbsp;
														<label class="text-normal">Both Users</label>
													</div>
													<!-- /input-group -->
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-lg-12">
													<label class="text-uppercase">Subscription Type *</label>
												</div>
												<div class="col-lg-12">
													<div class="input-group">
														<input type="radio" name="type_of_subscription" value="1" checked="">&nbsp;
														<label class="text-normal">One Time Payment</label>&nbsp;
														<input type="radio" name="type_of_subscription" value="2">&nbsp;
														<label class="text-normal">Recurring Payment</label>
													</div>
													<!-- /input-group -->
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-lg-12">
													<label class="text-uppercase">Amount *</label>
												</div>
												<div class="col-lg-12">
													<input type="number" required="" value="0" name="amount" class="form-control" id="amount" placeholder="Amount" step="any"> </div>
											</div>
										</div>
										<div class="modal-footer">
											<div class="pull-left"> </div>
											<div class="pull-right">
												<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
												<button type="submit" class="btn btn-primary" onclick="return confirm(&quot;Are you sure?&quot;);">Submit</button>
											</div>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
							</div>
							<div id="banner_329" class="modal fade" role="dialog">
								<div class="modal-dialog">
									<form action="https://apistream.ulademos.com/admin/videos/banner/set?admin_video_id=329" method="POST" enctype="multipart/form-data"></form>
									<!-- Modal content-->
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal">×</button>
											<h4 class="modal-title">Set/Change Mobile Banner Video</h4> </div>
										<div class="modal-body">
											<div class="row">
												<div class="col-lg-12">
													<p class="text-blue text-uppercase"> Only one banner video you can set. When you updating this video as "Banner Video", the other banner videos will be update as normal video </p>
												</div>
												<div class="col-lg-12">
													<p>I Love You Hater</p>
												</div>
												<div class="col-lg-12">
													<label>Picture *</label>
													<p class="help-block">Please enter .png .jpeg .jpg images only. Upload Rectangle images 4:3 Ratio Ex: 400 * 300</p>
												</div>
												<div class="col-lg-12">
													<div class="input-group">
														<input type="file" id="banner_image_file_329" accept="image/png,image/jpeg" name="banner_image" placeholder="Banner image" style="display:none" onchange="loadFile(this,'banner_image_329')">
														<div> <img src="https://apistream.ulademos.com/images/320x150.png" style="width:300px;height:150px;cursor: pointer" onclick="$('#banner_image_file_329').click();return false;" id="banner_image_329"> </div>
													</div>
													<!-- /input-group -->
												</div>
											</div>
											<br> </div>
										<div class="modal-footer">
											<div class="pull-right">
												<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
												<button type="submit" class="btn btn-primary" onclick="return confirm(&quot;Are you sure?&quot;);">Submit</button>
											</div>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
							</div>
							<div id="328" class="modal fade" role="dialog">
								<div class="modal-dialog">
									<form action="https://apistream.ulademos.com/admin/videos/ppv/add/328" method="POST"></form>
									<!-- Modal content-->
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal">×</button>
											<h4 class="modal-title text-uppercase">

										        		<b>PayPerView</b>

										        		
										        	</h4> </div>
										<div class="modal-body">
											<div class="row">
												<input type="hidden" name="ppv_created_by" id="ppv_created_by" value="Admin">
												<div class="col-lg-12">
													<label class="text-uppercase">Video</label>
												</div>
												<div class="col-lg-12">
													<p>My Lockdown Romance</p>
												</div>
												<div class="col-lg-12">
													<label class="text-uppercase">User Type *</label>
												</div>
												<div class="col-lg-12">
													<div class="input-group">
														<input type="radio" name="type_of_user" value="1" checked="">&nbsp;
														<label class="text-normal">Normal Users</label>&nbsp;
														<input type="radio" name="type_of_user" value="2">&nbsp;
														<label class="text-normal">Paid Users</label>&nbsp;
														<input type="radio" name="type_of_user" value="3">&nbsp;
														<label class="text-normal">Both Users</label>
													</div>
													<!-- /input-group -->
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-lg-12">
													<label class="text-uppercase">Subscription Type *</label>
												</div>
												<div class="col-lg-12">
													<div class="input-group">
														<input type="radio" name="type_of_subscription" value="1" checked="">&nbsp;
														<label class="text-normal">One Time Payment</label>&nbsp;
														<input type="radio" name="type_of_subscription" value="2">&nbsp;
														<label class="text-normal">Recurring Payment</label>
													</div>
													<!-- /input-group -->
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-lg-12">
													<label class="text-uppercase">Amount *</label>
												</div>
												<div class="col-lg-12">
													<input type="number" required="" value="0" name="amount" class="form-control" id="amount" placeholder="Amount" step="any"> </div>
											</div>
										</div>
										<div class="modal-footer">
											<div class="pull-left"> </div>
											<div class="pull-right">
												<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
												<button type="submit" class="btn btn-primary" onclick="return confirm(&quot;Are you sure?&quot;);">Submit</button>
											</div>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
							</div>
							<div id="banner_328" class="modal fade" role="dialog">
								<div class="modal-dialog">
									<form action="https://apistream.ulademos.com/admin/videos/banner/set?admin_video_id=328" method="POST" enctype="multipart/form-data"></form>
									<!-- Modal content-->
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal">×</button>
											<h4 class="modal-title">Set/Change Mobile Banner Video</h4> </div>
										<div class="modal-body">
											<div class="row">
												<div class="col-lg-12">
													<p class="text-blue text-uppercase"> Only one banner video you can set. When you updating this video as "Banner Video", the other banner videos will be update as normal video </p>
												</div>
												<div class="col-lg-12">
													<p>My Lockdown Romance</p>
												</div>
												<div class="col-lg-12">
													<label>Picture *</label>
													<p class="help-block">Please enter .png .jpeg .jpg images only. Upload Rectangle images 4:3 Ratio Ex: 400 * 300</p>
												</div>
												<div class="col-lg-12">
													<div class="input-group">
														<input type="file" id="banner_image_file_328" accept="image/png,image/jpeg" name="banner_image" placeholder="Banner image" style="display:none" onchange="loadFile(this,'banner_image_328')">
														<div> <img src="https://apistream.ulademos.com/images/320x150.png" style="width:300px;height:150px;cursor: pointer" onclick="$('#banner_image_file_328').click();return false;" id="banner_image_328"> </div>
													</div>
													<!-- /input-group -->
												</div>
											</div>
											<br> </div>
										<div class="modal-footer">
											<div class="pull-right">
												<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
												<button type="submit" class="btn btn-primary" onclick="return confirm(&quot;Are you sure?&quot;);">Submit</button>
											</div>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
							</div>
							<div id="327" class="modal fade" role="dialog">
								<div class="modal-dialog">
									<form action="https://apistream.ulademos.com/admin/videos/ppv/add/327" method="POST"></form>
									<!-- Modal content-->
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal">×</button>
											<h4 class="modal-title text-uppercase">

										        		<b>PayPerView</b>

										        		
										        	</h4> </div>
										<div class="modal-body">
											<div class="row">
												<input type="hidden" name="ppv_created_by" id="ppv_created_by" value="Admin">
												<div class="col-lg-12">
													<label class="text-uppercase">Video</label>
												</div>
												<div class="col-lg-12">
													<p>Love The Way U Lie</p>
												</div>
												<div class="col-lg-12">
													<label class="text-uppercase">User Type *</label>
												</div>
												<div class="col-lg-12">
													<div class="input-group">
														<input type="radio" name="type_of_user" value="1" checked="">&nbsp;
														<label class="text-normal">Normal Users</label>&nbsp;
														<input type="radio" name="type_of_user" value="2">&nbsp;
														<label class="text-normal">Paid Users</label>&nbsp;
														<input type="radio" name="type_of_user" value="3">&nbsp;
														<label class="text-normal">Both Users</label>
													</div>
													<!-- /input-group -->
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-lg-12">
													<label class="text-uppercase">Subscription Type *</label>
												</div>
												<div class="col-lg-12">
													<div class="input-group">
														<input type="radio" name="type_of_subscription" value="1" checked="">&nbsp;
														<label class="text-normal">One Time Payment</label>&nbsp;
														<input type="radio" name="type_of_subscription" value="2">&nbsp;
														<label class="text-normal">Recurring Payment</label>
													</div>
													<!-- /input-group -->
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-lg-12">
													<label class="text-uppercase">Amount *</label>
												</div>
												<div class="col-lg-12">
													<input type="number" required="" value="0" name="amount" class="form-control" id="amount" placeholder="Amount" step="any"> </div>
											</div>
										</div>
										<div class="modal-footer">
											<div class="pull-left"> </div>
											<div class="pull-right">
												<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
												<button type="submit" class="btn btn-primary" onclick="return confirm(&quot;Are you sure?&quot;);">Submit</button>
											</div>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
							</div>
							<div id="banner_327" class="modal fade" role="dialog">
								<div class="modal-dialog">
									<form action="https://apistream.ulademos.com/admin/videos/banner/set?admin_video_id=327" method="POST" enctype="multipart/form-data"></form>
									<!-- Modal content-->
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal">×</button>
											<h4 class="modal-title">Set/Change Mobile Banner Video</h4> </div>
										<div class="modal-body">
											<div class="row">
												<div class="col-lg-12">
													<p class="text-blue text-uppercase"> Only one banner video you can set. When you updating this video as "Banner Video", the other banner videos will be update as normal video </p>
												</div>
												<div class="col-lg-12">
													<p>Love The Way U Lie</p>
												</div>
												<div class="col-lg-12">
													<label>Picture *</label>
													<p class="help-block">Please enter .png .jpeg .jpg images only. Upload Rectangle images 4:3 Ratio Ex: 400 * 300</p>
												</div>
												<div class="col-lg-12">
													<div class="input-group">
														<input type="file" id="banner_image_file_327" accept="image/png,image/jpeg" name="banner_image" placeholder="Banner image" style="display:none" onchange="loadFile(this,'banner_image_327')">
														<div> <img src="https://apistream.ulademos.com/images/320x150.png" style="width:300px;height:150px;cursor: pointer" onclick="$('#banner_image_file_327').click();return false;" id="banner_image_327"> </div>
													</div>
													<!-- /input-group -->
												</div>
											</div>
											<br> </div>
										<div class="modal-footer">
											<div class="pull-right">
												<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
												<button type="submit" class="btn btn-primary" onclick="return confirm(&quot;Are you sure?&quot;);">Submit</button>
											</div>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
							</div>
							<div id="326" class="modal fade" role="dialog">
								<div class="modal-dialog">
									<form action="https://apistream.ulademos.com/admin/videos/ppv/add/326" method="POST"></form>
									<!-- Modal content-->
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal">×</button>
											<h4 class="modal-title text-uppercase">

										        		<b>PayPerView</b>

										        		
						                  					<span class="text-green"><i class="fa fa-check-circle"></i></span>

						                  				
										        	</h4> </div>
										<div class="modal-body">
											<div class="row">
												<input type="hidden" name="ppv_created_by" id="ppv_created_by" value="Admin">
												<div class="col-lg-12">
													<label class="text-uppercase">Video</label>
												</div>
												<div class="col-lg-12">
													<p>James &amp; Pat &amp; Dave</p>
												</div>
												<div class="col-lg-12">
													<label class="text-uppercase">User Type *</label>
												</div>
												<div class="col-lg-12">
													<div class="input-group">
														<input type="radio" name="type_of_user" value="1">&nbsp;
														<label class="text-normal">Normal Users</label>&nbsp;
														<input type="radio" name="type_of_user" value="2">&nbsp;
														<label class="text-normal">Paid Users</label>&nbsp;
														<input type="radio" name="type_of_user" value="3" checked="">&nbsp;
														<label class="text-normal">Both Users</label>
													</div>
													<!-- /input-group -->
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-lg-12">
													<label class="text-uppercase">Subscription Type *</label>
												</div>
												<div class="col-lg-12">
													<div class="input-group">
														<input type="radio" name="type_of_subscription" value="1" checked="">&nbsp;
														<label class="text-normal">One Time Payment</label>&nbsp;
														<input type="radio" name="type_of_subscription" value="2">&nbsp;
														<label class="text-normal">Recurring Payment</label>
													</div>
													<!-- /input-group -->
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-lg-12">
													<label class="text-uppercase">Amount *</label>
												</div>
												<div class="col-lg-12">
													<input type="number" required="" value="100" name="amount" class="form-control" id="amount" placeholder="Amount" step="any"> </div>
											</div>
										</div>
										<div class="modal-footer">
											<div class="pull-left"> <a class="btn btn-danger" href="" >

											       				Remove Pay Per View

											       			</a> </div>
											<div class="pull-right">
												<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
												<button type="submit" class="btn btn-primary" >Submit</button>
											</div>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
							</div>
							<div id="banner_326" class="modal fade" role="dialog">
								<div class="modal-dialog">
									<form action="" method="POST" enctype="multipart/form-data"></form>
									<!-- Modal content-->
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal">×</button>
											<h4 class="modal-title">Set/Change Mobile Banner Video</h4> </div>
										<div class="modal-body">
											<div class="row">
												<div class="col-lg-12">
													<p class="text-blue text-uppercase"> Only one banner video you can set. When you updating this video as "Banner Video", the other banner videos will be update as normal video </p>
												</div>
												<div class="col-lg-12">
													<p>James &amp; Pat &amp; Dave</p>
												</div>
												<div class="col-lg-12">
													<label>Picture *</label>
													<p class="help-block">Please enter .png .jpeg .jpg images only. Upload Rectangle images 4:3 Ratio Ex: 400 * 300</p>
												</div>
												<div class="col-lg-12">
													<div class="input-group">
														<input type="file" id="banner_image_file_326" accept="image/png,image/jpeg" name="banner_image" placeholder="Banner image" style="display:none" onchange="loadFile(this,'banner_image_326')">
														<div> <img src="https://apistream.ulademos.com/images/320x150.png" style="width:300px;height:150px;cursor: pointer" onclick="$('#banner_image_file_326').click();return false;" id="banner_image_326"> </div>
													</div>
													<!-- /input-group -->
												</div>
											</div>
											<br> </div>
										<div class="modal-footer">
											<div class="pull-right">
												<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
												<button type="submit" class="btn btn-primary" onclick="return confirm(&quot;Are you sure?&quot;);">Submit</button>
											</div>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
							</div>
							<div id="325" class="modal fade" role="dialog">
								<div class="modal-dialog">
									<form action="https://apistream.ulademos.com/admin/videos/ppv/add/325" method="POST"></form>
									<!-- Modal content-->
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal">×</button>
											<h4 class="modal-title text-uppercase">

										        		<b>PayPerView</b>

										        		
						                  					<span class="text-green"><i class="fa fa-check-circle"></i></span>

						                  				
										        	</h4> </div>
										<div class="modal-body">
											<div class="row">
												<input type="hidden" name="ppv_created_by" id="ppv_created_by" value="Admin">
												<div class="col-lg-12">
													<label class="text-uppercase">Video</label>
												</div>
												<div class="col-lg-12">
													<p>Block Z</p>
												</div>
												<div class="col-lg-12">
													<label class="text-uppercase">User Type *</label>
												</div>
												<div class="col-lg-12">
													<div class="input-group">
														<input type="radio" name="type_of_user" value="1" checked="">&nbsp;
														<label class="text-normal">Normal Users</label>&nbsp;
														<input type="radio" name="type_of_user" value="2">&nbsp;
														<label class="text-normal">Paid Users</label>&nbsp;
														<input type="radio" name="type_of_user" value="3">&nbsp;
														<label class="text-normal">Both Users</label>
													</div>
													<!-- /input-group -->
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-lg-12">
													<label class="text-uppercase">Subscription Type *</label>
												</div>
												<div class="col-lg-12">
													<div class="input-group">
														<input type="radio" name="type_of_subscription" value="1">&nbsp;
														<label class="text-normal">One Time Payment</label>&nbsp;
														<input type="radio" name="type_of_subscription" value="2" checked="">&nbsp;
														<label class="text-normal">Recurring Payment</label>
													</div>
													<!-- /input-group -->
												</div>
											</div>
											<br>
											<div class="row">
												<div class="col-lg-12">
													<label class="text-uppercase">Amount *</label>
												</div>
												<div class="col-lg-12">
													<input type="number" required="" value="100" name="amount" class="form-control" id="amount" placeholder="Amount" step="any"> </div>
											</div>
										</div>
										<div class="modal-footer">
											<div class="pull-left"> <a class="btn btn-danger" href="" >

											       				Remove Pay Per View

											       			</a> </div>
											<div class="pull-right">
												<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
												<button type="submit" class="btn btn-primary" >Submit</button>
											</div>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
							</div>
							
							<div id="datatable-withoutpagination_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
								<div class="row">
									<div class="col-sm-6"></div>
									<!-- <div class="col-sm-6">
										<div id="datatable-withoutpagination_filter" class="dataTables_filter">
											<label>Search:
												<input type="search" class="form-control input-sm" placeholder="" aria-controls="datatable-withoutpagination">
											</label>
										</div>
									</div> -->
								</div>
								<div class="row">
									<div class="col-sm-12">
										<table id="datatable-withoutpagination" class="table table-bordered table-striped dataTable no-footer" role="grid" aria-describedby="datatable-withoutpagination_info">
											<thead>
												<tr role="row">
													<th class="sorting_asc" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-sort="ascending" aria-label="ID: activate to sort column descending" style="width: 13px;">ID</th>
													<th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Action: activate to sort column ascending" style="width: 52px;">Action</th>
													<th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Status: activate to sort column ascending" style="width: 39px;">Status</th>
													<th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Title: activate to sort column ascending" style="width: 44px;">Title</th>
													<th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Revenue: activate to sort column ascending" style="width: 53px;">Revenue</th>
													<th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="PPV: activate to sort column ascending" style="width: 24px;">PPV</th>
													<th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Category: activate to sort column ascending" style="width: 56px;">Category</th>
													<th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Sub Category: activate to sort column ascending" style="width: 55px;">Sub Category</th>
													<th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Genre: activate to sort column ascending" style="width: 37px;">Genre</th>
													<th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Views: activate to sort column ascending" style="width: 36px;">Views</th>
													<th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Video Type: activate to sort column ascending" style="width: 35px;">Video Type</th>
													<th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Video Upload Type: activate to sort column ascending" style="width: 44px;">Video Upload Type</th>
													<th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Banner: activate to sort column ascending" style="width: 45px;">Banner</th>
													<th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Position: activate to sort column ascending" style="width: 51px;">Position</th>
													<th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Download: activate to sort column ascending" style="width: 62px;">Download</th>
													<th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Uploaded: activate to sort column ascending" style="width: 60px;">Uploaded</th>
												</tr>
											</thead>
											<tbody>
												<!-- PPV Modal Popup-->
												<!-- Modal -->
												<!-- PPV Modal Popup-->
												<!-- Modal -->
												<!-- PPV Modal Popup-->
												<!-- Modal -->
												<!-- PPV Modal Popup-->
												<!-- Modal -->
												<!-- PPV Modal Popup-->
												<!-- Modal -->
												<!-- PPV Modal Popup-->
												<!-- Modal -->
												<!-- PPV Modal Popup-->
												<!-- Modal -->
												<!-- PPV Modal Popup-->
												<!-- Modal -->
												<!-- PPV Modal Popup-->
												<!-- Modal -->
												<!-- PPV Modal Popup-->
												<!-- Modal -->
												<tr role="row" class="odd">
													<td class="sorting_1">1</td>
													<td>
														<ul class="admin-action btn btn-default">
															<li class="dropdown"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">
								                  Action <span class="caret"></span>
								                </a>
																<ul class="dropdown-menu dropdown-menu-left">
																	<li role="presentation"> <a role="menuitem" tabindex="-1" href=""><i class="fa fa-pencil"></i> Edit</a> </li>
																	<li role="presentation"><a role="menuitem" tabindex="-1" target="_blank" href=""><i class="fa fa-eye text-green"></i> View</a></li>
																
																	<li class="divider" role="presentation"></li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" data-toggle="modal" data-target="#banner_331"> <i class="fa fa-mobile text-green"></i> Banner Video </a>
																	</li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" href="" > <i class="fa fa-plus-circle text-green"></i> Add to originals </a>
																	</li>
																	<li class="divider" role="presentation"></li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" data-toggle="modal" data-target="#331"> <i class="fa fa-money text-green"></i> PayPerView </a>
																	</li>
																	<li class="divider" role="presentation"></li>
																	<li role="presentation"><a role="menuitem" tabindex="-1" href=""><i class="fa fa-ban text-red"></i> Decline</a></li>
																	<li role="presentation"> <a role="menuitem" tabindex="-1"  href=""><i class="fa fa-trash text-red"></i> Delete</a> </li>
																</ul>
															</li>
														</ul>
													</td>
													<td> <span class="label label-success">Approved</span> </td>
													<td> <a href="">Finding Agnes...</a> </td>
													<td> $0.00</td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td>Pinoy Movie </td>
													<td>For Family | Drama | Adventure</td>
													<td>-</td>
													<td>0</td>
													<td> Upload Video </td>
													<td> Streaming Upload </td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td> <span class="label label-warning">No</span> </td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td> admin </td>
												</tr>
												<tr role="row" class="even">
													<td class="sorting_1">2</td>
													<td>
														<ul class="admin-action btn btn-default">
															<li class="dropdown"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">
								                  Action <span class="caret"></span>
								                </a>
																<ul class="dropdown-menu dropdown-menu-left">
																	<li role="presentation"> <a role="menuitem" tabindex="-1" href=""><i class="fa fa-pencil"></i> Edit</a> </li>
																	<li role="presentation"><a role="menuitem" tabindex="-1" target="_blank" href=""><i class="fa fa-eye text-green"></i> View</a></li>
																	<!-- <li role="presentation"><a role="menuitem" href="https://apistream.ulademos.com/admin/gif/generation?video_id=330">Generate Gif Image</a></li> -->
																	<li class="divider" role="presentation"></li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" data-toggle="modal" data-target="#banner_330"> <i class="fa fa-mobile text-green"></i> Banner Video </a>
																	</li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" href=""> <i class="fa fa-plus-circle text-green"></i> Add to originals </a>
																	</li>
																	<li class="divider" role="presentation"></li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" data-toggle="modal" data-target="#330"> <i class="fa fa-money text-green"></i> PayPerView </a>
																	</li>
																	<li class="divider" role="presentation"></li>
																	<li role="presentation"><a role="menuitem" tabindex="-1" href=""><i class="fa fa-ban text-red"></i> Decline</a></li>
																	<li role="presentation"> <a role="menuitem" tabindex="-1"  href=""><i class="fa fa-trash text-red"></i> Delete</a> </li>
																</ul>
															</li>
														</ul>
													</td>
													<td> <span class="label label-success">Approved</span> </td>
													<td> <a href="">U Turn...</a> </td>
													<td> $0.00</td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td>Pinoy Movie </td>
													<td>Horror /Thriller</td>
													<td>-</td>
													<td>9</td>
													<td> Upload Video </td>
													<td> Streaming Upload </td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td> <span class="label label-warning">No</span> </td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td> admin </td>
												</tr>
												<tr role="row" class="odd">
													<td class="sorting_1">3</td>
													<td>
														<ul class="admin-action btn btn-default">
															<li class="dropdown"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">
								                  Action <span class="caret"></span>
								                </a>
																<ul class="dropdown-menu dropdown-menu-left">
																	<li role="presentation"> <a role="menuitem" tabindex="-1" href=""><i class="fa fa-pencil"></i> Edit</a> </li>
																	<li role="presentation"><a role="menuitem" tabindex="-1" target="_blank" href="https://apistream.ulademos.com/admin/videos/view?id=329"><i class="fa fa-eye text-green"></i> View</a></li>
																	<!-- <li role="presentation"><a role="menuitem" href="https://apistream.ulademos.com/admin/gif/generation?video_id=329">Generate Gif Image</a></li> -->
																	<li class="divider" role="presentation"></li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" data-toggle="modal" data-target="#banner_329"> <i class="fa fa-mobile text-green"></i> Banner Video </a>
																	</li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" href="https://apistream.ulademos.com/admin/videos/originals/status?admin_video_id=329" onclick="return confirm(&quot;Are you sure?&quot;)"> <i class="fa fa-plus-circle text-green"></i> Add to originals </a>
																	</li>
																	<li class="divider" role="presentation"></li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" data-toggle="modal" data-target="#329"> <i class="fa fa-money text-green"></i> PayPerView </a>
																	</li>
																	<li class="divider" role="presentation"></li>
																	<li role="presentation"><a role="menuitem" tabindex="-1" href="https://apistream.ulademos.com/admin/video/decline?admin_video_id=329"><i class="fa fa-ban text-red"></i> Decline</a></li>
																	<li role="presentation"> <a role="menuitem" tabindex="-1" onclick="return confirm('Are you sure want to delete video? Remaining video positions will Rearrange')" href="https://apistream.ulademos.com/admin/videos/delete?admin_video_id=329"><i class="fa fa-trash text-red"></i> Delete</a> </li>
																</ul>
															</li>
														</ul>
													</td>
													<td> <span class="label label-success">Approved</span> </td>
													<td> <a href="https://apistream.ulademos.com/admin/videos/view?id=329">I Love You Hater...</a> </td>
													<td> $0.00</td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td>Pinoy Movie </td>
													<td>Kilig Movie</td>
													<td>-</td>
													<td>0</td>
													<td> YouTube Link </td>
													<td> </td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td> <span class="label label-warning">No</span> </td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td> admin </td>
												</tr>
												<tr role="row" class="even">
													<td class="sorting_1">4</td>
													<td>
														<ul class="admin-action btn btn-default">
															<li class="dropdown"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">
								                  Action <span class="caret"></span>
								                </a>
																<ul class="dropdown-menu dropdown-menu-left">
																	<li role="presentation"> <a role="menuitem" tabindex="-1" href="https://apistream.ulademos.com/admin/videos/edit?admin_video_id=328"><i class="fa fa-pencil"></i> Edit</a> </li>
																	<li role="presentation"><a role="menuitem" tabindex="-1" target="_blank" href="https://apistream.ulademos.com/admin/videos/view?id=328"><i class="fa fa-eye text-green"></i> View</a></li>
																	<!-- <li role="presentation"><a role="menuitem" href="https://apistream.ulademos.com/admin/gif/generation?video_id=328">Generate Gif Image</a></li> -->
																	<li class="divider" role="presentation"></li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" data-toggle="modal" data-target="#banner_328"> <i class="fa fa-mobile text-green"></i> Banner Video </a>
																	</li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" href="https://apistream.ulademos.com/admin/videos/originals/status?admin_video_id=328" onclick="return confirm(&quot;Are you sure?&quot;)"> <i class="fa fa-plus-circle text-green"></i> Add to originals </a>
																	</li>
																	<li class="divider" role="presentation"></li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" data-toggle="modal" data-target="#328"> <i class="fa fa-money text-green"></i> PayPerView </a>
																	</li>
																	<li class="divider" role="presentation"></li>
																	<li role="presentation"><a role="menuitem" tabindex="-1" href="https://apistream.ulademos.com/admin/video/decline?admin_video_id=328"><i class="fa fa-ban text-red"></i> Decline</a></li>
																	<li role="presentation"> <a role="menuitem" tabindex="-1" onclick="return confirm('Are you sure want to delete video? Remaining video positions will Rearrange')" href="https://apistream.ulademos.com/admin/videos/delete?admin_video_id=328"><i class="fa fa-trash text-red"></i> Delete</a> </li>
																</ul>
															</li>
														</ul>
													</td>
													<td> <span class="label label-success">Approved</span> </td>
													<td> <a href="https://apistream.ulademos.com/admin/videos/view?id=328">My Lockdown Romance...</a> </td>
													<td> $0.00</td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td>Pinoy Movie </td>
													<td>Pinoy Movie </td>
													<td>-</td>
													<td>0</td>
													<td> Upload Video </td>
													<td> Streaming Upload </td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td> <span class="label label-warning">No</span> </td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td> admin </td>
												</tr>
												<tr role="row" class="odd">
													<td class="sorting_1">5</td>
													<td>
														<ul class="admin-action btn btn-default">
															<li class="dropdown"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">
								                  Action <span class="caret"></span>
								                </a>
																<ul class="dropdown-menu dropdown-menu-left">
																	<li role="presentation"> <a role="menuitem" tabindex="-1" href="https://apistream.ulademos.com/admin/videos/edit?admin_video_id=327"><i class="fa fa-pencil"></i> Edit</a> </li>
																	<li role="presentation"><a role="menuitem" tabindex="-1" target="_blank" href="https://apistream.ulademos.com/admin/videos/view?id=327"><i class="fa fa-eye text-green"></i> View</a></li>
																	<!-- <li role="presentation"><a role="menuitem" href="https://apistream.ulademos.com/admin/gif/generation?video_id=327">Generate Gif Image</a></li> -->
																	<li class="divider" role="presentation"></li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" data-toggle="modal" data-target="#banner_327"> <i class="fa fa-mobile text-green"></i> Banner Video </a>
																	</li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" href="https://apistream.ulademos.com/admin/videos/originals/status?admin_video_id=327" onclick="return confirm(&quot;Are you sure?&quot;)"> <i class="fa fa-plus-circle text-green"></i> Add to originals </a>
																	</li>
																	<li class="divider" role="presentation"></li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" data-toggle="modal" data-target="#327"> <i class="fa fa-money text-green"></i> PayPerView </a>
																	</li>
																	<li class="divider" role="presentation"></li>
																	<li role="presentation"><a role="menuitem" tabindex="-1" href="https://apistream.ulademos.com/admin/video/decline?admin_video_id=327"><i class="fa fa-ban text-red"></i> Decline</a></li>
																	<li role="presentation"> <a role="menuitem" tabindex="-1" onclick="return confirm('Are you sure want to delete video? Remaining video positions will Rearrange')" href="https://apistream.ulademos.com/admin/videos/delete?admin_video_id=327"><i class="fa fa-trash text-red"></i> Delete</a> </li>
																</ul>
															</li>
														</ul>
													</td>
													<td> <span class="label label-success">Approved</span> </td>
													<td> <a href="https://apistream.ulademos.com/admin/videos/view?id=327">Love The Way U Lie...</a> </td>
													<td> $0.00</td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td>Pinoy Movie </td>
													<td>For Family | Drama | Adventure</td>
													<td>-</td>
													<td>0</td>
													<td> Upload Video </td>
													<td> Streaming Upload </td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td> <span class="label label-warning">No</span> </td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td> admin </td>
												</tr>
												<tr role="row" class="even">
													<td class="sorting_1">6</td>
													<td>
														<ul class="admin-action btn btn-default">
															<li class="dropup"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">
								                  Action <span class="caret"></span>
								                </a>
																<ul class="dropdown-menu dropdown-menu-left">
																	<li role="presentation"> <a role="menuitem" tabindex="-1" href="https://apistream.ulademos.com/admin/videos/edit?admin_video_id=326"><i class="fa fa-pencil"></i> Edit</a> </li>
																	<li role="presentation"><a role="menuitem" tabindex="-1" target="_blank" href="https://apistream.ulademos.com/admin/videos/view?id=326"><i class="fa fa-eye text-green"></i> View</a></li>
																	<!-- <li role="presentation"><a role="menuitem" href="https://apistream.ulademos.com/admin/gif/generation?video_id=326">Generate Gif Image</a></li> -->
																	<li class="divider" role="presentation"></li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" data-toggle="modal" data-target="#banner_326"> <i class="fa fa-mobile text-green"></i> Banner Video </a>
																	</li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" href="https://apistream.ulademos.com/admin/videos/originals/status?admin_video_id=326" onclick="return confirm(&quot;Are you sure?&quot;)"> <i class="fa fa-plus-circle text-green"></i> Add to originals </a>
																	</li>
																	<li class="divider" role="presentation"></li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" data-toggle="modal" data-target="#326"> <i class="fa fa-money text-green"></i> PayPerView <span class="text-green pull-right"><i class="fa fa-check-circle"></i></span> </a>
																	</li>
																	<li class="divider" role="presentation"></li>
																	<li role="presentation"><a role="menuitem" tabindex="-1" href="https://apistream.ulademos.com/admin/video/decline?admin_video_id=326"><i class="fa fa-ban text-red"></i> Decline</a></li>
																	<li role="presentation"> <a role="menuitem" tabindex="-1" onclick="return confirm('Are you sure want to delete video? Remaining video positions will Rearrange')" href="https://apistream.ulademos.com/admin/videos/delete?admin_video_id=326"><i class="fa fa-trash text-red"></i> Delete</a> </li>
																</ul>
															</li>
														</ul>
													</td>
													<td> <span class="label label-success">Approved</span> </td>
													<td> <a href="https://apistream.ulademos.com/admin/videos/view?id=326">James &amp; Pat &amp; Dave...</a> </td>
													<td> $0.00</td>
													<td class="text-center"> <span class="label label-success">Yes</span> </td>
													<td>Pinoy Movie </td>
													<td>Kilig Movie</td>
													<td>-</td>
													<td>0</td>
													<td> Upload Video </td>
													<td> Streaming Upload </td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td> <span class="label label-warning">No</span> </td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td> admin </td>
												</tr>
												<tr role="row" class="odd">
													<td class="sorting_1">7</td>
													<td>
														<ul class="admin-action btn btn-default">
															<li class="dropup"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">
								                  Action <span class="caret"></span>
								                </a>
																<ul class="dropdown-menu dropdown-menu-left">
																	<li role="presentation"> <a role="menuitem" tabindex="-1" href="https://apistream.ulademos.com/admin/videos/edit?admin_video_id=325"><i class="fa fa-pencil"></i> Edit</a> </li>
																	<li role="presentation"><a role="menuitem" tabindex="-1" target="_blank" href="https://apistream.ulademos.com/admin/videos/view?id=325"><i class="fa fa-eye text-green"></i> View</a></li>
																	<!-- <li role="presentation"><a role="menuitem" href="https://apistream.ulademos.com/admin/gif/generation?video_id=325">Generate Gif Image</a></li> -->
																	<li class="divider" role="presentation"></li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" data-toggle="modal" data-target="#banner_325"> <i class="fa fa-mobile text-green"></i> Banner Video </a>
																	</li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" href="https://apistream.ulademos.com/admin/videos/originals/status?admin_video_id=325" onclick="return confirm(&quot;Are you sure?&quot;)"> <i class="fa fa-plus-circle text-green"></i> Add to originals </a>
																	</li>
																	<li class="divider" role="presentation"></li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" data-toggle="modal" data-target="#325"> <i class="fa fa-money text-green"></i> PayPerView <span class="text-green pull-right"><i class="fa fa-check-circle"></i></span> </a>
																	</li>
																	<li class="divider" role="presentation"></li>
																	<li role="presentation"><a role="menuitem" tabindex="-1" href="https://apistream.ulademos.com/admin/video/decline?admin_video_id=325"><i class="fa fa-ban text-red"></i> Decline</a></li>
																	<li role="presentation"> <a role="menuitem" tabindex="-1" onclick="return confirm('Are you sure want to delete video? Remaining video positions will Rearrange')" href="https://apistream.ulademos.com/admin/videos/delete?admin_video_id=325"><i class="fa fa-trash text-red"></i> Delete</a> </li>
																</ul>
															</li>
														</ul>
													</td>
													<td> <span class="label label-success">Approved</span> </td>
													<td> <a href="https://apistream.ulademos.com/admin/videos/view?id=325">Block Z...</a> </td>
													<td> $0.00</td>
													<td class="text-center"> <span class="label label-success">Yes</span> </td>
													<td>Pinoy Movie </td>
													<td>Horror /Thriller</td>
													<td>-</td>
													<td>0</td>
													<td> Upload Video </td>
													<td> Streaming Upload </td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td> <span class="label label-warning">No</span> </td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td> admin </td>
												</tr>
												<tr role="row" class="even">
													<td class="sorting_1">8</td>
													<td>
														<ul class="admin-action btn btn-default">
															<li class="dropup"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">
								                  Action <span class="caret"></span>
								                </a>
																<ul class="dropdown-menu dropdown-menu-left">
																	<li role="presentation"> <a role="menuitem" tabindex="-1" href="https://apistream.ulademos.com/admin/videos/edit?admin_video_id=324"><i class="fa fa-pencil"></i> Edit</a> </li>
																	<li role="presentation"><a role="menuitem" tabindex="-1" target="_blank" href="https://apistream.ulademos.com/admin/videos/view?id=324"><i class="fa fa-eye text-green"></i> View</a></li>
																	<!-- <li role="presentation"><a role="menuitem" href="https://apistream.ulademos.com/admin/gif/generation?video_id=324">Generate Gif Image</a></li> -->
																	<li class="divider" role="presentation"></li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" data-toggle="modal" data-target="#banner_324"> <i class="fa fa-mobile text-green"></i> Banner Video </a>
																	</li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" href="https://apistream.ulademos.com/admin/videos/originals/status?admin_video_id=324" onclick="return confirm(&quot;Are you sure?&quot;)"> <i class="fa fa-plus-circle text-green"></i> Add to originals </a>
																	</li>
																	<li class="divider" role="presentation"></li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" data-toggle="modal" data-target="#324"> <i class="fa fa-money text-green"></i> PayPerView </a>
																	</li>
																	<li class="divider" role="presentation"></li>
																	<li role="presentation"><a role="menuitem" tabindex="-1" href="https://apistream.ulademos.com/admin/video/decline?admin_video_id=324"><i class="fa fa-ban text-red"></i> Decline</a></li>
																	<li role="presentation"> <a role="menuitem" tabindex="-1" onclick="return confirm('Are you sure want to delete video? Remaining video positions will Rearrange')" href="https://apistream.ulademos.com/admin/videos/delete?admin_video_id=324"><i class="fa fa-trash text-red"></i> Delete</a> </li>
																</ul>
															</li>
														</ul>
													</td>
													<td> <span class="label label-success">Approved</span> </td>
													<td> <a href="https://apistream.ulademos.com/admin/videos/view?id=324">D'Ninang...</a> </td>
													<td> $0.00</td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td>Pinoy Movie </td>
													<td>For Family | Drama | Adventure</td>
													<td>-</td>
													<td>0</td>
													<td> Upload Video </td>
													<td> Streaming Upload </td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td> <span class="label label-warning">No</span> </td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td> admin </td>
												</tr>
												<tr role="row" class="odd">
													<td class="sorting_1">9</td>
													<td>
														<ul class="admin-action btn btn-default">
															<li class="dropup"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">
								                  Action <span class="caret"></span>
								                </a>
																<ul class="dropdown-menu dropdown-menu-left">
																	<li role="presentation"> <a role="menuitem" tabindex="-1" href="https://apistream.ulademos.com/admin/videos/edit?admin_video_id=323"><i class="fa fa-pencil"></i> Edit</a> </li>
																	<li role="presentation"><a role="menuitem" tabindex="-1" target="_blank" href="https://apistream.ulademos.com/admin/videos/view?id=323"><i class="fa fa-eye text-green"></i> View</a></li>
																	<!-- <li role="presentation"><a role="menuitem" href="https://apistream.ulademos.com/admin/gif/generation?video_id=323">Generate Gif Image</a></li> -->
																	<li class="divider" role="presentation"></li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" data-toggle="modal" data-target="#banner_323"> <i class="fa fa-mobile text-green"></i> Banner Video </a>
																	</li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" href="https://apistream.ulademos.com/admin/videos/originals/status?admin_video_id=323" onclick="return confirm(&quot;Are you sure?&quot;)"> <i class="fa fa-plus-circle text-green"></i> Add to originals </a>
																	</li>
																	<li class="divider" role="presentation"></li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" data-toggle="modal" data-target="#323"> <i class="fa fa-money text-green"></i> PayPerView </a>
																	</li>
																	<li class="divider" role="presentation"></li>
																	<li role="presentation"><a role="menuitem" tabindex="-1" href="https://apistream.ulademos.com/admin/video/decline?admin_video_id=323"><i class="fa fa-ban text-red"></i> Decline</a></li>
																	<li role="presentation"> <a role="menuitem" tabindex="-1" onclick="return confirm('Are you sure want to delete video? Remaining video positions will Rearrange')" href="https://apistream.ulademos.com/admin/videos/delete?admin_video_id=323"><i class="fa fa-trash text-red"></i> Delete</a> </li>
																</ul>
															</li>
														</ul>
													</td>
													<td> <span class="label label-success">Approved</span> </td>
													<td> <a href="https://apistream.ulademos.com/admin/videos/view?id=323">Jowable ...</a> </td>
													<td> $0.00</td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td>Pinoy Movie </td>
													<td>Hugot Movies</td>
													<td>-</td>
													<td>0</td>
													<td> Upload Video </td>
													<td> Streaming Upload </td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td> <span class="label label-warning">No</span> </td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td> admin </td>
												</tr>
												<tr role="row" class="even">
													<td class="sorting_1">10</td>
													<td>
														<ul class="admin-action btn btn-default">
															<li class="dropup"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">
								                  Action <span class="caret"></span>
								                </a>
																<ul class="dropdown-menu dropdown-menu-left">
																	<li role="presentation"> <a role="menuitem" tabindex="-1" href="https://apistream.ulademos.com/admin/videos/edit?admin_video_id=322"><i class="fa fa-pencil"></i> Edit</a> </li>
																	<li role="presentation"><a role="menuitem" tabindex="-1" target="_blank" href="https://apistream.ulademos.com/admin/videos/view?id=322"><i class="fa fa-eye text-green"></i> View</a></li>
																	<!-- <li role="presentation"><a role="menuitem" href="https://apistream.ulademos.com/admin/gif/generation?video_id=322">Generate Gif Image</a></li> -->
																	<li class="divider" role="presentation"></li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" data-toggle="modal" data-target="#banner_322"> <i class="fa fa-mobile text-green"></i> Banner Video </a>
																	</li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" href="https://apistream.ulademos.com/admin/videos/originals/status?admin_video_id=322" onclick="return confirm(&quot;Are you sure?&quot;)"> <i class="fa fa-minus-circle text-red"></i>Remove from Originals </a>
																	</li>
																	<li class="divider" role="presentation"></li>
																	<li role="presentation">
																		<a role="menuitem" tabindex="-1" data-toggle="modal" data-target="#322"> <i class="fa fa-money text-green"></i> PayPerView <span class="text-green pull-right"><i class="fa fa-check-circle"></i></span> </a>
																	</li>
																	<li class="divider" role="presentation"></li>
																	<li role="presentation"><a role="menuitem" tabindex="-1" href="https://apistream.ulademos.com/admin/video/decline?admin_video_id=322"><i class="fa fa-ban text-red"></i> Decline</a></li>
																	<li role="presentation"> <a role="menuitem" tabindex="-1" onclick="return confirm('Are you sure want to delete video? Remaining video positions will Rearrange')" href="https://apistream.ulademos.com/admin/videos/delete?admin_video_id=322"><i class="fa fa-trash text-red"></i> Delete</a> </li>
																</ul>
															</li>
														</ul>
													</td>
													<td> <span class="label label-success">Approved</span> </td>
													<td> <a href="https://apistream.ulademos.com/admin/videos/view?id=322">The Ice Cream...</a> </td>
													<td> $0.00</td>
													<td class="text-center"> <span class="label label-success">Yes</span> </td>
													<td>Photato And The Team Up</td>
													<td>Exclusive Content</td>
													<td>-</td>
													<td>0</td>
													<td> YouTube Link </td>
													<td> </td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td> <span class="label label-warning">No</span> </td>
													<td class="text-center"> <span class="label label-danger">No</span> </td>
													<td> admin </td>
												</tr>
											</tbody>
										</table>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-5">
										<div class="dataTables_info" id="datatable-withoutpagination_info" role="status" aria-live="polite"></div>
									</div>
									<div class="col-sm-7"></div>
								</div>
							</div>
							<div align="right" id="paglink">
								<ul class="pagination">
									<li class="disabled"><span>«</span></li>
									<li class="active"><span>1</span></li>
									<li><a href="https://apistream.ulademos.com/admin/videos?category_id=0&amp;sub_category_id=0&amp;genre_id=0&amp;moderator_id=0&amp;page=2">2</a></li>
									<li><a href="https://apistream.ulademos.com/admin/videos?category_id=0&amp;sub_category_id=0&amp;genre_id=0&amp;moderator_id=0&amp;page=3">3</a></li>
									<li><a href="https://apistream.ulademos.com/admin/videos?category_id=0&amp;sub_category_id=0&amp;genre_id=0&amp;moderator_id=0&amp;page=4">4</a></li>
									<li><a href="https://apistream.ulademos.com/admin/videos?category_id=0&amp;sub_category_id=0&amp;genre_id=0&amp;moderator_id=0&amp;page=5">5</a></li>
									<li><a href="https://apistream.ulademos.com/admin/videos?category_id=0&amp;sub_category_id=0&amp;genre_id=0&amp;moderator_id=0&amp;page=6">6</a></li>
									<li><a href="https://apistream.ulademos.com/admin/videos?category_id=0&amp;sub_category_id=0&amp;genre_id=0&amp;moderator_id=0&amp;page=7">7</a></li>
									<li><a href="https://apistream.ulademos.com/admin/videos?category_id=0&amp;sub_category_id=0&amp;genre_id=0&amp;moderator_id=0&amp;page=8">8</a></li>
									<li class="disabled"><span>...</span></li>
									<li><a href="https://apistream.ulademos.com/admin/videos?category_id=0&amp;sub_category_id=0&amp;genre_id=0&amp;moderator_id=0&amp;page=11">11</a></li>
									<li><a href="https://apistream.ulademos.com/admin/videos?category_id=0&amp;sub_category_id=0&amp;genre_id=0&amp;moderator_id=0&amp;page=12">12</a></li>
									<li><a href="https://apistream.ulademos.com/admin/videos?category_id=0&amp;sub_category_id=0&amp;genre_id=0&amp;moderator_id=0&amp;page=2" rel="next">»</a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<!-- include('layouts.admin.footer') -->
<!-- include('layouts.admin.left-side-bar') -->
</div>
<!-- jQuery 2.2.0 -->
<script src="https://apistream.ulademos.com/admin-css/plugins/jQuery/jQuery-2.2.0.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="https://apistream.ulademos.com/admin-css/bootstrap/js/bootstrap.min.js"></script>
<script src="https://apistream.ulademos.com/admin-css/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="https://apistream.ulademos.com/admin-css/plugins/datatables/dataTables.bootstrap.min.js"></script>
<!-- Select2 -->
<script src="https://apistream.ulademos.com/admin-css/plugins/select2/select2.full.min.js"></script>
<!-- InputMask -->
<script src="https://apistream.ulademos.com/admin-css/plugins/input-mask/jquery.inputmask.js"></script>
<script src="https://apistream.ulademos.com/admin-css/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<script src="https://apistream.ulademos.com/admin-css/plugins/input-mask/jquery.inputmask.extensions.js"></script>
<!-- SlimScroll -->
<script src="https://apistream.ulademos.com/admin-css/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="https://apistream.ulademos.com/admin-css/plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="https://apistream.ulademos.com/admin-css/dist/js/app.min.js"></script>
<!-- jvectormap -->
<script src="https://apistream.ulademos.com/admin-css/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="https://apistream.ulademos.com/admin-css/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<script src="https://apistream.ulademos.com/admin-css/plugins/chartjs/Chart.min.js"></script>
<!-- Datapicker -->
<script src="https://apistream.ulademos.com/admin-css/plugins/datepicker/bootstrap-datepicker.js"></script>
<script src="https://apistream.ulademos.com/admin-css/plugins/tokenize2-1.1-dist/tokenize2.min.js"></script>
<script src="https://apistream.ulademos.com/admin-css/plugins/iCheck/icheck.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<!-- <script src="https://apistream.ulademos.com/admin-css/dist/js/pages/dashboard2.js"></script> -->
<script src="https://apistream.ulademos.com/admin-css/dist/js/demo.js"></script>
<!-- page script -->
<script type="text/javascript">
function loadFile(event, id) {
	$('#' + id).show();
	var reader = new FileReader();
	reader.onload = function() {
		var output = document.getElementById(id);
		output.src = reader.result;
	};
	reader.readAsDataURL(event.files[0]);
}
$(document).ready(function() {
	$('#help-popover').popover({
		html: true,
		content: function() {
			return $('#help-content').html();
		}
	});
});
$(function() {
	$("#example1").DataTable();
	$("#datatable-withoutpagination").DataTable({
		"paging": false,
		"lengthChange": false,
		"language": {
			"info": ""
		}
	});
	$('#example2').DataTable({
		"paging": true,
		"lengthChange": false,
		"searching": false,
		"ordering": true,
		"info": true,
		"autoWidth": false
	});
});
</script>
<script type="text/javascript">
function loadFile(event, id) {
	// alert(event.files[0]);
	var reader = new FileReader();
	reader.onload = function() {
		var output = document.getElementById(id);
		// alert(output);
		output.src = reader.result;
		//$("#imagePreview").css("background-image", "url("+this.result+")");
	};
	reader.readAsDataURL(event.files[0]);
}
window.setTimeout(function() {
	$(".sidebar-toggle").click();
}, 1000);
</script>
<script type="text/javascript">
$("#videos").addClass("active");
$("#view-videos").addClass("active");
</script>
<script type="text/javascript">
$(document).ready(function() {
	$('#expiry_date').datepicker({
		autoclose: true,
		format: 'dd-mm-yyyy',
		startDate: 'today',
	});
});
</script>
<script type="text/javascript">
$(function() {
	//Initialize Select2 Elements
	$(".select2").select2();
	//Datemask dd/mm/yyyy
	$("#datemask").inputmask("dd:mm:yyyy", {
		"placeholder": "hh:mm:ss"
	});
	//Datemask2 mm/dd/yyyy
	// $("#datemask2").inputmask("hh:mm:ss", {"placeholder": "hh:mm:ss"});
	//Money Euro
	$("[data-mask]").inputmask();
	//iCheck for checkbox and radio inputs
	$('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
		checkboxClass: 'icheckbox_minimal-blue',
		radioClass: 'iradio_minimal-blue',
		increaseArea: '20%'
	});
	//Red color scheme for iCheck
	$('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
		checkboxClass: 'icheckbox_minimal-red',
		radioClass: 'iradio_minimal-red',
		increaseArea: '20%'
	});
	//Flat red color scheme for iCheck
	$('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
		checkboxClass: 'icheckbox_flat-green',
		radioClass: 'iradio_flat-green',
		increaseArea: '20%'
	});
	//Flat red color scheme for iCheck
	$('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
		checkboxClass: 'icheckbox_flat-green',
		radioClass: 'iradio_flat-green'
	});
});
</script>
</body>

</html>