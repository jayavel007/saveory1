<div class="content-wrapper" style="min-height: 1217px;">
	<section class="content-header">
		<h1>Cast &amp; Crews<small></small></h1>
		<ol class="breadcrumb">
			<li><a href=""><i class="fa fa-dashboard"></i>Home</a></li>
			<li class="active"><i class="fa fa-users"></i> Cast &amp; Crews</li>
		</ol>
	</section>
	<!-- Main content -->
	<section class="content">
		<div class="row">
			<div class="col-xs-12">
				<div class="box box-primary">
					<div class="box-header label-primary"> <b style="font-size:18px;">Cast &amp; Crews</b> <a href="" class="btn btn-default pull-right">Add Cast &amp; Crew</a> </div>
					<div class="box-body">
						<div id="datatable-withoutpagination_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
							<div class="row">
								<div class="col-sm-6"></div>
					
							</div>
							<div class="row">
								<div class="col-sm-12">
									<table id="datatable-withoutpagination" class="table table-bordered table-striped dataTable no-footer" role="grid" aria-describedby="datatable-withoutpagination_info">
										<thead>
											<tr role="row">
												<th class="sorting_asc" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-sort="ascending" aria-label="ID: activate to sort column descending" style="width: 84px;">ID</th>
												<th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Name: activate to sort column ascending" style="width: 323px;">Name</th>
												<th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Image: activate to sort column ascending" style="width: 143px;">Image</th>
												<th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Status: activate to sort column ascending" style="width: 144px;">Status</th>
												<th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Action: activate to sort column ascending" style="width: 174px;">Action</th>
											</tr>
										</thead>
										<tbody id="appendGrid">
											<tr role="row" class="odd">
												<td class="sorting_1">1</td>
												<td><a href=""> Kim Chiu</a></td>
												<td> <img style="height: 30px;" src="SV-2021-11-16-08-03-38-60f95b1c1264a99af7a7a5b2a6a8b25babc57e9b.jpg"> </td>
												<td> <span class="label label-success">Approve</span> </td>
												<td>
													<ul class="admin-action btn btn-default">
														<li class="dropup"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">
								                  Action <span class="caret"></span>
								                </a>
															<ul class="dropdown-menu dropdown-menu-right">
																<li role="presentation"><a role="menuitem" tabindex="-1" href="">View</a></li>
																<li role="presentation"><a role="menuitem" tabindex="-1" href="">Edit</a></li>
																<li role="presentation"><a role="menuitem" tabindex="-1"  href="">Delete</a></li>
																<li role="presentation" class="divider"></li>
																<li role="presentation"> <a class="menuitem" tabindex="-1" href="" >Decline</a> </li>
															</ul>
														</li>
													</ul>
												</td>
											</tr>
										</tbody>
									</table>
								</div>
							</div>
							<div class="row">
								<div class="col-sm-5">
									<div class="dataTables_info" id="datatable-withoutpagination_info" role="status" aria-live="polite"></div>
								</div>
								<div class="col-sm-7"></div>
							</div>
						</div>
					
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<!-- include('layouts.admin.footer') -->
<!-- include('layouts.admin.left-side-bar') -->
</div>
<!-- jQuery 2.2.0 -->

    <!-- jQuery 2.2.0 -->
    <script src="admin-css/plugins/jQuery/jQuery-2.2.0.min.js"></script>
    <!-- Bootstrap 3.3.6 -->
    <script src="admin-css/bootstrap/js/bootstrap.min.js"></script>

    <script src="admin-css/plugins/datatables/jquery.dataTables.min.js"></script>

    <script src="admin-css/plugins/datatables/dataTables.bootstrap.min.js"></script>

    <!-- Select2 -->
    <script src="plugins/select2/select2.full.min.js"></script>
    <!-- InputMask -->
    <script src="admin-css/plugins/input-mask/jquery.inputmask.js"></script>
    <script src="admin-css/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>

    <script src="admin-css/plugins/input-mask/jquery.inputmask.extensions.js"></script>

    <!-- SlimScroll -->
    <script src="admin-css/plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="admin-css/plugins/fastclick/fastclick.js"></script>
    <!-- AdminLTE App -->
    <script src="admin-css/dist/js/app.min.js"></script>

    <!-- jvectormap -->
    <script src="admin-css/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>

    <script src="admin-css/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>

    <script src="admin-css/plugins/chartjs/Chart.min.js"></script>

    <!-- Datapicker -->
    <script src="admin-css/plugins/datepicker/bootstrap-datepicker.js"></script> 

    <script src="admin-css/plugins/tokenize2-1.1-dist/tokenize2.min.js"></script>

    <script src="admin-css/plugins/iCheck/icheck.min.js"></script>

    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <!-- <script src="https://apistream.ulademos.com/admin-css/dist/js/pages/dashboard2.js"></script> -->

    <script src="admin-css/dist/js/demo.js"></script>

<!-- page script -->
<script type="text/javascript">

$(document).ready(function(){


$('#pagination').on('click','a',function(e){

  e.preventDefault(); 

  var pageno = $(this).attr('data-ci-pagination-page');

  loadPagination(pageno);

});



loadPagination(0);



function loadPagination(pagno){
	
	// var page = $('#pagename').val();

  $.ajax({

	url: '<?php echo base_url(); ?>Cast_crew/loadCrewList/'+pagno,

	type: 'post',

	// data:{page:page},

	dataType: 'json',

	success: function(response){
		console.log(response);

	   $('#pagination').html(response.pagination);

	   createTable(response.result,response.row);

	}

  });

}



function createTable(result,sno){

  sno = Number(sno);

  $('#appendGrid').empty();

  for(index in result){
	   var cast_crew_id = result[index].cast_crew_id;
	   var cc_name = result[index].cc_name;
	   var cc_image = result[index].cc_image;
	   var cc_description = result[index].cc_description;
	   var status = result[index].status;

	   var sno =1;
  	   var tr= '<tr role="row" class="odd"><td class="sorting_1">'+ sno++ +'</td><td><a href="">'+cc_name+'</a></td><td><img style="height: 50px; width:50px" src="'+cc_image+'"> </td><td> <span class="label label-success">Approve</span> </td><td><ul class="admin-action btn btn-default"><li class="dropup"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">Action <span class="caret"></span></a><ul class="dropdown-menu dropdown-menu-right"><li role="presentation"><a role="menuitem" tabindex="-1" href="">View</a></li><li role="presentation"><a role="menuitem" tabindex="-1" href="">Edit</a></li><li role="presentation"><a role="menuitem" tabindex="-1"  href="">Delete</a></li><li role="presentation" class="divider"></li><li role="presentation"> <a class="menuitem" tabindex="-1" href="" >Decline</a> </li></ul></li></ul></td></tr>';

	 $('#appendGrid').append(tr);



   }

 }

  

});


</script>
<script type="text/javascript">
$("#cast-crews").addClass("active");
$("#cast-crew-index").addClass("active");
</script>


</body>

</html>