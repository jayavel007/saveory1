 <div class="content-wrapper" style="min-height: 1217px;">
            <section class="content-header">
                <h1>Moderators<small></small></h1>
                <ol class="breadcrumb">
                    <li><a href=""><i class="fa fa-dashboard"></i>Home</a></li>
                    <li class="active"><i class="fa fa-users"></i> Moderators</li>
                </ol>
            </section>
            <!-- Main content -->
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="box box-primary">
                            <div class="box-header label-primary"> <b style="font-size:18px;">Moderators</b> <a href="" class="btn btn-default pull-right">Add Moderator</a>
                                <!-- EXPORT OPTION START -->
                                <ul class="admin-action btn btn-default pull-right" style="margin-right: 20px">
                                    <li class="dropdown"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                  Export <span class="caret"></span>
                                </a>
                                        <ul class="dropdown-menu">
                                            <li role="presentation">
                                                <a role="menuitem" tabindex="-1" href=""> <span class="text-red"><b>Excel Sheet</b></span> </a>
                                            </li>
                                            <li role="presentation">
                                                <a role="menuitem" tabindex="-1" href=""> <span class="text-blue"><b>CSV</b></span> </a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                                <!-- EXPORT OPTION END -->
                            </div>
                            <div class="box-body">
                                <div id="datatable-withoutpagination_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-6"></div>
                                     <!--    <div class="col-sm-6">
                                            <div id="datatable-withoutpagination_filter" class="dataTables_filter">
                                                <label>Search:
                                                    <input type="search" class="form-control input-sm" placeholder="" aria-controls="datatable-withoutpagination">
                                                </label>
                                            </div>
                                        </div> -->
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="datatable-withoutpagination" class="table table-bordered table-striped dataTable no-footer" role="grid" aria-describedby="datatable-withoutpagination_info">
                                                <thead>
                                                    <tr role="row">
                                                        <th class="sorting_asc" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-sort="ascending" aria-label="ID: activate to sort column descending" style="width: 21px;">ID</th>
                                                        <th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Username: activate to sort column ascending" style="width: 96px;">Username</th>
                                                        <th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Email: activate to sort column ascending" style="width: 194px;">Email</th>
                                                        <th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Mobile: activate to sort column ascending" style="width: 85px;">Mobile</th>
                                                        <th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Address: activate to sort column ascending" style="width: 62px;">Address</th>
                                                        <th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Total Videos: activate to sort column ascending" style="width: 92px;">Total Videos</th>
                                                        <th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Total: activate to sort column ascending" style="width: 41px;">Total</th>
                                                        <th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Status: activate to sort column ascending" style="width: 51px;">Status</th>
                                                        <th class="sorting" tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Action: activate to sort column ascending" style="width: 66px;">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr role="row" class="odd">
                                                        <td class="sorting_1">1</td>
                                                        <td><a href="">moderator</a></td>
                                                        <td>moderator@ulastream.com</td>
                                                        <td>9876543121</td>
                                                        <td></td>
                                                        <td><a href="">1</a></td>
                                                        <td>$0.00</td>
                                                        <td> <span class="label label-success">Approved</span> </td>
                                                        <td>
                                                            <ul class="admin-action btn btn-default">
                                                                <li class="dropup"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                                      Action <span class="caret"></span>
                                                    </a>
                                                                    <ul class="dropdown-menu dropdown-menu-right">
                                                                        <li role="presentation"><a role="menuitem" tabindex="-1" href="">View</a></li>
                                                                        <li role="presentation"><a role="menuitem" tabindex="-1" href="">Edit</a></li>
                                                                        <li role="presentation"> <a role="menuitem" tabindex="-1" onclick="return confirm(&quot;Once you've deleted this account, the moderator (moderator) will no longer be able to log in to the site or apps. This action cannot be undone.&quot;);" href="">Delete</a> </li>
                                                                        <li role="presentation" class="divider"></li>
                                                                        <li role="presentation"><a role="menuitem" tabindex="-1" href="">Decline</a></li>
                                                                        <li role="presentation" class="divider"></li>
                                                                        <li role="presentation"><a role="menuitem" tabindex="-1" href="">Redeems</a></li>
                                                                        <li> </li>
                                                                        <li role="presentation"> <a role="menuitem" tabindex="-1" href="">Videos</a> </li>
                                                                    </ul>
                                                                </li>
                                                            </ul>
                                                        </td>
                                                    </tr>
                                                    <tr role="row" class="even">
                                                        <td class="sorting_1">2</td>
                                                        <td><a href="">jazyam</a></td>
                                                        <td>rdualan800@gmail.com</td>
                                                        <td>02928292929</td>
                                                        <td></td>
                                                        <td><a href="">1</a></td>
                                                        <td>$0.00</td>
                                                        <td> <span class="label label-success">Approved</span> </td>
                                                        <td>
                                                            <ul class="admin-action btn btn-default">
                                                                <li class="dropup"> <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                                      Action <span class="caret"></span>
                                                    </a>
                                                                    <ul class="dropdown-menu dropdown-menu-right">
                                                                        <li role="presentation"><a role="menuitem" tabindex="-1" href="">View</a></li>
                                                                        <li role="presentation"><a role="menuitem" tabindex="-1" href="">Edit</a></li>
                                                                        <li role="presentation"> <a role="menuitem" tabindex="-1"  href="">Delete</a> </li>
                                                                        <li role="presentation" class="divider"></li>
                                                                        <li role="presentation"><a role="menuitem" tabindex="-1"  href="">Decline</a></li>
                                                                        <li role="presentation" class="divider"></li>
                                                                        <li role="presentation"><a role="menuitem" tabindex="-1" href="">Redeems</a></li>
                                                                        <li> </li>
                                                                        <li role="presentation"> <a role="menuitem" tabindex="-1" href="">Videos</a> </li>
                                                                    </ul>
                                                                </li>
                                                            </ul>
                                                        </td>
                                                    </tr>
                                                   
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-5">
                                            <div class="dataTables_info" id="datatable-withoutpagination_info" role="status" aria-live="polite"></div>
                                        </div>
                                        <div class="col-sm-7"></div>
                                    </div>
                                </div>
                                <div align="right" id="paglink"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <!-- include('layouts.admin.footer') -->
        <!-- include('layouts.admin.left-side-bar') -->
    </div>
    <!-- jQuery 2.2.0 -->
   
    <!-- jQuery 2.2.0 -->
    <script src="admin-css/plugins/jQuery/jQuery-2.2.0.min.js"></script>
    <!-- Bootstrap 3.3.6 -->
    <script src="admin-css/bootstrap/js/bootstrap.min.js"></script>

    <script src="admin-css/plugins/datatables/jquery.dataTables.min.js"></script>

    <script src="admin-css/plugins/datatables/dataTables.bootstrap.min.js"></script>

    <!-- Select2 -->
    <script src="plugins/select2/select2.full.min.js"></script>
    <!-- InputMask -->
    <script src="admin-css/plugins/input-mask/jquery.inputmask.js"></script>
    <script src="admin-css/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>

    <script src="admin-css/plugins/input-mask/jquery.inputmask.extensions.js"></script>

    <!-- SlimScroll -->
    <script src="admin-css/plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="admin-css/plugins/fastclick/fastclick.js"></script>
    <!-- AdminLTE App -->
    <script src="admin-css/dist/js/app.min.js"></script>

    <!-- jvectormap -->
    <script src="admin-css/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>

    <script src="admin-css/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>

    <script src="admin-css/plugins/chartjs/Chart.min.js"></script>

    <!-- Datapicker -->
    <script src="admin-css/plugins/datepicker/bootstrap-datepicker.js"></script> 

    <script src="admin-css/plugins/tokenize2-1.1-dist/tokenize2.min.js"></script>

    <script src="admin-css/plugins/iCheck/icheck.min.js"></script>

    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <!-- <script src="https://apistream.ulademos.com/admin-css/dist/js/pages/dashboard2.js"></script> -->

    <script src="admin-css/dist/js/demo.js"></script>

    <!-- page script -->
    <script type="text/javascript">
    function loadFile(event, id) {
        $('#' + id).show();
        var reader = new FileReader();
        reader.onload = function() {
            var output = document.getElementById(id);
            output.src = reader.result;
        };
        reader.readAsDataURL(event.files[0]);
    }
    $(document).ready(function() {
        $('#help-popover').popover({
            html: true,
            content: function() {
                return $('#help-content').html();
            }
        });
    });
    $(function() {
        $("#example1").DataTable();
        $("#datatable-withoutpagination").DataTable({
            "paging": false,
            "lengthChange": false,
            "language": {
                "info": ""
            }
        });
        $('#example2').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false
        });
    });
    </script>
    <script type="text/javascript">
    $("#moderators").addClass("active");
    $("#moderators-view").addClass("active");
    </script>
    <script type="text/javascript">
    $(document).ready(function() {
        $('#expiry_date').datepicker({
            autoclose: true,
            format: 'dd-mm-yyyy',
            startDate: 'today',
        });
    });
    </script>
    <script type="text/javascript">
    $(function() {
        //Initialize Select2 Elements
        $(".select2").select2();
        //Datemask dd/mm/yyyy
        $("#datemask").inputmask("dd:mm:yyyy", {
            "placeholder": "hh:mm:ss"
        });
        //Datemask2 mm/dd/yyyy
        // $("#datemask2").inputmask("hh:mm:ss", {"placeholder": "hh:mm:ss"});
        //Money Euro
        $("[data-mask]").inputmask();
        //iCheck for checkbox and radio inputs
        $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
            checkboxClass: 'icheckbox_minimal-blue',
            radioClass: 'iradio_minimal-blue',
            increaseArea: '20%'
        });
        //Red color scheme for iCheck
        $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
            checkboxClass: 'icheckbox_minimal-red',
            radioClass: 'iradio_minimal-red',
            increaseArea: '20%'
        });
        //Flat red color scheme for iCheck
        $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
            checkboxClass: 'icheckbox_flat-green',
            radioClass: 'iradio_flat-green',
            increaseArea: '20%'
        });
        //Flat red color scheme for iCheck
        $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
            checkboxClass: 'icheckbox_flat-green',
            radioClass: 'iradio_flat-green'
        });
    });
    </script>
</body>

</html>