
        
        <div class="content-wrapper" style="min-height: 1157px;">

            <section class="content-header">
                <h1>Mail Camp<small></small></h1>
                <ol class="breadcrumb"></ol>
            </section>

            <!-- Main content -->
            <section class="content">
                
                
                
    <div class="row">

        <div class="col-md-10">

            <div class="box box-primary">

                <div class="box-header label-primary">
                    <b style="font-size:18px;">New Message</b>
                </div>

                <form class="form-horizontal" action="admin/email/form/action" method="POST" enctype="multipart/form-data" role="form">

                    <div class="box-body">

                        <div class="form-group">
                            <label for="from" class="col-sm-2 control-label">* To</label>

                            <div class="col-sm-6">
                                <!-- Users -->
                            	<label for="users">	
                                <input type="radio" name="to" id="users" value="0">&nbsp;Users</label>


                                <!-- Moderators-->
                                <label for="moderators">
                                <input type="radio" name="to" id="moderators" value="1">&nbsp;Moderators </label>

                                <label for="custom_users">
                                <input type="radio" name="to" id="custom_user" value="2"> &nbsp; Custom Users
                                </label>
                                <br><br>
                                <!-- Users -->
                            	<div id="preview" style="display: none">

                                	<input type="radio" name="users_type" id="users_list" value="ALL_USER"> &nbsp;<label for="all_user">All Users</label>

                                	<input type="radio" name="users_type" id="users_list1" value="NORMAL_USERS"> &nbsp;<label for="normal_user">Normal Users</label>

                                	<input type="radio" name="users_type" id="users_list2" value="PAID_USERS">&nbsp;<label for="paid_user">Paid Users</label>

                                	<input type="radio" name="users_type" value="SELECT_USERS" id="select_user">&nbsp;<label for="select_user">Select Users</label>
                                </div>
                            
                                <!-- Moderators-->
                            	<div id="mod_preview" style="display: none">

                                	<input type="radio" name="users_type" id="moderators_list" value="ALL_MODERATOR"><label for="all_moderators">All Moderators</label>
                                       
                                	<input type="radio" name="users_type" value="SELECT_MODERATOR" id="select_mod"><label for="select_moderators">
                                    Select Moderators</label>

                                </div>
                        	</div>
                            <!-- User -->
                                                        <div class="col-md-10 pull-right" id="select" style="display: none">
                                <label for="custom_user" class="control-label"><p class="help-block">Note : Select User List</p></label>

                                <select style="display: none" id="multi-select-user" name="select_user[]" class="form-control" multiple="">

                                                                        <option value="1">user@ulastream.com</option>
                                                                        <option value="2">test@ulastream.com</option>
                                                                        <option value="3">android@mailinator.com</option>
                                                                        <option value="4">maninr28@gmail.com</option>
                                                                        <option value="5">test3@ulastream.com</option>
                                                                        <option value="6">anu@demo.com</option>
                                                                        <option value="7">anu@test.com</option>
                                                                        <option value="8">anusuya@demo.com</option>
                                                                        <option value="9">anuaadhi1997@gmail.com</option>
                                                                        <option value="10">anuaadhi@demo.com</option>
                                                                        <option value="11">demo@test.com</option>
                                                                        <option value="12">sample@demo.com</option>
                                                                        <option value="13">dev@tranxit.co</option>
                                                                        <option value="14">fad2krpejd@privaterelay.appleid.com</option>
                                                                        <option value="15">madhanakumar.g@tranxitgroup.com</option>
                                                                        <option value="16">testandroid@mailinator.com</option>
                                                                        <option value="17">ZXSIVQE3ZG7FZNCGVKY5U7KAMU-00@cloudtestlabaccounts.com</option>
                                                                        <option value="18">pkc6cphdt7@privaterelay.appleid.com</option>
                                                                        <option value="19">playstorecnx17@gmail.com</option>
                                                                        <option value="20">nemo@demo.com</option>
                                                                        <option value="21">qaappooets1@gmail.com</option>
                                                                        <option value="22">king@demo.com</option>
                                                                        <option value="24">a@demo.com</option>
                                                                        <option value="26">mahesh.n483@gmail.com</option>
                                                                        <option value="27">ayaztasarim@hotmail.com</option>
                                                                        <option value="28">photographerdibyenduchowdhury@gmail.com</option>
                                                                        <option value="29">srjn0301@gmail.com</option>
                                                                        <option value="30">tofailshaheen@gmail.com</option>
                                                                        <option value="31">jhonataferreirasilva@gmail.com</option>
                                                                        <option value="33">geyaf26233@brayy.com</option>
                                                                        <option value="35">maunilgajjar@gmail.com</option>
                                                                        <option value="37">vudinhphu933@gmail.com</option>
                                                                        <option value="38">ankitkumar.ak770@gmail.com</option>
                                                                        <option value="40">admin@ulastream.com</option>
                                                                        <option value="41">mariasalavaria123@gmail.com</option>
                                                                        <option value="42">rdualan800@gmail.com</option>
                                                                        <option value="43">ramsemtupaz@gmail.com</option>
                                                                        <option value="44">hjsisksbhsjj@gmail.com</option>
                                                                        <option value="45">marinettedualan26@gmail.com</option>
                                                                        <option value="46">angeldel.dualan@gmail.com</option>
                                                                        <option value="47">sumactonhanjin@gmail.com</option>
                                                                        <option value="48">guddidurre@gmail.com</option>
                                                                        <option value="49">popo@test.test</option>
                                                                        <option value="50">maker12@gmail.com</option>
                                                                        <option value="51">impactzoom@gmail.com</option>
                                                                        <option value="52">akshay@gmail.com</option>
                                                                        <option value="53">Car12@hotmail.com</option>
                                                                        <option value="54">barajosueka15+1@gmail.com</option>
                                                                        <option value="55">ysjdjdbdnd@gmail.com</option>
                                                                        <option value="56">jajehrjei@gmail.com</option>
                                                                        <option value="57">gsjdjdndndj@gmail.com</option>
                                                                        <option value="58">hdkdkdnrhe@gmail.com</option>
                                                                        <option value="59">02928292929@gmail.com</option>
                                                                        <option value="60">hdkdkdnrghe@gmail.com</option>
                                                                        <option value="61">hshsjdjjddj@gmail.com</option>
                                                                        <option value="62">hsjsjejeej@gmail.com</option>
                                                                        <option value="63">jsksjrbrj@gmail.com</option>
                                                                        <option value="64">02928292hsjsjd929@gmail.com</option>
                                                                        <option value="65">yejejebeue@gmail.com</option>
                                                                        <option value="66">yejejejek@gmail.com</option>
                                                                        <option value="67">hdjdjene@gmail.com</option>
                                                                        <option value="68">usidjdj@gmail.com</option>
                                                                        <option value="69">hsksjdbdh@gmail.com</option>
                                                                        <option value="70">hsjsbshs@gmail.com</option>
                                                                        <option value="71">jdkdkdndi@gmail.com</option>
                                                                        <option value="72">hdjdkdkd@gmail.com</option>
                                                                        <option value="73">hdkdkrnrjll@gmail.com</option>
                                                                        <option value="74">maria12@gmail.com</option>
                                                                        <option value="75">jdjdjsjsj@gmail.com</option>
                                                                        <option value="76">hejdjeje@gmail.com</option>
                                                                        <option value="77">029282929298@gmail.com</option>
                                                                        <option value="78">gsjdjdj@gmail.com</option>
                                                                        <option value="79">hsjdje@gmail.com</option>
                                                                        <option value="80">sghdhd@gmail.com</option>
                                                                        <option value="81">hsjdjej@gmail.com</option>
                                                                        <option value="82">gdhdjd@gmail.com</option>
                                                                        <option value="83">02928292929hj@gmail.com</option>
                                                                        <option value="84">02928292929@gmqil.com</option>
                                                                        <option value="85">hsjdkkffj@gmail.com</option>
                                                                        <option value="86">02928292929hsj@gmail.com</option>
                                                                        <option value="87">029282929hshdjd29@gmail.com</option>
                                                                        <option value="88">029282929g29@gmail.com</option>
                                                                        <option value="89">02928292929ysjdj@gmail.com</option>
                                                                        <option value="90">02928292929tsusj@gmail.com</option>
                                                                        <option value="91">02928292929sa@gmail.com</option>
                                                                        <option value="92">02928292929gwjsj@gmail.com</option>
                                                                        <option value="93">02928292929fa@gmail.com</option>
                                                                        <option value="94">02928292929ywhs@gmail.com</option>
                                                                        <option value="95">02928292929twhs@gmail.ccom</option>
                                                                        <option value="96">02928292ghs929@hmail.com</option>
                                                                        <option value="97">02928292929hejdj@hn.com</option>
                                                                        <option value="98">02928292929fs@gmail.com</option>
                                                                        <option value="99">02928292929gwhsj@gmail.com</option>
                                                                        <option value="100">02928292929fshs@hmil.com</option>
                                                                        <option value="101">02928292929gw@gmail.com</option>
                                                                        <option value="102">yshdjd@gmail.com</option>
                                                                        <option value="103">02928292929vshsj@gmwo.com</option>
                                                                        <option value="104">02928292929fsgsus@mil.com</option>
                                                                        <option value="105">02928292929ga@gmail.com</option>
                                                                        <option value="106">02928292929gs@gmail.cok</option>
                                                                        <option value="107">02928292929cshs@gmail.com</option>
                                                                        <option value="108">7stocks@gmail.com</option>
                                                                        <option value="109">creatives@teckzy.com</option>
                                                                        <option value="110">jundi2391@gmail.com</option>
                                                                        <option value="111">vjkklkbghiobb@gmail.com</option>
                                                                        <option value="112">mahmoodabbas521@gmail.com</option>
                                                                        <option value="113">dualan.madilyn@gmail.com</option>
                                                                        <option value="114">omnifla@ulastream.com</option>
                                                                        <option value="116">hskdkdjdb@gmail.com</option>
                                                                        <option value="117">hskdkdjdgsjdb@gmail.com</option>
                                                                        <option value="118">hskdkdjqdgsjdb@gmail.com</option>
                                                                        <option value="119">hermonesealjohn@gmail.com</option>
                                                                        <option value="120">nikabillz60.com@gmail.com</option>
                                                                        <option value="121">hdkdjddbfbbdjxkxk@gmail.com</option>
                                                                        <option value="122">asdf@asdf.com.br</option>
                                                                        <option value="123">saan@demo.com</option>
                                                                        <option value="124">mathi@demo.com</option>
                                                                        <option value="125">lubagminaynicamae@gmail.com</option>
                                                                        <option value="126">hdjdkdfnhzjjddjfbc@gmail.com</option>
                                                                        <option value="127">desireebuhain87@gmail.com</option>
                                                                        <option value="128">sm@user.com</option>
                                                                    </select><div class="tokenize" id="97201384-bb13-db79-5318-786b718d2ad2"><ul class="tokens-container form-control" tabindex="0"><li class="token-search" style="width: 17px;"><input autocomplete="off"></li></ul></div>
                            </div>
                            
                            <!-- Moderator -->
                                                       
                            <div class="col-md-10 pull-right" id="select_moderator" style="display: none">

                                <label for="custom_user" class="control-label"><p class="help-block">Note : Select Moderator List</p></label>
                                <select style="display: none" id="multi-select-moderator" name="select_moderator[]" class="form-control" multiple="">
                                                                        <option value="6">sumactonhanjin@gmail.com</option>
                                                                        <option value="7">angeldel.dualan@gmail.com</option>
                                                                        <option value="8">marinettedualan26@gmail.com</option>
                                                                        <option value="9">hjsisksbhsjj@gmail.com</option>
                                                                        <option value="10">ramsemtupaz@gmail.com</option>
                                                                        <option value="12">hermonesealjohn@gmail.com</option>
                                                                    </select><div class="tokenize" id="3c7a0efa-f935-fe3d-fd75-b4a71d4fd48c"><ul class="tokens-container form-control" tabindex="0"><li class="token-search" style="width: 17px;"><input autocomplete="off"></li></ul></div>
                            </div>
                                                        <div class="col-sm-10 pull-right" id="custom" style="display: none">
                                <label for="custom_user" class="control-label"><p class="help-block">Note : How Many user you want send the mail. choose settings-&gt;Other Settings-&gt;Custom User Count.</p></label>
                                <input type="text" max="255" name="custom_user" class="form-control" placeholder="Custom Users">
                            </div>
                        
                        </div>
                        <div class="form-group">
                            <label for="subject" class="col-sm-2 control-label">* Subject</label>

                            <div class="col-sm-10">
                                <input type="text" min="5" max="255" pattern=".{5,}" required="" name="subject" class="form-control" id="subject" placeholder="Subject Minimum 5 characters" title="Subject Minimum 5 characters">

                            </div>
                        </div>

                        <div class="form-group">
                            <label for="content" class="col-sm-2 control-label">*Content</label>

                            <div class="col-sm-10">

                                <textarea type="content" min="5" name="content" class="form-control" id="ckeditor" placeholder="Content is minium five letters is Important" style="visibility: hidden; display: none;"></textarea>
                                
                            </div>
                        </div>

                    </div>

                    <!--Footer Section -->
                    <div class="box-footer">
                    <button type="submit" class="btn btn-success pull-right">Submit</button>
                    </div>
                </form>
            
            </div>

        </div>

    </div>
                
            </section>

        </div>

        <!-- include('layouts.admin.footer') -->

        <!-- include('layouts.admin.left-side-bar') -->

    </div>


    <!-- jQuery 2.2.0 -->
    <script src="admin-css/plugins/jQuery/jQuery-2.2.0.min.js"></script>
    <!-- Bootstrap 3.3.6 -->
    <script src="admin-css/bootstrap/js/bootstrap.min.js"></script>

    <script src="admin-css/plugins/datatables/jquery.dataTables.min.js"></script>

    <script src="admin-css/plugins/datatables/dataTables.bootstrap.min.js"></script>

    <!-- Select2 -->
    <script src="admin-css/plugins/select2/select2.full.min.js"></script>
    <!-- InputMask -->
    <script src="admin-css/plugins/input-mask/jquery.inputmask.js"></script>
    <script src="admin-css/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>

    <script src="admin-css/plugins/input-mask/jquery.inputmask.extensions.js"></script>

    <!-- SlimScroll -->
    <script src="admin-css/plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="admin-css/plugins/fastclick/fastclick.js"></script>
    <!-- AdminLTE App -->
    <script src="admin-css/dist/js/app.min.js"></script>

    <!-- jvectormap -->
    <script src="admin-css/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>

    <script src="admin-css/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>

    <script src="admin-css/plugins/chartjs/Chart.min.js"></script>

    <!-- Datapicker -->
    <script src="admin-css/plugins/datepicker/bootstrap-datepicker.js"></script> 

    <script src="admin-css/plugins/tokenize2-1.1-dist/tokenize2.min.js"></script>

    <script src="admin-css/plugins/iCheck/icheck.min.js"></script>

    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <!-- <script src="https://apistream.ulademos.com/admin-css/dist/js/pages/dashboard2.js"></script> -->

    <script src="admin-css/dist/js/demo.js"></script>

    <!-- page script -->
    <script type="text/javascript">

        function loadFile(event,id){

            $('#'+id).show();

            var reader = new FileReader();

            reader.onload = function(){

                var output = document.getElementById(id);

                output.src = reader.result;
            };

            reader.readAsDataURL(event.files[0]);
        }

        $(document).ready(function(){
            $('#help-popover').popover({
                html : true, 
                content: function() {
                    return $('#help-content').html();
                } 
            });  
        });
        
        $(function () {

            $("#example1").DataTable();

            $("#datatable-withoutpagination").DataTable({
                 "paging": false,
                 "lengthChange": false,
                 "language": {
                       "info": ""
                }
            });
            
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false
            });
        });
    </script>

    
<script src="admin-css/plugins/tokenize2-1.1-dist/tokenize2.min.js"></script>

<script src="https://cdn.ckeditor.com/4.5.5/standard/ckeditor.js"></script>

    <script>
        CKEDITOR.replace( 'ckeditor' );
    </script>

	<script type="text/javascript">

        $('#multi-select-user').tokenize2();

        $('#multi-select-moderator').tokenize2();
		
		$(document).ready(function(){

    		$("input[name='to']").click(function () {

            $('#preview').css('display', ($(this).val() === '0') ? 'block':'none');

            $('#select_moderator').hide();

            });

            $("input[name='to']").click(function () {

            $('#mod_preview').css('display', ($(this).val() === '1') ? 'block':'none');

                $('#select').hide();

            });


            $("input[name='to']").click(function () {

            $('#custom').css('display', ($(this).val() === '2') ? 'block':'none');

                $('#select').hide();

                $('#select_moderator').hide();
            });

		});
	</script>

    <script type="text/javascript">

        $('#select_user').click(function() {

            $('#select').css('display',($(this).val()==='SELECT_USERS') ? 'block':'none');
            $('#custom').hide();
            $('#select_moderator').hide();
        });

        $("#users_list").click(function () {
            $('#select').hide();
            $('#custom').hide();
            $('#select_moderator').hide();
        });

        $("#users_list1").click(function () {
            $('#select').hide();
            $('#custom').hide();
            $('#select_moderator').hide();
        });

        $("#users_list2").click(function () {
            $('#select').hide();
            $('#custom').hide();
            $('#select_moderator').hide();
        });

        $('#select_mod').click(function(){

            $('#select_moderator').css('display',($(this).val()==='SELECT_MODERATOR') ? 'block':'none');
            $('#custom').hide();
            $('#select').hide();
        }); 
        
        $('#moderators_list').click(function(){
            $('#select').hide();
            $('#custom').hide();
            $('#select_moderator').hide();
        });
    </script>

    <script type="text/javascript">
         $("#mail_camp").addClass("active"); 
            </script>

    <script type="text/javascript">
        
        $(document).ready(function() {
            
            $('#expiry_date').datepicker({
                autoclose:true,
                format : 'dd-mm-yyyy',
                startDate: 'today',
            });
            
        });

    </script>
    <script type="text/javascript">
        
        $(function () {
            //Initialize Select2 Elements
            $(".select2").select2();

            //Datemask dd/mm/yyyy
            $("#datemask").inputmask("dd:mm:yyyy", {"placeholder": "hh:mm:ss"});
            //Datemask2 mm/dd/yyyy
            // $("#datemask2").inputmask("hh:mm:ss", {"placeholder": "hh:mm:ss"});
            //Money Euro
            $("[data-mask]").inputmask();

             //iCheck for checkbox and radio inputs
            $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
              checkboxClass: 'icheckbox_minimal-blue',
              radioClass: 'iradio_minimal-blue',
               increaseArea : '20%'
            });
            //Red color scheme for iCheck
            $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
              checkboxClass: 'icheckbox_minimal-red',
              radioClass: 'iradio_minimal-red',
               increaseArea : '20%'
            });
            //Flat red color scheme for iCheck
            $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
              checkboxClass: 'icheckbox_flat-green',
              radioClass: 'iradio_flat-green',
              increaseArea : '20%'

            });

             //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass: 'iradio_flat-green'
    });

        });
    </script>

    




</body></html>