<html class="no-js" lang="">
<head>
    <style type="text/css">
  .center-card{
    	width: 30% !important;
	}
  .small-box .icon {
    top: 0px !important;
  }
  .inner {
    color:white !important;
  }
</style>






    <meta charset="utf-8">
    <title>Dashboard</title>
    
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

    <meta name="description" content="UlaStream">

    <meta name="keywords" content="UlaStream">
    
    <meta name="author" content="UlaStream">


    <link rel="stylesheet" href="<?= base_url() ?>admin-css/bootstrap/css/bootstrap.min.css">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">

    <!-- Ionicons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">

    <link rel="stylesheet" href="<?= base_url() ?>admin-css/plugins/jvectormap/jquery-jvectormap-1.2.2.css">

    <!-- DataTables -->
    <link rel="stylesheet" href="<?= base_url() ?>admin-css/plugins/datatables/dataTables.bootstrap.css">

     <!-- Select Multiple dropdown -->
    

    
    <link rel="stylesheet" href="<?= base_url() ?>admin-css/plugins/select2/select2.min.css">

      <!-- Theme style -->
    <link rel="stylesheet" href="<?= base_url() ?>admin-css/dist/css/AdminLTE.min.css">

    <link rel="stylesheet" href="<?= base_url() ?>admin-css/dist/css/_all-skins.min.css">

    <link rel="stylesheet" href="<?= base_url() ?>admin-css/dist/css/custom.css">

    <!-- Datepicker-->
    <link rel="stylesheet" href="<?= base_url() ?>admin-css/plugins/datepicker/datepicker3.css">
    
    <!--Select with search option plugin -->
  
    <!-- Select Multiple dropdown -->
    <link rel="stylesheet" href="<?= base_url() ?>admin-css/plugins/tokenize2-1.1-dist/tokenize2.min.css">

    <link rel="stylesheet" href="<?= base_url() ?>admin-css/plugins/iCheck/all.css">

    <style>
        /*.skin-blue .main-header .navbar {
            background: linear-gradient(to bottom right, rgb(86, 202, 193), #0e5c73);
        }
        .skin-blue .main-header .logo {
            background: linear-gradient(to bottom right, rgb(86, 202, 193), #0e5c73);
        }
        .skin-blue .main-sidebar{
            background: linear-gradient(to bottom right, rgb(42, 49, 53), #39a1bf);
        }*/

        .popover {
            max-width: 500px;
        }

        .popover-content {
            padding: 10px 5px;

        }

        .popover-list li{

            margin-bottom: 5px;

        }
        .column {

            position: fixed;top:0;left: 0;bottom: 0;right: 0;display: flex; justify-content: center; align-items: center;background: #fff !important;opacity: 0.6;
        }

        .loader-form {
            position: relative;width: 100%;height: 100%;z-index: 9999;;
        }
        .skin-blue .left-side, .skin-blue .main-sidebar, .skin-blue .wrapper {
    background-color: #000;
}

.skin-blue .sidebar-menu>li.header {
    color: #000000;
       background: #ddddcde0;
}
.skin-blue .sidebar-menu>li.active>a, .skin-blue .sidebar-menu>li:hover>a {
    background: #000000;
}
.skin-blue .main-header .navbar {
    background-image: unset!important;
    background-color: rgb(0 0 0);
}
.skin-blue .main-header .logo {
    background-image: unset!important;
    background-color: rgb(0 0 0);
    width: 100px;
}
    </style>

    

    </head>

<body class="skin-blue sidebar-mini">

    <div class="loader-form" style="display: none;">
        <div class="column">
            <div class="loader-container animation-5">
              <div class="shape shape1"></div>
              <div class="shape shape2"></div>
              <div class="shape shape3"></div>
              <div class="shape shape4"></div>
            </div>
        </div>

    </div>          

    <div class="wrapper admin">

        <!-- popup -->
        
        
            <header class="main-header">
    <!-- Logo -->
   
    <a class="" href="#">
                        <img class="img-fluid logo" style="margin-left: 55px;" src="http://localhost/ott/admin/file_folder/logo.png" alt="streamlab-image">
                   <!--        <h2>SUNSHINE</h2> -->
                     </a>
    <!-- <a class="" href="#">
                        <img class="img-fluid logo" style="margin-left: 55px;" src="https://sunshineott.com/admin/file_folder/logo.png" alt="streamlab-image">
                          <h2>SUNSHINE</h2> 
                     </a> -->

    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top" style="background-image: linear-gradient(to right top, #3c8dbc, #309dc9, #20acd4, #0ebcdc, #08cce3);">

        <!-- <a href="" class="btn btn-sm btn-default ml15">Hello</a> -->

        <!-- Sidebar toggle button-->
        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </a>

        <div class="navbar-custom-menu">

            <ul class="nav navbar-nav">

                <li class="dropdown notifications-menu">
                <a href="https://sunshineott.com/" class="btn btn-default" target="_blank" style="color:black;border: 2px dotted gray"> 
                        <i class="fa fa-external-link mr-2"></i>
                        <b> Visit Website</b>
                        <span class="label label-warning"></span>
                    </a>
                    <!-- <a href="https://sunshineott.com/" class="btn btn-default" target="_blank" style="color:black;border: 2px dotted gray"> 
                        <i class="fa fa-external-link mr-2"></i>
                        <b> Visit Website</b>
                        <span class="label label-warning"></span>
                    </a> -->

                </li>

     

            </ul>

        </div>
    </nav>

</header>

<style>
.nav>li>a:hover,.nav>li>a:active,.nav>li>a:focus {
    background: #fdfdfd !important;
}
</style>
            <aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar" style="height: auto;">

        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?php echo base_url(''); ?>file_folder/profile.png" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <p>Admin</p>
                <a href="#">Admin</a>
            </div>
        </div>

        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu">

            <li id="dashboard" class="active">
                <a href="<?php echo base_url('home'); ?>">
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>              
            </li>

            <!-- account_management start -->

            <li class="header text-uppercase">Accounts Management</li>

         <!--    <li class="treeview" id="users">
                <a href="#">
                    <i class="fa fa-user"></i> <span>Users</span> <i class="fa fa-angle-right pull-right"></i>
                </a>

                <ul class="treeview-menu">
                    <li id="users-create"><a href="<?php echo base_url('home'); ?>"><i class="fa fa-circle-o"></i>Add User</a></li>
                    <li id="users-view"><a href="<?php echo base_url('home'); ?>"><i class="fa fa-circle-o"></i>View Users</a></li>
                </ul>    
            
            </li>
 -->
            <li id="user_view">
                <a href="<?php echo base_url('user_view'); ?>">
                    <i class="fa fa-trophy"></i> <span>User List</span> 
                </a>
            </li>
             <li id="user_view">
                <a href="<?php echo base_url('subscriber_view'); ?>">
                    <i class="fa fa-trophy"></i> <span>Subscriber List</span> 
                </a>
            </li>
           <!--  <li class="treeview" id="moderators">                
                <a href="#">
                    <i class="fa fa-users"></i> <span>Moderators</span> <i class="fa fa-angle-right pull-right"></i>
                </a>

                <ul class="treeview-menu">

                    <li id="moderators-create"><a href="<?php echo base_url('moderator'); ?>"><i class="fa fa-circle-o"></i>Add Moderator</a></li>
                    <li id="moderators-view"><a href="<?php echo base_url('view_moderator'); ?>"><i class="fa fa-circle-o"></i>View Moderators</a></li>
                </ul>            
            
            </li> -->
<!-- 
            <li class="treeview" id="sub-admins">
                <a href="#">
                    <i class="fa fa-support"></i> <span>Sub Admins</span> <i class="fa fa-angle-right pull-right"></i>
                </a>

                <ul class="treeview-menu">
                   
                    <li id="sub-admins-create"><a href="<?php echo base_url('add_sub_admin'); ?>"><i class="fa fa-circle-o"></i>Add Sub Admin</a></li>
                   <li id="sub-admins-view"><a href="<?php echo base_url('view_sub_admin'); ?>"><i class="fa fa-circle-o"></i>View Sub Admins</a></li>

                </ul>    
            
            </li> -->

            <!-- account_management end -->

            <!-- video_management start -->

            <li class="header text-uppercase">Category Management</li>

            <li class="treeview" id="categories">
                <a href="#">
                    <i class="fa fa-suitcase"></i> <span>Categories</span> <i class="fa fa-angle-right pull-right"></i>
                </a>

                <ul class="treeview-menu">
                    <li id="categories-create"><a href="<?php echo base_url('Category'); ?>"><i class="fa fa-circle-o"></i>Add Category</a></li>
                    <li id="categories-view"><a href="<?php echo base_url('view_category'); ?>"><i class="fa fa-circle-o"></i>View Categories</a></li>
                </ul>
            
            </li>

          <!--   <li class="treeview" id="cast-crews">
                <a href="#">
                    <i class="fa fa-male"></i><span>Cast &amp; Crews</span><i class="fa fa-angle-right pull-right"></i>
                </a>

                <ul class="treeview-menu">

                    <li id="cast-crews-create"><a href="<?php echo base_url('add_cast_crew'); ?>"><i class="fa fa-circle-o"></i>Add Cast &amp; Crew</a></li>
                    <li id="cast-crews-view"><a href="<?php echo base_url('view_cast_crew'); ?>"><i class="fa fa-circle-o"></i>Cast &amp; Crews</a></li>
                </ul>
            
            </li> -->

           <!--  <li class="treeview" id="movie-types">
                <a href="#">
                    <i class="fa fa-male"></i><span>Movie Types</span><i class="fa fa-angle-right pull-right"></i>
                </a>

                <ul class="treeview-menu">

                    <li id="movie-types-create"><a href="<?php echo base_url('add_movie_type'); ?>"><i class="fa fa-circle-o"></i>Add Movie &amp; Types</a></li>
                    <li id="movie-types-view"><a href="<?php echo base_url('view_movie_type'); ?>"><i class="fa fa-circle-o"></i>Movie &amp; Types</a></li>
                </ul>
            
            </li> -->
<!-- 
            <li class="treeview" id="videos">
                <a href="#">
                    <i class="fa fa-video-camera"></i> <span>Videos</span> <i class="fa fa-angle-right pull-right"></i>
                </a>

                <ul class="treeview-menu">
                    <li id="admin_videos_create">
                        <a href="<?php echo base_url('upload_video'); ?>"><i class="fa fa-circle-o"></i>Upload Video</a>
                    </li>

                    <li id="view-videos">
                        <a href="<?php echo base_url('view_video'); ?>"><i class="fa fa-circle-o"></i>View Videos</a>
                    </li>

               

                </ul>

            </li> -->

            <!-- video_management end -->

            <!-- payments_management start -->

            <li class="header text-uppercase">Payment Management</li>

            <li id="payments">
                <a href="#">
                    <i class="fa fa-credit-card"></i> <span>Payments</span> <i class="fa fa-angle-right pull-right"></i>
                </a>

                <ul class="treeview-menu">
<!-- 
                    <li id="revenue_system"><a href="<?php echo base_url('revenue_system'); ?>"><i class="fa fa-circle-o"></i>Revenue System</a></li>
                     -->
                    <li id="user-payments">
                        <a href="<?php echo base_url('subscription_pay'); ?>">
                            <i class="fa fa-circle-o"></i> <span>Subscription Payments</span>
                        </a>
                    </li>
                  <!--   <li id="video-subscription">
                            <a href="<?php echo base_url('ppv_payment'); ?>">
                                <i class="fa fa-circle-o"></i> <span>PPV Payments</span>
                            </a>
                    </li> -->

                                        
                </ul>
            
            </li>

           <!--  <li class="treeview" id="subscriptions">
                <a href="#">
                    <i class="fa fa-key"></i> <span>Subscriptions</span> <i class="fa fa-angle-right pull-right"></i>
                </a>

                <ul class="treeview-menu">

                    <li id="subscriptions-create"><a href="<?php echo base_url('add_subscriptions'); ?>"><i class="fa fa-circle-o"></i>Add Subscription</a></li>

                    <li id="subscriptions-view"><a href="<?php echo base_url('view_subscriptions'); ?>"><i class="fa fa-circle-o"></i>View Subscriptions</a></li>
                    
                </ul>
            
            </li> -->

        <!--     <li class="treeview" id="coupons">
                <a href="#">
                    <i class="fa fa-gift"></i><span>Coupons</span><i class="fa fa-angle-right pull-right"></i>
                </a>

                <ul class="treeview-menu">
                    <li id="coupons-create"><a href="<?php echo base_url('add_coupon'); ?>"> <i class="fa fa-circle-o"></i>Add Coupon</a></li>
                    <li id="coupons-view"><a href="<?php echo base_url('view_coupon'); ?>"><i class="fa fa-circle-o"></i>View Coupon</a></li>
                </ul>
            
            </li> -->

         <!--    
            <li id="redeems">
                <a href="<?php echo base_url('redeems'); ?>">
                    <i class="fa fa-trophy"></i> <span>Redeems</span> 
                </a>
            </li> -->

            
            <!-- payments_management end -->

            <!-- site_management start -->

            <!-- <li class="header text-uppercase">Site Management</li>

            <li class="treeview" id="settings">

                <a href="#">
                    <i class="fa fa-gears"></i><span>Settings</span><i class="fa fa-angle-right pull-right"></i>
                </a>
            </li> -->

            <!--     <ul class="treeview-menu">

                    <li id="site_settings"><a href="<?php echo base_url('site_settings'); ?>"><i class="fa fa-circle-o"></i>Site Settings</a></li>
                    <li id="home_page_settings"><a href="<?php echo base_url('home_page_settings'); ?>"><i class="fa fa-circle-o"></i>Home Page Settings</a></li>
                </ul>
            
            </li>

            <li id="custom-push">
                <a href="<?php echo base_url('custom_push'); ?>">
                    <i class="fa fa-send"></i> <span>Custom Push</span>
                </a>
            </li>

            <li class="treeview" id="pages">
                <a href="#">
                    <i class="fa fa-picture-o"></i> <span>Pages</span> <i class="fa fa-angle-right pull-right"></i>
                </a>

                <ul class="treeview-menu">

                    <li id="pages-create"><a href="<?php echo base_url('add_page'); ?>"><i class="fa fa-circle-o"></i>Add Page</a></li>

                    <li id="pages-view"><a href="<?php echo base_url('view_page'); ?>"><i class="fa fa-circle-o"></i>View Page</a></li>

                </ul>
            </li> -->

            <!-- site_management end -->

            <!-- lookups_management start -->

 <!--  <li class="header text-uppercase">Video Management</li>

        <li class="treeview" id="coupons">
                <a href="#">
                    <i class="fa fa-file"></i><span>Video's</span><i class="fa fa-angle-right pull-right"></i>
                </a>

                <ul class="treeview-menu">
                <li id="mail_camp">
                <a href="<?php echo base_url('user_report'); ?>">
                    <i class="fa fa-circle-o"></i> <span>Movies</span> 
                </a>
            </li>
              <li id="">
                <a href="<?php echo base_url('movie_tv_series'); ?>">
                    <i class="fa fa-circle-o"></i> <span>series</span> 
                </a>
            </li>
                <li id="">
                <a href="<?php echo base_url('revenue_report'); ?>">
                    <i class="fa fa-circle-o"></i> <span>Revenue Report</span> 
                </a>
            </li>
                </ul>
            
            </li>
        -->

            
          

            

            <li class="header text-uppercase">Lookup's Management</li>

     

            
        <!--     <li id="mail_camp">
                <a href="<?php echo base_url('mail_camp'); ?>">
                    <i class="fa fa-envelope"></i> <span>Mail Camp</span> 
                </a>
            </li> -->

            <!-- lookups_management end -->

            <!-- admin_account end -->
             
            <!-- <li class="header text-uppercase">Admin Account</li> -->

          <!--   <li id="profile">
                <a href="<?php echo base_url('my_account'); ?>">
                    <i class="fa fa-diamond"></i> <span>Account</span>
                </a>
            </li>
 -->

 
            <li>
                <a href="<?php echo base_url(''); ?>">
                    <i class="fa fa-sign-out"></i> <span>Sign out</span>
                </a>
            </li>

        </ul>

    </section>

    <!-- /.sidebar -->

</aside>
<style >
    .label-default {
    background-color: #ff0000;
    color: #fff;
}
</style>
