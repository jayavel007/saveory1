  <div class="content-wrapper" style="min-height: 1217px;">
            <section class="content-header">
                <h1>Subscribers<small></small></h1>
                <ol class="breadcrumb">
                    <li><a href=""><i class="fa fa-dashboard"></i>Home</a></li>
                    <li class="active"><i class="fa fa-suitcase"></i> Subscribers</li>
                </ol>
            </section>
            <!-- Main content -->
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="box box-primary">
                         <!--    <div class="box-header label-primary"> <b style="font-size:18px;">Users</b> <a href="#" class="btn btn-default pull-right">Add Category</a> </div> -->
                            <div class="box-body">
                                <div id="datatable-withoutpagination_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                                    <div class="row">
                                        <div class="col-sm-6"></div>
                                       <!--  <div class="col-sm-6">
                                            <div id="datatable-withoutpagination_filter" class="dataTables_filter">
                                                <label>Search:
                                                    <input type="search" class="form-control input-sm" placeholder="" aria-controls="datatable-withoutpagination">
                                                </label>
                                            </div>
                                        </div> -->
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="datatable-withoutpagination" class="table table-bordered table-striped dataTable no-footer" role="grid" aria-describedby="datatable-withoutpagination_info">
                                                <thead>
                                                    <tr role="row">
                                                        <th tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-sort="ascending" aria-label="ID: activate to sort column descending" style="width: 34px;">ID</th>
                                                        <th tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Category: activate to sort column ascending" style="width: 287px;">Users</th>
                                                        <th  tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Picture: activate to sort column ascending" style="width: 78px;">Mail</th>
                                                        <th  tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Picture: activate to sort column ascending" style="width: 78px;">
                                                        Subscribe plans</th>
                                                          <th tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Status: activate to sort column ascending" style="width: 70px;">Expiry Date</th>
                                                        <th tabindex="0" aria-controls="datatable-withoutpagination" rowspan="1" colspan="1" aria-label="Status: activate to sort column ascending" style="width: 70px;">Status</th>

                                                    
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    
                                                    <?php
                                                    $i = 1;
                                                    foreach($subscribersList as $row){
                                                        ?>
                                                          <tr role="row" class="odd">
                                                        <td class="sorting_1"><?= $i++ ?></td>
                                                        <td><?= $row['name']; ?> </td>
                                                        <td> <?= $row['user_login']; ?> </td>
                                                        <td> <?= $row['subscribe_amt']; ?> </td>
                                                        <td> <?= $row['subscribe_end']; ?> </td>
                                                    
                                                        <td>  <?php $status=$row['status']; 
                                                        if($status=='1'){ echo '<span class="label label-success">Active</span>';}
                                                        else{
                                                            echo '<span class="label label-danger">Deactive</span>';
                                                        }  ?></td>
                                                  
                                                    </tr>
                                                        <?php
                                                    }

                                                    ?>
                                                  
                                               
                                                   
                                               
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-5">
                                            <div class="dataTables_info" id="datatable-withoutpagination_info" role="status" aria-live="polite"></div>
                                        </div>
                                        <div class="col-sm-7"></div>
                                    </div>
                                </div>
                              <!--   <div align="right" id="paglink">
                                    <ul class="pagination">
                                        <li class="disabled"><span>«</span></li>
                                        <li class="active"><span>1</span></li>
                                        <li><a href="admin/categories?page=2">2</a></li>
                                        <li><a href="admin/categories?page=2" rel="next">»</a></li>
                                    </ul>
                                </div> -->
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        <!-- include('layouts.admin.footer') -->
        <!-- include('layouts.admin.left-side-bar') -->
    </div>
    <!-- jQuery 2.2.0 -->
    <script src="https://apistream.ulademos.com/admin-css/plugins/jQuery/jQuery-2.2.0.min.js"></script>
    <!-- Bootstrap 3.3.6 -->
    <script src="https://apistream.ulademos.com/admin-css/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://apistream.ulademos.com/admin-css/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="https://apistream.ulademos.com/admin-css/plugins/datatables/dataTables.bootstrap.min.js"></script>
    <!-- Select2 -->
    <script src="https://apistream.ulademos.com/admin-css/plugins/select2/select2.full.min.js"></script>
    <!-- InputMask -->
    <script src="https://apistream.ulademos.com/admin-css/plugins/input-mask/jquery.inputmask.js"></script>
    <script src="https://apistream.ulademos.com/admin-css/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
    <script src="https://apistream.ulademos.com/admin-css/plugins/input-mask/jquery.inputmask.extensions.js"></script>
    <!-- SlimScroll -->
    <script src="https://apistream.ulademos.com/admin-css/plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="https://apistream.ulademos.com/admin-css/plugins/fastclick/fastclick.js"></script>
    <!-- AdminLTE App -->
    <script src="https://apistream.ulademos.com/admin-css/dist/js/app.min.js"></script>
    <!-- jvectormap -->
    <script src="https://apistream.ulademos.com/admin-css/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
    <script src="https://apistream.ulademos.com/admin-css/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
    <script src="https://apistream.ulademos.com/admin-css/plugins/chartjs/Chart.min.js"></script>
    <!-- Datapicker -->
    <script src="https://apistream.ulademos.com/admin-css/plugins/datepicker/bootstrap-datepicker.js"></script>
    <script src="https://apistream.ulademos.com/admin-css/plugins/tokenize2-1.1-dist/tokenize2.min.js"></script>
    <script src="https://apistream.ulademos.com/admin-css/plugins/iCheck/icheck.min.js"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <!-- <script src="https://apistream.ulademos.com/admin-css/dist/js/pages/dashboard2.js"></script> -->
    <script src="https://apistream.ulademos.com/admin-css/dist/js/demo.js"></script>
    <!-- page script -->
    <script type="text/javascript">
    function loadFile(event, id) {
        $('#' + id).show();
        var reader = new FileReader();
        reader.onload = function() {
            var output = document.getElementById(id);
            output.src = reader.result;
        };
        reader.readAsDataURL(event.files[0]);
    }
    $(document).ready(function() {
        $('#help-popover').popover({
            html: true,
            content: function() {
                return $('#help-content').html();
            }
        });
    });
    $(function() {
        $("#example1").DataTable();
        $("#datatable-withoutpagination").DataTable({
            "paging": false,
            "lengthChange": false,
            "language": {
                "info": ""
            }
        });
        $('#example2').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false
        });
    });
    </script>
    <script type="text/javascript">
    $("#categories").addClass("active");
    $("#categories-view").addClass("active");
    </script>
    <script type="text/javascript">
    $(document).ready(function() {
        $('#expiry_date').datepicker({
            autoclose: true,
            format: 'dd-mm-yyyy',
            startDate: 'today',
        });
    });
    </script>
    <script type="text/javascript">
    $(function() {
        //Initialize Select2 Elements
        $(".select2").select2();
        //Datemask dd/mm/yyyy
        $("#datemask").inputmask("dd:mm:yyyy", {
            "placeholder": "hh:mm:ss"
        });
        //Datemask2 mm/dd/yyyy
        // $("#datemask2").inputmask("hh:mm:ss", {"placeholder": "hh:mm:ss"});
        //Money Euro
        $("[data-mask]").inputmask();
        //iCheck for checkbox and radio inputs
        $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
            checkboxClass: 'icheckbox_minimal-blue',
            radioClass: 'iradio_minimal-blue',
            increaseArea: '20%'
        });
        //Red color scheme for iCheck
        $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
            checkboxClass: 'icheckbox_minimal-red',
            radioClass: 'iradio_minimal-red',
            increaseArea: '20%'
        });
        //Flat red color scheme for iCheck
        $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
            checkboxClass: 'icheckbox_flat-green',
            radioClass: 'iradio_flat-green',
            increaseArea: '20%'
        });
        //Flat red color scheme for iCheck
        $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
            checkboxClass: 'icheckbox_flat-green',
            radioClass: 'iradio_flat-green'
        });
    });
    </script>
</body>

</html>