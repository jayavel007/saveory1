
   
    <style>
        /*.skin-blue .main-header .navbar {
            background: linear-gradient(to bottom right, rgb(86, 202, 193), #0e5c73);
        }
        .skin-blue .main-header .logo {
            background: linear-gradient(to bottom right, rgb(86, 202, 193), #0e5c73);
        }
        .skin-blue .main-sidebar{
            background: linear-gradient(to bottom right, rgb(42, 49, 53), #39a1bf);
        }*/

        .popover {
            max-width: 500px;
        }

        .popover-content {
            padding: 10px 5px;

        }

        .popover-list li{

            margin-bottom: 5px;

        }
        .column {

            position: fixed;top:0;left: 0;bottom: 0;right: 0;display: flex; justify-content: center; align-items: center;background: #fff !important;opacity: 0.6;
        }

        .loader-form {
            position: relative;width: 100%;height: 100%;z-index: 9999;;
        }
    </style>

    
<style>
    
/*  maxflix tab */
div.maxflix-tab-container{
  z-index: 10;
  background-color: #ffffff;
  padding: 0 !important;
  border-radius: 4px;
  -moz-border-radius: 4px;
  border:1px solid #ddd;
  margin-top: 20px;
  margin-left: 50px;
  -webkit-box-shadow: 0 6px 12px rgba(0,0,0,.175);
  box-shadow: 0 6px 12px rgba(0,0,0,.175);
  -moz-box-shadow: 0 6px 12px rgba(0,0,0,.175);
  background-clip: padding-box;
  opacity: 0.97;
  filter: alpha(opacity=97);
}
div.maxflix-tab-menu{
  padding-right: 0;
  padding-left: 0;
  padding-bottom: 0;
}
div.maxflix-tab-menu div.list-group{
  margin-bottom: 0;
}
div.maxflix-tab-menu div.list-group>a{
  margin-bottom: 0;
}
div.maxflix-tab-menu div.list-group>a .glyphicon,
div.maxflix-tab-menu div.list-group>a .fa {
  color: #1e5780;
}
div.maxflix-tab-menu div.list-group>a:first-child{
  border-top-right-radius: 0;
  -moz-border-top-right-radius: 0;
}
div.maxflix-tab-menu div.list-group>a:last-child{
  border-bottom-right-radius: 0;
  -moz-border-bottom-right-radius: 0;
}
div.maxflix-tab-menu div.list-group>a.active,
div.maxflix-tab-menu div.list-group>a.active .glyphicon,
div.maxflix-tab-menu div.list-group>a.active .fa{
  background-color: #1e5780;
  background-image: #1e5780;
  color: #ffffff;
}
div.maxflix-tab-menu div.list-group>a.active:after{
  content: '';
  position: absolute;
  left: 100%;
  top: 50%;
  margin-top: -13px;
  border-left: 0;
  border-bottom: 13px solid transparent;
  border-top: 13px solid transparent;
  border-left: 10px solid #1e5780;
}

div.maxflix-tab-content{
  background-color: #ffffff;
  /* border: 1px solid #eeeeee; */
  padding-left: 20px;
  padding-top: 10px;
}

.box-body {
    padding: 0px;
}

div.maxflix-tab div.maxflix-tab-content:not(.active){
  display: none;
}

.sub-title {
    width: fit-content;
    color: #2c648c;
    font-size: 18px;
    /*border-bottom: 2px dashed #285a86;*/
    padding-bottom: 5px;
}

hr {
    margin-top: 15px;
    margin-bottom: 15px;
}

.list-group-item {

    cursor: pointer;

}

</style>
     
        <div class="content-wrapper" style="min-height: 1217px;">

            <section class="content-header">
                <h1> 

Settings 

<a href="#" id="help-popover" class="btn btn-danger" style="font-size: 14px;font-weight: 600" title="" data-original-title="">HELP ?</a>

<div id="help-content" style="display: none">

    <ul class="popover-list">
        <li><b>PayPal- </b>Minimum Accepted Amount - $ 0.01</li>
        <li><b>Stripe- </b>Minimum Accepted Amount - $ 0.50<br> <a target="_blank" href="">Check References</a></li>
    </ul>
    
</div>

<small></small></h1>
                <ol class="breadcrumb">    <li><a href=""><i class="fa fa-dashboard"></i>Home</a></li>
    <li class="active"><i class="fa fa-gears"></i> Settings</li>
</ol>
            </section>

            <!-- Main content -->
            <section class="content">
                
                
                
<div class="row">

    <div class="col-lg-11 col-md-11 col-sm-11 col-xs-11 maxflix-tab-container">

        <div class="col-lg-2 col-md-2 col-sm-2 col-xs-2 maxflix-tab-menu">
            
            <div class="list-group">
                
                <a class="list-group-item text-left">Site Settings</a>

                <a class="list-group-item text-left">Video Settings</a>
                
                <a class="list-group-item text-left">Revenue Settings</a>

                <a class="list-group-item text-left">Social Settings</a>
                
                <a class="list-group-item text-left">Payment Settings</a>
                
                <a class="list-group-item text-left">Email Settings</a>
                
                <a class="list-group-item text-left">Company Site Url's</a>

                <a class="list-group-item text-left">Mobile Settings</a>

                <a class="list-group-item text-left">SEO Settings</a>

                <a class="list-group-item text-left active">Other Settings</a>

            </div>

        </div>

        <div class="col-lg-10 col-md-9 col-sm-10 col-xs-10 maxflix-tab">
            
            <!-- site settings begins -->            
            <div class="maxflix-tab-content">

                <form action="https://apistream.ulademos.com/admin/settings" method="POST" enctype="multipart/form-data" role="form">

                    <div class="box-body">

                        <div class="row">

                            <div class="col-md-12">
                                <h3 class="settings-sub-header text-uppercase"><b>Site Settings</b></h3>
                                <hr>
                            </div>
                            <div class="col-md-6">

                                <div class="form-group">
                                    
                                    <label for="sitename">Site Name</label>
                                    
                                    <input type="text" class="form-control" name="site_name" value="ULAStream" id="sitename" placeholder="Enter sitename">

                                </div>

                                <div class="form-group">
                                   
                                    <label for="site_logo">Site Logo</label>

                                    <br>

                                                                            <img class="settings-img-preview " src="fbe7e8c54bee454.jpg" title="">
                                    
                                    <input type="file" id="site_logo" name="site_logo" accept="image/png, image/jpeg">
                                    <p class="help-block">Please enter .png images only.</p>
                                </div>

                            </div>

                            <div class="col-lg-6">

                                <div class="form-group">

                                    <label for="streaming_url">App URL</label>

                                    <input type="text" value="" class="form-control" name="ANGULAR_SITE_URL" id="ANGULAR_SITE_URL" placeholder="Enter Frontend URL">
                                </div> 

                                <div class="form-group">

                                    <label for="site_icon">Site Favicon</label>

                                    <br>

                                                                            <img class="settings-img-preview " src="http://apistream.uberlikeapp.com/uploads/settings/SV-2021-11-03-01-24-25-c7f2228ebf0fb26864a9c26d67ae4476438a1c75.jpg" title="">
                                                                        <input type="file" id="site_icon" name="site_icon" accept="image/png, image/jpeg">
                                    <p class="help-block">Please enter .png images only.</p>
                                </div>

                            </div>

                        </div>

                    </div>

                    <!-- /.box-body -->

                    <div class="box-footer">

                        <button type="reset" class="btn btn-warning">Reset</button>

                        <button type="submit" class="btn btn-primary pull-right">Submit</button>

                    </div>
                
                </form>

            </div>
            <!-- site settings ends -->

            <!-- Video settings begins -->
            <div class="maxflix-tab-content">   

                <form action="https://apistream.ulademos.com/admin/video-settings_save" method="POST" enctype="multipart/form-data" role="form">

                    <div class="box-body">

                        <div class="row">

                            <div class="col-md-12">
                                <h3 class="settings-sub-header text-uppercase"><b>Video Settings</b></h3>
                                <hr>
                            </div>

                            <div class="col-md-12">
                                <h5 class="sub-title">Player Configuration</h5>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">

                                    <label for="JWPLAYER_KEY">Jwplayer Key</label>

                                    <input type="text" value="M2NCefPoiiKsaVB8nTttvMBxfb1J3Xl7PDXSaw==" class="form-control" name="JWPLAYER_KEY" id="JWPLAYER_KEY" placeholder="Jwplayer Key">
                                </div> 
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">

                                    <label for="socket_url">Socket Url</label>

                                    <input type="text" value="https://apistream.uberlikeapp.com:3003" class="form-control" name="socket_url" id="socket_url" placeholder="Socket Url">
                                </div> 
                            </div>

                            <div class="col-md-12">
                                <hr>
                                <h5 class="sub-title">Streaming Configuration</h5>
                            </div>

                           <!--  <div class="col-lg-6">
                                <div class="form-group">

                                    <label for="streaming_url">Streaming URL</label>

                                    <br>

                                    <p class="example-note">Ex : rtmp://IP_ADDRESS_OR_DOMAIN:1935/vod2/</p>

                                    <input type="text" value="" class="form-control" name="streaming_url" id="streaming_url" placeholder="Enter Streaming URL">
                                </div> 
                            </div>
 -->
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="HLS_STREAMING_URL">HLS Streaming URL</label>
                                    
                                    <br>

                                    <p class="example-note">Ex : http://IP_ADDRESS_OR_DOMAIN:8080/</p>

                                    <input type="text" value="" class="form-control" name="HLS_STREAMING_URL" id="HLS_STREAMING_URL" placeholder="Enter Streaming URL">
                                </div> 
                            </div>

                            <div class="col-md-12">
                                <hr>
                                <h5 class="sub-title">S3 Settings</h5>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="s3_key">S3 Key</label>
                                    <input type="text" class="form-control" name="S3_KEY" id="s3_key" placeholder="S3 Key" value="">
                                </div>
                            </div>
                            
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="s3_secret">S3 Secret Key</label>    
                                    <input type="text" class="form-control" name="S3_SECRET" id="s3_secret" placeholder="S3 Secret Key" value="">
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="s3_region">S3 Region</label>    
                                    <input type="text" class="form-control" name="S3_REGION" id="s3_region" placeholder="S3 Region" value="">
                                </div>
                            </div>
                            
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="s3_bucket">S3 Bucket</label>    
                                    <input type="text" class="form-control" name="S3_BUCKET" id="s3_bucket" placeholder="S3 Bucket" value="">
                                </div>
                            </div>
                            
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="s3_ses_region">S3 Ses Region</label>    
                                    <input type="text" class="form-control" name="S3_SES_REGION" id="s3_ses_region" placeholder="S3 Ses Region" value="">
                                </div>
                            </div>
                        </div>

                    </div>

                     <div class="box-footer">

                        <button type="reset" class="btn btn-warning">Reset</button>

                        <button type="submit" class="btn btn-primary pull-right">Submit</button>
                        
                    </div>
                
                </form>
                
            </div>
            <!-- Video settings ends-->

            <!-- Revenue settings begins-->
            <div class="maxflix-tab-content">
                <form action="https://apistream.ulademos.com/admin/settings" method="POST" enctype="multipart/form-data" role="form">
                    
                    <div class="box-body">

                        <div class="row">

                            <div class="col-md-12">
                                <h3 class="settings-sub-header text-uppercase"><b>Revenue Settings</b></h3>
                                <hr>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">

                                    <label for="video_viewer_count">Set Viewer Count Limit Per Video</label>

                                    <br>

                                    <p class="example-note">Usage : View count limit. Once the view count reaches the limit set by the admin, the moderator gets paid for each view.</p>

                                    <input type="number" class="form-control" name="video_viewer_count" value="10" id="video_viewer_count" min="0" max="100" maxlength="100" pattern="[0-9]{0,}" placeholder="Set Viewer Count Limit Per Video" step="any">
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="upload_max_size">Amount Per Video View</label>
                                    
                                    <br>
                                    
                                    <p class="example-note">Usage : The amount set for each view once the count crosses the view limit.</p>

                                    <input type="number" class="form-control" name="amount_per_video" value="100" min="0" max="100" maxlength="100" pattern="[0-9]{0,}" id="amount_per_video" placeholder="Amount Per Video View" step="any">

                                </div>
                            </div>

                             <div class="col-md-6">
                                <div class="form-group">

                                    <label for="admin_commission">Admin Commission (in %)</label>

                                    <input type="number" class="form-control" name="admin_commission" value="10" min="0" max="100" maxlength="100" pattern="[0-9]{0,}" id="admin_commission" placeholder="Admin Commission (in %)">
                                </div>

                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="user_commission">Moderator Commission</label>
                                    <input type="number" class="form-control" name="user_commission" value="90" min="0" max="100" maxlength="100" pattern="[0-9]{0,}" id="user_commission" placeholder="Moderator Commission">
                                </div>
                            </div>
                            <div class="clearfix"></div>

                        </div>
                        
                    </div>

                     <div class="box-footer">

                        <button type="reset" class="btn btn-warning">Reset</button>

                        <button type="submit" class="btn btn-primary pull-right">Submit</button>
                        
                    </div>

                </form>            
            </div>
            <!-- Revenue settings ends-->

            <!-- Social settings begins-->
            <div class="maxflix-tab-content">   

                <form action="https://apistream.ulademos.com/admin/common-settings_save" method="POST" enctype="multipart/form-data" role="form">
                    <div class="box-body">

                        <div class="row">

                            <div class="col-md-12">
                                <h3 class="settings-sub-header text-uppercase"><b>Social Settings</b></h3>
                                <hr>
                            </div>

                            <div class="col-md-12">
                                <h5 class="sub-title">FB Settings</h5>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="fb_client_id">FB Client Id</label>
                                    <input type="text" class="form-control" name="FB_CLIENT_ID" id="fb_client_id" placeholder="FB Client Id" value="">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="fb_client_secret">FB Client Secret</label>    
                                    <input type="text" class="form-control" name="FB_CLIENT_SECRET" id="fb_client_secret" placeholder="FB Client Secret" value="">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="fb_call_back">FB CallBack</label>    
                                    <input type="text" class="form-control" name="FB_CALL_BACK" id="fb_call_back" placeholder="FB CallBack" value="">
                                </div>
                            </div>
                            <div class="clearfix"></div>

                            <div class="col-md-12">
                                <hr>
                                <h5 class="sub-title">Google Settings</h5>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="google_client_id">Google Client Id</label>
                                    <input type="text" class="form-control" name="GOOGLE_CLIENT_ID" id="google_client_id" placeholder="Google Client Id" value="">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="google_client_secret">Google Client Secret</label>    
                                    <input type="text" class="form-control" name="GOOGLE_CLIENT_SECRET" id="google_client_secret" placeholder="Google Client Secret" value="">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="google_call_back">Google CallBack</label>    
                                    <input type="text" class="form-control" name="GOOGLE_CALL_BACK" id="google_call_back" placeholder="Google CallBack" value="">
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="col-md-12">
                                <hr>
                                <h5 class="sub-title">FCM Settings</h5>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">

                                    <label for="FCM_SERVER_KEY">FCM SERVER KEY</label>

                                    <input type="text" class="form-control" name="FCM_SERVER_KEY" id="FCM_SERVER_KEY" value="" placeholder="FCM SERVER KEY">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">

                                    <label for="FCM_SENDER_ID">FCM SENDER ID</label>

                                    <input type="text" class="form-control" name="FCM_SENDER_ID" id="FCM_SENDER_ID" value="" placeholder="FCM SENDER ID">
                                </div>
                            </div>

                        </div>
                    
                    </div>
                   
                     <div class="box-footer">

                        <button type="reset" class="btn btn-warning">Reset</button>

                        <button type="submit" class="btn btn-primary pull-right">Submit</button>
                        
                    </div>

                </form>
            </div>
            <!-- Social settings ends -->

            <!-- Payment settings begins -->
            <div class="maxflix-tab-content">    

                <form action="https://apistream.ulademos.com/admin/common-settings_save" method="POST" enctype="multipart/form-data" role="form">
                   
                    <div class="box-body">

                        <div class="row">

                            <div class="col-md-12">
                                <h3 class="settings-sub-header text-uppercase"><b>Payment Settings</b></h3>
                                <hr>
                            </div>

                            <div class="col-md-12">
                                <h5 class="sub-title">PayPal Settings</h5>
                            </div>

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="paypal_id">Paypal Id</label>
                                    <input type="text" class="form-control" name="PAYPAL_ID" id="paypal_id" placeholder="Paypal Id" value="leftyqqhero@gmail.com">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="paypal_secret">Paypal Secret</label>    
                                    <input type="text" class="form-control" name="PAYPAL_SECRET" id="paypal_secret" placeholder="Paypal Secret" value="">
                                </div>
                            </div>
                            <!-- <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="paypal_mode">Paypal Mode</label>    
                                    <input type="text" class="form-control" name="PAYPAL_MODE" id="paypal_mode" placeholder="Paypal Mode" value="sandbox">
                                </div>
                            </div> -->

                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="PAYPAL_URL_MODE">Paypal Url Mode</label> 

                                    <div class="clearfix"></div>
                                    
                                    <input type="radio" name="PAYPAL_MODE" value="production" id="paypal_live">Live

                                    <input type="radio" name="PAYPAL_MODE" value="sandbox" id="paypal_sandbox" checked="">Sandbox
                                    
                                </div>
                            </div>

                            <div class="clearfix"></div>

                            <div class="col-md-12">
                                <hr>
                                <h5 class="sub-title">Stripe Settings</h5>
                            </div>

                             <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="stripe_publishable_key">Stripe Publishable Key</label>
                                    <input type="text" class="form-control" name="stripe_publishable_key" id="stripe_publishable_key" placeholder="Stripe Publishable Key" value="pk_test_uDYrTXzzAuGRwDYtu7dkhaF3">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="stripe_secret_key">Stripe Secret Key</label>
                                    <input type="text" class="form-control" name="stripe_secret_key" id="stripe_secret_key" placeholder="Stripe Secret Key" value="sk_test_lRUbYflDyRP3L2UbnsehTUHW">
                                </div>
                            </div>

                        </div>

                    </div>

                    <div class="box-footer">

                        <button type="reset" class="btn btn-warning">Reset</button>

                        <button type="submit" class="btn btn-primary pull-right">Submit</button>
                        
                    </div>

                </form>
            
            </div>
            <!-- Payment Settings ends -->

            <!-- Email settings begins-->
            <div class="maxflix-tab-content">
                
                <form action="https://apistream.ulademos.com/admin/common-settings_save" method="POST" enctype="multipart/form-data" role="form">
                            
                    <div class="box-body">

                        <div class="row">

                            <div class="col-md-12">
                                <h3 class="settings-sub-header text-uppercase"><b>Email Settings</b></h3>
                                <hr>
                            </div>

                            <div class="col-md-6">

                                <div class="form-group">
                                    <label for="MAIL_DRIVER">MAIL DRIVER</label>
                                    <input type="text" value="smtp" class="form-control" name="MAIL_DRIVER" id="MAIL_DRIVER" placeholder="Enter MAIL DRIVER">
                                </div>

                                <div class="form-group">
                                    <label for="MAIL_HOST">MAIL HOST</label>
                                    <input type="text" class="form-control" value="smtp.gmail.com" name="MAIL_HOST" id="MAIL_HOST" placeholder="MAIL HOST">
                                </div>

                                <div class="form-group">
                                    <label for="MAIL_PORT">MAIL PORT</label>
                                    <input type="text" class="form-control" value="587" name="MAIL_PORT" id="MAIL_PORT" placeholder="MAIL PORT">
                                </div>

                            </div>

                            <div class="col-md-6">

                                <div class="form-group">
                                    <label for="MAIL_USERNAME">MAIL USERNAME</label>
                                    <input type="text" class="form-control" value="" name="MAIL_USERNAME" id="MAIL_USERNAME" placeholder="MAIL USERNAME">
                                </div>

                                <div class="form-group">
                                    <label for="MAIL_PASSWORD">MAIL PASSWORD</label>
                                    <input type="password" class="form-control" name="MAIL_PASSWORD" id="MAIL_PASSWORD" placeholder="MAIL PASSWORD" value="">
                                </div>

                                <div class="form-group">
                                    <label for="MAIL_ENCRYPTION">MAIL ENCRYPTION</label>
                                    <input type="text" class="form-control" value="tls" name="MAIL_ENCRYPTION" id="MAIL_ENCRYPTION" placeholder="MAIL ENCRYPTION">
                                </div>

                            </div>

                            <div class="clearfix"></div>

                            
                        </div>

                    </div>

                     <div class="box-footer">
                        
                        <button type="reset" class="btn btn-warning">Reset</button>
                        
                        <button type="submit" class="btn btn-primary pull-right">Submit</button>                       
                    </div>

                </form>
            </div>
            <!-- Email Settings ends -->

            <!-- Company Settings begins-->
            <div class="maxflix-tab-content">
               
                <form action="https://apistream.ulademos.com/admin/settings" method="POST" enctype="multipart/form-data" role="form">
                    
                    <div class="box-body">

                        <div class="row">

                            <div class="col-md-12">
                                <h3 class="settings-sub-header text-uppercase"><b>Company Site Url's</b></h3>
                                <hr>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">

                                    <label for="facebook_link">Facebook Link</label>

                                    <input type="url" class="form-control" name="facebook_link" id="facebook_link" value="" placeholder="Facebook Link">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="linkedin_link">LinkedIn Link</label>

                                    <input type="url" class="form-control" name="linkedin_link" value="" id="linkedin_link" placeholder="LinkedIn Link">

                                </div>
                            </div>

                             <div class="col-md-6">
                                <div class="form-group">

                                    <label for="twitter_link">Twitter Link</label>

                                    <input type="url" class="form-control" name="twitter_link" value="" id="twitter_link" placeholder="Twitter Link">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="google_plus_link">Google Plus Link</label>
                                    <input type="url" class="form-control" name="google_plus_link" value="" id="google_plus_link" placeholder="Google Plus Link">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="pinterest_link">Pinterest Link</label>
                                    <input type="url" class="form-control" name="pinterest_link" value="" id="pinterest_link" placeholder="Pinterest Link">
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            
                        </div>
                    
                    </div>
                    
                    <div class="box-footer">
                        <button type="reset" class="btn btn-warning">Reset</button>
                        
                        <button type="submit" class="btn btn-primary pull-right">Submit</button>                       
                    </div>

                </form>
            </div>
            <!-- Company Settings ends -->

            <!-- APP Url Settings begins-->
            <div class="maxflix-tab-content">
                
                <form action="https://apistream.ulademos.com/admin/settings" method="POST" enctype="multipart/form-data" role="form">

                    <div class="box-body">
                            
                        <div class="row">

                            <div class="col-md-12">
                                <h3 class="settings-sub-header text-uppercase"><b>Mobile Settings</b></h3>
                                <hr>
                            </div>

                            <div class="col-md-12">
                                <h5 class="sub-title">App Url Settings</h5>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="appstore">Appstore</label>
                                    <input type="url" class="form-control" name="appstore" id="appstore" value="" placeholder="Appstore">
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="playstore">Playstore</label>
                                    <input type="url" class="form-control" name="playstore" value="" id="playstore" placeholder="Playstore">
                                </div>
                            </div>
                            
                        </div>

                    </div>

                    <div class="box-footer">
                        <button type="reset" class="btn btn-warning">Reset</button>
                        
                        <button type="submit" class="btn btn-primary pull-right">Submit</button>                       
                    </div>

                </form>

            </div>
            <!-- APP Url Settings ends -->

            <!-- SEO Settings begins-->
            <div class="maxflix-tab-content">

                <form action="https://apistream.ulademos.com/admin/settings" method="POST" enctype="multipart/form-data" role="form">

                    <div class="box-body">

                        <div class="row">

                            <div class="col-md-12">
                                <h3 class="settings-sub-header text-uppercase"><b>SEO Settings</b></h3>
                                <hr>
                            </div>

                            <div class="col-md-5">
                                <div class="form-group">
                                    <label>Meta Title</label>
                                     <input type="text" name="meta_title" value="UlaStream" required="" class="form-control" placeholder="Meta Title">
                                </div>                               
                            </div>

                            <div class="col-md-5 col-md-offset-1">
                                <div class="form-group">
                                    <label for="meta_author">Meta Author</label>
                                    <input type="text" class="form-control" value="UlaStream" name="meta_author" id="meta_author" placeholder="Meta Author">
                                </div>                             
                            </div>

                            <div class="clearfix"></div>

                            <div class="col-md-12">

                                <div class="form-group">
                                    <label for="meta_keywords">Meta Keywords</label>
                                    <textarea class="form-control" id="meta_keywords" name="meta_keywords">UlaStream</textarea>
                                </div>

                                <div class="form-group">
                                    <label for="meta_description">Meta Description</label>
                                    <textarea class="form-control" id="meta_description" name="meta_description">UlaStream</textarea>
                                </div>  

                            </div>

                            <div class="clearfix"></div>
                            
                        </div>
                    
                    </div>

                    <div class="box-footer">
                        <button type="reset" class="btn btn-warning">Reset</button>
                        
                        <button type="submit" class="btn btn-primary pull-right">Submit</button>                       
                    </div>

                </form>

            </div>
            <!-- SEO Settings ends -->

            <!-- OTHER Settings begins -->
            <div class="maxflix-tab-content active">
                
                <form action="https://apistream.ulademos.com/admin/settings" method="POST" enctype="multipart/form-data" r="" ole="form">
                            
                    <div class="box-body"> 
                        <div class="row"> 

                            <div class="col-md-12">

                                <h3 class="settings-sub-header text-uppercase"><b>Other Settings</b></h3>

                                <hr>

                            </div>

                            <div class="col-lg-12">

                                <div class="form-group">
                                    <label for="google_analytics">Google Analytics</label>
                                    <textarea class="form-control" id="google_analytics" name="google_analytics"></textarea>
                                </div>

                            </div> 

                            <div class="col-lg-12">

                                <div class="form-group">
                                    <label for="header_scripts">Header Scripts</label>
                                    <textarea class="form-control" id="header_scripts" name="header_scripts"></textarea>
                                </div>

                            </div> 

                            <div class="col-lg-12">

                                <div class="form-group">
                                    <label for="body_scripts">Body Scripts</label>
                                    <textarea class="form-control" id="body_scripts" name="body_scripts"></textarea>
                                </div>
                            </div> 

                            <div class="col-lg-6">

                                <div class="form-group">

                                    <label for="email_notification">Email Notification</label>
                                    <div class="clearfix"></div>

                                    <input type="checkbox" name="email_notification" value="1" id="email_notification" checked="">Send Email Notifications to User
                                </div>

                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="header_scripts">Social Email Suffix</label>
                                    <input type="text" class="form-control" id="email_suffix" name="social_email_suffix" value="@ulastream.uberlikeapp.com">
                                </div>
                            </div>
                            
                        </div>
                    </div>
                          <!-- /.box-body -->

                    <div class="box-footer">
                        <button type="reset" class="btn btn-warning">Reset</button>
                        
                        <button type="submit" class="btn btn-primary pull-right">Submit</button>                       
                    </div>

                </form>

            </div>

        </div>
    
    </div>
    
    <div class="clearfix"></div>

</div>

                
            </section>

        </div>

        <!-- include('layouts.admin.footer') -->

        <!-- include('layouts.admin.left-side-bar') -->

    </div>


    <!-- jQuery 2.2.0 -->
    <script src="admin-css/plugins/jQuery/jQuery-2.2.0.min.js"></script>
    <!-- Bootstrap 3.3.6 -->
    <script src="admin-css/bootstrap/js/bootstrap.min.js"></script>

    <script src="admin-css/plugins/datatables/jquery.dataTables.min.js"></script>

    <script src="admin-css/plugins/datatables/dataTables.bootstrap.min.js"></script>

    <!-- Select2 -->
    <script src="plugins/select2/select2.full.min.js"></script>
    <!-- InputMask -->
    <script src="admin-css/plugins/input-mask/jquery.inputmask.js"></script>
    <script src="admin-css/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>

    <script src="admin-css/plugins/input-mask/jquery.inputmask.extensions.js"></script>

    <!-- SlimScroll -->
    <script src="admin-css/plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="admin-css/plugins/fastclick/fastclick.js"></script>
    <!-- AdminLTE App -->
    <script src="admin-css/dist/js/app.min.js"></script>

    <!-- jvectormap -->
    <script src="admin-css/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>

    <script src="admin-css/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>

    <script src="admin-css/plugins/chartjs/Chart.min.js"></script>

    <!-- Datapicker -->
    <script src="admin-css/plugins/datepicker/bootstrap-datepicker.js"></script> 

    <script src="admin-css/plugins/tokenize2-1.1-dist/tokenize2.min.js"></script>

    <script src="admin-css/plugins/iCheck/icheck.min.js"></script>

    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <!-- <script src="https://apistream.ulademos.com/admin-css/dist/js/pages/dashboard2.js"></script> -->

    <script src="admin-css/dist/js/demo.js"></script>

    <!-- page script -->
    <script type="text/javascript">

        function loadFile(event,id){

            $('#'+id).show();

            var reader = new FileReader();

            reader.onload = function(){

                var output = document.getElementById(id);

                output.src = reader.result;
            };

            reader.readAsDataURL(event.files[0]);
        }

        $(document).ready(function(){
            $('#help-popover').popover({
                html : true, 
                content: function() {
                    return $('#help-content').html();
                } 
            });  
        });
        
        $(function () {

            $("#example1").DataTable();

            $("#datatable-withoutpagination").DataTable({
                 "paging": false,
                 "lengthChange": false,
                 "language": {
                       "info": ""
                }
            });
            
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false
            });
        });
    </script>

    
<script type="text/javascript">
    
    $(document).ready(function() {
        $("div.maxflix-tab-menu>div.list-group>a").click(function(e) {
            e.preventDefault();
            $(this).siblings('a.active').removeClass("active");
            $(this).addClass("active");
            var index = $(this).index();
            $("div.maxflix-tab>div.maxflix-tab-content").removeClass("active");
            $("div.maxflix-tab>div.maxflix-tab-content").eq(index).addClass("active");
        });
    });
</script>

    <script type="text/javascript">
         $("#settings").addClass("active"); 
         $("#site_settings").addClass("active");     </script>

    <script type="text/javascript">
        
        $(document).ready(function() {
            
            $('#expiry_date').datepicker({
                autoclose:true,
                format : 'dd-mm-yyyy',
                startDate: 'today',
            });
            
        });

    </script>
    <script type="text/javascript">
        
        $(function () {
            //Initialize Select2 Elements
            $(".select2").select2();

            //Datemask dd/mm/yyyy
            $("#datemask").inputmask("dd:mm:yyyy", {"placeholder": "hh:mm:ss"});
            //Datemask2 mm/dd/yyyy
            // $("#datemask2").inputmask("hh:mm:ss", {"placeholder": "hh:mm:ss"});
            //Money Euro
            $("[data-mask]").inputmask();

             //iCheck for checkbox and radio inputs
            $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
              checkboxClass: 'icheckbox_minimal-blue',
              radioClass: 'iradio_minimal-blue',
               increaseArea : '20%'
            });
            //Red color scheme for iCheck
            $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
              checkboxClass: 'icheckbox_minimal-red',
              radioClass: 'iradio_minimal-red',
               increaseArea : '20%'
            });
            //Flat red color scheme for iCheck
            $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
              checkboxClass: 'icheckbox_flat-green',
              radioClass: 'iradio_flat-green',
              increaseArea : '20%'

            });

             //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass: 'iradio_flat-green'
    });

        });
    </script>

    




</body></html>