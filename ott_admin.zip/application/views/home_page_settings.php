
        
        <div class="content-wrapper" style="min-height: 1217px;">

            <section class="content-header">
                <h1>Home Page Settings<small></small></h1>
                <ol class="breadcrumb">    <li><a href=""><i class="fa fa-dashboard"></i>Home</a></li>
    <li class="active"><i class="fa fa-gears"></i> Home Page Settings</li>
</ol>
            </section>

            <!-- Main content -->
            <section class="content">
                
                
                
    <div class="row">
    
        <div class="col-xs-12">

            <div class="box box-primary">
            
                <div class="nav-tabs-custom">

                    <div class="box-header with-border label-primary">

                        <h3 class="box-title">Settings</h3>

                    </div>

                    <div class="tab-content">
                       
                        <form action="https://apistream.ulademos.com/admin/settings" method="POST" enctype="multipart/form-data" role="form">

                            <div class="box-body">

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="home_banner_heading">Banner Heading</label>
                                        <input type="text" class="form-control" maxlength="80" name="home_banner_heading" value="See what's next." id="home_banner_heading" placeholder="Banner Heading">
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="home_banner_description">Banner Description</label>
                                        <textarea class="form-control" id="home_banner_description" maxlength="150" name="home_banner_description">WATCH ANYWHERE. CANCEL ANYTIME.</textarea>
                                    </div>
                                </div>

                                <div class="box-body">

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="home_about_site">About Site</label>
                                            <textarea class="form-control" id="home_about_site" name="home_about_site">ChillTv is programmed to start subscription based on-demand video streaming sites like Netflix and Amazon Prime. Any business idea with this core concept can be easily developed using Maxflix. From admin uploading a video to users making payment to users watching the videos, it’s all automated by a dynamic and responsive admin panel with multiple monetization channels.</textarea>
                                        </div>
                                    </div>

                                    <div class="col-lg-6">
                                         <div class="form-group">
                                            <label for="home_cancel_content">Cancel Content</label>
                                            <textarea class="form-control" id="home_cancel_content" name="home_cancel_content">If you decide Maxflix isn't for you - no problem. No commitment. Cancel online at anytime.</textarea>
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="form-group">                                       
                                            <label for="home_browse_desktop_image">Browse Desktop IMG</label>

                                            <br>

                                                                                            <img class="settings-img-preview " src="https://apistream.ulademos.com/uploads/settings/SV-2021-10-22-00-43-41-4a6769d9ce2e29a291ac767eed1f0a910d37c695.jpg" title="Browse Desktop IMG">
                                            
                                            <input type="file" id="home_browse_desktop_image" name="home_browse_desktop_image" accept="image/png, image/jpeg">
                                            <p class="help-block">Please enter .png .jpeg .jpg images only.</p>
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="home_browse_tv_image">Browse TV IMG</label>

                                            <br>

                                                                                            <img class="settings-img-preview " src="https://apistream.ulademos.com/uploads/settings/SV-2021-10-22-00-43-41-60464249e4845025a1246bc0d4e1b2b50bbd23c7.jpg" title="Browse TV IMG">
                                                                                        <input type="file" id="home_browse_tv_image" name="home_browse_tv_image" accept="image/png, image/jpeg">
                                            <p class="help-block">Please enter .png .jpeg .jpg images only.</p>
                                        </div>
                                    </div>

                                    <div class="col-md-4">

                                        <div class="form-group">
                                            <label for="home_browse_mobile_image">Browse Mobile IMG</label>

                                            <br>

                                                                                            <img class="settings-img-preview " src="https://apistream.ulademos.com/uploads/settings/SV-2021-10-22-00-43-41-5124ae5b705aa0b72d5b5e5410a2f33faab07a4a.jpg" title="Browse Mobile IMG">
                                            
                                            <input type="file" id="home_browse_mobile_image" name="home_browse_mobile_image" accept="image/png, image/jpeg">
                                            <p class="help-block">Please enter .png .jpeg .jpg images only.</p>
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="form-group">                                        
                                            <label for="home_cancel_image">Cancel IMG</label>
                                            <br>
                                                                                            <img class="settings-img-preview " src="https://apistream.ulademos.com/uploads/settings/SV-2021-10-22-00-43-41-91c26a8f15a0a5b4236f5ef5a72f418f242db184.jpg" title="Cancel IMG">
                                                                                        <input type="file" id="home_cancel_image" name="home_cancel_image" accept="image/png, image/jpeg">
                                            <p class="help-block">Please enter .png .jpeg .jpg images only.</p>
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="home_page_bg_image">Home Page BG</label>

                                            <br>

                                                                                            <img class="settings-img-preview " src="https://apistream.ulademos.com/uploads/settings/SV-2021-10-22-00-43-41-477668f43e1428aa7f5f9a23efaa1de4d40cdce2.jpg" title="">
                                            
                                            <input type="file" id="home_page_bg_image" name="home_page_bg_image" accept="image/png, image/jpeg">
                                            <p class="help-block">Please enter .png images only.</p>
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label for="common_bg_image">Common BG</label>
                                            <br>
                                                                                            <img class="settings-img-preview " src="https://apistream.ulademos.com/uploads/settings/SV-2021-10-22-00-43-41-c928fd237fdcfe8a00ac110d262152b4180e1d3b.jpg" title="">
                                                                                        <input type="file" id="common_bg_image" name="common_bg_image" accept="image/png, image/jpeg">
                                            <p class="help-block">Please enter .png images only.</p>
                                        </div>
                                    </div>

                                </div>

                                <div class="box-footer">
                               
                                    <button type="submit" class="btn btn-primary">Submit</button>
                               
                                </div>

                            </div>
                        
                        </form>
                    
                    </div>

                </div>

            </div>
    
        </div>

    </div>


                
            </section>

        </div>

        <!-- include('layouts.admin.footer') -->

        <!-- include('layouts.admin.left-side-bar') -->

    </div>


    <!-- jQuery 2.2.0 -->
    <script src="admin-css/plugins/jQuery/jQuery-2.2.0.min.js"></script>
    <!-- Bootstrap 3.3.6 -->
    <script src="admin-css/bootstrap/js/bootstrap.min.js"></script>

    <script src="admin-css/plugins/datatables/jquery.dataTables.min.js"></script>

    <script src="admin-css/plugins/datatables/dataTables.bootstrap.min.js"></script>

    <!-- Select2 -->
    <script src="admin-css/plugins/select2/select2.full.min.js"></script>
    <!-- InputMask -->
    <script src="admin-css/plugins/input-mask/jquery.inputmask.js"></script>
    <script src="admin-css/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>

    <script src="admin-css/plugins/input-mask/jquery.inputmask.extensions.js"></script>

    <!-- SlimScroll -->
    <script src="admin-css/plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="admin-css/plugins/fastclick/fastclick.js"></script>
    <!-- AdminLTE App -->
    <script src="admin-css/dist/js/app.min.js"></script>

    <!-- jvectormap -->
    <script src="admin-css/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>

    <script src="admin-css/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>

    <script src="admin-css/plugins/chartjs/Chart.min.js"></script>

    <!-- Datapicker -->
    <script src="admin-css/plugins/datepicker/bootstrap-datepicker.js"></script> 

    <script src="admin-css/plugins/tokenize2-1.1-dist/tokenize2.min.js"></script>

    <script src="admin-css/plugins/iCheck/icheck.min.js"></script>

    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <!-- <script src="https://apistream.ulademos.com/admin-css/dist/js/pages/dashboard2.js"></script> -->

    <script src="admin-css/dist/js/demo.js"></script>

    <!-- page script -->
    <script type="text/javascript">

        function loadFile(event,id){

            $('#'+id).show();

            var reader = new FileReader();

            reader.onload = function(){

                var output = document.getElementById(id);

                output.src = reader.result;
            };

            reader.readAsDataURL(event.files[0]);
        }

        $(document).ready(function(){
            $('#help-popover').popover({
                html : true, 
                content: function() {
                    return $('#help-content').html();
                } 
            });  
        });
        
        $(function () {

            $("#example1").DataTable();

            $("#datatable-withoutpagination").DataTable({
                 "paging": false,
                 "lengthChange": false,
                 "language": {
                       "info": ""
                }
            });
            
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false
            });
        });
    </script>

    
    <script type="text/javascript">
         $("#settings").addClass("active"); 
         $("#home_page_settings").addClass("active");     </script>

    <script type="text/javascript">
        
        $(document).ready(function() {
            
            $('#expiry_date').datepicker({
                autoclose:true,
                format : 'dd-mm-yyyy',
                startDate: 'today',
            });
            
        });

    </script>
    <script type="text/javascript">
        
        $(function () {
            //Initialize Select2 Elements
            $(".select2").select2();

            //Datemask dd/mm/yyyy
            $("#datemask").inputmask("dd:mm:yyyy", {"placeholder": "hh:mm:ss"});
            //Datemask2 mm/dd/yyyy
            // $("#datemask2").inputmask("hh:mm:ss", {"placeholder": "hh:mm:ss"});
            //Money Euro
            $("[data-mask]").inputmask();

             //iCheck for checkbox and radio inputs
            $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
              checkboxClass: 'icheckbox_minimal-blue',
              radioClass: 'iradio_minimal-blue',
               increaseArea : '20%'
            });
            //Red color scheme for iCheck
            $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
              checkboxClass: 'icheckbox_minimal-red',
              radioClass: 'iradio_minimal-red',
               increaseArea : '20%'
            });
            //Flat red color scheme for iCheck
            $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
              checkboxClass: 'icheckbox_flat-green',
              radioClass: 'iradio_flat-green',
              increaseArea : '20%'

            });

             //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass: 'iradio_flat-green'
    });

        });
    </script>

    




</body></html>