
<!DOCTYPE html>
<html>


<!-- Mirrored from apistream.ulademos.com/admin/login by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 16 Nov 2021 05:36:41 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title> Login </title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.6 -->
    <link rel="stylesheet" href="admin-css/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="../../cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="admin-css/bootstrap/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="admin-css/dist/css/AdminLTE.min.css">
    <link rel="stylesheet" href="admin-css/dist/css/custom.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="admin-css/plugins/iCheck/square/blue.css">

    <link rel="shortcut icon" href="../../apistream.uberlikeapp.com/uploads/settings/SV-2021-11-03-01-24-25-c7f2228ebf0fb26864a9c26d67ae4476438a1c75.jpg">

<style type="text/css">
body {
    background: #000 !important; 

}
</style>




    
    <style>

        .admin-login-page {
            background-image: url("../admin-bg.html");
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-size: 100%;
        }
    </style>

</head>

<body class="hold-transition login-page">

    <div class="admin-login-page">
    
        <div class="col-md-6 col-md-offset-3">

            
        </div>

        <div class="login-box ">

            <div class="login-logo">
                 <a href="<?php echo base_url(''); ?>"><b> 
                    <img class="adm-log-logo" style="width:50%;height:auto" src="SV-2021-11-03-01-24-25-e408f89fe0c10d860f0e715b7fbe7e8c54bee454.jpg" /></b></a>
            </div>

            
    <div class="login-box-body" style="height:275px;">


        <form class="form-layout" role="form" method="POST" action="admin/login">
            <input type="hidden" name="_token" value="xUZX9HOf8JsATrqAVAuvHQC08Id2MyCrQrNhwvKj">

            <div class="login-logo">
               <input type="hidden" name="timezone" value="" id="userTimezone">
            </div>

            <p class="text-center mb30"></p>

            <div class="form-inputs">
                <div class="form-group">

                    <input type="email" class="form-control input-lg" value="admin@gmail.com" name="email"  required placeholder="Email">

                    
                </div>

                <div class="form-group">

                    <input type="password" class="form-control input-lg" value="123456" required name="password" placeholder="Password" >

                    
                </div>


            </div>
 </form>
            <div class="col-md-12 " style="display: flex;">
        <!--         <button class="btn btn-success btn-block mb15" type="submit">
                    <h5><span><i class="fa fa-btn fa-sign-in"></i> Login</span></h5>
                </button> -->
               <button class="btn btn-success btn-block mb15" style="margin-left: 10px;"><a href="<?php echo base_url('home'); ?>">
                    <h5><span><i class="fa fa-btn fa-sign-in"></i> Login</span></h5></a>
                </button>
             
            </div>

            <div class="clearfix"></div>

        <!-- </form> -->
        <br>
<!--    <button class="btn btn-success btn-block mb15" style="margin-left: 10px;"><a href="<?php echo base_url('home'); ?>">
                    <h5><span><i class="fa fa-btn fa-sign-in"></i> Skip</span></h5></a>
                </button> -->
    </div>


        </div>

    </div>

    <!-- jQuery 2.2.0 -->
    <script src="admin-css/plugins/jQuery/jQuery-2.2.0.min.js"></script>
    <!-- Bootstrap 3.3.6 -->
    <script src="admin-css/bootstrap/js/bootstrap.min.js"></script>
    <!-- iCheck -->
    <script src="admin-css/plugins/iCheck/icheck.min.js"></script>

    <script>
        $(function () {
            $('input').iCheck({
              checkboxClass: 'icheckbox_square-blue',
              radioClass: 'iradio_square-blue',
              increaseArea: '20%' // optional
            });
        });
    </script>

    
<script src="../assets/js/jstz.min.js"></script>
<script>
    
    $(document).ready(function() {

        var dMin = new Date().getTimezoneOffset();
        var dtz = -(dMin/60);
        // alert(dtz);
        $("#userTimezone").val(jstz.determine().name());
    });

</script>

</body>


<!-- Mirrored from apistream.ulademos.com/admin/login by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 16 Nov 2021 05:36:49 GMT -->
</html>

