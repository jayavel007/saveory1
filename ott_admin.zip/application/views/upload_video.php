
    
    <link rel="stylesheet" href="assets/css/wizard.css">

    <link rel="stylesheet" href="assets/css/jquery.jbswizard.min.css">

    <link rel="stylesheet" href="assets/css/style.css">

    <link rel="stylesheet" href="admin-css/plugins/bootstrap-datetimepicker/css/bootstrap-datetimepicker.min.css">

    <link rel="stylesheet" href="assets/css/imgareaselect-default.css">

    <link rel="stylesheet" href="assets/css/jquery.awesome-cropper.css">

    <link rel="stylesheet" href="admin-css/plugins/iCheck/all.css">

  

    <style type="text/css">
        
        .container-narrow {
          margin: 150px auto 50px auto;
          max-width: 728px;
        }

        canvas{
            width: 100%;
            height: auto;
        }
        span.select2-container{
            width:100% !important;
        }

        .select2-container--default .select2-selection--multiple .select2-selection__choice {
            margin-bottom: 10px;
            width: 30%;
        }

        .select2-container .select2-search--inline {
            border: 1px solid #d2d6df !important;
            width: 30%;
        }

    </style>


<div class="content-wrapper" style="min-height: 1277px;">
	<section class="content-header">
		<h1>Upload Video<small></small></h1>
		<ol class="breadcrumb"></ol>
	</section>
	<!-- Main content -->
	<section class="content">
		<div>
			<div class="main-content">
				<button class="btn btn-primary" data-toggle="modal" data-target="#myModal" style="display: none" id="error_popup">popup</button>
				<!-- popup -->
				<div class="modal fade error-popup" id="myModal" role="dialog">
					<div class="modal-dialog">
						<div class="modal-content">
							<div class="modal-body">
								<div class="media">
									<div class="media-left"> <img src="https://apistream.ulademos.com/images/warning.jpg" class="media-object" style="width:60px"> </div>
									<div class="media-body">
										<h4 class="media-heading">Information</h4>
										<p id="error_messages_text"></p>
									</div>
								</div>
								<div class="text-right">
									<button type="button" class="btn btn-primary top" data-dismiss="modal">Okay</button>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div id="example">
					<div class="example-wizard panel panel-primary">
						<div class="">
							<!-- Example Wizard START -->
							<div id="j-bs-wizard-example" class="j-bs-wizard js-bs-wizard--initialized">
								<ul class="nav nav-tabs nav-justified j-bs-wizard--steps" role="tablist">
									<li role="presentation" class="active j-bs-wizard--steps-item"> <a href="#first" role="tab" data-toggle="tab">Video Details</a> </li>
									<!-- <li role="presentation" class="j-bs-wizard--steps-item undone"> <a href="#second" role="tab" data-toggle="">Category</a> </li>
									<li role="presentation" class="j-bs-wizard--steps-item undone"> <a href="#third" role="tab" data-toggle="">Sub Category</a> </li> -->
									<li role="presentation" class="j-bs-wizard--steps-item undone"> <a href="#fourth" role="tab" data-toggle="">Upload Video / Image</a> </li>
								</ul>
							<form method="post" enctype="multipart/form-data" id="upload_video_form" action="">
									<div class="tab-content j-bs-wizard--steps-content">
										<div class="progress j-bs-wizard--progress">
											<div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div>
										</div>
										<!-- tab1 -->
										<div role="tabpanel" class="tab-pane fade in active j-bs-wizard--steps-content-item" id="first">
											<p class="note-sec">Note: <span class="asterisk"><i class="fa fa-asterisk"></i></span> fields are mandatory. Please fill and click next.
												<input type="hidden" name="admin_video_id" id="admin_video_id" value="">
												<!--  <a href="#" data-toggle="tooltip" title="Hooray!" data-placement="right">Note</a> --></p>
											<ul class="form-style-7">
												<li>
													<label for="title">Title <span class="asterisk"><i class="fa fa-asterisk"></i></span> </label>
													<input type="text" name="title" maxlength="100" value="" id="title"> </li>
												<li>
													<label for="age">Year Of Release <span class="asterisk"><i class="fa fa-asterisk"></i></span></label>
													<input type="text" name="year_of_release" maxlength="4" value="" id="age"> </li>
												<li>
													<label for="duration">Trailer Duration <span class="asterisk"><i class="fa fa-asterisk"></i></span>(hh:mm:ss)</label>
													<input type="text" name="trailer_duration" maxlength="16" data-inputmask="'alias': 'hh:mm:ss'" data-mask="" value="" id="trailer_duration"> </li>
												<li>
													<label for="duration">Main Video Duration <span class="asterisk"><i class="fa fa-asterisk"></i></span>(hh:mm:ss)</label>
													<input type="text" name="duration" maxlength="16" data-inputmask="'alias': 'hh:mm:ss'" data-mask="" value="" id="duration"> </li>
														<li>
													<label >Category <span class="asterisk"><i class="fa fa-asterisk"></i></span></label>
											
													<select name="category_id">
														<option value="">Choose</option>
													<?php
													
													foreach($categoryList as $row){
															?>
															<option value="<?= $row['category_id'] ?>"><?= $row['category_name'] ?></option>
															<?php
													}
													
													?>	
													</select>
												</li>
												<li class="cast-list">
													<label for="details">Moview/Series &amp; Type </label>
													<select id="movie_type_id" name="movie_type_id[]" class="select2 select2-hidden-accessible" multiple="" tabindex="-1" aria-hidden="true">
													<option value="">Choose</option>
													<?php
													
													foreach($movieTypeList as $row){
															?>
															<option value="<?= $row['movie_type_id'] ?>"><?= $row['movie_type_name'] ?></option>
															<?php
													}
													
													?>	
													<!-- <option value="1">Hollywood</option>
														<option value="2">Bollywood</option>
														<option value="3">KollyWood</option>
														<option value="4">Tollywood</option>
														<option value="5">South Indian Movies</option> -->
													</select><span class="select2 select2-container select2-container--default" dir="ltr" style="width: 1029px;"><span class="selection"><span class="select2-selection select2-selection--multiple" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="-1"><ul class="select2-selection__rendered"><li class="select2-search select2-search--inline"><input class="select2-search__field" type="search" tabindex="0" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" role="textbox" aria-autocomplete="list" placeholder="" style="width: 0.75em;"></li></ul></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
												</li>
												<li class="cast-list">
													<label for="details">Genre </label>
													<select id="genre_id" name="genre_id[]" class="select2 select2-hidden-accessible" multiple="" tabindex="-1" aria-hidden="true">
													<option value="">Choose</option>
													<?php
													
													foreach($genreList as $row){
															?>
															<option value="<?= $row['genre_id'] ?>"><?= $row['genre_name'] ?></option>
															<?php
													}
													
													?>	
													</select><span class="select2 select2-container select2-container--default" dir="ltr" style="width: 1029px;"><span class="selection"><span class="select2-selection select2-selection--multiple" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="-1"><ul class="select2-selection__rendered"><li class="select2-search select2-search--inline"><input class="select2-search__field" type="search" tabindex="0" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" role="textbox" aria-autocomplete="list" placeholder="" style="width: 0.75em;"></li></ul></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
												</li>
													<!-- <li>
													<label for="duration">Sub Category <span class="asterisk"><i class="fa fa-asterisk"></i></span></label>
											
													<select>
														<option>test</option>
															<option>test3</option>
																<option>test2</option>
													</select>
												</li> -->
											<!-- 	 <li>
                                                <label for="description">Description <span class="asterisk"><i class="fa fa-asterisk"></i></span></label>

                                                <textarea name="description"  class="height-122" id="description"></textarea>
                                            </li> -->
												<li class="height-54">
													<label for="reviews">Ratings <span class="asterisk"><i class="fa fa-asterisk"></i></span></label>
													<div class="starRating">
														<input id="rating5" type="radio" name="ratings" value="5">
														<label for="rating5">5</label>
														<input id="rating4" type="radio" name="ratings" value="4">
														<label for="rating4">4</label>
														<input id="rating3" type="radio" name="ratings" value="3">
														<label for="rating3">3</label>
														<input id="rating2" type="radio" name="ratings" value="2">
														<label for="rating2">2</label>
														<input id="rating1" type="radio" name="ratings" value="1">
														<label for="rating1">1</label>
													</div>
												</li>
												<li class="height-54">
													<label for="reviews">Publish Type <span class="asterisk"><i class="fa fa-asterisk"></i></span></label>
													<div class="publish">
														<div class="radio radio-primary radio-inline">
															<input type="radio" id="now" value="1" name="publish_type" onchange="checkPublishType(this.value)" checked="">
															<label for="now"> Now </label>
														</div>
														<div class="radio radio-primary radio-inline">
															<input type="radio" id="later" value="2" name="publish_type" onchange="checkPublishType(this.value)">
															<label for="later"> Later </label>
														</div>
													</div>
												</li>
												<li id="time_li" style="display: none;width: 98%;">
													<label for="time">Publish Time <span class="asterisk"><i class="fa fa-asterisk"></i></span></label>
													<input type="text" name="publish_time" id="datepicker" value="" readonly=""> </li>
												<li>
													<label for="description">Description <span class="asterisk"><i class="fa fa-asterisk"></i></span></label>
													<textarea name="description" rows="4"></textarea>
												</li>
												<!-- <li>
													<label for="details">Details <span class="asterisk"><i class="fa fa-asterisk"></i></span></label>
													<textarea name="details" rows="4" id="details"></textarea>
												</li> -->
												<li style="width: 98%" class="cast-list">
													<label for="details">Cast &amp; Crews </label>
													<select id="cast_crews" name="cast_crew_id[]" class="select2 select2-hidden-accessible" multiple="" tabindex="-1" aria-hidden="true">
														<option value="1">Johnny Depp</option>
														<option value="2">Robert John Downey Jr</option>
														<option value="3">Chris Evans</option>
														<option value="4">Chris Hemsworth</option>
														<option value="5">Scarlett Johansson</option>
														<option value="6">Justin Bieber</option>
														<option value="7">Kids</option>
														<option value="8">Daniel</option>
														<option value="9">Joshua Dualan</option>
														<option value="10">Hansel Sumacaton</option>
														<option value="11">Janella Salvador</option>
														<option value="12">Elmo Magalona</option>
														<option value="13">Jo Jung-suk</option>
														<option value="14">Do Kyung-soo</option>
														<option value="15">Ha Jung-woo</option>
														<option value="16">Bae Doona</option>
														<option value="17">Oh Dal-su</option>
														<option value="18">Thiti Mahayotaruk</option>
														<option value="19">Sutatta Udomsilp</option>
														<option value="20">Thanapob Leeratanakajorn</option>
														<option value="21">Baifern Pimchanok</option>
														<option value="22">Nadech Kugimiya</option>
														<option value="23">Sunny Suwanmethanont</option>
														<option value="24">Preechaya Pongthananikorn</option>
														<option value="25">Esther Supreeleela</option>
														<option value="26">Natthawat Chainarongsophon</option>
														<option value="27">Sarah Geronimo</option>
														<option value="28">Xian Lim</option>
											
													</select><span class="select2 select2-container select2-container--default" dir="ltr" style="width: 1029px;"><span class="selection"><span class="select2-selection select2-selection--multiple" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="-1"><ul class="select2-selection__rendered"><li class="select2-search select2-search--inline"><input class="select2-search__field" type="search" tabindex="0" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" role="textbox" aria-autocomplete="list" placeholder="" style="width: 0.75em;"></li></ul></span></span><span class="dropdown-wrapper" aria-hidden="true"></span></span>
												</li>
											</ul>
											<div class="clearfix"></div>
											<br>
											<div class="j-bs-wizard--action-btn-set clearfix"><span class="btn btn-primary j-bs-wizard--action-btn-next pull-right "><i class="j-bs-wizard--arrow j-bs-wizard--arrow-right" aria-hidden="true"></i> Next</span></div>
										</div>
								
						

										<!-- tab4 -->
										<div role="tabpanel" class="tab-pane fade j-bs-wizard--steps-content-item" id="fourth">
											<p class="note-sec">Note: <span class="asterisk"><i class="fa fa-asterisk"></i></span> fields are mandatory. Please fill and click next. </p>
										
											<!-- upload  video section -->
											<ul class="form-style-7 manual_video_upload">
											<li>
													<label for="duration">Language <span class="asterisk"><i class="fa fa-asterisk"></i></span></label>
											
													<select name="language_id">
														<option value="">Choose</option>
													<?php
													foreach($languageList as $row){
															?>
															<option value="<?= $row['language_id'] ?>"><?= $row['language_name'] ?></option>
															<?php
													}
													
													?>	
													</select>
												</li>
												<!-- video -->
												<li>
													<label for="title">Video <span class="asterisk"><i class="fa fa-asterisk"></i></span> </label>
													<p class="img-note mb-10">Please enter .mp4, .avi, .mov videos only.</p>
													<div class="">
														<div class="">
															<label class="">
																<input type="file" name="video" accept="video/mp4,video/x-matroska, .avi, .mov" id="video" required=""> </label>
														</div>
													</div>
												</li>
												<li>
													<label for="title">Trailer Video <span class="asterisk"><i class="fa fa-asterisk"></i></span> </label>
													<p class="img-note mb-10">Please enter .mp4, .avi, .mov videos only.</p>
													<div class="">
														<div class="">
															<label class="">
																<input type="file" name="trailer_video" accept="video/mp4,video/x-matroska, .avi, .mov" id="trailer_video"> </label>
														</div>
													
												</div>
												</li>
												<li>
													<label for="title">Subtitle</label>
													<p class="img-note mb-10">The video subtitle must be a file of type: srt.</p>
													<div class="">
														<div class="">
															<label class="">
																<input id="video_subtitle" type="file" name="video_subtitle" onchange="checksrt(this, this.id)"> </label>
														</div>
													
												</div>
												</li>
											
											</ul>
											<!-- upload  video section -->
											<ul class="form-style-7 others" style="display: none;">
												<!-- video -->
												<li>
													<label for="trailer_video"> Trailer Video <span class="asterisk"><i class="fa fa-asterisk"></i></span> </label>
													<input type="url" name="trailer_video" maxlength="256" id="other_trailer_video"> </li>
												<li>
													<label for="video">Video <span class="asterisk"><i class="fa fa-asterisk"></i></span> </label>
													<input type="url" name="video" maxlength="256" id="other_video"> </li>
											</ul>
											<div class="clearfix"></div>
											<div style="margin: 10px;">
												<div class="row">
													<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
														<div class="checkbox checkbox-inline checkbox-primary">
															<input type="checkbox" value="1" name="send_notification" checked="" id="send_notification">
															<label for="send_notification">Send Notification</label>
														</div>
													</div>
													<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
														<div class="checkbox checkbox-inline checkbox-primary">
															<input type="checkbox" value="1" name="is_kids_video" id="is_kids_video">
															<label for="is_kids_video">Mark as Kids Video</label>
														</div>
													</div>
												</div>
											</div>
											<!-- select image section -->
											<div>
												<div class="row">
													<div class="col-xs-12 col-sm-6 col-md-4 image-upload">
														<label>Default image <span class="asterisk"><i class="fa fa-asterisk"></i></span> </label>
														<input type="file" id="default_image" accept=".png" name="default_image" placeholder="Default image" style="display:none" onchange="loadFile(this,'default_img')"> <img src="https://apistream.ulademos.com/images/default.png" onclick="$('#default_image').click();return false;" id="default_img">
														<!-- <div id="default_image"></div> -->
														<p class="img-note">Please enter .png images only. Upload Rectangle images 4:3 Ratio Ex: 400 * 300</p>
													</div>
													<div class="col-xs-12 col-sm-6 col-md-4 image-upload">
														<label>Other Image 1 <span class="asterisk"><i class="fa fa-asterisk"></i></span> </label>
														<input type="file" id="other_image1" accept=".png" name="other_image1" placeholder="Other Image 1" style="display:none" onchange="loadFile(this,'other_img1')"> <img src="https://apistream.ulademos.com/images/default.png" onclick="$('#other_image1').click();return false;" id="other_img1">
														<!-- <div id="other_image1"></div> -->
														<p class="img-note">Please enter .png images only. Upload Rectangle images 4:3 Ratio Ex: 400 * 300</p>
													</div>
													<div class="col-xs-12 col-sm-6 col-md-4 image-upload">
														<label>Other Image 2 <span class="asterisk"><i class="fa fa-asterisk"></i></span> </label>
														<input type="file" id="other_image2" accept=".png" name="other_image2" placeholder="Other Image 2" style="display:none" onchange="loadFile(this,'other_img2')"> <img src="https://apistream.ulademos.com/images/default.png" onclick="$('#other_image2').click();return false;" id="other_img2">
														<!-- <div id="other_image2"></div> -->
														<p class="img-note">Please enter .png images only. Upload Rectangle images 4:3 Ratio Ex: 400 * 300</p>
													</div>
													<div class="col-xs-12 col-sm-6 col-md-4 image-upload">
														<label>Mobile Image</label>
														<input type="file" id="mobile_image" accept=".png, .jpg, .jpeg" name="mobile_image" placeholder="Mobile Image" style="display:none" onchange="loadFile(this,'mobile_image_1')">
														<div class="clearfix"></div> <img src="https://apistream.ulademos.com/images/default.png" onclick="$('#mobile_image').click();return false;" id="mobile_image_1" style="width: 50%;height: 200px;">
														<p class="img-note">Upload only .png, .jpg or .jpeg image files. Image Ratio 2:1 (200 * 100px)</p>
													</div>
												</div>
												<div class="progress">
													<div class="bar"></div>
													<div class="percent">0%</div>
												</div>
												<div class="clearfix"></div>
												<button class="btn  btn-primary finish-btn" type="button" onclick="saveVideo()" id="finish_video"><i class="fa fa-arrow-right" aria-hidden="true"></i> &nbsp; Finish</button>
											</div>
											<div class="j-bs-wizard--action-btn-set clearfix"><span class="btn btn-default j-bs-wizard--action-btn-prev "><i class="j-bs-wizard--arrow j-bs-wizard--arrow-left" aria-hidden="true"></i> Previous</span></div>
										</div>
										<!-- tab4 -->
									</div>
									<input type="hidden" name="timezone" value="Asia/Kolkata"> </form>
								<div class="j-bs-wizard--processing panel panel-default">
									<div class="j-bs-wizard--spinner">
										<div class="j-bs-wizard--spinner1 j-bs-wizard--spinner-child"></div>
										<div class="j-bs-wizard--spinner2 j-bs-wizard--spinner-child"></div>
										<div class="j-bs-wizard--spinner3 j-bs-wizard--spinner-child"></div>
										<div class="j-bs-wizard--spinner4 j-bs-wizard--spinner-child"></div>
										<div class="j-bs-wizard--spinner5 j-bs-wizard--spinner-child"></div>
										<div class="j-bs-wizard--spinner6 j-bs-wizard--spinner-child"></div>
										<div class="j-bs-wizard--spinner7 j-bs-wizard--spinner-child"></div>
										<div class="j-bs-wizard--spinner8 j-bs-wizard--spinner-child"></div>
										<div class="j-bs-wizard--spinner9 j-bs-wizard--spinner-child"></div>
										<div class="j-bs-wizard--spinner10 j-bs-wizard--spinner-child"></div>
										<div class="j-bs-wizard--spinner11 j-bs-wizard--spinner-child"></div>
										<div class="j-bs-wizard--spinner12 j-bs-wizard--spinner-child"></div>
									</div><span class="sr-only">Loading...</span></div>
							</div>
							<!-- Example Wizard END -->
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="overlay">
			<div id="loading-img"></div>
		</div>
	</section>
</div>
<!-- include('layouts.admin.footer') -->

    <!-- jQuery 2.2.0 -->
    <script src="admin-css/plugins/jQuery/jQuery-2.2.0.min.js"></script>
    <!-- Bootstrap 3.3.6 -->
    <script src="admin-css/bootstrap/js/bootstrap.min.js"></script>

    <script src="admin-css/plugins/datatables/jquery.dataTables.min.js"></script>

    <script src="admin-css/plugins/datatables/dataTables.bootstrap.min.js"></script>

    <!-- Select2 -->
    <script src="admin-css/plugins/select2/select2.full.min.js"></script>
    <!-- InputMask -->
    <script src="admin-css/plugins/input-mask/jquery.inputmask.js"></script>
    <script src="admin-css/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>

    <script src="admin-css/plugins/input-mask/jquery.inputmask.extensions.js"></script>

    <!-- SlimScroll -->
    <script src="admin-css/plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="admin-css/plugins/fastclick/fastclick.js"></script>
    <!-- AdminLTE App -->
    <script src="admin-css/dist/js/app.min.js"></script>

    <!-- jvectormap -->
    <script src="admin-css/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>

    <script src="admin-css/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>

    <script src="admin-css/plugins/chartjs/Chart.min.js"></script>

    <!-- Datapicker -->
    <script src="admin-css/plugins/datepicker/bootstrap-datepicker.js"></script> 

    <script src="admin-css/plugins/tokenize2-1.1-dist/tokenize2.min.js"></script>

    <script src="admin-css/plugins/iCheck/icheck.min.js"></script>

    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <!-- <script src="https://apistream.ulademos.com/admin-css/dist/js/pages/dashboard2.js"></script> -->

    <script src="admin-css/dist/js/demo.js"></script>

<!-- page script -->
<script type="text/javascript">
function loadFile(event, id) {
	$('#' + id).show();
	var reader = new FileReader();
	reader.onload = function() {
		var output = document.getElementById(id);
		output.src = reader.result;
	};
	reader.readAsDataURL(event.files[0]);
}
$(document).ready(function() {
	$('#help-popover').popover({
		html: true,
		content: function() {
			return $('#help-content').html();
		}
	});
});
$(function() {
	$("#example1").DataTable();
	$("#datatable-withoutpagination").DataTable({
		"paging": false,
		"lengthChange": false,
		"language": {
			"info": ""
		}
	});
	$('#example2').DataTable({
		"paging": true,
		"lengthChange": false,
		"searching": false,
		"ordering": true,
		"info": true,
		"autoWidth": false
	});
});
</script>

<script src="admin-css/plugins/bootstrap-datetimepicker/js/moment.min.js"></script>
<script src="admin-css/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js"></script>
<script src="admin-css/plugins/iCheck/icheck.min.js"></script>
<script src="assets/js/jquery.jbswizard.min.js"></script>
<script src="assets/js/jbswizard.js"></script>
<script src="admin-css/plugins/jquery.form.js"></script>
<script src="assets/js/jquery.awesome-cropper.js"></script>
<script src="assets/js/jquery.imgareaselect.js"></script>



<script>
$(document).ready(function() {
	$('[data-toggle="tooltip"]').tooltip();
});
</script>

<script src="assets/js/upload-video.js"></script>
<script type="text/javascript">
// $('.multipleSelect').select2();
var banner_image = "";
var cat_url = "https://apistream.ulademos.com/select/sub_category";
var step3 = "3";
var sub_cat_url = "https://apistream.ulademos.com/select/genre";
var final = "4";
var video_id = "";
var genreId = "";
var video_type = "";
var view_video_url = "https://apistream.ulademos.com/admin/videos/view?id=";
$('#datepicker').datetimepicker({
	minDate: moment(),
	autoclose: true,
	format: 'dd-mm-yyyy hh:ii',
});
$('.manual_video_upload').show();
$('.others').hide();
$("#video_upload").change(function() {
	$(".manual_video_upload").show();
	$(".others").hide();
});
$("#youtube").change(function() {
	$(".others").show();
	$(".manual_video_upload").hide();
});
$("#other_link").change(function() {
	$(".others").show();
	$(".manual_video_upload").hide();
});

function videoUploadType(value, autoload_status) {
	// On initialization, show others videos section
	$(".others").show();
	$("#other_video").attr('required', true);
	$("#other_trailer_video").attr('required', true);
	if(autoload_status == 0) {
		$("#video").attr('required', true);
		$("#trailer_video").attr('required', true);
	}
	$(".manual_video_upload").hide();
	$("#other_video").val("");
	$("#other_trailer_video").val("");
	if(value == "1") {
		$("#other_video").val("");
		$("#other_trailer_video").val("");
		$(".manual_video_upload").show();
		$(".others").hide();
		$("#other_video").attr('required', false);
		$("#other_trailer_video").attr('required', false);
		// If admin editing the video means remove the required fields for video & trailer video (If already in VIDEO_TYPE_UPLOAD)
	}
	if((value == "3" || value == "2") && autoload_status == 0) {
		$("#other_video").val("");
		$("#other_trailer_video").val("");
		if(("" == value) || ("" == value)) {
			$("#other_video").val("");
			$("#other_trailer_video").val("");
		}
		$("#video").attr('required', false);
		$("#trailer_video").attr('required', false);
	}
	if((value == "3" || value == "2") && autoload_status == 0) {
		$("#other_video").val("");
		$("#other_trailer_video").val("");
	}
}
 function saveVideo() {

     var formData = new FormData($('#upload_video_form')[0]);
    // alert(formData);
     $.ajax({

         type : 'post',

        //  url : "https://apistream.ulademos.com/admin/videos/save",
		 url: "<?= base_url('Video/uploadVideo') ?>",

         data : formData,

         contentType :false,

         processData:false,

         beforeSend : function(data) {

             $("#finish_video").attr('disabled', true);

         },
         success : function(data) {

			console.log(data);

            //  if (data.response.success) {

            //      window.location.href= ""+data.response.data.id;

            //  } else {

            //      $("#error_messages_text").html(data.response.error_messages);

            //      $("#error_popup").click();

            //  }

         },

         error : function(data) {


         },

         complete : function(data) {

             $("#finish_video").attr('disabled', false);

         }

     });

 }
function checkPublishType(val) {
	$("#time_li").hide();
	//$("#datepicker").prop('required',false);
	$("#datepicker").val("");
	if(val == 2) {
		$("#time_li").show();
		// $("#datepicker").prop('required',true);
	}
}
</script>
<div class="datetimepicker datetimepicker-dropdown-bottom-right dropdown-menu" style="left: 0px; z-index: 10039;">
	<div class="datetimepicker-minutes" style="display: none;">
		<table class=" table-condensed">
			<thead>
				<tr>
					<th class="prev" style="visibility: visible;"><i class="icon-arrow-left"></i></th>
					<th colspan="5" class="switch">16 November 2021</th>
					<th class="next" style="visibility: visible;"><i class="icon-arrow-right"></i></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td colspan="7"><span class="minute">15:00</span><span class="minute active">15:05</span><span class="minute">15:10</span><span class="minute">15:15</span><span class="minute">15:20</span><span class="minute">15:25</span><span class="minute">15:30</span><span class="minute">15:35</span><span class="minute">15:40</span><span class="minute">15:45</span><span class="minute">15:50</span><span class="minute">15:55</span></td>
				</tr>
			</tbody>
			<tfoot>
				<tr>
					<th colspan="7" class="today" style="display: none;">Today</th>
				</tr>
			</tfoot>
		</table>
	</div>
	<div class="datetimepicker-hours" style="display: none;">
		<table class=" table-condensed">
			<thead>
				<tr>
					<th class="prev" style="visibility: visible;"><i class="icon-arrow-left"></i></th>
					<th colspan="5" class="switch">16 November 2021</th>
					<th class="next" style="visibility: visible;"><i class="icon-arrow-right"></i></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td colspan="7"><span class="hour">0:00</span><span class="hour">1:00</span><span class="hour">2:00</span><span class="hour">3:00</span><span class="hour">4:00</span><span class="hour">5:00</span><span class="hour">6:00</span><span class="hour">7:00</span><span class="hour">8:00</span><span class="hour">9:00</span><span class="hour">10:00</span><span class="hour">11:00</span><span class="hour">12:00</span><span class="hour">13:00</span><span class="hour">14:00</span><span class="hour active">15:00</span><span class="hour">16:00</span><span class="hour">17:00</span><span class="hour">18:00</span><span class="hour">19:00</span><span class="hour">20:00</span><span class="hour">21:00</span><span class="hour">22:00</span><span class="hour">23:00</span></td>
				</tr>
			</tbody>
			<tfoot>
				<tr>
					<th colspan="7" class="today" style="display: none;">Today</th>
				</tr>
			</tfoot>
		</table>
	</div>
	<div class="datetimepicker-days" style="display: block;">
		<table class=" table-condensed">
			<thead>
				<tr>
					<th class="prev" style="visibility: visible;"><i class="icon-arrow-left"></i></th>
					<th colspan="5" class="switch">November 2021</th>
					<th class="next" style="visibility: visible;"><i class="icon-arrow-right"></i></th>
				</tr>
				<tr>
					<th class="dow">Su</th>
					<th class="dow">Mo</th>
					<th class="dow">Tu</th>
					<th class="dow">We</th>
					<th class="dow">Th</th>
					<th class="dow">Fr</th>
					<th class="dow">Sa</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td class="day old">31</td>
					<td class="day">1</td>
					<td class="day">2</td>
					<td class="day">3</td>
					<td class="day">4</td>
					<td class="day">5</td>
					<td class="day">6</td>
				</tr>
				<tr>
					<td class="day">7</td>
					<td class="day">8</td>
					<td class="day">9</td>
					<td class="day">10</td>
					<td class="day">11</td>
					<td class="day">12</td>
					<td class="day">13</td>
				</tr>
				<tr>
					<td class="day">14</td>
					<td class="day">15</td>
					<td class="day active">16</td>
					<td class="day">17</td>
					<td class="day">18</td>
					<td class="day">19</td>
					<td class="day">20</td>
				</tr>
				<tr>
					<td class="day">21</td>
					<td class="day">22</td>
					<td class="day">23</td>
					<td class="day">24</td>
					<td class="day">25</td>
					<td class="day">26</td>
					<td class="day">27</td>
				</tr>
				<tr>
					<td class="day">28</td>
					<td class="day">29</td>
					<td class="day">30</td>
					<td class="day new">1</td>
					<td class="day new">2</td>
					<td class="day new">3</td>
					<td class="day new">4</td>
				</tr>
				<tr>
					<td class="day new">5</td>
					<td class="day new">6</td>
					<td class="day new">7</td>
					<td class="day new">8</td>
					<td class="day new">9</td>
					<td class="day new">10</td>
					<td class="day new">11</td>
				</tr>
			</tbody>
			<tfoot>
				<tr>
					<th colspan="7" class="today" style="display: none;">Today</th>
				</tr>
			</tfoot>
		</table>
	</div>
	<div class="datetimepicker-months" style="display: none;">
		<table class="table-condensed">
			<thead>
				<tr>
					<th class="prev" style="visibility: visible;"><i class="icon-arrow-left"></i></th>
					<th colspan="5" class="switch">2021</th>
					<th class="next" style="visibility: visible;"><i class="icon-arrow-right"></i></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td colspan="7"><span class="month">Jan</span><span class="month">Feb</span><span class="month">Mar</span><span class="month">Apr</span><span class="month">May</span><span class="month">Jun</span><span class="month">Jul</span><span class="month">Aug</span><span class="month">Sep</span><span class="month">Oct</span><span class="month active">Nov</span><span class="month">Dec</span></td>
				</tr>
			</tbody>
			<tfoot>
				<tr>
					<th colspan="7" class="today" style="display: none;">Today</th>
				</tr>
			</tfoot>
		</table>
	</div>
	<div class="datetimepicker-years" style="display: none;">
		<table class="table-condensed">
			<thead>
				<tr>
					<th class="prev" style="visibility: visible;"><i class="icon-arrow-left"></i></th>
					<th colspan="5" class="switch">2020-2029</th>
					<th class="next" style="visibility: visible;"><i class="icon-arrow-right"></i></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td colspan="7"><span class="year old">2019</span><span class="year">2020</span><span class="year active">2021</span><span class="year">2022</span><span class="year">2023</span><span class="year">2024</span><span class="year">2025</span><span class="year">2026</span><span class="year">2027</span><span class="year">2028</span><span class="year">2029</span><span class="year old">2030</span></td>
				</tr>
			</tbody>
			<tfoot>
				<tr>
					<th colspan="7" class="today" style="display: none;">Today</th>
				</tr>
			</tfoot>
		</table>
	</div>
</div>
<script>
$('form').submit(function() {
	window.onbeforeunload = null;
});
window.onbeforeunload = function() {
	return "Data will be lost if you leave the page, are you sure?";
};
loadGenre(genreId);
window.setTimeout(function() {}, 2000);
</script>
<script type="text/javascript">
$("#videos").addClass("active");
$("#admin_videos_create").addClass("active");
</script>
<script type="text/javascript">
$(document).ready(function() {
	$('#expiry_date').datepicker({
		autoclose: true,
		format: 'dd-mm-yyyy',
		startDate: 'today',
	});
});
</script>
<script type="text/javascript">
$(function() {
	//Initialize Select2 Elements
	$(".select2").select2();
	//Datemask dd/mm/yyyy
	$("#datemask").inputmask("dd:mm:yyyy", {
		"placeholder": "hh:mm:ss"
	});
	//Datemask2 mm/dd/yyyy
	// $("#datemask2").inputmask("hh:mm:ss", {"placeholder": "hh:mm:ss"});
	//Money Euro
	$("[data-mask]").inputmask();
	//iCheck for checkbox and radio inputs
	$('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
		checkboxClass: 'icheckbox_minimal-blue',
		radioClass: 'iradio_minimal-blue',
		increaseArea: '20%'
	});
	//Red color scheme for iCheck
	$('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
		checkboxClass: 'icheckbox_minimal-red',
		radioClass: 'iradio_minimal-red',
		increaseArea: '20%'
	});
	//Flat red color scheme for iCheck
	$('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
		checkboxClass: 'icheckbox_flat-green',
		radioClass: 'iradio_flat-green',
		increaseArea: '20%'
	});
	//Flat red color scheme for iCheck
	$('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
		checkboxClass: 'icheckbox_flat-green',
		radioClass: 'iradio_flat-green'
	});
});
</script>
</body>

</html>