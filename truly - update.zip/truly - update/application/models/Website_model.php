<?php

class Website_model extends CI_Model
{

    public function checkUserStatus()
    {

        if ($this->session->userdata('tex_user_id')) {
            $get['user_id'] = $this->session->userdata('tex_user_id');
            $get['status'] = 1;
            $qry = $this->db->get_where('users_list', $get)->num_rows();
            if ($qry == 0) {
                $this->session->sess_destroy();
                redirect('Home/index');
            }
        } else {
            redirect('Home/index');
        }
    }

    public function checkName()
    {
        if ($this->input->post('type') == "user") {
            $type = "users_list";
            $get['username'] = $this->input->post('value');
            $msg = "Username";
        } else {
            $type = "group_list";
            $get['group_name'] = $this->input->post('value');
            $msg = "Group Name";
        }


        $qry = $this->db->get_where($type, $get);
        if ($qry->num_rows() == 0) {
            $status = true;
            $msg .= " Available";
        } else {
            $status = false;
            $msg .= " Already Taken";
        }
        echo json_encode(array('status' => $status, 'msg' => $msg));
    }
    public function reset()
    {
        $email = $this->input->post('email');

        $this->db->where('email', $email);
        $count = $this->db->get('users_list')->num_rows();
        print_r($count);
        if ($count > 0) {

            $data['password'] = md5($this->input->post('password'));
            $this->db->where('email', $email);
            $this->db->update('users_list', $data);
        }
    }
    public function otp()
    {


        $email = $this->input->post('email');

        $this->db->where('email', $email);

        $count = $this->db->get('users_list')->num_rows();
        //  $qry = $this->db->get_where('users_list', array('email' => $email))->row()->username;
        // print_r($this->db->last_query());
        if ($count > 0) {
           
            $otp_no = mt_rand(100000, 999999);
            $data['otp'] = $otp_no;
            $this->session->set_userdata('email', $email);
            $this->db->where('email', $email);
            $this->db->update('users_list', $data);
            $bodymes = '<!DOCTYPE html>
            <html lang="en">
            <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta http-equiv="X-UA-Compatible" content="ie=edge">
            <link rel="stylesheet" href="style.css">
            <title>Email</title>
            <style>
            body{
            background-color: #e1e1e1;
            font-family: Arial, Helvetica, sans-serif;
            }
            .container{
            max-width: 680px;
            width: 100%;
            margin: auto;
            }
            main{
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            color: #555555; 
            }
    
            .body h2{
            font-weight: 300;
            color: #464646;
            }
            a{
            text-decoration: underline; 
            color: #0c99d5; 
            }
            .body{
            padding: 20px;
            background-color: white;
            font-family: Geneva, Tahoma, Verdana, sans-serif; 
            font-size: 16px; 
            line-height: 22px; 
            color: #555555; 
            }
            </style>
            </head>
            <body>
            <main class="container">
            <div class="body">
            <h6> Dear User,</h6>
                <p>your OTP No is:&nbsp;&nbsp;' . $otp_no . '</p>
             
            <p>Thanks & Regards,</p>
            <p>TrulyEx</p>
            </div>
    
            </main>
    
            </body>
    
            </html>';
    
            $this->load->library('phpmailer_lib');
    
            /* PHPMailer object */
            $mail = $this->phpmailer_lib->load();
    
            /* SMTP configuration */
            $mail->isSMTP();
            $mail->Host     = 'sg2plzcpnl487141.prod.sin2.secureserver.net';
            $mail->SMTPAuth = true;
            $mail->Username = 'info@trulyex.com';
            $mail->Password = 'Bk0}wPiV2#Hx';
            $mail->SMTPSecure = 'ssl';
            $mail->Port     = 465;
            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );
            $mail->setFrom('info@trulyex.com', 'Trulyex');
            $mail->addReplyTo('info@trulyex.com', 'Trulyex');
    
            /* Add a recipient */
            $mail->addAddress($email);
    
            /* Add cc or bcc */
            //$mail->addCC('cc@example.com');
            //$mail->addBCC('bcc@example.com');
    
            /* Email subject */
            // $mail->Subject = $subject;
    
            /* Set email format to HTML */
            $mail->isHTML(true);
    
            /* Email body content */
            //$mailContent = "<h1>Send HTML Email using SMTP in CodeIgniter</h1><p>This is a test email sending using SMTP mail server with PHPMailer.</p>";
            $mail->Body = $bodymes;
    
            /* Send email */
            if ($mail->send()) {
                echo 2;
            } else {
                echo 1;
            }
        } else {
            echo 1;
        }
        
        exit;
    }
    public function modify_profile()
    {
    }
    public function verify_otp()
    {

        $email = $this->input->post('email');
        $this->session->set_userdata('tex_user_name', $email);
        $otp = $this->input->post('otp');
        $this->db->where('email', $email);
        $this->db->where('otp', $otp);
        $count = $this->db->get('users_list')->num_rows();
        if ($count > 0) {

            echo 1;
        } else {
            echo 2;
        }
    }
    public function checkRegister()
    {

        $val = $this->input->post('value');
        if ($this->input->post('type') != "email") {
            $get['mobile_no'] = $val;
        } else {
            $get['email'] = $val;
        }

        $qry = $this->db->get_where('users_list', $get);
        if ($qry->num_rows() == 0) {
            echo 1;
        } else {
            echo 0;
        }
    }

    public function registerUser()
    {
        $ins['username'] = $this->input->post('user_name');
        $ins['profile_name'] = $this->input->post('profile_name');
        $ins['mobile_no'] = $this->input->post('mobile');
        $ins['email'] = $this->input->post('email');
        $ins['dob'] = $this->input->post('dob');
        $ins['refferal_code'] = $this->generateRandomString(7);
        $get['refferal_code'] = $this->input->post('refferal_code');
        $codeCheck = $this->db->get_where('users_list', $get)->row();
        if ($codeCheck != NULL) {
            $ins['referred_by'] = $codeCheck->user_id;
        }
        $ins['password'] = md5($this->input->post('password'));
        $ins['social_media_name'] = $this->input->post('social_media_name');
        $ins['social_media_id'] = $check['social_media_id'] = $this->input->post('social_media_id');
        $proPic = NULL;
        $config['upload_path']   = 'admin/images/';
        $config['allowed_types'] = '*';
        $this->load->library('upload', $config);

        if (!empty($_FILE['file'])) {
            if (!$this->upload->do_upload('file')) {
                $msg = "Something Wrong";
                $status = false;
            } else {

                $uploadedImage = $this->upload->data();
                $ins['profile_picture'] = $proPic = 'images/' . $uploadedImage['file_name'];
                $msg = "Profile Added";
                $status = true;
            }
        }

        if ($check['social_media_id'] != "") {
            $qry = $this->db->get_where('users_list', $check)->row();
            if ($qry != NULL) {
                $uid = $qry->user_id;
                $username = $qry->username;
                $proName = $qry->profile_name;
            }
        } else {
            $qry = $this->db->insert('users_list', $ins);
            $uid = $this->db->insert_id();
            $username = $this->input->post('user_name');
            $proName = $this->input->post('profile_name');
        }



        if ($qry) {
            set_cookie('truly_ex_user_id', $uid, '1296000');
            set_cookie('truly_ex_user_name', $username, '1296000');
            $this->session->set_userdata('tex_user_id', $uid);
            $this->session->set_userdata('tex_user_name', $username);
            $this->session->set_userdata('tex_profile_picture', $proPic);
            $this->session->set_userdata('tex_profile_name', $proName);
            echo 1;
        } else {
            echo 0;
        }
    }

    public function googleSignIn($addData)
    {

        $get['social_media_id'] = $addData['social_media_id'];
        $qry = $this->db->get_where('users_list', $get);
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                $this->session->set_userdata('tex_user_id', $row->user_id);
                $this->session->set_userdata('tex_user_name', $row->username);
                $this->session->set_userdata('tex_profile_picture', $row->profile_picture);
                $this->session->set_userdata('tex_profile_name', $row->profile_name);
            }
        } else {
            $addData['refferal_code'] = $this->generateRandomString(7);
            $this->db->insert('users_list', $addData);
            // print_r($addData);
            // exit;
            $this->session->set_userdata('tex_user_id', $this->db->insert_id());
            // $this->session->set_userdata('tex_user_name', $row->username);
            $this->session->set_userdata('tex_profile_picture', $addData['profile_picture']);
            $this->session->set_userdata('tex_profile_name', $addData['profile_name']);
        }
    }

    function generateRandomString($length)
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        $get['refferal_code'] = $randomString;
        $qry = $this->db->get_where('users_list', $get)->num_rows();
        // if($qry->num_rows() > 0){
        //     $this->generateRandomString($length);
        // }
        return $randomString;
    }

    public function checkLogin()
    {
        $name = $this->input->post('name');
        $password = md5($this->input->post('password'));

        $this->db->select('*');
        $this->db->from('users_list');
        $this->db->where('password', $password);
        $this->db->group_start();
        $this->db->where('username', $name);
        $this->db->or_where('mobile_no', $name);
        $this->db->or_where('email', $name);
        $this->db->group_end();
        $qry = $this->db->get();

        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                $this->session->set_userdata('tex_user_id', $row->user_id);
                $this->session->set_userdata('tex_user_name', $row->username);
                $this->session->set_userdata('tex_profile_picture', $row->profile_picture);
                $this->session->set_userdata('tex_profile_name', $row->profile_name);
                $followCnt = $this->checkFollowingCount(2);
                if ($followCnt > 0) {
                    echo 1;
                } else {
                    echo 2;
                }
            }
        } else {
            echo 0;
        }
    }
    public function forget1()
    {
        $name = $this->input->post('name');
        $password = $this->input->post('password');

        // $otp_no = mt_rand(100000, 999999);
        $this->db->where('mobile_no', $name);
        $count = $this->db->get('users_list')->num_rows();

        if ($count > 0) {
            $data['password'] = md5($password);
            $this->db->where('mobile_no', $name);
            $qry = $this->db->update('users_list', $data);
            if ($qry) {
                echo 1;
                // redirect('Home/index');
            }
        } else {
            echo 2;
        }
    }
    public function topGroups()
    {

        // $get['top_list'] = 1;
        // $get['status'] = 1;
        // // $get['group_type_id'] = 1;
        $qry = $this->db->get_where('group_list', array('group_type_id' => 1));
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                $followCnt = $this->followCheck($this->session->userdata('tex_user_id'), $row->group_id, 'group');
                $return[] = array(
                    'group_id' => $row->group_id,
                    'group_name' => $row->group_name,
                    'group_image' => $row->group_image,
                    'follow_status' => $followCnt
                );
            }
        } else {
            $return = array();
        }
        return $return;
    }
    public function topGroups1()
    {

        // $get['top_list'] = 1;
        // $get['status'] = 1;
        // // $get['group_type_id'] = 1;
        $qry = $this->db->get_where('group_list', array('group_type_id' => 2));
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                $followCnt = $this->followCheck($this->session->userdata('tex_user_id'), $row->group_id, 'group');
                $return[] = array(
                    'group_id' => $row->group_id,
                    'group_name' => $row->group_name,
                    'group_image' => $row->group_image,
                    'follow_status' => $followCnt
                );
            }
        } else {
            $return = array();
        }
        return $return;
    }
    public function topGroups2()
    {

        // $get['top_list'] = 1;
        // $get['status'] = 1;
        // // $get['group_type_id'] = 1;
        $qry = $this->db->get_where('group_list', array('group_type_id' => 3));
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                $followCnt = $this->followCheck($this->session->userdata('tex_user_id'), $row->group_id, 'group');
                $return[] = array(
                    'group_id' => $row->group_id,
                    'group_name' => $row->group_name,
                    'group_image' => $row->group_image,
                    'follow_status' => $followCnt
                );
            }
        } else {
            $return = array();
        }
        return $return;
    }

    public function groupsListContents()
    {
        $type = $this->input->post('type');
        $groupType = $this->input->post('groupType');
        $filter = $this->input->post('filter');

        $get[$type] = 1;
        $this->db->select('*');
        $this->db->from('group_list');
        $this->db->where('group_type_id', $groupType);
        $this->db->where('status', 1);
        $this->db->where('pending_status', 0);
        // $this->db->where($type, 1);
        if ($filter == 1) {
            $this->db->order_by('group_name', 'ASC');
        } else if ($filter == 2) {
            $this->db->order_by('group_name', 'DESC');
        } else if ($filter == 3) {
            $this->db->order_by('followers', 'DESC');
        }
        if ($this->input->post('search') != "") {
            $this->db->like('group_name', $this->input->post('search'));
        }
        $qry = $this->db->get();
        $html = "";
        $i = 0;
        if ($qry->num_rows() > 0) {

            foreach ($qry->result() as $row) {
                $followCnt = $this->followCheck($this->session->userdata('tex_user_id'), $row->group_id, 'group');
                $jsArg = $row->group_id . ",'group','followBtn_" . $i . "'";
                $link = base_url('groupPage/' . $row->group_id);

                $btn = $followCnt == "Following" ? "followed" : "follow";
                $groupImg = $row->group_image == NULL ? "https://ui-avatars.com/api/?background=random&name=" . $row->group_name : base_url('admin/' . $row->group_image);
                $html .= '
                <div class="col-md-6 col-sm-6 pe-2 ps-2">
                    <div
                      class="card d-block border-0 shadow-xss rounded-3 overflow-hidden mb-3"
                    >
                      <div
                        class="card-body d-block w-100 text-left position-relative group"
                      >
                        <figure class="avatar w75">
                        <a href="' . $link . '">
                          <img
                            src="' . $groupImg . '"
                            alt="image"
                            class="p-1 bg-white rounded-circle"
                          />
                         </a> 
                        </figure>
                        <a href="' . $link . '" class="">
                          <h4 class="fw-700 font-xsss mt-3 mb-1 w-22">
                          ' . $row->group_name . '
                          </h4>
                          <p class="fw-500 font-xsssss text-grey-500 mt-0 mb-3 ellipsis">
                          ' . $row->group_description . '
                          </p>
                        </a>
                        
                      </div>
                      <span class="position-absolute right-15 top-50 d-flex align-items-center" style="transform: translateY(-50%);">
                        <a href="#"  id="followBtn_' . $i . '" onclick="followUserGroup(' . $jsArg . ')" class="' . $btn . '">
                        ' . $followCnt . '</a>
                    </span>
                    </div>
                  </div>
            
                ';
                $i++;
            }
        }else{
            $html .='<div class="d-flex justify-content-center">No Data Found</div>';
        }
        echo $html;
    }

    //     <div class="col-md-6 col-sm-6 pe-2 ps-2">
    //     <div class="card d-block border-0 shadow-xss rounded-3 overflow-hidden mb-3">
    //         <div class="card-body position-relative h100 bg-image-cover bg-image-center" style="background-image: url(' . base_url($row->group_cover_pic) . ')"></div>
    //         <div class="card-body d-block w-100 pl-10 pe-4 pb-4 pt-0 text-left position-relative">
    //             <figure class="avatar position-absolute w75 z-index-1" style="top: -40px; left: 15px">
    //                 <img src="' . base_url($row->group_image) . '" alt="image" class="float-right p-1 bg-white rounded-circle w-100" />
    //             </figure>
    //             <div class="clearfix"></div>
    //             <h4 class="fw-700 font-xsss mt-3 mb-1">
    //                 ' . $row->group_name . '
    //             </h4>
    //             <p class="fw-500 font-xsssss text-grey-500 mt-0 mb-3">
    //             ' . $row->group_description . '
    //             </p>
    //             <span class="position-absolute right-15 top-0 d-flex align-items-center">
    //                 <a href="#"  id="followBtn_' . $i . '" onclick="followUserGroup(' . $jsArg . ')" class="text-center p-2 lh-24 w100 ms-1 ls-3 d-inline-block rounded-xl bg-current font-xsssss fw-700 ls-lg text-white">
    //                 ' . $followCnt . '</a>
    //             </span>
    //         </div>
    //     </div>
    //      </div>
    public function followUserGroup()
    {
        // $this->session->userdata('tex_user_id');
        $followersCnt = 0;
        $get['user_id'] = $fid = $this->session->userdata('tex_user_id');


        $get['user_following_id'] = $followid =  $this->input->post('id');
        $get['following_type'] = $this->input->post('type');

        $qry = $this->db->get_where('user_group_merge', $get)->row();
        $status = true;
        if ($qry == NULL) {

            $get['date'] =  $ins['date'] = date('Y-m-d');
            $get['time'] = $ins['time'] = date('H:i:s');
            $this->db->insert('user_group_merge', $get);

            $id = $this->db->insert_id();
            $math = "+";

            if ($this->input->post('type') == 'user') {
                $ins['user_id'] = $followid;
                $ins['nuser_id'] = $fid;
                $ins['post_id'] = 0;
                $ins['notify_message'] = "is started to following you";
                $this->db->insert('notifications', $ins);
            }

            $msg = "Following";
        } else {
            $id = $qry->ugm_id;
            $math = "-";
            $this->db->where('ugm_id', $id);
            $this->db->delete('user_group_merge');
            $msg = "Follow";
            $get['followed_date'] = $qry->date;
            $get['followed_time'] = $qry->time;
            $get['unfollowed_date'] = date('Y-m-d');
            $get['unfollowed_time'] = date('H:i:s');
            $this->db->insert('unfollow_history', $get);
        }

        if ($this->input->post('following_type') == "user") {
            $this->db->query("UPDATE users_list SET user_followers = user_followers " . $math . " 1 WHERE user_id =" . $fid);
            $this->db->query("UPDATE users_list SET user_following = user_following " . $math . " 1 WHERE user_id =" . $followid);
        } else {
            $this->db->query("UPDATE group_list SET followers = followers " . $math . " 1 WHERE group_id =" . $followid);
            // print_r($this->db->last_query()); 
            $this->db->query("UPDATE users_list SET user_following = user_following " . $math . " 1 WHERE user_id =" . $fid);
            // print_r($this->db->last_query()); 
            $this->db->select('followers');
            $this->db->where("group_id", $followid);
            $this->db->limit(1);
            $query = $this->db->get('group_list');
            if ($query->num_rows() > 0) {
                $followersCnt = $query->row()->followers;
            }
        }
        echo $msg . "@@" . $followersCnt;
    }

    function checkFollowingCount($type = 0)
    {
        $get['user_id'] = $this->session->userdata('tex_user_id');
        $qry = $this->db->get_where('user_group_merge', $get);
        // print_r($this->db->last_query());
        if ($type == 0) {
            echo $qry->num_rows();
        } else {
            return $qry->num_rows();
        }
    }

    public function followCheck($user, $otherUser, $type)
    {
        $get['user_id'] = $user;
        $get['user_following_id'] = $otherUser;
        $get['following_type'] = $type;
        return $this->db->get_where('user_group_merge', $get)->num_rows() > 0 ? "Following" : "Follow";
    }
    public function turnUrlIntoHyperlink($string){
        //The Regular Expression filter
        $reg_exUrl = "/(?i)\b((?:https?:\/\/|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}\/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:'\".,<>?«»“”‘’]))/";
    
        // Check if there is a url in the text
        if(preg_match_all($reg_exUrl, $string, $url)) {
    
            // Loop through all matches
            foreach($url[0] as $newLinks){
                if(strstr( $newLinks, ":" ) === false){
                    $link = 'http://'.$newLinks;
                }else{
                    $link = $newLinks;
                }
    
                // Create Search and Replace strings
                $search  = $newLinks;
                $replace = '<a href="'.$link.'" title="'.$newLinks.'" target="_blank">'.$link.'</a>';
                $string = str_replace($search, $replace, $string);
            }
        }
    
        //Return result
        return $string;
    }
    public function homeFeeds($pageType)
    {

        $get['user_id'] = $uid = $this->session->userdata('tex_user_id');
        $type = $this->input->post('type');
        //$cnt = $this->input->post('cnt');
        $page = 1;
        $perPage = 4;
        if(!empty($this->input->post('page'))) {
            $page = $this->input->post('page');
        }
        $start = ($page != 'NaN') ? ($page-1)*$perPage : 0;
        if($start < 0) $start = 0;
        
        $html = "";

        $qry = $this->db->get_where('user_group_merge', $get);
        if ($qry->num_rows() > 0) {
            $group = array();
            $user = array();
            foreach ($qry->result() as $row) {
                if ($row->following_type == "group") {
                    $group[] = $row->user_following_id;
                } else {
                    $user[] = $row->user_following_id;
                }
            }
            $gCheck = 0;
            $sql = "SELECT COUNT(1) as rowcount FROM post_list pl,group_list gl,users_list ul,group_types gt WHERE gl.group_id = pl.group_id AND ul.user_id = pl.user_id AND gt.gt_id = gl.group_type_id AND group_type_id = '".$type."' AND gl.status = 1 AND pl.status = 1 AND pl.post_pending_status != 1";
            if ($pageType == "home") {
                if (!empty($group)) {
                    $sql .= " AND pl.group_id IN( ".implode(",", $group).")";
                }
                if (!empty($user)) {
                    $sql .= $gCheck == 1 ? "OR pl.user_id IN (".implode(",", $user).")" : " AND pl.user_id IN (".implode(",", $user).")";
                }
            } else {
                if (!empty($group)) {
                    $sql .= " AND pl.group_id NOT IN (".implode(",", $group).")";
                }
            }
            $res = $this->db->query($sql)->result()[0];
            $rowcount = $res->rowcount;
            
            $this->db->where('group_type_id', $type);
            $this->db->where('gl.status', 1);
            $this->db->where('pl.status', 1);
            $this->db->where('pl.post_pending_status !=', 1);
            $this->db->group_start();
            if ($pageType == "home") {
                if (!empty($group)) {
                    $this->db->where_in('pl.group_id', $group);
                    $gCheck = 1;
                }
                if (!empty($user)) {
                    $where = $gCheck == 1 ? "or_where_in" : "where_in";
                    $this->db->$where('pl.user_id', $user);
                }
                $followTxt  = "Unfollow Group";
                $followDef  = "remove from following list";
            } else {
                if (!empty($group)) {
                    $this->db->where_not_in('pl.group_id', $group);
                    $gCheck = 1;
                }
                $followTxt  = "Follow Group";
                $followDef  = "add to following list";
            }
            $this->db->group_end();

            $this->db->from('post_list pl');
            $this->db->join('group_list gl', 'gl.group_id = pl.group_id');
            $this->db->join('users_list ul', 'ul.user_id = pl.user_id');
            $this->db->join('group_types gt', 'gt.gt_id = gl.group_type_id');
            /*if(empty($this->input->post('rowcount'))) {
                $rowcount = $this->db->count_all_results();
            }*/
            $this->db->limit($perPage, $start);
            $sQry = $this->db->order_by('posted_date DESC,posted_time DESC')->get();

            // print_r($this->db->last_query()); exit;
            //echo "<pre>";
            //print_r($sQry->result()); exit;
            $postId = array();
            $j = 0;
            if ($sQry->num_rows() > 0) {
                foreach ($sQry->result() as $row) {

                    if (in_array($row->post_id, $postId)) {
                        continue;
                    }
                    $postId = array($row->post_id);
                    $date = date('Y-m-d') == $row->posted_date ? "Today" : date('d-m-Y', strtotime($row->posted_date));
                    $files = $this->getPostFile($row->post_id);
                    $like = $this->checkLike($row->post_id, $uid);
                    $gLink = base_url('groupPage/' . $row->group_id);
                    $saveStatus = $this->checkSaveStatus($row->post_id, $uid);
                    $groupImg = $row->group_image == NULL ? "https://ui-avatars.com/api/?background=random&name=" . $row->username : base_url($row->username);

                    //https://ui-avatars.com/api/?background=random&name=".$this->session->userdata('tex_profile_name')

                    $jsArg = $row->group_id . ",'group','postSide'";
                    $html .= '<input type="hidden" class="pagenum" value="' . $page . '" /><input type="hidden" class="rowcount" value="' . $rowcount . '" />';
                    $html .= ' <div class="card w-100 shadow-xss rounded-xxl border-0 p-4 mb-0">
                    <div class="card-body p-0 d-flex">
                      <figure class="avatar me-3">
                      <a href="' . $gLink . '">
                        <img src="' . $groupImg . '" alt="image" class="shadow-sm rounded-circle w45" />
                      </a>
                        </figure>
                      <h4 class="fw-700 text-grey-900 font-xssss mt-1">
                        <a href="' . base_url('userPage/' . $row->user_id) . '">' . $row->username . '</a> posted in  <a href="' . $gLink . '">' . $row->group_name . '</a>.
                        <span class="d-block font-xssss fw-500 mt-1 lh-3 text-grey-500">' . $date . ' ' . date('h:i A', strtotime($row->posted_time)) . '</span>
                      </h4>
                      <a href="#" class="ms-auto" id="dropdownMenu' . $row->post_id . '" data-bs-toggle="dropdown" aria-expanded="false"><i class="ti-more-alt text-grey-900 btn-round-md bg-greylight font-xss"></i></a>
                      <div class="dropdown-menu dropdown-menu-end p-4 rounded-xxl border-0 shadow-lg" aria-labelledby="dropdownMenu' . $row->post_id . '">
                   
                     
                    
                      <div class="card-body p-0 d-flex mt-2" onclick="followUserGroup(' . $jsArg . ')">
                        <i class="feather-lock text-grey-500 me-3 font-lg"></i>
                        <h4 class="fw-600 mb-0 text-grey-900 font-xssss mt-0 me-4">
                          ' . $followTxt . '
                          <span class="d-block font-xsssss fw-500 mt-1 lh-3 text-grey-500">' . $followDef . '</span>
                        </h4>
                      </div>
                      <div class="card-body p-0 d-flex mt-3"  data-toggle="modal"
                      data-target="#reportModal" onclick="openReportModal(' . $row->post_id . ')">
                        <i class="feather-alert-octagon text-grey-500 me-3 font-lg"></i>
                        <h4 class="fw-600 mb-0 text-grey-900 font-xssss mt-0 me-4">
                          Report Post
                          <span class="d-block font-xsssss fw-500 mt-1 lh-3 text-grey-500">Report post contents</span>
                        </h4>
                      </div>

                      
                    </div>
                    </div>
                    
                    <div class="card-body p-0 me-lg-5">
                      <p class="fw-500 text-grey-500 lh-26 font-xssss w-100 mb-2">
                        ' . $this->turnUrlIntoHyperlink($row->post_detail) . '
                        
                      </p>
                    </div>';
                    if (!empty($files['images']) || !empty($files['videos'])) {
                        $html .= '<div class="card-body">
                        <div class="slider">
                          <div class="slider__items">';
                        $i = 0;
                        foreach ($files['images'] as $rows) {

                            $active = $i == 0 ? "active" : "";
                            $html .=  '<div class="slider__img ' . $active . '" onclick="fetchPostData(' . $row->post_id . ')">
                              <a href="' . base_url($rows['img']) . '" data-lightbox="roadtrip_' . $j . '">
                                <img src="' . base_url($rows['img']) . '" alt="" />
                              </a>
                            </div>';
                            $i++;
                        }

                        $html .= '</div>
                          <div class="left__slide">
                            <i class="fas fa-chevron-left"></i>
                          </div>
                          <div class="right__slide">
                            <i class="fas fa-chevron-right"></i>
                          </div>
                        </div>
                        </div>';
                    }
                    $comments = $row->comments == 0 ? "" : $row->comments;
                    $likes =  $row->likes == 0 ? "" : $row->likes;
                    $likeClass =  $like == true ? "likeBtn text-success" : "likeBtn";
                    $likeArgs = $row->post_id . ",'post','postlike_'";
                    $shareLink = base_url('sharedPost/' . $row->post_id);
                    $html .= '<div class="card-body d-flex p-0 ">
                      <a onclick="likePost(' . $likeArgs . ')"  class="emoji-bttn d-flex align-items-center fw-600 text-grey-900 text-dark lh-26 font-xssss me-2" id="postlike_'.$row->post_id.'">
                      <i class="feather-thumbs-up text-white bg-primary-gradiant me-1 btn-round-xs font-xss"></i>   <span id="feedLike_' . $row->post_id . '" class="' . $likeClass . '" ">' . $likes . ' Like</span></a>
                     
                      <a role="button"  class="d-flex align-items-center fw-600 text-grey-900 text-dark lh-26 font-xssss" onclick="fetchPostData(' . $row->post_id . ')"><i class="feather-message-circle text-dark text-grey-900 btn-round-sm font-lg"></i><span class="d-none-xss">' . $comments . ' Comment</span></a>
                      <a   id="dropdownMenuShare' . $row->post_id . '"
                      data-bs-toggle="dropdown"
                      aria-expanded="false" class="ms-auto d-flex align-items-center fw-600 text-grey-900 text-dark lh-26 font-xssss"><i class="feather-share-2 text-grey-900 text-dark btn-round-sm font-lg"></i><span class="d-none-xs">Share</span></a>
                      <div
                      class="dropdown-menu dropdown-menu-end p-4 rounded-xxl border-0 shadow-lg"
                      aria-labelledby="dropdownMenuShare' . $row->post_id . '"
                    >
                      <h4
                        class="fw-700 font-xss text-grey-900 d-flex align-items-center"
                      >
                        Share
                        <i
                          class="feather-x ms-auto font-xssss btn-round-xs bg-greylight text-grey-900 me-2"
                        ></i>
                      </h4>
                      <div class="card-body p-0 d-flex">
                        <ul
                          class="d-flex align-items-center justify-content-between mt-2"
                        >
                          <li class="me-1">
                            <a target="_blank"  href="https://www.facebook.com/sharer/sharer.php?u=' . $shareLink . '" class="btn-round-lg bg-facebook"
                              ><i class="font-xs ti-facebook text-white"></i
                            ></a>
                          </li>
                          <li class="me-1">
                            <a href="https://twitter.com/intent/tweet?url=' . $shareLink . '" target="_blank" class="btn-round-lg bg-twiiter"
                              ><i class="font-xs ti-twitter-alt text-white"></i
                            ></a>
                          </li>
                          <li class="me-1">
                            <a  href="https://www.linkedin.com/sharing/share-offsite/?url=' . $shareLink . '" target="_blank" class="btn-round-lg bg-linkedin"
                              ><i class="font-xs ti-linkedin text-white"></i
                            ></a>
                          </li>
                          <li>
                            <a target="_blank" href="https://wa.me/?text=' . $shareLink . '" class="btn-round-lg bg-whatsup"
                              ><i class="font-xs feather-phone text-white"></i
                            ></a>
                          </li>
                          <li>
                            <a target="_blank" href="http://pinterest.com/pin/create/link/?url=' . $shareLink . '
                            " class="btn-round-lg bg-pinterest"
                              ><i class="font-xs ti-pinterest text-white"></i
                            ></a>
                          </li>
                        </ul>
                      </div>
                     
                      <h4
                        class="fw-700 font-xssss mt-4 text-grey-500 d-flex align-items-center mb-3"
                      >
                        Copy Link
                      </h4>
                      <i
                        class="feather-copy position-absolute right-35 mt-3 font-xs text-grey-500"
                        onclick = "copyToClipboard(' . $row->post_id . ')"
                      ></i>
                      <input
                        type="text" id="copyLink_' . $row->post_id . '"
                        value="' . $shareLink . '" readonly
                        class="bg-grey text-grey-500 font-xssss border-0 lh-32 p-2 font-xssss fw-600 rounded-3 w-100 theme-dark-bg"
                      />
                    </div>
                      </div>
                  </div>';
                    $j++;
                }
            }
        }
        //$text = $sQry->num_rows() < 0 ? "No Post Available" : '<div class="dot-typing"></div>';
        /*$html .= '<div class="card w-100 text-center shadow-xss rounded-xxl border-0 p-4 mb-3 mt-3">
        <div class="snippet mt-2 ms-auto me-auto" data-title=".dot-typing">
          <div class="stage">
            ' . $text . '
          </div>
        </div>
      </div>';*/
        echo $html;
    }

    public function getPostFile($id)
    {
        $get['post_id'] = $id;
        $qry = $this->db->get_where('post_multimedia', $get);
        $pic = array();
        $video = array();
        if ($qry->num_rows()  > 0) {
            foreach ($qry->result() as $row) {
                if ($row->type == "picture") {
                    $pic[] = array(
                        'img' => $row->file_link
                    );
                } else {
                    $video[] = array(
                        'img' => $row->file_link
                    );
                }
            }
        }
        return array('images' => $pic, 'videos' => $video);
    }

    public function checkLike($pId, $uId)
    {
        $get['post_id'] = $pId;
        $get['user_id'] = $uId;

        $qry = $this->db->get_where('user_likes_list', $get)->row();
        return $qry != NULL ? true : false;
    }

    public function checkSaveStatus($pid, $uid)
    {
        $get['post_id'] = $pid;
        $get['user_id'] = $uid;
        $qry = $this->db->get_where('saved_posts', $get)->row();
        return $qry != NULL ? TRUE : FALSE;
    }

    public function groupTypeList()
    {
        $get['status'] = 1;
        $qry = $this->db->get_where('group_types', $get);

        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                $return[] = array(
                    'group_type_id' => $row->gt_id,
                    'group_type_name' => $row->group_type_name
                );
            }
        } else {
            $return = array();
        }
        return $return;
    }

    public function postGroupAppend()
    {
        $this->db->select('*');
        $this->db->from('group_list');

        if ($this->input->post('search') != "") {
            $this->db->like('group_name', $this->input->post('search'));
        } else {
            $this->db->where('top_list', 1);
        }
        $qry = $this->db->get();
    }

    public function followingList()
    {
        $uId = $this->session->userdata('tex_user_id');
        $groupType = $this->input->post('groupType');



        $this->db->select('*');
        if ($this->input->post('search') != "") {
            $this->db->from('group_list gl');
            $this->db->like('group_name', $this->input->post('search'));
        } else {
            $this->db->from('user_group_merge ugm');
            $this->db->join('group_list gl', 'gl.group_id = ugm.user_following_id');
            $this->db->where('ugm.user_id', $uId);
            $this->db->where('ugm.following_type', "group");
        }
        $this->db->where('group_type_id', $groupType);
        $this->db->where('gl.status', 1);

        $qry = $this->db->get();
        $html = "";
        if ($qry->num_rows() > 0) {
            $i = 0;
            foreach ($qry->result() as $row) {
                $groupImg = $row->group_image == NULL ? "https://ui-avatars.com/api/?background=random&name=" . $row->group_name : base_url('admin/' . $row->group_image);

                $followStatus = $this->followCheck($this->session->userdata('tex_user_id'), $row->group_id, "group");
                $jsArg = $row->group_id . ",'group','addPostFollowBtn_" . $row->group_id . "'";
                $btn = $followStatus == "Following" ? "followed" : "follow";
                $html .= '<div class="page justify-content-between">
                <div class="d-flex align-items-center">
                <input type="hidden" id="grpFollowStatus_' . $row->group_id . '" value="' . $followStatus . '">
                <input type="radio" name="radio" value="' . $row->group_id . '#' . $row->group_name . '" onclick=" selectedGroup(this.value)" class="page__select" />
                  <div class="page__img">
                  <img src="' . $groupImg . '" alt="pic" />
                  </div>
                  <div class="page__title">' . $row->group_name . '</div>
                </div>
                
                <a href="#" onclick="followUserGroup(' . $jsArg . ')"
                            class="' . $btn . '"
                            id="addPostFollowBtn_' . $row->group_id . '" >' . $followStatus . '</a
                          >
              </div>';
            }
        } else {
            $html = "No Groups Available";
        }

        //     <span class="position-absolute right-15 top-0 d-flex align-items-center">
        //     <a href="#"  id="followBtn_' . $i . '" onclick="followUserGroup(' . $jsArg . ')" class="text-center p-2 lh-24 w100 ms-1 ls-3 d-inline-block rounded-xl bg-current font-xsssss fw-700 ls-lg text-white">
        //     ' . $followStatus . '</a>
        // </span>

        $html .= '
        <div class="groups h" >
        
        <a class="btn text-dark fw-bold"  id="addNewGroup">
        Add New Group
        </a>

        <div class="group_detail p-3 hidden" id="grp_detail">
        <form action="javascript: void(0)" id="submitGroupForm" enctype="multipart/form-data" method="POST" onsubmit="submitGroupForm()" >
        <div class="form-floating mb-3">
        <input type="input" name="group_name" id="group_name" autocomplete="off" onkeyup="checkName(this.value)" class="form-control" required >
        <label for="floatingInput">Enter Group Name <sup>*</sup></label>
        </div>
        <span id="nameCheck"></span>
        <div class="form-floating">
        <textarea class="form-control" id="group_description" name="group_description" required ></textarea>
        <label for="floatingTextarea">Enter Group Description</label>
        </div>
        <div class="form__group col">
        <label for="group_image mb-3">Group Cover Image</label>
        <input class="form-control" type="file" name="group_image" id="group_image"  >
        </div>
        <button type="submit" id="newGroupSubmit"  class="btn btn-success" style="margin-top: 2%;">Add</button>
        </form>
        </div>
       
        </div>
        ';

        echo $html;
    }

    public function uDetail($id)
    {
        $get['user_id'] = $id;
        $qry = $this->db->get_where('users_list', $get)->row();
        $return['id'] = $qry->user_id;
        $return['name'] = $qry->username;
        $return['profile_name'] = $qry->profile_name;
        $return['email'] = $qry->email;
        $return['mobile_no'] = $qry->mobile_no;
        $return['dob'] = $qry->dob;
        $return['image'] = $qry->profile_picture;
        $return['user_followers'] = $qry->user_followers;
        $return['user_following'] = $qry->user_following;
        $return['user_posts'] = $qry->user_posts;
        return $return;
    }

    public function gDetail($id)
    {
        $get['group_id'] = $id;
        $qry = $this->db->get_where('group_list', $get)->row();
        $return['id'] = $qry->group_id;
        $return['name'] = $qry->group_name;
        $return['image'] = $qry->group_image;
        $return['group_description'] = $qry->group_description;
        $return['total_post'] = $qry->total_post;
        $return['followers'] = $qry->followers;
        return $return;
    }

    public function addPost()
    {
        $get['group_id'] = $gId = $this->input->post('selectedGroupId');

        $fQry = $this->db->get_where('group_list', $get)->row();

        $get['post_pending_status'] = $fQry->pending_status;

        $get['user_id'] = $uId = $this->session->userdata('tex_user_id');
        $get['post_detail'] = $this->input->post('post_detail');
        $get['posted_date'] = date('Y-m-d');
        $get['posted_time'] = date('H:i:s');



        $qry = $this->db->insert('post_list', $get);
        $config['upload_path']   = 'admin/images/';
        $config['allowed_types'] = '*';
        $this->load->library('upload', $config);
        if ($qry) {
            $ins['post_id'] = $this->db->insert_id();
            $i = 0;
            $j = 0;
            foreach ($_FILES['file_pic'] as $row) {

                if (!empty($_FILES['file_pic']['name'][$i])) {

                    if ($_FILES['file_pic']['name'][$i] != "") {

                        $_FILES['files']['name']       = $_FILES['file_pic']['name'][$i];
                        $_FILES['files']['type']       = $_FILES['file_pic']['type'][$i];
                        $_FILES['files']['tmp_name']   = $_FILES['file_pic']['tmp_name'][$i];
                        // $_FILES['files']['error']      = $_FILES['file_pic']['error'][$i];
                        $_FILES['files']['size']       = $_FILES['file_pic']['size'][$i];

                        if (!$this->upload->do_upload('files')) {
                            $error = array('error' => $this->upload->display_errors());
                        } else {

                            $uploadedImage = $this->upload->data();
                            $ins['file_link'] = 'admin/images/' . $uploadedImage['file_name'];
                            $ins['type'] = "picture";
                            // $this->resizeImage($uploadedImage['file_name']);
                            $this->db->insert('post_multimedia', $ins);
                        }
                    }
                }

                $i++;
            }
            foreach ($_FILES['file_video'] as $row) {

                if (!empty($_FILES['file_video']['name'][$j])) {

                    if ($_FILES['file_video']['name'][$j] != "") {

                        $_FILES['files']['name']       = $_FILES['file_video']['name'][$j];
                        $_FILES['files']['type']       = $_FILES['file_video']['type'][$j];
                        $_FILES['files']['tmp_name']   = $_FILES['file_video']['tmp_name'][$j];
                        // $_FILES['files']['error']      = $_FILES['file_video']['error'][$j];
                        $_FILES['files']['size']       = $_FILES['file_video']['size'][$j];

                        if (!$this->upload->do_upload('files')) {
                            $error = array('error' => $this->upload->display_errors());
                        } else {

                            $uploadedImage = $this->upload->data();
                            $ins['file_link'] = 'images/' . $uploadedImage['file_name'];
                            $ins['type'] = "video";
                            // $this->resizeImage($uploadedImage['file_name']);
                            $this->db->insert('post_multimedia', $ins);
                        }
                    }
                }

                $j++;
            }

            if ($this->session->userdata('created_group_id')) {
                $this->session->unset_userdata('created_group_id');
                $this->session->unset_userdata('created_group_name');
            }
            $this->db->query("UPDATE group_list SET total_post = total_post + 1 WHERE group_id =" . $gId);
            $this->db->query("UPDATE users_list SET user_posts = user_posts + 1 WHERE user_id =" . $uId);
            $status = true;
            $msg = "Post Added";
        } else {
            $status = false;
            $msg = "Post Failed";
        }
        echo json_encode(array('status' => $status, 'msg' => $msg));
    }

    public function onlineUsersList()
    {
        $get['ugm.user_id'] = $this->session->userdata('tex_user_id');
        $get['following_type'] = "user";
        $this->db->join('users_list ul', 'ul.user_id = ugm.user_following_id');
        $qry = $this->db->get_where('user_group_merge ugm', $get);
        $return = array();
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {

                $lastActivity = $row->last_activity_date . " " . $row->last_activity_time;
                $currentDate = strtotime($lastActivity);
                $futureDate = $currentDate + (60 * 5);
                $formatDate = date("Y-m-d H:i:s", $futureDate);

                if (date("Y-m-d H:i:s") < $formatDate) {
                    $status = "online";
                    $order = 0;
                } else {
                    $dtNow = new DateTime(date('Y-m-d H:i:s'));
                    $formatDate = date("Y-m-d H:i:s", $currentDate + (60 * 3));
                    $dtToCompare = new DateTime($formatDate);
                    $diff = $dtNow->diff($dtToCompare);
                    $minutes = (($diff->days * 24 * 60) + ($diff->h * 60) + $diff->i);

                    $status = $minutes <= 30 ? $minutes . " mins" : "";
                    $order = $minutes;
                }

                if ($status != "") {
                    $return[] = array(
                        'user_id' => $row->user_id,
                        'username' => $row->username,
                        'profile_picture' => "admin/" . $row->profile_picture,
                        'status' => $status,
                        'order' => $order
                    );
                }
            }
        }
        if (!empty($return)) {
            array_multisort(array_column($return, 'order'), SORT_ASC, $return);
        }
        return $return;
    }

    function time_elapsed_string($datetime, $full = false)
    {
        $now = new DateTime;
        $ago = new DateTime($datetime);
        $diff = $now->diff($ago);

        $diff->w = floor($diff->d / 7);
        $diff->d -= $diff->w * 7;

        $string = array(
            'y' => 'year',
            'm' => 'month',
            'w' => 'week',
            'd' => 'day',
            'h' => 'hour',
            'i' => 'minute',
            's' => 'second',
        );
        foreach ($string as $k => &$v) {
            if ($diff->$k) {
                $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
            } else {
                unset($string[$k]);
            }
        }

        if (!$full) $string = array_slice($string, 0, 1);
        return $string ? implode(', ', $string) . ' ago' : 'just now';
    }
    public function acc_info(){
        $config['upload_path'] = './admin/images/';
		$config['allowed_types'] = 'jpg|png|jpeg|jfif';
		$this->load->library('upload', $config);
		if (!empty($_FILES['profile_picture']['name'])) {
			if (!$this->upload->do_upload('profile_picture')) {
				$img = "";
               
			} else {
				$file_info = $this->upload->data();
                $this->session->set_userdata('tex_profile_picture', $file_info['file_name']);
				$img = $file_info['file_name'];
			}
			$data['profile_picture'] = $img;
           
		}
        $id=$this->input->post('id');
        $data['profile_name']= $this->input->post('pro_name');
        $data['username'] = $this->input->post('uname');
        $data['email'] = $this->input->post('email');
        $data['mobile_no'] = $this->input->post('phone');
        $data['dob'] = $this->input->post('dob');   
        $this->db->where('email',$id);
       $this->db->update('users_list',$data);

		
        

    }
    public function fetchPostData()
    {

        $get['post_id'] = $fGet['post_id'] = $pId = $this->input->post('id');
        $get['pcl.status'] = 1;
        $like = $this->checkLike($pId, $this->session->userdata('tex_user_id'));
        $this->db->join('users_list ul', 'ul.user_id = pl.user_id');
        $this->db->join('group_list gl', 'gl.group_id = pl.group_id');
        $fQry = $this->db->get_where('post_list pl', $fGet)->row();
        $likeArgs =  $pId . ",'post','popupLike_'";
        $likeClass =  $like == true ? "text-success" : "";
        $likes =  $fQry->likes == 0 ? "" : $fQry->likes;
        $img = $fQry->group_image == NULL ? "https://ui-avatars.com/api/?background=random&name=" . $fQry->group_name : base_url('admin/' . $fQry->group_image);
        $currDate = date('Y-m-d H:i:s');
        $postDt = $fQry->posted_date . " " . $fQry->posted_time;
        $days = $this->time_elapsed_string($postDt);

        $html = '<div class="right-comment chat-left scroll-bar theme-dark-bg">
        <div class="card-body ps-2 pe-4 pb-0 d-flex">
        <i class="feather-x text-grey-500 me-3 font-lg" style="cursor:pointer;" onclick="closeCommentSideCard()"></i>
            <figure class="avatar me-3"><img src="' . $img . '" alt="image" class="shadow-sm rounded-circle w45"></figure>
            <h4 class="fw-700 text-grey-900 font-xssss mt-1 text-left">' . $fQry->username . ' posted in ' . $fQry->group_name . ' <span class="d-block font-xssss fw-500 mt-1 lh-3 text-grey-500">' . $days . '</span></h4>
            <a href="#" class="ms-auto"><i class="ti-more-alt text-grey-900 btn-round-md bg-greylight font-xss"></i></a>
        </div>';
        $html .= '<div class="card-body d-flex ps-2 pe-4 pt-0 mt-0"> 
        <a  class="d-flex align-items-center fw-600 text-grey-900 lh-26 font-xssss me-3 text-dark " onclick="likePost(' . $likeArgs . ')"> 
        <span id="popupLike_' . $fQry->post_id . '" class="likeBtn ' . $likeClass . '"><i class="feather-thumbs-up text-white bg-primary-gradiant me-1 btn-round-xs font-xss"></i>' . $likes . ' Like</span></a > 
        <a  class="d-flex align-items-center fw-600 text-grey-900 lh-26 font-xssss text-dark" >
        <i class="feather-message-circle text-grey-900 btn-round-sm font-lg text-dark" ></i >' . $fQry->comments . ' Comment</a > 
        
        </div>
        <div class="card w-100 border-0 shadow-none right-scroll-bar">
        ';

        $user_id = $this->session->userdata('tex_user_id');

        $this->db->join('users_list ul', 'pcl.user_id = ul.user_id');
        $this->db->order_by('date DESC,time DESC');
        $qry = $this->db->get_where('post_comments_list pcl', $get);

        $return = array();
        $own = array();
        $owncmt = "";
        $otrcmt = "";
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                $date = date('Y-m-d') == $row->date ? "Today" : date('d-m-Y', strtotime($row->date));
                $tGet['comment_id'] = $sGet['pcl_id'] = $row->pcl_id;
                $imgS = $row->profile_picture == NULL ? "https://ui-avatars.com/api/?background=random&name=" . $row->profile_name : base_url('admin/' . $row->profile_picture);

                $commentReply = $this->getCommentReply($row->pcl_id);
                $commentLikeCount = $this->db->get_where('likeacomment_list', $tGet)->num_rows();
                if ($user_id == $row->user_id) {
                    $owncmt .= '<div class="card-body border-top-xs pt-4 pb-3 pe-4 d-block ps-5">
                    <figure class="avatar position-absolute left-0 ms-2 mt-1"><img src="' . $imgS . '" alt="image" class="shadow-sm rounded-circle w35"></figure>
                    <div class="chat p-3 bg-greylight rounded-xxl d-block text-left theme-dark-bg">
                        <h4 class="fw-700 text-grey-900 font-xssss mt-0 mb-1">' . $row->username . '<a href="javascript:removeComment(' . $row->pcl_id . ',' . $pId . ')" class="ms-auto" ><i class="feather-trash-2 float-right text-grey-800 font-xsss"></i></a></h4>
                        
                        <p class="fw-500 text-grey-500 lh-20 font-xssss w-100 mt-2 mb-0">' . $row->comment . '</p>
                    </div>
                </div>';
                    if ($commentReply['count'] != 0) {
                        foreach ($commentReply['data'] as $rows) {
                            $owncmt .= ' <div class="card-body pt-0 pb-3 pe-4 d-block ps-5 ms-5 position-relative">
                            <figure class="avatar position-absolute left-0 ms-2 mt-1"><img src="' . base_url('admin/' . $row->reply_profile_picture) . '" alt="image" class="shadow-sm rounded-circle w35"></figure>
                            <div class="chat p-3 bg-greylight rounded-xxl d-block text-left theme-dark-bg">
                                <h4 class="fw-700 text-grey-900 font-xssss mt-0 mb-1">' . $rows->reply_commented_person . '<a href="#" class="ms-auto"><i class="ti-more-alt float-right text-grey-800 font-xsss"></i></a></h4>
                                <p class="fw-500 text-grey-500 lh-20 font-xssss w-100 mt-2 mb-0">' . $rows->reply_comment . '</p>
                            </div>
                        </div>';
                        }
                    }
                } else {

                    $otrcmt .= '<div class="card-body border-top-xs pt-4 pb-3 pe-4 d-block ps-5">
                    <figure class="avatar position-absolute left-0 ms-2 mt-1"><img src="' . base_url($row->profile_picture) . '" alt="image" class="shadow-sm rounded-circle w35"></figure>
                    <div class="chat p-3 bg-greylight rounded-xxl d-block text-left theme-dark-bg">
                        <h4 class="fw-700 text-grey-900 font-xssss mt-0 mb-1">' . $row->username . '<a href="#" class="ms-auto"></a></h4>
                        <p class="fw-500 text-grey-500 lh-20 font-xssss w-100 mt-2 mb-0">' . $row->comment . '</p>
                    </div>
                </div>';
                    if ($commentReply['count'] != 0) {
                        foreach ($commentReply['data'] as $rows) {
                            $otrcmt .= ' <div class="card-body pt-0 pb-3 pe-4 d-block ps-5 ms-5 position-relative">
                            <figure class="avatar position-absolute left-0 ms-2 mt-1"><img src="' . base_url($row->reply_profile_picture) . '" alt="image" class="shadow-sm rounded-circle w35"></figure>
                            <div class="chat p-3 bg-greylight rounded-xxl d-block text-left theme-dark-bg">
                                <h4 class="fw-700 text-grey-900 font-xssss mt-0 mb-1">' . $rows->reply_commented_person . '<a href="#" class="ms-auto"><i class="ti-more-alt float-right text-grey-800 font-xsss"></i></a></h4>
                                <p class="fw-500 text-grey-500 lh-20 font-xssss w-100 mt-2 mb-0">' . $rows->reply_comment . '</p>
                            </div>
                        </div>';
                        }
                    }
                }
            }
        }
        if ($this->session->userdata('tex_profile_picture') == NULL) {
            $cPic = "https://ui-avatars.com/api/?background=0D8ABC&color=fff&name=" . $this->session->userdata('tex_profile_name');
        } else {
            $cPic = base_url('admin/' . $this->session->userdata('tex_profile_picture'));
        }
        $final = '  <div class="card-body position-fixed bottom-0 w-30">
        <div class="comment ">
            <figure class="avatar"> <img src="' . $cPic . '" alt="image" class="shadow-sm rounded-circle w35" />
            </figure> <textarea name="comment" type="text" id="postAddComment" class="text p-0 m-0 ps-5 pt-2 pe-5" cols="20" rows="10"></textarea><button class="btn" type="button" onclick="addComment(' . $pId . ')">Comment</button>
        </div>
    </div></div></div>';
        if ($fQry->comments == 0) {
            echo $html . "<br><h2>No Comments </h2>" . $final;
        } else {
            echo $html . " " . $owncmt . " " . $otrcmt . " " . $final;
        }
    }
    public function getCommentReply($id)
    {
        $sGet['pcl_id'] = $id;

        $this->db->join('users_list ul', 'ul.user_id = pcrl.user_id');
        $qry = $this->db->get_where('post_comments_reply_list pcrl', $sGet);
        $return = array();
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                $date = date('Y-m-d') == $row->date ? "Today" : date('d-m-Y', strtotime($row->date));
                if($row->profile_picture == NULL){
                    $profile_picture = "https://ui-avatars.com/api/?background=0D8ABC&color=fff&name=".$row->username;
                }else{
                    $profile_picture = base_url('admin/'.$row->profile_picture);
                }

                $return[] = array(
                    'reply_comment_id' => $row->pcrl_id,
                    'reply_comment' => $row->reply_comment,
                    'reply_profile_picture' => $profile_picture,
                    'reply_commented_person' => $row->username,
                    'reply_commented_person_id' => $row->user_id,
                    'date' => $date,
                    'time' => date('H:i A', strtotime($row->time))
                );
            }
        }

        return (array('data' => $return, 'count' => $qry->num_rows()));
    }

    public function likePost()
    {
        $get['user_id'] = $uid = $this->session->userdata('tex_user_id');
        $get['post_id'] = $pGet['post_id'] = $pid = $this->input->post('id');

        $status  = true;
        $qry = $this->db->get_where('user_likes_list', $get)->row();
        $pQry = $this->db->get_where('post_list', $pGet)->row();
        if ($qry == NULL) {

            $get['date'] =  $ins['date'] = date('Y-m-d');
            $get['time'] = $ins['time'] = date('H:i:s');
            $this->db->insert('user_likes_list', $get);

            if ($pQry->user_id != $uid) {
                $ins['user_id'] = $pQry->user_id;
                $ins['nuser_id'] = $uid;
                $ins['post_id'] = $pid;
                $ins['notify_message'] = "is liked your post";
                $this->db->insert('notifications', $ins);
            }

            $math = "+";
            $cnt = $pQry->likes + 1;
            $msg = "Liked";
        } else {
            $id = $qry->ull_id;
            $math = "-";
            $this->db->where('ull_id', $id);
            $this->db->delete('user_likes_list');
            $msg = "Like";
            $cnt = $pQry->likes - 1;
        }



        $this->db->query("UPDATE post_list SET likes = likes " . $math . " 1 WHERE post_id =" . $pid);

        $gQry = $this->db->get_where('post_list',);
        echo json_encode(array('status' => $status, 'msg' => $msg, 'cnt' => $cnt));
    }

    public function notificationCount()
    {
        $get['user_id'] = $this->session->userdata('tex_user_id');
        $get['view_status'] = 1;
        $qry = $this->db->get_where('notifications', $get)->num_rows();
        echo $qry;
    }

    public function createGroup()
    {

        $ins['admin_id'] =  $this->session->userdata('tex_user_id');
        $ins['group_type_id'] =  $this->session->userdata('selected_group_type_id');
        $ins['group_name'] =  $this->input->post('group_name');
        $ins['group_description'] =  $this->input->post('group_description');

        $config['upload_path']   = 'admin/images/';
        $config['allowed_types'] = '*';
        $this->load->library('upload', $config);

        if (!empty($_FILE['group_image'])) {
            if (!$this->upload->do_upload('group_image')) {
                $msg = "Something Wrong";
                $status = false;
            } else {

                $uploadedImage = $this->upload->data();
                $ins['group_image'] = 'images/' . $uploadedImage['file_name'];
            }
        }



        $qry = $this->db->insert('group_list', $ins);
        if ($qry) {
            $echo = $this->db->insert_id() . "#" . $this->input->post('group_name');

            $get['user_id'] = $this->session->userdata('tex_user_id');
            $get['user_following_id'] = $iId = $this->db->insert_id();
            $get['following_type'] = 'group';
            $get['date'] = date('Y-m-d');
            $get['time'] = date('H:i:s');
            $this->db->insert('user_group_merge', $get);
            $this->db->query("UPDATE group_list SET followers = followers + 1 WHERE group_id =" . $iId);
            $this->db->query("UPDATE users_list SET user_following = user_following + 1 WHERE user_id =" . $this->session->userdata('tex_user_id'));
            $this->session->set_userdata('created_group_id', $iId);
            $this->session->set_userdata('created_group_name', $this->input->post('group_name'));
            echo $echo;
        } else {
            echo 0;
        }
    }
    public function createSettingGroup()
    {
        $ins['admin_id'] =  $this->session->userdata('tex_user_id');
        $ins['group_type_id'] =  $this->input->post('group_type');
        $ins['group_name'] =  $this->input->post('group_name');
        $ins['group_description'] =  $this->input->post('group_description');

        $config['upload_path']   = 'admin/images/';
        $config['allowed_types'] = '*';
        $this->load->library('upload', $config);

        if (!empty($_FILE['group_image'])) {
            if (!$this->upload->do_upload('group_image')) {
                $msg = "Something Wrong";
                $status = false;
            } else {

                $uploadedImage = $this->upload->data();
                $ins['group_image'] = 'images/' . $uploadedImage['file_name'];
            }
        }


        $qry = $this->db->insert('group_list', $ins);
        if ($qry) {
            $echo = $this->db->insert_id() . "#" . $this->input->post('group_name');

            $get['user_id'] = $this->session->userdata('tex_user_id');
            $get['user_following_id'] = $iId = $this->db->insert_id();
            $get['following_type'] = 'group';
            $get['date'] = date('Y-m-d');
            $get['time'] = date('H:i:s');
            $this->db->insert('user_group_merge', $get);
            $this->db->query("UPDATE group_list SET followers = followers + 1 WHERE group_id =" . $iId);
            $this->db->query("UPDATE users_list SET user_following = user_following + 1 WHERE user_id =" . $this->session->userdata('tex_user_id'));
            $this->session->set_userdata('created_group_id', $iId);
            $this->session->set_userdata('created_group_name', $this->input->post('group_name'));
            echo $echo;
        } else {
            echo 0;
        }
    }
    public function uploadProfilePicture()
    {
        $id = $this->input->post('id');
        $type = $this->input->post('type');

        $config['upload_path']   = 'admin/images/';
        $config['allowed_types'] = '*';
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('pro_pic')) {
            // $data['profile_picture'] = $this->upload->display_errors();
            $msg = "Something Wrong";
            $status = false;
        } else {

            $uploadedImage = $this->upload->data();
            $pic = 'images/' . $uploadedImage['file_name'];
            $msg = "Profile Added";
            $status = true;
        }

        if ($status) {
            if ($type == "user") {
                $data['profile_picture'] = $pic;
                $this->db->where('user_id', $id);
                $this->db->update('users_list', $data);
            } else {
                $data['group_image'] = $pic;
                $this->db->where('group_id', $id);
                $this->db->update('group_list', $data);
            }
        }

        echo json_encode(array('status' => $status, 'msg' => $msg));
    }


    public function notificationTopBar()
    {
        $get['user_id'] = $this->session->userdata('tex_user_id');

        $html = "";
        // $return = array();
        $this->db->limit('8');
        $this->db->order_by('notification_id', 'DESC');
        $qry = $this->db->get_where('notifications', $get);
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                $detail = $this->uDetail($row->nuser_id);
                if ($row->post_id != 0) {
                    $sGet['post_id'] = $row->post_id;
                    $this->db->join('users_list ul', 'ul.user_id = pl.user_id');
                    $this->db->join('group_list gl', 'gl.group_id = pl.group_id');
                    $fQry = $this->db->get_where('post_list pl', $sGet)->row();

                    //print_r($fQry);
                   // exit;
                    $sQry = $this->db->get_where('post_multimedia', $sGet);
                    if ($sQry->num_rows() > 0) {
                        $res = $sQry->result_array();
                        $img = "admin/" . $res[0]['file_link'];
                    } else {
                        if (strpos($detail['image'], 'https') !== false) {
                            $img = $detail['image'];
                        } else {
                            $img = $detail['image'] == NULL ? "https://ui-avatars.com/api/?background=random&name=" . $detail['profile_name'] : base_url('admin/' . $detail['image']);
                        }
                    }
                } else {
                    if (strpos($detail['image'], 'https') !== false) {
                        $img = $detail['image'];
                    } else {
                        $img = $detail['image'] == NULL ? "https://ui-avatars.com/api/?background=random&name=" . $detail['profile_name'] : base_url('admin/' . $detail['image']);
                    }
                }

                $d1 = new DateTime($row->date . " " . $row->time);
                $d2 = new DateTime(date('Y-m-d H:i:s'));
                $interval = $d1->diff($d2);
                if ($interval->d == 0) {
                    if ($interval->h == 0) {
                        $time = $interval->i == 0 ? "just now" : $interval->i . " mins ago";;
                    } else {
                        $time = $interval->h . " Hrs ago";
                    }
                } else {
                    $time = $interval->d >= 31 ? $interval->d . " days ago" : ($interval->d / 7) . " weeks ago";
                }
                $gLink = base_url('groupPage/' . $fQry->group_id);
                $groupImg = $fQry->group_image == NULL ? "https://ui-avatars.com/api/?background=random&name=" . $fQry->username : base_url($fQry->username);
                $date = date('Y-m-d') == $fQry->posted_date ? "Today" : date('d-m-Y', strtotime($fQry->posted_date));
                
                $html .= ' <div class="card bg-transparent-card w-100 border-0 mb-3">
                <div class="card-body p-0 d-flex"><figure class="avatar me-3">
                <a href="' . $gLink . '">
                  <img src="' . $groupImg . '" alt="image" class="shadow-sm rounded-circle w45" />
                </a>
                  </figure>
                  
                <h4 class="fw-700 text-grey-900 font-xssss mt-1">
                  <a href="' . base_url('userPage/' . $fQry->user_id) . '">' . $fQry->username . '</a> posted in  <a href="' . $gLink . '">' . $fQry->group_name . '</a>.
                  <span class="d-block font-xssss fw-500 mt-1 lh-3 text-grey-500">' . $date . ' ' . date('h:i A', strtotime($fQry->posted_time)) . '</span>
                </h4></div>
                <p class="fw-500 text-grey-500 lh-26 font-xssss w-100 mb-2">
                ' . $this->turnUrlIntoHyperlink($fQry->post_detail) . '
                
              </p></div>';
              $html .= '<div class="card bg-transparent-card w-100 border-0 ps-5 mb-3">';
                $html .= '<img src="' . $img . '" alt="user" class="w40 position-absolute left-0" />
                <h5 class="font-xsss text-grey-900 mb-1 mt-0 fw-700 d-block">
                  ' . $detail['name'] . '
                  <span class="text-grey-400 font-xsssss fw-600 float-right mt-1">
                    ' . $time . '</span>
                </h5>
                <h6 class="text-grey-500 fw-500 font-xssss lh-4">
                  ' . $row->notify_message . '
                </h6>
              </div>';

                // if ($row->view_status == 1) {
                //     $update['view_status'] = 0;
                //     $this->db->where('notification_id', $row->notification_id);
                //     $this->db->update('notifications', $update);
                // }
            }
        }
        if ($html == "") {
            $html .= "No Notifications";
        } else {
            $html .= '<h5 class="fw-700 font-xss mb-4"><a href="' . base_url('notificationPage') . '">View More</a></h5>';
        }
        echo $html;
    }

    public function notifactionPageList()
    {
        $get['user_id'] = $this->session->userdata('tex_user_id');
        $count = 0;

        $return = array();
        $qry = $this->db->get_where('notifications', $get);
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                $detail = $this->uDetail($row->nuser_id);
                if ($row->post_id != 0) {
                    $sGet['post_id'] = $row->post_id;
                    $this->db->join('users_list ul', 'ul.user_id = pl.user_id');
                    $this->db->join('group_list gl', 'gl.group_id = pl.group_id');
                    $fQry = $this->db->get_where('post_list pl', $sGet)->row();
                    $sQry = $this->db->get_where('post_multimedia', $sGet);
                    if ($sQry->num_rows() > 0) {
                        $res = $sQry->result_array();
                        $img = $res[0]['file_link'];
                    } else {
                        $img = "";
                    }
                } else {

                    if (strpos($detail['image'], 'https') !== false) {
                        $img = $detail['image'];
                    } else {
                        $img = $detail['image'] == NULL ? "https://ui-avatars.com/api/?background=random&name=" . $detail['profile_name'] : base_url('admin/' . $detail['image']);
                    }
                }

                $d1 = new DateTime($row->date . " " . $row->time);
                $d2 = new DateTime(date('Y-m-d H:i:s'));
                $interval = $d1->diff($d2);
                if ($interval->d == 0) {
                    if ($interval->h == 0) {
                        $time = $interval->i == 0 ? "just now" : $interval->i . " mins ago";;
                    } else {
                        $time = $interval->h . " Hrs ago";
                    }
                } else {
                    $time = $interval->d >= 31 ? $interval->d . " days ago" : ($interval->d / 7) . " weeks ago";
                }
                $gLink = base_url('groupPage/' . $fQry->group_id);
                $groupImg = $fQry->group_image == NULL ? "https://ui-avatars.com/api/?background=random&name=" . $fQry->username : base_url($fQry->username);
                $date = date('Y-m-d') == $fQry->posted_date ? "Today" : date('d-m-Y', strtotime($fQry->posted_date));

                $html = ' <div class="card bg-transparent-card w-100 border-0 mb-3">
                <div class="card-body p-0 d-flex"><figure class="avatar me-3">
                <a href="' . $gLink . '">
                  <img src="' . $groupImg . '" alt="image" class="shadow-sm rounded-circle w45" />
                </a>
                  </figure>
                  
                <h4 class="fw-700 text-grey-900 font-xssss mt-1">
                  <a style="padding-left: 0px !important;" href="' . base_url('userPage/' . $fQry->user_id) . '">' . $fQry->username . '</a> posted in  <a style="padding-left: 0px !important;" href="' . $gLink . '">' . $fQry->group_name . '</a>.
                  <span class="d-block font-xssss fw-500 mt-1 lh-3 text-grey-500">' . $date . ' ' . date('h:i A', strtotime($fQry->posted_time)) . '</span>
                </h4></div>
                
                <p class="d-block fw-500 text-grey-500 lh-26 font-xssss w-100 mb-2 p-2" style="margin-left:9%">
                ' . $this->turnUrlIntoHyperlink($fQry->post_detail) . '
                
              </p></div>';

                $return[] = array(
                    'post_id' => $row->post_id,
                    'notify_message' => $row->notify_message,
                    'username' => $detail['name'],
                    'user_id' => $row->nuser_id,
                    'view_status' => $row->view_status,
                    'image' => $img,
                    'time' => $time,
                    'postData' => $html
                );
                if ($row->view_status == 1) {
                    $count += 1;
                    $update['view_status'] = 0;
                    $this->db->where('notification_id', $row->notification_id);
                    $this->db->update('notifications', $update);
                }
            }
        }

        $val = array('return' => $return, 'count' => $count);

        return $val;
    }

    public function groupUserFeeds()
    {
        $get['user_id'] = $uid = $this->session->userdata('tex_user_id');
        $cnt = $this->input->post('cnt');
        $html = "";

        if (1) {
            $group = array();
            $user = array();

            $gCheck = 0;
            if ($this->input->post('page') == "group") {
                $this->db->where('gl.group_id', $this->input->post('type'));
            } else {
                $this->db->where('pl.user_id', $this->input->post('type'));
            }

            $this->db->where('gl.status', 1);
            $this->db->where('pl.status', 1);
            $this->db->where('pl.post_pending_status !=', 1);

            $this->db->from('post_list pl');
            $this->db->join('group_list gl', 'gl.group_id = pl.group_id');
            $this->db->join('users_list ul', 'ul.user_id = pl.user_id');
            $this->db->join('group_types gt', 'gt.gt_id = gl.group_type_id');

            $this->db->limit($cnt);
            $sQry = $this->db->order_by('posted_date DESC,posted_time DESC')->get();

            $postId = array();
            $j = 0;
            if ($sQry->num_rows() > 0) {
                foreach ($sQry->result() as $row) {

                    if (in_array($row->post_id, $postId)) {
                        continue;
                    }
                    $postId = array($row->post_id);
                    $date = date('Y-m-d') == $row->posted_date ? "Today" : date('d-m-Y', strtotime($row->posted_date));
                    $files = $this->getPostFile($row->post_id);
                    $like = $this->checkLike($row->post_id, $uid);
                    $saveStatus = $this->checkSaveStatus($row->post_id, $uid);
                    $gLink = base_url('groupPage/' . $row->group_id);
                    $uLink = base_url('userPage/' . $row->user_id);
                    $jsArg = $row->group_id . ",'group','postSide'";
                    $groupImg = $row->group_image == NULL ? "https://ui-avatars.com/api/?background=random&name=" . $row->group_name : base_url('admin/' . $row->group_image);
                    $html .= ' <div class="card w-100 shadow-xss rounded-xxl border-0 p-4 mb-3">
                    <div class="card-body p-0 d-flex">
                      <figure class="avatar me-3">
                      <a href="' . $gLink . '">
                        <img src="' . $groupImg . '" alt="image" class="shadow-sm rounded-circle w45" />
                      </a>
                     </figure>
                      <h4 class="fw-700 text-grey-900 font-xssss mt-1">
                      <a href="' . $uLink . '">' . $row->username . '</a> posted in <a href="' . $gLink . '">' . $row->group_name . '</a>.
                        <span class="d-block font-xssss fw-500 mt-1 lh-3 text-grey-500">' . $date . ' ' . date('h:i A', strtotime($row->posted_time)) . '</span>
                      </h4>
                      <a href="#" class="ms-auto" id="dropdownMenu' . $row->post_id . '" data-bs-toggle="dropdown" aria-expanded="false"><i class="ti-more-alt text-grey-900 btn-round-md bg-greylight font-xss"></i></a>
                      <div class="dropdown-menu dropdown-menu-end p-4 rounded-xxl border-0 shadow-lg" aria-labelledby="dropdownMenu' . $row->post_id . '">
                   
                     
                    
                      <div class="card-body p-0 d-flex mt-2" onclick="followUserGroup(' . $jsArg . ')">
                        <i class="feather-lock text-grey-500 me-3 font-lg"></i>
                        <h4 class="fw-600 mb-0 text-grey-900 font-xssss mt-0 me-4">
                        Follow Group
                          <span class="d-block font-xsssss fw-500 mt-1 lh-3 text-grey-500">add to following list</span>
                        </h4>
                      </div>
                      <div class="card-body p-0 d-flex mt-3"  data-toggle="modal"
                      data-target="#reportModal" onclick="openReportModal(' . $row->post_id . ')">
                        <i class="feather-alert-octagon text-grey-500 me-3 font-lg"></i>
                        <h4 class="fw-600 mb-0 text-grey-900 font-xssss mt-0 me-4">
                          Report Post
                          <span class="d-block font-xsssss fw-500 mt-1 lh-3 text-grey-500">Report post contents</span>
                        </h4>
                      </div>';

                    if ($this->input->post('page') != 'group' && $row->user_id == $this->session->userdata('tex_user_id')) {
                        $html .= '<div class="card-body p-0 d-flex mt-3" data-toggle="modal"
                        data-target="#removePostModal" onclick="removePostId(' . $row->post_id . ')">
                        <i class="feather-alert-octagon text-grey-500 me-3 font-lg"></i>
                        <h4 class="fw-600 mb-0 text-grey-900 font-xssss mt-0 me-4">
                          Remove Post
                          <span class="d-block font-xsssss fw-500 mt-1 lh-3 text-grey-500">Save to your saved items</span>
                        </h4>
                      </div>';
                    }
                    $html .= '</div>
                      </div>
                    <div class="card-body p-0 me-lg-5">
                      <p class="fw-500 text-grey-500 lh-26 font-xssss w-100 mb-2">
                        ' . $row->post_detail . '
                        
                      </p>
                    </div>';
                    if (!empty($files['images']) || !empty($files['videos'])) {
                        $html .= '<div class="card-body">
                        <div class="slider">
                          <div class="slider__items">';
                        $i = 0;
                        foreach ($files['images'] as $rows) {

                            $active = $i == 0 ? "active" : "";
                            $html .=  '<div class="slider__img ' . $active . '" onclick="fetchPostData(' . $row->post_id . ')">
                              <a href="' . base_url($rows['img']) . '" data-lightbox="roadtrip_' . $j . '">
                                <img src="' . base_url($rows['img']) . '" alt="" />
                              </a>
                            </div>';
                            $i++;
                        }

                        $html .= '</div>
                          <div class="left__slide">
                            <i class="fas fa-chevron-left"></i>
                          </div>
                          <div class="right__slide">
                            <i class="fas fa-chevron-right"></i>
                          </div>
                        </div>
                        </div>';
                    }
                    $comments = $row->comments == 0 ? "" : $row->comments;
                    $likes =  $row->likes == 0 ? "" : $row->likes;
                    $likeClass =  $like == true ? "text-success" : "";
                    $likeArgs = $row->post_id . ",'post','feedLike_'";
                    $shareLink = base_url('sharedPost/' . $row->post_id);

                    $html .= '<div class="card-body d-flex p-0">
                      <a onclick="likePost(' . $likeArgs . ')"  class="emoji-bttn d-flex align-items-center fw-600 text-grey-900 text-dark lh-26 font-xssss me-2">
                        <span  id="feedLike_' . $row->post_id . '" class="likeBtn ' . $likeClass . '"><i class="feather-thumbs-up text-white bg-primary-gradiant me-1 btn-round-xs font-xss"></i>' . $likes . ' Like</span></a>
                    
                      <a  class="d-flex align-items-center fw-600 text-grey-900 text-dark lh-26 font-xssss" onclick="fetchPostData(' . $row->post_id . ')"><i class="feather-message-circle text-dark text-grey-900 btn-round-sm font-lg"></i><span class="d-none-xss">' . $comments . ' Comment</span></a>
                      <a   id="dropdownMenuShare' . $row->post_id . '"
                      data-bs-toggle="dropdown"
                      aria-expanded="false" class="ms-auto d-flex align-items-center fw-600 text-grey-900 text-dark lh-26 font-xssss"><i class="feather-share-2 text-grey-900 text-dark btn-round-sm font-lg"></i><span class="d-none-xs">Share</span></a>
                      <div
                      class="dropdown-menu dropdown-menu-end p-4 rounded-xxl border-0 shadow-lg"
                      aria-labelledby="dropdownMenuShare' . $row->post_id . '"
                    >
                      <h4
                        class="fw-700 font-xss text-grey-900 d-flex align-items-center"
                      >
                        Share
                        <i
                          class="feather-x ms-auto font-xssss btn-round-xs bg-greylight text-grey-900 me-2"
                        ></i>
                      </h4>
                      <div class="card-body p-0 d-flex">
                        <ul
                          class="d-flex align-items-center justify-content-between mt-2"
                        >
                          <li class="me-1">
                            <a target="_blank"  href="https://www.facebook.com/sharer/sharer.php?u=' . $shareLink . '" class="btn-round-lg bg-facebook"
                              ><i class="font-xs ti-facebook text-white"></i
                            ></a>
                          </li>
                          <li class="me-1">
                            <a href="https://twitter.com/intent/tweet?url=' . $shareLink . '" target="_blank" class="btn-round-lg bg-twiiter"
                              ><i class="font-xs ti-twitter-alt text-white"></i
                            ></a>
                          </li>
                          <li class="me-1">
                            <a  href="https://www.linkedin.com/sharing/share-offsite/?url=' . $shareLink . '" target="_blank" class="btn-round-lg bg-linkedin"
                              ><i class="font-xs ti-linkedin text-white"></i
                            ></a>
                          </li>
                          <li>
                            <a target="_blank" href="https://wa.me/?text=' . $shareLink . '" class="btn-round-lg bg-whatsup"
                              ><i class="font-xs feather-phone text-white"></i
                            ></a>
                          </li>
                          <li>
                            <a target="_blank" href="http://pinterest.com/pin/create/link/?url=' . $shareLink . '
                            " class="btn-round-lg bg-pinterest"
                              ><i class="font-xs ti-pinterest text-white"></i
                            ></a>
                          </li>
                        </ul>
                      </div>
                     
                      <h4
                        class="fw-700 font-xssss mt-4 text-grey-500 d-flex align-items-center mb-3"
                      >
                        Copy Link
                      </h4>
                      <i
                        class="feather-copy position-absolute right-35 mt-3 font-xs text-grey-500"
                        onclick = "copyToClipboard(' . $row->post_id . ')"
                      ></i>
                      <input
                        type="text" id="copyLink_' . $row->post_id . '"
                        value="' . $shareLink . '" readonly
                        class="bg-grey text-grey-500 font-xssss border-0 lh-32 p-2 font-xssss fw-600 rounded-3 w-100 theme-dark-bg"
                      />
                    </div>
                    </div>
                  </div>';
                    $j++;
                }
            }
        }
        $text = $sQry->num_rows() <= $cnt ? "No Post Available" : '<div class="dot-typing"></div>';
        $html .= '<div class="card w-100 text-center shadow-xss rounded-xxl border-0 p-4 mb-3 mt-3">
        <div class="snippet mt-2 ms-auto me-auto" data-title=".dot-typing">
          <div class="stage">
            ' . $text . '
          </div>
        </div>
      </div>';
        echo $html;
    }

    public function addComment()
    {

        $pGet['post_id'] = $get['post_id'] = $pid = $this->input->post('post_id');

        $get['user_id'] = $uid = $this->session->userdata('tex_user_id');

        $get['comment'] = $this->input->post('cmt');
        $get['date'] = date('Y-m-d');
        $get['time'] = date('H:i:s');
        $qry = $this->db->insert('post_comments_list', $get);
        if ($qry) {
            $id = $this->db->insert_id();
            $math = "+";

            $msg = "Commented";
            $status = true;
            $pQry = $this->db->get_where('post_list', $pGet)->row();
            if ($pQry->user_id != $uid) {
                $ins['user_id'] = $pQry->user_id;
                $ins['nuser_id'] = $uid;
                $ins['post_id'] = $pid;
                $ins['notify_message'] = "is commented on your post";
                $this->db->insert('notifications', $ins);
            }

            $this->db->query("UPDATE post_list SET comments = comments " . $math . " 1 WHERE post_id =" . $pid);
        } else {
            $msg = "Something Wrong";
            $status = false;
        }

        echo $status;
    }

    public function removeComment()
    {
        $comment_id = $this->input->post('comment_id');
        $post_id  = $this->input->post('post_id');
        $math = "-";
        $qry = $this->db->delete('post_comments_list', array('pcl_id' => $comment_id));
        if ($qry) {
            $this->db->query("UPDATE post_list SET comments = comments " . $math . " 1 WHERE post_id =" . $post_id);
            $status = true;
        } else {
            $status = false;
        }
        echo $status;
    }
    public function groupFollowersList($id)
    {
        $uId = $this->session->userdata('tex_user_id');

        $get['user_following_id'] = $id;



        $qry = $this->db->get_where('user_group_merge', $get);

        $list = array();

        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {

                $fStatus = $this->followCheck($uId, $row->user_id, "user");
                $detail = $this->uDetail($row->user_id);
                $fStatus == "Following" ? "followed" : "follow";
                $type = "user";


                $list[] = array(
                    'id' => $detail['id'],
                    'name' => $detail['name'],
                    'image' => $detail['image'],
                    'type' => $type,
                    'follow_status' => $fStatus
                );
            }
        }

        return  $list;
    }

    public function userFollowingList($id, $pageType)
    {
        $uId = $this->session->userdata('tex_user_id');

        if ($pageType == "following") {
            $get['user_id'] = $id;
        } else {
            $get['user_following_id'] = $id;
            $get['following_type'] = "user";
        }


        $qry = $this->db->get_where('user_group_merge', $get);

        $list = array();
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                if ($pageType == "following") {
                    if ($row->following_type == "group") {
                        $fStatus = $this->followCheck($uId, $row->user_following_id, "group");
                        $detail = $this->gDetail($row->user_following_id);
                        $type = "group";
                    } else {
                        $fStatus = $this->followCheck($uId, $row->user_following_id, "user");
                        $detail = $this->uDetail($row->user_following_id);
                        $type = "user";
                    }
                } else {
                    $fStatus = $this->followCheck($uId, $row->user_id, "user");
                    $detail = $this->uDetail($row->user_id);
                    $type = "user";
                }


                $list[] = array(
                    'id' => $detail['id'],
                    'name' => $detail['name'],
                    'image' => $detail['image'],
                    'type' => $type,
                    'follow_status' => $fStatus
                );
            }
        }

        // print_r($list);exit;
        return $list;
    }

    public function updatePassword()
    {
        $id = $get['user_id'] = $this->session->userdata('tex_user_id');
        $get['password'] = md5($this->input->post('old'));
        $up['password'] = md5($this->input->post('newp'));
        $qry = $this->db->get_where('users_list', $get);
        if ($qry->num_rows() > 0) {
            $this->db->where('user_id', $id);
            $this->db->update('users_list', $up);
            echo "Password Updated";
        } else {
            echo "Old Password Wrong";
        }
    }

    public function searchPage()
    {
        $uid = $this->session->userdata('tex_user_id');
        $search = $this->input->post('search');

        $ulist = array();
        $glist = array();

        $qry = $this->db->like('username', $search)->from('users_list')->get();
        $this->db->join('group_types gt', 'gt.gt_id = gl.group_type_id');
        $sQry = $this->db->like('group_name', $search)->from('group_list gl')->get();

        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                $fStatus = $this->followCheck($uid, $row->user_id, "user");
                $ulist[] = array(
                    'user_id' => $row->user_id,
                    'username' => $row->username,
                    'profile_name' => $row->profile_name,
                    'profile_picture' => $row->profile_picture,
                    'follow_status' => $fStatus
                );
            }
        }

        if ($sQry->num_rows() > 0) {
            foreach ($sQry->result() as $row) {
                $fStatus = $this->followCheck($uid, $row->group_id, "group");
                $glist[] = array(
                    'group_id' => $row->group_id,
                    'group_name' => $row->group_name,
                    'group_description' => $row->group_description,
                    'group_image' => $row->group_image,
                    'group_type' => $row->group_type_name,
                    'follow_status' => $fStatus
                );
            }
        }

        return array('user' => $ulist, 'group' => $glist);
    }

    public function pendingPostList()
    {

        $get['user_id'] = $uid = $this->session->userdata('tex_user_id');

        $return = array();

        $this->db->select('*');
        $this->db->from('post_list pl');
        $this->db->join('group_list gl', 'gl.group_id = pl.group_id');
        $this->db->join('users_list ul', 'ul.user_id = pl.user_id');
        $this->db->join('group_types gt', 'gt.gt_id = gl.group_type_id');
        $this->db->where('pl.user_id', $uid);
        $this->db->where('pl.post_pending_status', 1);
        $sQry = $this->db->order_by('posted_date DESC,posted_time DESC')->get();


        if ($sQry->num_rows() > 0) {
            foreach ($sQry->result() as $row) {
                $date = date('Y-m-d') == $row->posted_date ? "Today" : date('d-m-Y', strtotime($row->posted_date));
                $files = $this->getPostFile($row->post_id);


                $return[] = array(
                    'post_id' => $row->post_id,
                    'user_id' => $row->user_id,
                    'group_id' => $row->group_id,
                    'group_name' => $row->group_name,
                    'username' => $row->username,
                    'profile_name' => $row->profile_name,
                    'group_image' => $row->group_image,
                    'group_name' => $row->group_name,
                    'post_files' =>  $files,
                    'post_detail' => $row->post_detail,

                    'posted_date' => $date,
                    'posted_time' => date('h:i A', strtotime($row->posted_time))

                );
            }
        }
        return $return;
    }


    public function postDetail($id)
    {
        $uid = $this->session->userdata('tex_user_id');
        $this->db->select('*');
        $this->db->from('post_list pl');
        $this->db->join('group_list gl', 'gl.group_id = pl.group_id');
        $this->db->join('users_list ul', 'ul.user_id = pl.user_id');

        $this->db->where('pl.post_id', $id);
        $this->db->where('pl.status', 1);
        $qry = $this->db->get();
        $return = array();
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                $date = date('Y-m-d') == $row->posted_date ? "Today" : date('d-m-Y', strtotime($row->posted_date));
                $files = $this->getPostFile($row->post_id);
                $comments = $this->postCommentsList($row->post_id);
                $like = $this->checkLike($row->post_id, $uid);
                $saveStatus = $this->checkSaveStatus($row->post_id, $uid);
                if($row->profile_picture == NULL){
                    $profile_picture = "https://ui-avatars.com/api/?background=0D8ABC&color=fff&name=".$row->profile_name;
                }else{
                    $profile_picture = base_url('admin/'.$row->profile_picture);
                }
                $return = array(
                    'post_id' => $row->post_id,
                    'user_id' => $row->user_id,
                    'group_id' => $row->group_id,
                    'group_name' => $row->group_name,
                    'username' => $row->username,
                    'profile_name' => $row->profile_name,
                    'profile_picture' => $profile_picture,
                    'group_name' => $row->group_name,
                    'post_files' =>  $files,
                    'post_detail' => $row->post_detail,
                    'likes_count' => $row->likes,
                    'comments_count' => $row->comments,
                    'comments' => $comments,
                    'like_status' => $like,
                    'save_status' => $saveStatus,
                    'posted_date' => $date,
                    'posted_time' => date('h:i A', strtotime($row->posted_time))

                );
            }
        }

        return $return;
    }

    public function postCommentsList($pid)
    {
        $get['post_id'] = $pid;
        $get['pcl.status'] = 1;
        $user_id = $this->session->userdata('tex_user_id');
        $this->db->join('users_list ul', 'pcl.user_id = ul.user_id');
        $this->db->order_by('date DESC,time DESC');
        $qry = $this->db->get_where('post_comments_list pcl', $get);
        $return = array();
        $own = array();
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                $date = date('Y-m-d') == $row->date ? "Today" : date('d-m-Y', strtotime($row->date));
                $frGet['comment_id'] = $tGet['comment_id']  = $row->pcl_id;
                $commentReply = $this->getCommentReply($row->pcl_id);
                $commentLikeCount = $this->db->get_where('likeacomment_list', $tGet)->num_rows();
                $frGet['user_id'] = $user_id;
                $commentLikeStatus = $this->db->get_where('likeacomment_list', $tGet)->num_rows() > 0 ? true : false;
                if ($user_id == $row->user_id) {
                    if($row->profile_picture == NULL){
                        $profile_picture = "https://ui-avatars.com/api/?background=0D8ABC&color=fff&name=".$row->username;
                    }else{
                        $profile_picture = base_url('admin/'.$row->profile_picture);
                    }

                    $own[] = array(
                        'comment_id' => $row->pcl_id,
                        'comment' => $row->comment,
                        'commented_person' => $row->username,
                        'commented_profile' =>  $profile_picture,
                        'commented_person_id' => $row->user_id,
                        'reply_count' => $commentReply['count'],
                        'comment_replies' => $commentReply['data'],
                        'comment_like_count' => $commentLikeCount,
                        'comment_like_status' => $commentLikeStatus,
                        'date' => $date,
                        'time' => date('H:i A', strtotime($row->time))
                    );
                } else {
                    $return[] = array(
                        'comment_id' => $row->pcl_id,
                        'comment' => $row->comment,
                        'commented_person' => $row->username,
                        'commented_profile' => $row->profile_picture,
                        'commented_person_id' => $row->user_id,
                        'reply_count' => $commentReply['count'],
                        'comment_replies' => $commentReply['data'],
                        'comment_like_count' => $commentLikeCount,
                        'date' => $date,
                        'time' => date('H:i A', strtotime($row->time))
                    );
                }
            }
        }

        return array('owncmt' => $own, 'otherscmt' => $return);
    }

    public function postReportTypes()
    {

        $get['status'] = 1;
        $qry = $this->db->get_where('report_type_list', $get);
        $return = array();
        $html = "";
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {


                $html .= '<div class="page">
            <input type="radio" name ="report" value="' . $row->report_type_id . '" class="page__select" />
            <div class="page__title">' . $row->report_message . '</div>
          </div>';
            }
        }
        $html .= '<div class="page">
       <input type="radio" name ="report" value="0" onclick="toggleClass()" class="page__select" />
       <div class="page__title">Something else</div>
     </div>
     <span id="reportHideSpan" class="hidden">
     <textarea name="reportTextArea" id="reportTextArea" cols="30" class="form__input"></textarea>
     </span>
     ';

        echo $html;
    }

    public function addReport()
    {

        $ins['user_id'] =  $this->session->userdata('tex_user_id');
        $ins['report_type_id'] = $this->input->post('report_id');
        $ins['reported_id'] = $this->input->post('post_id');
        $ins['message'] = $this->input->post('report_text');

        $qry = $this->db->insert('report_list', $ins);

        if ($qry) {
            $msg = "Reported Successfully";
            $status = TRUE;
        } else {
            $msg = "Something Wrong";
            $status = FALSE;
        }

        echo json_encode(array('status' => $status, 'msg' => $msg));
    }

    public function removePost()
    {
        $id = $this->input->post('post_id');
        $update['status'] = 0;
        $this->db->where('post_id', $id);
        $qry = $this->db->update('post_list', $update);
        if ($qry) {
            $status = true;
            $this->session->set_userdata('toastmsg', 'Post Removed Successfully');
        } else {
            $status = false;
        }
        echo json_encode(array('status' => $status));
    }

    public function sendMail()
    {

        $get['user_id'] = $this->session->userdata('tex_user_id');
        $qry = $this->db->get_where('users_list', $get)->row();
        $body = $qry->refferal_code;
        //  $body .= "<br>Your order id:".$qres[0]['order_id'];

        $subject = "TrulyEx - REFERRAL CODE";




        $to = $this->input->post('mail');





        $bodymes = '<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="style.css">
<title>Email</title>
<style>
body{
background-color: #e1e1e1;
font-family: Arial, Helvetica, sans-serif;
}

.container{
max-width: 680px;
width: 100%;
margin: auto;
}

main{
margin: 0 auto;
display: flex;
flex-direction: column;
color: #555555; 
}

.body h2{
font-weight: 300;
color: #464646;
}





a{
text-decoration: underline; 
color: #0c99d5; 
}


.body{
padding: 20px;
background-color: white;
font-family: Geneva, Tahoma, Verdana, sans-serif; 
font-size: 16px; 
line-height: 22px; 
color: #555555; 
}




</style>
</head>

<body>

<main class="container">

<div class="body">
   <h6> Dear ' . $qry->profile_name . ',</h6>
    <p>Your Truly Ex Referal Code is:' . $body . '</p>
<p>Thanks & Regards,</p>
<p>Truly Ex</p>
</div>

</main>

</body>

</html>';





        $bodymessage = $bodymes;

        $header = "From:trulyex.app@gmail.com" . " \r\n";
        // $header = "Cc:afgh@somedomain.com \r\n";
        $header .= "MIME-Version: 1.0\r\n";
        $header .= "Content-type: text/html\r\n";
        // ;
        $mail = mail($to, $subject, $bodymessage, $header);
        if ($mail) {
            $status = true;
        } else {
            print_r($mail);
            exit;
        }
        echo json_encode(array('status' => $status));
    }
}
