<?php
class Appapi_model extends CI_Model
{

    public function onlineActivity()
    {

        if ($this->session->userdata('tex_user_id')) {
            $id = $this->session->userdata('tex_user_id');
        } else {
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $id = $this->input->post('user_id');
            } else {
                $id = 0;
            }
        }

        if ($id != 0) {
            $update['last_activity_date'] = date('Y-m-d');
            $update['last_activity_time'] = date('H:i:S');
            $this->db->where('user_id', $id);
            $this->db->update('users_list', $update);
        }
    }

    public function login()
    {
        $name = $this->input->post('name');
        $password = md5($this->input->post('password'));

        $this->db->select('*');
        $this->db->from('users_list');
        $this->db->where('password', $password);
        $this->db->group_start();
        $this->db->where('username', $name);
        $this->db->or_where('mobile_no', $name);
        $this->db->or_where('email', $name);
        $this->db->group_end();
        $qry = $this->db->get();
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                $return = array(
                    'status' => TRUE,
                    'msg' => "Login Successfull",
                    'user_id' => $row->user_id,
                    'username' => $row->username,
                    'profile_picture' => $row->profile_picture,
                    'profile_name' => $row->profile_name
                );
            }
        } else {
            $return = array(
                'status' => FALSE,
                'msg' => "Invalid Credentials",
                'user_id' => "",
                'username' => "",
                'profile_picture' => "",
                'profile_name' => ""
            );
        }
        echo json_encode($return);
    }

    public function register()
    {
        $ins['username'] = $this->input->post('user_name');
        $ins['profile_name'] = $this->input->post('profile_name');
        $ins['mobile_no'] = $this->input->post('mobile');
        $ins['email'] = $this->input->post('email');
        $ins['dob'] = $this->input->post('dob');
        $ins['password'] = md5($this->input->post('password'));
        $ins['social_media_name'] = $this->input->post('social_media_name');
        $ins['social_media_id'] = $check['social_media_id'] = $this->input->post('social_media_id');

        if ($check['social_media_id'] != "") {
            $qry = $this->db->get_where('users_list', $check)->row();
            if ($qry != NULL) {
                $uid = $qry->user_id;
                $username = $qry->username;
            }
        } else {
            $qry = $this->db->insert('users_list', $ins);
            $uid = $this->db->insert_id();
            $username = $this->input->post('user_name');
        }



        if ($qry) {
            $return = array('status' => TRUE, "user_id" => $uid, "username" => $username);
        } else {
            $return = array('status' => FALSE, "user_id" => "", "username" => "");
        }

        echo json_encode($return);
    }

    public function checkRegister()
    {

        $val = $this->input->post('val');
        if ($this->input->post('type') == 1) {
            $get['mobile_no'] = $val;
        } else {
            $get['email'] = $val;
        }

        $qry = $this->db->get_where('users_list', $get);
        if ($qry->num_rows() == 0) {
            echo json_encode(array('status' => true, 'msg' => "Allow"));
        } else {
            echo json_encode(array('status' => false, 'msg' => "Already Registered"));
        }
    }
    public function sendOtp()
    {
        $ins['otp'] = $otp = rand('1000', '9999');
        $ins['mobile'] = $this->input->post('mobile');
        $ins['date'] = date('Y-m-d');
        $ins['time'] = date('H:i:s');
        $this->db->insert('otp_user', $ins);
        echo json_encode(array("otp" => $otp));
    }

    public function forgotPassword()
    {
        $get['mobile_no'] = $this->input->post('mobile');

        $qry = $this->db->get_where('users_list', $get);
        if ($qry->num_rows() > 0) {
            $res = $qry->result_array();
            $otp = rand('1000', '9999');
            $user_id = $res[0]['user_id'];
            $status = "true";
        } else {
            $status = "false";
            $otp = "";
            $user_id = 0;
        }
        echo json_encode(array("status" => $status, "otp" => $otp, "user_id" => $user_id));
    }

    public function updatePassword()
    {
        $id = $this->input->post('user_id');
        $up['password'] = md5($this->input->post('password'));
        $this->db->where('user_id', $id);
        $this->db->update('users_list', $up);
        echo json_encode(array('msg' => "Password Changed"));
    }
    public function uploadProfilePicture()
    {
        $id = $this->input->post('id');
        $type = $this->input->post('type');

        $config['upload_path']   = 'admin/images/';
        $config['allowed_types'] = '*';
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('pro_pic')) {
            // $data['profile_picture'] = $this->upload->display_errors();
            $msg = "Something Wrong";
            $status = false;
        } else {

            $uploadedImage = $this->upload->data();
            $pic = 'images/' . $uploadedImage['file_name'];
            $msg = "Profile Added";
            $status = true;
        }

        if ($status) {
            if ($type == "user") {
                $data['profile_picture'] = $pic;
                $this->db->where('user_id', $id);
                $this->db->update('users_list', $data);
            } else {
                $data['group_image'] = $pic;
                $this->db->where('group_id', $id);
                $this->db->update('group_list', $data);
            }
        }

        echo json_encode(array('status' => $status, 'msg' => $msg));
    }



    public function topGroups()
    {
         
        $get['status'] = 1;
        $get['group_type_id'] = $this->input->post('group_type_id');
        $qry = $this->db->get_where('group_list', $get);
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                      $followStatus = $this->followCheck($this->input->post('user_id'), $row->group_id, 'group');

                $return[] = array(
                    'group_id' => $row->group_id,
                    'group_name' => $row->group_name,
                    'group_image' => $row->group_image,
                    'follow_status' => $followStatus
                );
            }
        } else {
            $return = array();
        }
        echo json_encode($return);
    }

    public function groupPeopleFollowStatus()
    {
        $get['user_id'] = $fid = $this->input->post('user_id');
        $get['user_following_id'] = $followid =  $this->input->post('follow_id');
        $get['following_type'] = $this->input->post('following_type');
        if ($fid == "" || $followid == "" || $this->input->post('following_type') == "") {
            echo json_encode(array('status' => false, 'msg' => "Something Wrong"));
            die;
        }
        $qry = $this->db->get_where('user_group_merge', $get)->row();
        $status = true;
        if ($qry == NULL) {


            $get['date'] = date('Y-m-d');
            $get['time'] = date('H:i:s');
            $this->db->insert('user_group_merge', $get);
            $math = "+";
            if($this->input->post('following_type') == 'user'){
                 $id = $this->db->insert_id();
            $ins['user_id'] = $followid;
            $ins['nuser_id'] = $fid;
            $ins['post_id'] = 0;
            $ins['notify_message'] = "is started to following you";
            $this->db->insert('notifications', $ins);
            }
           
            $msg = "Following";
        } else {
            $id = $qry->ugm_id;
            $math = "-";
            $this->db->where('ugm_id', $id);
            $this->db->delete('user_group_merge');
            $msg = "Follow";
            $get['followed_date'] = $qry->date;
            $get['followed_time'] = $qry->time;
            $get['unfollowed_date'] = date('Y-m-d');
            $get['unfollowed_time'] = date('H:i:s');
            $this->db->insert('unfollow_history', $get);
        }

        if ($this->input->post('following_type') == "user") {
            $this->db->query("UPDATE users_list SET user_followers = user_followers " . $math . " 1 WHERE user_id =" . $followid);
            $this->db->query("UPDATE users_list SET user_following = user_following " . $math . " 1 WHERE user_id =" . $fid);
        } else {
            $this->db->query("UPDATE group_list SET followers = followers " . $math . " 1 WHERE group_id =" . $followid);
            $this->db->query("UPDATE users_list SET user_following = user_following " . $math . " 1 WHERE user_id =" . $fid);
        }

        echo json_encode(array('status' => $status, 'msg' => $msg));
    }

    public function createGroup()
    {

        $ins['admin_id'] =  $this->input->post('user_id');
        $ins['group_type_id'] =  $this->input->post('group_type_id');
        $ins['group_name'] =  $this->input->post('group_name');
        $ins['group_description'] =  $this->input->post('group_description');
        $config['upload_path']   = 'admin/images/';
        $config['allowed_types'] = '*';
        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('pro_pic')) {
            // $data['profile_picture'] = $this->upload->display_errors();
            $msg = "Something Wrong";
            $status = false;
        } else {

            $uploadedImage = $this->upload->data();
            $pic = 'images/' . $uploadedImage['file_name'];
            $msg = "Profile Added";
            $status = true;
            $ins['group_image'] = $pic;
        }

        $qry = $this->db->insert('group_list', $ins);
        if ($qry) {
            $id = $this->db->insert_id();
            $status = true;
            $msg = "Group Added";
        } else {
            $status = false;
            $msg = "Something Wrong";
            $id = 0;
        }

        echo json_encode(array('status' => $status, 'msg' => $msg, 'id' => $id));
    }

    public function updateGroupDescription()
    {
        $id = $this->input->post('group_id');
        $update['group_description'] =  $this->input->post('group_description');
        $this->db->where('group_id', $id);
        $qry = $this->db->update('group_list', $update);
        if ($qry) {
            $status = true;
            $msg = "Group Description Updated";
        } else {
            $status = false;
            $msg = "Something Wrong";
        }

        echo json_encode(array('status' => $status, 'msg' => $msg));
    }

    public function updateUserProfile()
    {
        $id = $this->input->post('user_id');
        $update['profile_name'] =  $this->input->post('profile_name');
        $update['dob'] =  $this->input->post('dob');
        $update['username'] =  $this->input->post('username');
        $this->db->where('user_id', $id);
        $qry = $this->db->update('users_list', $update);
        if ($qry) {
            $status = true;
            $msg = "User Profile Updated";
        } else {
            $status = false;
            $msg = "Something Wrong";
        }

        echo json_encode(array('status' => $status, 'msg' => $msg));
    }

    public function checkName()
    {
        $type = $this->input->post('type') == "user" ? "users_list" : "group_list";
        $get['username'] = $this->input->post('username');
        $qry = $this->db->get_where($type, $get);
        if ($qry->num_rows() == 0) {
            $status = true;
            $msg = "Available";
        } else {
            $status = false;
            $msg = "Already Taken";
        }

        echo json_encode(array('status' => $status, 'msg' => $msg));
    }


    public function addPost()
    {
        $get['group_id'] = $this->input->post('group_id');
        $get['user_id'] = $this->input->post('user_id');
        $get['post_detail'] = $this->input->post('post_detail');
        $get['posted_date'] = date('Y-m-d');
        $get['posted_time'] = date('H:i:s');

        $qry = $this->db->insert('post_list', $get);
        $config['upload_path']   = 'admin/images/';
        $config['allowed_types'] = '*';
        $this->load->library('upload', $config);
        if ($qry) {
            $ins['post_id'] = $this->db->insert_id();
            $i = 0;
            $j = 0;
            if(isset($_FILES['file_pic'])){
            foreach ($_FILES['file_pic'] as $row) {

                // if(){
                    
                // }
                if (!empty($_FILES['file_pic']['name'][$i])) {

                    if ($_FILES['file_pic']['name'][$i] != "") {

                        $_FILES['files']['name']       = $_FILES['file_pic']['name'][$i];
                        $_FILES['files']['type']       = $_FILES['file_pic']['type'][$i];
                        $_FILES['files']['tmp_name']   = $_FILES['file_pic']['tmp_name'][$i];
                        // $_FILES['files']['error']      = $_FILES['file_pic']['error'][$i];
                        $_FILES['files']['size']       = $_FILES['file_pic']['size'][$i];

                        if (!$this->upload->do_upload('files')) {
                            $error = array('error' => $this->upload->display_errors());
                        } else {

                            $uploadedImage = $this->upload->data();
                            $ins['file_link'] = 'images/' . $uploadedImage['file_name'];
                            $ins['type'] = "picture";
                            // $this->resizeImage($uploadedImage['file_name']);
                            $this->db->insert('post_multimedia', $ins);
                        }
                    }
                }

                $i++;
            }    
            }
            
            
            if(isset($_FILES['file_video'])){
                foreach ($_FILES['file_video'] as $row) {

                if (!empty($_FILES['file_video']['name'][$j])) {

                    if ($_FILES['file_video']['name'][$j] != "") {

                        $_FILES['files']['name']       = $_FILES['file_video']['name'][$j];
                        $_FILES['files']['type']       = $_FILES['file_video']['type'][$j];
                        $_FILES['files']['tmp_name']   = $_FILES['file_video']['tmp_name'][$j];
                        // $_FILES['files']['error']      = $_FILES['file_video']['error'][$j];
                        // $_FILES['files']['size']       = $_FILES['file_video']['size'][$j];

                        if (!$this->upload->do_upload('files')) {
                            $error = array('error' => $this->upload->display_errors());
                        } else {

                            $uploadedImage = $this->upload->data();
                            $ins['file_link'] = 'images/' . $uploadedImage['file_name'];
                            $ins['type'] = "video";
                            // $this->resizeImage($uploadedImage['file_name']);
                            $this->db->insert('post_multimedia', $ins);
                        }
                    }
                }

                $j++;
            }
            }
            
            
            $status = true;
            $msg = "Post Added";
        } else {
            $status = false;
            $msg = "Post Failed";
        }
        echo json_encode(array('status' => $status, 'msg' => $msg));
    }


    public function removePost()
    {
        $id = $this->input->post('post_id');
        $update['status'] = 0;
        $this->db->where('post_id', $id);
        $qry = $this->db->update('post_list', $update);
        if ($qry) {
            $status = true;
            $msg = "Post Deleted";
        } else {
            $status = false;
            $msg = "Something Wrong";
        }
        echo json_encode(array('status' => $status, 'msg' => $msg));
    }

    public function updatePost()
    {
        $id = $this->input->post('post_id');

        $update['post_detail'] = $this->input->post('post_detail');
        $this->db->where('post_id', $id);
        $qry = $this->db->update('post_list', $update);
        if ($qry) {
            $status = true;
            $msg = "Post Edited";
        } else {
            $status = false;
            $msg = "Something Wrong";
        }
        echo json_encode(array('status' => $status, 'msg' => $msg));
    }

    public function likePost()
    {
        $get['user_id'] = $uid = $this->input->post('user_id');
       $pGet['post_id'] = $get['post_id'] = $pid = $this->input->post('post_id');
        if ($uid == "" || $pid == "") {
            echo json_encode(array($status  = false, 'msg' => ""));
            die;
        }
        $status  = true;
        $qry = $this->db->get_where('user_likes_list', $get)->row();

        if ($qry == NULL) {

            $get['date'] = date('Y-m-d');
            $get['time'] = date('H:i:s');
            $this->db->insert('user_likes_list', $get);
             $pQry = $this->db->get_where('post_list', $pGet)->row();
            $ins['user_id'] = $pQry->user_id;
            $ins['nuser_id'] = $uid;
            $ins['post_id'] = $pid;
            $ins['notify_message'] = "is liked your post";
            $this->db->insert('notifications', $ins);
            $id = $this->db->insert_id();
            $math = "+";

            $msg = "Liked";
        } else {
            $id = $qry->ull_id;
            $math = "-";
            $this->db->where('ull_id', $id);
            $this->db->delete('user_likes_list');
            $msg = "Like";
        }



        $this->db->query("UPDATE post_list SET likes = likes " . $math . " 1 WHERE post_id =" . $pid);


        echo json_encode(array('status' => $status, 'msg' => $msg));
    }

    public function addCommentPost()
    {
       $pGet['post_id'] = $get['post_id'] = $pid = $this->input->post('post_id');
       
        $get['user_id'] = $uid = $this->input->post('user_id');

        $get['comment'] = $this->input->post('comment');
        $get['date'] = date('Y-m-d');
        $get['time'] = date('H:i:s');
        $qry = $this->db->insert('post_comments_list', $get);
        if ($qry) {
            $id = $this->db->insert_id();
            $math = "+";

            $msg = "Commented";
            $status = true;
              $pQry = $this->db->get_where('post_list', $pGet)->row();
            $ins['user_id'] = $pQry->user_id;
            $ins['nuser_id'] = $uid;
            $ins['post_id'] = $pid;
            $ins['notify_message'] = "is commented on your post";
            $this->db->insert('notifications', $ins);



            $this->db->query("UPDATE post_list SET comments = comments " . $math . " 1 WHERE post_id =" . $pid);
        } else {
            $msg = "Something Wrong";
            $status = false;
        }

        echo json_encode(array('status' => $status, 'msg' => $msg));
    }

    public function addReplyComment()
    {
        $ins['pcl_id'] = $this->input->post('comment_id');
        $ins['user_id'] = $uid = $this->input->post('user_id');
        $ins['reply_comment'] = $this->input->post('reply_comment');
        $ins['date'] = date('Y-m-d');
        $ins['time'] = date('H:i:s');
        // $qry = $this->db->get_where('post_comments_reply_list',$get);
        $qry = $this->db->insert('post_comments_reply_list', $ins);
        if ($qry) {
            $msg = "Replied";
            $status = true;
            $get['pcl_id'] = $this->input->post('comment_id');
            $sQry = $this->db->get_where('post_comments_list', $get)->row();
            $Sins['user_id'] = $sQry->user_id;
            $Sins['nuser_id'] = $uid;
            $Sins['post_id'] = $sQry->post_id;
            $Sins['notify_message'] = "is replied to your comment";
            $this->db->insert('notifications', $Sins);
        } else {
            $msg = "Something Wrong";
            $status = false;
        }
        echo json_encode(array('status' => $status, 'msg' => $msg));
    }

    public function removeComment()
    {
        $id = $this->input->post('comment_id');
        $pid = $this->input->post('post_id');
        $update['status'] = 0;
        $this->db->where('pcl_id', $id);
        $qry = $this->db->update('post_comments_list', $update);
        if ($qry) {
            $status = true;
            $msg = "Comment Deleted";
        } else {
            $status = false;
            $msg = "Something Wrong";
        }

        $this->db->query("UPDATE post_list SET comments = comments - 1 WHERE post_id =" . $pid);
        echo json_encode(array('status' => $status, 'msg' => $msg));
    }

    public function appContents()
    {
        $get['id'] = 1;
        $page = $this->input->post('page');
        $qry = $this->db->get_where('app_contents')->row();
        if ($qry != NULL) {
            $text = $qry->$page;
        } else {
            $text = "<h3>No data found</h3>";
        }

        echo json_encode(array('content' => $text));
    }
    public function checkSaveStatus($pid,$uid)
    {
        $get['post_id'] = $pid;
        $get['user_id'] = $uid;
        $qry = $this->db->get_where('saved_posts',$get)->row();
        return $qry != NULL?TRUE:FALSE;
    }
    public function homeFeeds()
    {
        $get['user_id'] = $uid = $this->input->post('user_id');
        $type = $this->input->post('group_type');
        $pageType = $this->input->post('page');
        if ($this->input->post('user_id') == "") {
            echo json_encode(array());
            die;
        }
        $return = array();
        $qry = $this->db->get_where('user_group_merge', $get);
        if ($qry->num_rows() > 0) {
            $group = array();
            $user = array();
            foreach ($qry->result() as $row) {
                if ($row->following_type == "group") {
                    $group[] = $row->user_following_id;
                } else {
                    $user[] = $row->user_following_id;
                }
            }
            $gCheck = 0;
            $this->db->where('group_type_id', $type);
            $this->db->where('gl.status', 1);
            $this->db->where('pl.status', 1);
            $this->db->where('pl.post_pending_status !=', 1);
            $this->db->where('pl.status', 1);
            $this->db->group_start();
            if ($pageType == "home") {
                if (!empty($group)) {
                    $this->db->where_in('pl.group_id', $group);
                    $gCheck = 1;
                }
                if (!empty($user)) {
                    $where = $gCheck == 1 ? "or_where_in" : "where_in";
                    $this->db->$where('pl.user_id', $user);
                }
            } else {
                if (!empty($group)) {
                    $this->db->where_not_in('pl.group_id', $group);
                    $gCheck = 1;
                }
            }
            $this->db->group_end();

            $this->db->from('post_list pl');
            $this->db->join('group_list gl', 'gl.group_id = pl.group_id');
            $this->db->join('users_list ul', 'ul.user_id = pl.user_id');
            $this->db->join('group_types gt', 'gt.gt_id = gl.group_type_id');

            $sQry = $this->db->order_by('posted_date DESC,posted_time DESC')->get();
       
            $postId = array();
            if ($sQry->num_rows() > 0) {
                foreach ($sQry->result() as $row) {
                    $date = date('Y-m-d') == $row->posted_date ? "Today" : date('d-m-Y', strtotime($row->posted_date));
                    $files = $this->getPostFile($row->post_id);
                    $like = $this->checkLike($row->post_id, $uid);
                    $saveStatus = $this->checkSaveStatus($row->post_id, $uid);
                    if (in_array($row->post_id, $postId)) {
                        continue;
                    }
                    $return[] = array(
                        'post_id' => $row->post_id,
                        'user_id' => $row->user_id,
                        'group_id' => $row->group_id,
                        'group_name' => $row->group_name,
                        'username' => $row->username,
                        'profile_name' => $row->profile_name,
                        'profile_picture' => $row->profile_picture,
                        'group_name' => $row->group_name,
                        'post_files' =>  $files,
                        'post_detail' => $row->post_detail,
                        'likes_count' => $row->likes,
                        'comments_count' => $row->comments,
                        'like_status' => $like,
                        'save_status' => $saveStatus,
                        'posted_date' => $date,
                        'posted_time' => date('h:i A', strtotime($row->posted_time))

                    );
                }
            }
        }

        echo json_encode($return);
    }

    public function checkLike($pId, $uId)
    {
        $get['post_id'] = $pId;
        $get['user_id'] = $uId;

        $qry = $this->db->get_where('user_likes_list', $get)->row();
        return $qry != NULL ? true : false;
    }

    public function postCommentsList()
    {
        $get['post_id'] = $this->input->post('post_id');
        $get['pcl.status'] = 1;
        $user_id = $this->input->post('user_id');
        if ($this->input->post('user_id') == "" || $this->input->post('post_id') == "") {
            echo json_encode(array('owncmt' => "", 'otherscmt' => ""));
            die;
        }
        $this->db->join('users_list ul', 'pcl.user_id = ul.user_id');
        $this->db->order_by('date DESC,time DESC');
        $qry = $this->db->get_where('post_comments_list pcl', $get);
        $return = array();
        $own = array();
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                $date = date('Y-m-d') == $row->date ? "Today" : date('d-m-Y', strtotime($row->date));
                $frGet['comment_id'] = $tGet['comment_id']  = $row->pcl_id;
                $commentReply = $this->getCommentReply($row->pcl_id);
                $commentLikeCount = $this->db->get_where('likeacomment_list', $tGet)->num_rows();
                $frGet['user_id'] = $user_id;
                $commentLikeStatus = $this->db->get_where('likeacomment_list', $tGet)->num_rows() >0?true:false;
                if ($user_id == $row->user_id) {
                    $own[] = array(
                        'comment_id' => $row->pcl_id,
                        'comment' => $row->comment,
                        'commented_person' => $row->username,
                        'commented_person_id' => $row->user_id,
                        'reply_count' => $commentReply['count'],
                        'comment_replies' =>$commentReply['data'],
                        'comment_like_count' => $commentLikeCount,
                        'comment_like_status' => $commentLikeStatus,
                        'date' => $date,
                        'time' => date('H:i A', strtotime($row->time))
                    );
                } else {
                    $return[] = array(
                        'comment_id' => $row->pcl_id,
                        'comment' => $row->comment,
                        'commented_person' => $row->username,
                        'commented_person_id' => $row->user_id,
                        'reply_count' => $commentReply['count'],
                        'comment_replies' =>$commentReply['data'],
                        'comment_like_count' => $commentLikeCount,
                        'date' => $date,
                        'time' => date('H:i A', strtotime($row->time))
                    );
                }
            }
        }

        echo json_encode(array('owncmt' => $own, 'otherscmt' => $return));
    }

    public function getCommentReply($id)
    {
        $sGet['pcl_id'] = $id;

        $this->db->join('users_list ul','ul.user_id = pcrl.user_id');
        $qry = $this->db->get_where('post_comments_reply_list pcrl', $sGet);
        $return = array();
        if($qry->num_rows() > 0){
            foreach($qry->result_array() as $row){
                $date = date('Y-m-d') == $row->date ? "Today" : date('d-m-Y', strtotime($row->date));
                $return[] = array(
                    'reply_comment_id' => $row->pcrl_id,
                        'reply_comment' => $row->reply_comment,
                        'reply_commented_person' => $row->username,
                        'reply_commented_person_id' => $row->user_id,
                        'date' => $date,
                        'time' => date('H:i A', strtotime($row->time))
                );
            }
        }

        return (array('data'=>$return,'count'=>$qry->num_rows()));

    }

    public function postLikersList()
    {
        $get['post_id'] = $this->input->post('post_id');
        $user_id = $this->input->post('user_id');
        if ($this->input->post('user_id') == "" || $this->input->post('post_id') == "") {
            echo json_encode(array());
            die;
        }
        $this->db->join('users_list ul', 'ull.user_id = ul.user_id');
        $this->db->order_by('date DESC,time DESC');
        $qry = $this->db->get_where('user_likes_list ull', $get);
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                if ($user_id != $row->user_id) {
                    $fStatus = $this->followCheck($user_id, $row->user_id, "user");
                } else {
                    $fStatus = "own";
                }

                $return[] = array(
                    'user_id' => $row->user_id,
                    'username' => $row->username,
                    'profile_picture' => $row->profile_picture,
                    'follow_status' => $fStatus
                );
            }
        } else {
            $return = array();
        }
        echo json_encode($return);
    }

    public function followCheck($user, $otherUser, $type)
    {
        $get['user_id'] = $user;
        $get['user_following_id'] = $otherUser;
        $get['following_type'] = $type;
        return $this->db->get_where('user_group_merge', $get)->num_rows() > 0 ? true : false;
    }

    public function myGroups()
    {
        $uid = $this->input->post('user_id');
       
        $groupType = $this->input->post('group_type');
        $filter = $this->input->post('filter');
      
        if ($this->input->post('user_id') == "" || $this->input->post('group_type') == "") {
            echo json_encode(array());
            die;
        }
        $this->db->select('*');
        $this->db->from('group_list');
        $this->db->where('group_type_id', $groupType);
        $this->db->where('status', 1);
        $this->db->where('pending_status', 0);
        if($filter == 1){
            $this->db->order_by('group_name','ASC');
        }else if($filter == 2){
            $this->db->order_by('group_name','DESC');
        }else if($filter == 3){
            $this->db->order_by('followers','DESC');
        }
        if ($this->input->post('search') != "") {
            $this->db->like('group_name', $this->input->post('search'));
        }
        $qry = $this->db->get();
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                 $fStatus = $this->followCheck($uid, $row->admin_id, "user");
                $return[] = array(
                    'group_id' => $row->group_id,
                    'group_name' => $row->group_name,
                    'group_image' => $row->group_image,
                    'follow_status'=> $fStatus 
                );
            }
        } else {
            $return = array();
        }
        echo json_encode($return);
    }



    public function groupDetail()
    {

        $get['group_id'] = $this->input->post('group_id');
       
        $uid = $this->input->post('user_id');
        if ($this->input->post('user_id') == "" || $this->input->post('group_id') == "") {
            echo json_encode(array());
            die;
        }
        $this->db->join('group_types gt', 'gt.gt_id = gl.group_type_id');
        $qry = $this->db->get_where('group_list gl', $get);
        $return = array();
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                $post = $this->getPostList("group", $row->group_id, $uid);
                $return = array(
                    'group_id' => $row->group_id,
                    'group_name' => $row->group_name,
                    'group_type_name' => $row->group_type_name,
                    'group_image' => $row->group_image,
                    'group_description' => $row->group_description,
                    'followers' => $row->followers,
                    'total_post' => $row->total_post,
                    'posts' => $post
                );
            }
        }
        echo json_encode($return);
    }

    public function profileDetail()
    {

        $get['user_id'] = $uid = $this->input->post('user_id');
        if ($this->input->post('user_id') == "") {
            echo json_encode(array());
            die;
        }
        $qry = $this->db->get_where('users_list', $get);
        $return = array();
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                $post = $this->getPostList("user", $row->user_id, $uid);
                $return = array(
                    'user_id' => $row->user_id,
                    'profile_name' => $row->profile_name,
                    'username' => $row->username,
                    'profile_picture' => $row->profile_picture,
                    'user_followers' => $row->user_followers,
                    'user_following' => $row->user_following,
                    'user_posts' => $row->user_posts,
                    'posts' => $post
                );
            }
        }
        echo json_encode($return);
    }

    public function getPostList($type, $id, $uid)
    {
        $return = array();
        $this->db->where('pl.status', 1);
        if ($type == "group") {
            $this->db->where('pl.group_id', $id);
        } else {
            $this->db->where('pl.user_id', $id);
        }

        $this->db->from('post_list pl');
        $this->db->join('group_list gl', 'gl.group_id = pl.group_id');
        $this->db->join('users_list ul', 'ul.user_id = pl.user_id');
        $sQry = $this->db->order_by('posted_date DESC,posted_time DESC')->get();

        if ($sQry->num_rows() > 0) {
            foreach ($sQry->result() as $row) {
                $date = date('Y-m-d') == $row->posted_date ? "Today" : date('d-m-Y', strtotime($row->posted_date));
                $like = $this->checkLike($row->post_id, $uid);
                $files = $this->getPostFile($row->post_id);
                $saveStatus = $this->checkSaveStatus($row->post_id, $uid);
                $return[] = array(
                    'post_id' => $row->post_id,
                    'user_id' => $row->user_id,
                    'group_id' => $row->group_id,
                    'group_name' => $row->group_name,
                    'username' => $row->username,
                    'profile_name' => $row->profile_name,
                    'profile_picture' => $row->profile_picture,
                    'group_name' => $row->group_name,
                    'post_detail' => $row->post_detail,
                    'likes_count' => $row->likes,
                    'comments_count' => $row->comments,
                    'post_files' => $files,
                    'save_post' => $saveStatus,
                    'like_status' => $like,
                    'posted_date' => $date,
                    'posted_time' => date('h:i A', strtotime($row->posted_time))

                );
            }
        }

        return $return;
    }

    public function getPostFile($id)
    {
        $get['post_id'] = $id;
        $qry = $this->db->get_where('post_multimedia', $get);
        $pic = array();
        $video = array();
        if ($qry->num_rows()  > 0) {
            foreach ($qry->result() as $row) {
                if ($row->type == "picture") {
                    $pic[] = array(
                        'img' => $row->file_link
                    );
                } else {
                    $video[] = array(
                        'img' => $row->file_link
                    );
                }
            }
        }
        return array('images' => $pic, 'videos' => $video);
    }

    public function postReportTypes()
    {
       $get['report_type'] = $this->input->post('type');
       $get['status'] = 1;
       $qry=$this->db->get_where('report_type_list',$get);
       $return = array();
       if($qry->num_rows() > 0){
        foreach($qry->result() as $row){
            $return[] = array(
                'report_type_id' => $row->report_type_id,
                'report_message' => $row->report_message
            );
        }
       }

       echo json_encode($return);
    }


    public function addReport()
    {

       $ins['user_id'] = $this->input->post('user_id');
       $ins['report_type_id'] = $this->input->post('report_type_id');
       $ins['reported_id'] = $this->input->post('reported_id');
       $ins['message'] = $this->input->post('message');
    
       $qry=$this->db->insert('report_list',$ins);
        
       if($qry){
            $msg = "Report Added";
            $status = TRUE;
       }else{
           $msg = "Something Wrong";
           $status = FALSE;
       }

       echo json_encode(array('status'=>$status,'msg'=>$msg));
    }

    public function search()
    {
        $uid = $this->input->post('user_id');
        $search = $this->input->post('search');
        $ulist = array();
        $glist = array();
        if ($this->input->post('user_id') == "" || $this->input->post('search') == "") {
            echo json_encode(array('status' => false, 'user_list' => $ulist, 'glist' => $glist));
            die;
        }
        $qry = $this->db->like('username', $search)->from('users_list')->get();
        $this->db->join('group_types gt', 'gt.gt_id = gl.group_type_id');
        $sQry = $this->db->like('group_name', $search)->from('group_list gl')->get();

        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                $fStatus = $this->followCheck($uid, $row->user_id, "user");
                $ulist[] = array(
                    'user_id' => $row->user_id,
                    'username' => $row->username,
                    'profile_picture' => $row->profile_picture,
                    'follow_status' => $fStatus
                );
            }
        }

        if ($sQry->num_rows() > 0) {
            foreach ($sQry->result() as $row) {
                $fStatus = $this->followCheck($uid, $row->group_id, "group");
                $glist[] = array(
                    'group_id' => $row->group_id,
                    'group_name' => $row->group_name,
                    'group_image' => $row->group_image,
                    'group_type' => $row->group_type_name,
                    'follow_status' => $fStatus
                );
            }
        }

        echo json_encode(array('status' => true, 'user_list' => $ulist, 'glist' => $glist));
    }

    public function followingList()
    {
        $uId = $this->input->post('user_id');
        $get['user_id'] = $this->input->post('following_list_id');
        if ($this->input->post('user_id') == "" || $this->input->post('following_list_id') == "") {
            echo json_encode(array());
            die;
        }
        $qry = $this->db->get_where('user_group_merge', $get);
        $list = array();
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                if ($row->following_type == "group") {
                    $fStatus = $this->followCheck($uId, $row->user_following_id, "group");
                    $detail = $this->gDetail($row->user_following_id);
                    $type = "group";
                } else {
                    $fStatus = $this->followCheck($uId, $row->user_following_id, "user");
                    $detail = $this->uDetail($row->user_following_id);
                    $type = "user";
                }

                $list[] = array(
                    'id' => $detail['id'],
                    'name' => $detail['name'],
                    'image' => $detail['image'],
                    'type' => $type,
                    'follow_status' => $fStatus
                );
            }
        }

        echo json_encode($list);
    }

    public function gDetail($id)
    {
        $get['group_id'] = $id;
        $qry = $this->db->get_where('group_list', $get)->row();
        $return['id'] = $qry->group_id;
        $return['name'] = $qry->group_name;
        $return['image'] = $qry->group_image;
        return $return;
    }

    public function uDetail($id)
    {
        $get['user_id'] = $id;
        $qry = $this->db->get_where('users_list', $get)->row();
        $return['id'] = $qry->user_id;
        $return['name'] = $qry->username;
        $return['image'] = $qry->profile_picture;
        return $return;
    }

    public function followersList()
    {
        $uId = $this->input->post('user_id');
        $get['user_following_id'] = $this->input->post('followers_list_id');
        if ($this->input->post('user_id') == "" || $this->input->post('followers_list_id') == "") {
            echo json_encode(array());
            die;
        }
        $qry = $this->db->get_where('user_group_merge', $get);
        $list = array();
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                // if ($row->following_type == "group") {
                //     $fStatus = $this->followCheck($uId, $row->user_id, "group");
                //     $detail = $this->gDetail($row->user_id);
                //     $type = "group";
                // } else {
                    $fStatus = $this->followCheck($uId, $row->user_id, "user");
                    $detail = $this->uDetail($row->user_id);
                    $type = "user";
                // }

                $list[] = array(
                    'id' => $detail['id'],
                    'name' => $detail['name'],
                    'image' => $detail['image'],
                    'follow_status' => $fStatus
                );
            }
        }

        echo json_encode($list);
    }

    public function notificationsList()
    {
        $get['user_id'] = $this->input->post('user_id');

        if ($this->input->post('user_id') == "") {
            echo json_encode(array());
            die;
        }
        $return = array();
        $qry = $this->db->get_where('notifications', $get);
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                $detail = $this->uDetail($row->nuser_id);
                if ($row->post_id != 0) {
                    $sGet['post_id'] = $row->post_id;
                    $sQry = $this->db->get_where('post_multimedia', $sGet);
                    if ($sQry->num_rows() > 0) {
                        $res = $sQry->result_array();
                        $img = $res[0]['file_link'];
                    } else {
                        $img = "";
                    }
                } else {
                    $img = $detail['image'];
                }
                $return[] = array(
                    'post_id' => $row->post_id,
                    'notify_message' => $row->notify_message,
                    'username' => $detail['name'],
                    'user_id' => $row->nuser_id,
                    'view_status' => $row->view_status,
                    'image' => $img
                );
                if ($row->view_status == 1) {
                    $update['view_status'] = 0;
                    $this->db->where('notification_id', $row->notification_id);
                    $this->db->update('notifications', $update);
                }
            }
        }

        echo json_encode($return);
    }

    public function groupTypeList()
    {
        $get['status'] = 1;
        $qry = $this->db->get_where('group_types', $get);

        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {
                $return[] = array(
                    'group_type_id' => $row->gt_id,
                    'group_type_name' => $row->group_type_name
                );
            }
        } else {
            $return = array();
        }
        echo json_encode($return);
    }

    public function likeaComment()
    {
        $ins['user_id'] = $this->input->post('user_id');
        $ins['comment_id'] = $this->input->post('comment_id');

        $qry = $this->db->get_where('likeacomment_list', $ins);
        if ($qry) {
            $status = true;
            if ($qry->num_rows() > 0) {
                $res = $qry->result_array();
                $id = $res[0]['lcl_id'];
                $this->db->where('lcl_id', $id);
                $this->db->delete('likeacomment_list');
                $msg = "like";
            } else {
                $this->db->insert('likeacomment_list', $ins);
                $msg = "liked";
            }
        } else {
            $status = false;
            $msg = "Something Wrong";
        }

        echo json_encode(array('status' => $status, 'msg' => $msg));
    }

    public function onlineUsersList()
    {
        $get['ugm.user_id'] = $this->input->post('user_id');
        $get['following_type'] = "user";
        if ($this->input->post('user_id') == "") {
            echo json_encode(array());
            die;
        }
        $this->db->join('users_list ul', 'ul.user_id = ugm.user_following_id');
        $qry = $this->db->get_where('user_group_merge ugm', $get);

        $return = array();
        if ($qry->num_rows() > 0) {
            foreach ($qry->result() as $row) {

                $lastActivity = $row->last_activity_date . " " . $row->last_activity_time;
                $currentDate = strtotime($lastActivity);
                $futureDate = $currentDate + (60 * 5);
                $formatDate = date("Y-m-d H:i:s", $futureDate);

                if (date("Y-m-d H:i:s") < $formatDate) {
                    $status = "online";
                } else {
                    $dtNow = new DateTime(date('Y-m-d H:i:s'));
                    $dtToCompare = new DateTime($formatDate);
                    $diff = $dtNow->diff($dtToCompare);
                    $minutes = (($diff->days * 24 * 60) + ($diff->h * 60) + $diff->i);
                    $status = $minutes <= 30 ? $minutes . " mns" : "";
                }

                if ($status != "") {
                    $return[] = array(
                        'user_id' => $row->user_id,
                        'username' => $row->username,
                        'profile_picture' => $row->profile_picture,
                        'status' => $status
                    );
                }
            }
        }
        echo json_encode(array($return));
    }

    public function savePosts()
    {
        $ins['user_id']=$this->input->post('user_id');
        $ins['post_id']=$this->input->post('post_id');

        if(in_array('',$ins)){
            $status = FALSE;
            $msg = "Something Wrong";
            echo json_encode(array('status'=>$status,'msg'=>$msg));
            die;
        }
        $qry=$this->db->get_where('saved_posts',$ins)->row();
        if($qry != NULL){
            $this->db->where('sp_id',$qry->sp_id);
            $this->db->delete('saved_posts');
            $status = TRUE;
            $msg = "Removed";
        }else{
            $this->db->insert('saved_posts',$ins);
            $status = TRUE;
            $msg = "Saved";
        }
        echo json_encode(array('status'=>$status,'msg'=>$msg));

    }

    public function savePostsList()
    {
        $uid=$this->input->post('user_id');
        $this->db->select('pl.user_id,posted_date,posted_time,gl.group_id,group_name,username,profile_name,profile_picture,group_name,post_detail,likes,comments,pl.post_id');
        $this->db->from('saved_posts sp');
        $this->db->join('post_list pl','pl.post_id = sp.post_id');
        $this->db->join('group_list gl', 'gl.group_id = pl.group_id');
        $this->db->join('users_list ul', 'ul.user_id = pl.user_id');
        $this->db->where('pl.status',1);
        $sQry = $this->db->order_by('sp_id DESC')->get();

        if ($sQry->num_rows() > 0) {
            foreach ($sQry->result() as $row) {
                $date = date('Y-m-d') == $row->posted_date ? "Today" : date('d-m-Y', strtotime($row->posted_date));
                $like = $this->checkLike($row->post_id, $uid);
                $files = $this->getPostFile($row->post_id);
                $return[] = array(
                    'post_id' => $row->post_id,
                    'user_id' => $row->user_id,
                    'group_id' => $row->group_id,
                    'group_name' => $row->group_name,
                    'username' => $row->username,
                    'profile_name' => $row->profile_name,
                    'profile_picture' => $row->profile_picture,
                    'group_name' => $row->group_name,
                    'post_detail' => $row->post_detail,
                    'likes_count' => $row->likes,
                    'comments_count' => $row->comments,
                    'post_files' => $files,
                    'like_status' => $like,
                    'posted_date' => $date,
                    'posted_time' => date('h:i A', strtotime($row->posted_time))

                );
            }
        }else{
            $return = array();
        }

        echo json_encode($return);
        
        
    }
    
    function checkFollowingCount()
    {
        $get['user_id'] = $this->input->post('user_id');
      
        // print_r($this->db->last_query());
        
        $this->form_validation->set_rules('user_id',"User Id","required");
        
        if($this->form_validation->run() === false){
            echo json_encode(array("status"=>false,"msg"=>"Something Wrong"));
            // $this->response(array("status"=>false,"msg"=>"Something Wrong"),REST_Controller::HTTP_NOT_FOUND);
            die;
            
        }
          $qry = $this->db->get_where('user_group_merge', $get);
        if ($qry->num_rows() >= 3) {
                 $status = true;
                 $msg = "Allow";
        } else {
             $status = false;
             $msg = "Dont Allow";
        }
        // $this->response(array("status"=>$status,"msg"=>$msg),REST_Controller::HTTP_OK);
        echo json_encode(array("status"=>$status,"msg"=>$msg));
    }
    
    
    
    public function groupsList(){
            $user_id = $this->input->post('user_id');
        $groupType = $this->input->post('groupType');
        $filter = $this->input->post('filter');

        // $get[$type] = 1;
        $this->db->select('*');
        $this->db->from('group_list');
        $this->db->where('group_type_id', $groupType);
        $this->db->where('status', 1);
        $this->db->where('pending_status', 0);
        // $this->db->where($type, 1);
        if($filter == 1){
            $this->db->order_by('group_name','ASC');
        }else if($filter == 2){
            $this->db->order_by('group_name','DESC');
        }else if($filter == 3){
            $this->db->order_by('followers','DESC');
        }
        if ($this->input->post('search') != "") {
            $this->db->like('group_name', $this->input->post('search'));
        }
        $qry = $this->db->get();
    }
    
    public function pendingPost(){
         $get['user_id'] = $uid = $this->input->post('user_id');
       
        if ($this->input->post('user_id') == "") {
            echo json_encode(array());
            die;
        }
        $return = array();
     
            $this->db->select('*');
            $this->db->from('post_list pl');
            $this->db->join('group_list gl', 'gl.group_id = pl.group_id');
            $this->db->join('users_list ul', 'ul.user_id = pl.user_id');
            $this->db->join('group_types gt', 'gt.gt_id = gl.group_type_id');
             $this->db->where('pl.user_id',$uid);     
            $this->db->where('pl.post_pending_status', 1);
            $sQry = $this->db->order_by('posted_date DESC,posted_time DESC')->get();
       
           
            if ($sQry->num_rows() > 0) {
                foreach ($sQry->result() as $row) {
                    $date = date('Y-m-d') == $row->posted_date ? "Today" : date('d-m-Y', strtotime($row->posted_date));
                    $files = $this->getPostFile($row->post_id);
                    
                
                    $return[] = array(
                        'post_id' => $row->post_id,
                        'user_id' => $row->user_id,
                        'group_id' => $row->group_id,
                        'group_name' => $row->group_name,
                        'username' => $row->username,
                        'profile_name' => $row->profile_name,
                        'profile_picture' => $row->profile_picture,
                        'group_name' => $row->group_name,
                        'post_files' =>  $files,
                        'post_detail' => $row->post_detail,
                        
                        'posted_date' => $date,
                        'posted_time' => date('h:i A', strtotime($row->posted_time))

                    );
                }
            }
        echo json_encode($return);
        
    }

        
    
}
