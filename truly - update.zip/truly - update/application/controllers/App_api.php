<?php

defined('BASEPATH') or exit('No direct script access allowed');
require APPPATH . 'libraries/RestController.php';

use chriskacerguis\RestServer\RestController;


class App_api extends RestController
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Appapi_model');
        $this->load->library('session');
        $this->load->library('form_validation');
    }

    public function login_post()
    {
        $this->Appapi_model->login();
    }

    public function register_post()
    {
        $this->Appapi_model->register();
    }

    public function sendOtp_post()
    {
        $this->Appapi_model->sendOtp();
    }

    public function forgotPassword_post()
    {
        $this->Appapi_model->forgotPassword();
    }

    public function updatePassword_post()
    {
        $this->Appapi_model->updatePassword();
    }

    public function uploadProfilePicture_post()
    {
        $this->Appapi_model->uploadProfilePicture();
    }

    public function updateGroupDescription_post()
    {
        $this->Appapi_model->updateGroupDescription();
    }
    public function updateUserProfile_post()
    {
        $this->Appapi_model->updateUserProfile();
    }
    public function topGroups_post()
    {
        $this->Appapi_model->topGroups();
    }

    public function groupPeopleFollowStatus_post()
    {
        $this->Appapi_model->groupPeopleFollowStatus();
    }

    public function addPost_post()
    {
        $this->Appapi_model->addPost();
    }

    public function createGroup_post()
    {
        $this->Appapi_model->createGroup();
    }

    public function removePost_post()
    {
        $this->Appapi_model->removePost();
    }
    public function updatePost_post()
    {
        $this->Appapi_model->updatePost();
    }

    public function addCommentPost_post()
    {
        $this->Appapi_model->addCommentPost();
    }

    public function likePost_post()
    {
        $this->Appapi_model->likePost();
    }

    public function removeComment_post()
    {
        $this->Appapi_model->removeComment();
    }

    public function appContents_post()
    {
        $this->Appapi_model->appContents();
    }

    public function homeFeeds_post()
    {
        $this->Appapi_model->homeFeeds();
    }

    public function postCommentsList_post()
    {
        $this->Appapi_model->postCommentsList();
    }

    public function postLikersList_post()
    {
        $this->Appapi_model->postLikersList();
    }

    public function checkRegister_post()
    {
        $this->Appapi_model->checkRegister();
    }

    public function checkName_post()
    {
        $this->Appapi_model->checkName();
    }

    public function myGroups_post()
    {
        $this->Appapi_model->myGroups();
    }

    public function groupDetail_post()
    {
        $this->Appapi_model->groupDetail();
    }

    public function profileDetail_post()
    {
        $this->Appapi_model->profileDetail();
    }

    public function postReport_post()
    {
        $this->Appapi_model->postReport();
    }

    public function search_post()
    {
        $this->Appapi_model->search();
    }

    public function followingList_post()
    {
        $this->Appapi_model->followingList();
    }

    public function followersList_post()
    {
        $this->Appapi_model->followersList();
    }

    public function notificationsList_post()
    {
        $this->Appapi_model->notificationsList();
    }

    public function groupTypeList_get()
    {
        $this->Appapi_model->groupTypeList();
    }

    public function likeaComment_post()
    {
        $this->Appapi_model->likeaComment();
    }

    public function addReplyComment_post()
    {
        $this->Appapi_model->addReplyComment();
    }

    public function onlineUsersList_post()
    {
        $this->Appapi_model->onlineUsersList();
    }

    public function postReportTypes_post()
    {
        $this->Appapi_model->postReportTypes();
    }

    public function addReport_post()
    {
        $this->Appapi_model->addReport();
    }

    public function savePosts_post()
    {
        $this->Appapi_model->savePosts();
    }

    public function savePostsList_post()
    {
        $this->Appapi_model->savePostsList();

    }
    
    public function checkFollowingCount_post(){
        $this->Appapi_model->checkFollowingCount();
    }
    
    public function pendingPost_post(){
        $this->Appapi_model->pendingPost();
    }
}
