<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Home extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Website_model');
        $this->load->library('session');
        require_once APPPATH . 'third_party/src/Google_Client.php';
        require_once APPPATH . 'third_party/src/contrib/Google_Oauth2Service.php';
    }
    public function index()
    {
        if ($this->session->userdata('tex_user_id')) {
            redirect('homeFeeds');
        } else {
            $this->load->view('login');
        }
    }
    public function forget1()
    {
        $this->Website_model->forget1();
    }
    public function addNewGroup()
    {
        $data['page'] = "newgroup";
        pages('addnewgroup', $data);
    }
    public function googleLogin()
    {
        $clientId = '551996253044-sc4mrgmisuosihcd1lpgmtdlfe39iapa.apps.googleusercontent.com'; //Google client ID
        $clientSecret = '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'; //Google client secret
        // $redirectURL = 'http://trulyex.com/Home/googlelogin';
        $redirectURL = 'http://localhost/truly_ex/Home/googlelogin';
        // $clientId = '692576488937-ef9q0phq3c20t76khmbt0quvgbt6vdip.apps.googleusercontent.com'; //Google client ID
        // $clientSecret = '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'; //Google client secret
        // $redirectURL = 'http://localhost/login/googlelogin/login';
        // $clientId = '176922621396-lshd3j91tsl53mujmrb3jlcvkh5vft06.apps.googleusercontent.com'; //Google client ID
        // $clientSecret = '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'; //Google client secret
        // $redirectURL = 'http://trulyex.teckzy.co.in/Home/googleLogin';
        //https://curl.haxx.se/docs/caextract.html

        //Call Google API
        $gClient = new Google_Client();
        $gClient->setApplicationName('Web client 2');
        $gClient->setClientId($clientId);
        $gClient->setClientSecret($clientSecret);
        $gClient->setRedirectUri($redirectURL);
        $google_oauthV2 = new Google_Oauth2Service($gClient);

        if (isset($_GET['code'])) {
            $gClient->authenticate($_GET['code']);
            $_SESSION['token'] = $gClient->getAccessToken();
            header('Location: ' . filter_var($redirectURL, FILTER_SANITIZE_URL));
        }

        if (isset($_SESSION['token'])) {
            $gClient->setAccessToken($_SESSION['token']);
        }
        // unset($_SESSION['token']);
        if ($gClient->getAccessToken()) {
            // echo "ghgfhf";
            $userProfile = $fbUserData = $google_oauthV2->userinfo->get();
            $addData['social_media_name'] = 'google';
            $addData['social_media_id']    = !empty($fbUserData['id']) ? $fbUserData['id'] : '';
            $addData['profile_name']    = !empty($fbUserData['name']) ? $fbUserData['name'] : '';
            $addData['email']        = !empty($fbUserData['email']) ? $fbUserData['email'] : '';
            $addData['profile_picture']    = !empty($fbUserData['picture']) ? $fbUserData['picture'] : '';
            // $addData['link_url']        = !empty($fbUserData['link'])?$fbUserData['link']:'https://www.gmail.com/'; 
            $userID = $this->Website_model->googleSignIn($addData);
            redirect('Home');
            // if(!empty($userID)){ 
            //     $data['fbData'] = $userID; 
            //     $this->session->set_userdata('fbData', $userID); 
            // }else{ 
            //    $data['fbData'] = array(); 
            // } 
            echo "<pre>";
            print_r($addData);
            die;
            // $field['logoutURL'] = $this->facebook->logout_url(); 
            // $field['first_name'] = !empty($fbUserData['name'])?$fbUserData['name']:''; 
            // $field['type'] = 'google';
            // $field['image_name'] = !empty($fbUserData['picture'])?$fbUserData['picture']:''; 
            // $field['oauth_uid'] = !empty($fbUserData['id'])?$fbUserData['id']:'';
            // $field['images'] = $this->facebook_model->get_image($fbUserData['id']);
            // $this->load->view('components/layout_main');
            // $this->load->view('post',$field);

        } else {
            $url = $gClient->createAuthUrl();
            header("Location: $url");
            exit;
        }
    }



    public function logout()
    {
        $this->session->sess_destroy();
        $this->session->set_userdata('toastmsg', 'Logged Out Successfully');
        redirect('Home');
    }
    public function register($code = "")
    {
        $data['code'] = $code;

        $this->load->view('register', $data);
    }

    public function checkName()
    {
        $this->Website_model->checkName();
    }

    public function checkRegister()
    {
        $this->Website_model->checkRegister();
    }

    public function registerUser()
    {
        $this->Website_model->registerUser();
    }

    public function checkLogin()
    {
        $this->Website_model->checkLogin();
    }
    public function forget()
    {
        $this->load->view('forget');
    }
    public function reset()
    {
        $this->Website_model->reset();
    }
    public function modify_profile()
    {
        $this->Website_model->modify_profile();
    }
    public function reset_password()
    {
        // $msg = $this->session->userdata('email');
        // echo $msg;
        $this->load->view('reset_password');
    }

    public function homePage($id = 0)
    {
        $data['post_popup_id'] = $id;
        $data['page'] = "home";
        pages('home', $data);
    }

    public function exploreFeeds()
    {
        $data['page'] = "explore";
        pages('explore', $data);
    }

    public function homeFeeds()
    {
        $this->Website_model->homeFeeds("home");
    }

    public function exploreFeedsLoad()
    {
        $this->Website_model->homeFeeds("explore");
    }

    public function topGroups()
    {
        $data['app'] = $this->Website_model->topGroups();
        $data['company'] = $this->Website_model->topGroups1();
        $data['institute'] = $this->Website_model->topGroups2();
        // $data['company'] = $this->Website_model->topGroups(2);
        // $data['institute'] = $this->Website_model->topGroups(3);

        $this->load->view('topGroups', $data);
    }

    public function followUserGroup()
    {
        $this->Website_model->followUserGroup();
    }

    public function checkFollowingCount()
    {
        $this->Website_model->checkFollowingCount();
    }

    public function groupsList()
    {
        $data['page'] = "groups";
        pages('groupsList', $data);
    }

    public function newHome()
    {
        pages('homeNew', '');
    }

    public function groupsListContents()
    {
        $this->Website_model->groupsListContents();
    }

    public function updatePassword()
    {
        $this->Website_model->updatePassword();
    }

    public function postGroupAppend()
    {
        $this->Website_model->followingList();
    }

    public function addPost()
    {
        $this->Website_model->addPost();
        // redirect('homeFeeds');
    }

    public function changeGroupType()
    {
        $this->session->set_userdata('selected_group_type_id', $this->input->post('id'));
        $this->session->set_userdata('selected_group_type_name', $this->input->post('name'));
        echo $this->input->post('name');
    }

    public function fetchPostData()
    {
        $this->Website_model->fetchPostData();
    }

    public function likePost()
    {
        $this->Website_model->likePost();
    }
    public function notificationCount()
    {
        $this->Website_model->notificationCount();
    }

    public function createGroup()
    {
        $this->Website_model->createGroup();
    }
    public function createSettingGroup()
    {
        $this->Website_model->createSettingGroup();
    }
    public function notificationTopBar()
    {
        $this->Website_model->notificationTopBar();
    }

    public function notificationPage()
    {
        $data['page'] = "notification";
        $data['list'] = $this->Website_model->notifactionPageList();
        // print_r($data);
        // exit;
        pages('notificationList', $data);
    }

    public function groupPage($id)
    {
        $data['page'] = "groupProfile";
        $data['details'] = $this->Website_model->gDetail($id);
        $data['status'] = $this->Website_model->followCheck($this->session->userdata('tex_user_id'), $id, "group");
        //$this->sendMail();
        pages('groupPage', $data);
    }

    public function userPage($id)
    {
        $data['page'] = "userProfile";
        $data['details'] = $this->Website_model->uDetail($id);
        $data['status'] = $this->Website_model->followCheck($this->session->userdata('tex_user_id'), $id, "user");
        pages('userPage', $data);
    }

    public function groupUserFeeds()
    {
        $this->Website_model->groupUserFeeds();
    }
    public function acc_info()
    {
        $this->Website_model->acc_info();
        redirect('Home/accountInfo');
    }

    public function addComment()
    {
        $this->Website_model->addComment();
    }

    public function removeComment()
    {
        $this->Website_model->removeComment();
    }
    public function groupFollowersList($id)
    {
        $data['list'] = $this->Website_model->groupFollowersList($id);
        $data['page'] = "followlist";
        pages('followList', $data);
    }

    public function userFollowList($id, $pageType)
    {

        $data['list'] = $this->Website_model->userFollowingList($id, $pageType);
        if ($pageType == "following") {
            $data['page'] = "following";
        } else {
            $data['page'] = "followlist";
        }

        pages('followList', $data);
    }
    public function settings()
    {
        $data['page'] = "settings";

        pages('settings', $data);
    }

    public function refer()
    {
        $data['page'] = "refer";

        $get['user_id'] = $this->session->userdata('tex_user_id');
        $qry = $this->db->get_where('users_list', $get)->row();

        $data['code'] = $qry->refferal_code;

        pages('refer', $data);
    }

    public function changePassword()
    {
        $data['page'] = "settings";
        pages('changePassword', $data);
    }

    public function helpBox()
    {
        $data['page'] = "settings";
        pages('helpBox', $data);
    }

    public function search()
    {
        $data['page'] = "search";
        $data['list'] = $this->Website_model->searchPage();
        pages('search', $data);
    }

    public function share($id)
    {
        $data['page'] = "share";
        $data['list'] =  $this->Website_model->postDetail($id);
        // print_r($data['list']);
        // exit;
        pages('singlePost', $data);
    }

    public function postReportTypes()
    {
        $this->Website_model->postReportTypes();
    }

    public function addReport()
    {
        $this->Website_model->addReport();
    }

    public function removePost()
    {
        $this->Website_model->removePost();
    }
    function sendMail()
    {
        $get['user_id'] = $this->session->userdata('tex_user_id');
        $qry = $this->db->get_where('users_list', $get)->row();
        $body = $qry->refferal_code;
        //  $body .= "<br>Your order id:".$qres[0]['order_id'];

        $subject = "TrulyEx - REFERRAL CODE";

        $to = $this->input->post('mail');
        $link = base_url('register/new');
        $bodymes = '<!DOCTYPE html>
        <html lang="en">
        <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="style.css">
        <title>Email</title>
        <style>
        body{
        background-color: #e1e1e1;
        font-family: Arial, Helvetica, sans-serif;
        }

        .container{
        max-width: 680px;
        width: 100%;
        margin: auto;
        }

        main{
        margin: 0 auto;
        display: flex;
        flex-direction: column;
        color: #555555; 
        }

        .body h2{
        font-weight: 300;
        color: #464646;
        }





        a{
        text-decoration: underline; 
        color: #0c99d5; 
        }


        .body{
        padding: 20px;
        background-color: white;
        font-family: Geneva, Tahoma, Verdana, sans-serif; 
        font-size: 16px; 
        line-height: 22px; 
        color: #555555; 
        }




        </style>
        </head>

        <body>

        <main class="container">

        <div class="body">
        <h6> Dear User,</h6>
            <p>Your TrulyEx Referal Code is:' . $body . '</p>
            <p>Please click below link to register</p>
            <a href="' . $link . '">TrulyEx</a>
        <p>Thanks & Regards,</p>
        <p>TrulyEx</p>
        </div>

        </main>

        </body>

        </html>';
        /* Load PHPMailer library */
        $this->load->library('phpmailer_lib');

        /* PHPMailer object */
        $mail = $this->phpmailer_lib->load();

        /* SMTP configuration */
        $mail->isSMTP();
        $mail->Host     = 'sg2plzcpnl487141.prod.sin2.secureserver.net';
        $mail->SMTPAuth = true;
        $mail->Username = 'info@trulyex.com';
        $mail->Password = 'Bk0}wPiV2#Hx';
        $mail->SMTPSecure = 'ssl';
        $mail->Port     = 465;
        $mail->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );
        $mail->setFrom('info@trulyex.com', 'Trulyex');
        $mail->addReplyTo('info@trulyex.com', 'Trulyex');

        /* Add a recipient */
        $mail->addAddress($to);

        /* Add cc or bcc */
        //$mail->addCC('cc@example.com');
        //$mail->addBCC('bcc@example.com');

        /* Email subject */
        $mail->Subject = $subject;

        /* Set email format to HTML */
        $mail->isHTML(true);

        /* Email body content */
        //$mailContent = "<h1>Send HTML Email using SMTP in CodeIgniter</h1><p>This is a test email sending using SMTP mail server with PHPMailer.</p>";
        $mail->Body = $bodymes;

        /* Send email */
        if (!$mail->send()) {
            echo 'Mail could not be sent.';
            echo 'Mailer Error: ' . $mail->ErrorInfo;
            echo json_encode(array('status' => false));
        } else {
            echo json_encode(array('status' => true));
        }
        exit;
    }
    public function sendMail1()
    {
        $this->Website_model->sendMail();
    }
    public function otp()
    {
        //$this->Website_model->otp();
        $email = $this->input->post('email');

        $this->db->where('email', $email);

        $count = $this->db->get('users_list')->num_rows();
        //  $qry = $this->db->get_where('users_list', array('email' => $email))->row()->username;
        // print_r($this->db->last_query());
        if ($count > 0) {
           
            $otp_no = mt_rand(100000, 999999);
            $data['otp'] = $otp_no;
            $this->session->set_userdata('email', $email);
            $this->db->where('email', $email);
            $this->db->update('users_list', $data);
            $bodymes = '<!DOCTYPE html>
            <html lang="en">
            <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta http-equiv="X-UA-Compatible" content="ie=edge">
            <link rel="stylesheet" href="style.css">
            <title>Email</title>
            <style>
            body{
            background-color: #e1e1e1;
            font-family: Arial, Helvetica, sans-serif;
            }
            .container{
            max-width: 680px;
            width: 100%;
            margin: auto;
            }
            main{
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            color: #555555; 
            }
    
            .body h2{
            font-weight: 300;
            color: #464646;
            }
            a{
            text-decoration: underline; 
            color: #0c99d5; 
            }
            .body{
            padding: 20px;
            background-color: white;
            font-family: Geneva, Tahoma, Verdana, sans-serif; 
            font-size: 16px; 
            line-height: 22px; 
            color: #555555; 
            }
            </style>
            </head>
            <body>
            <main class="container">
            <div class="body">
            <h6> Dear User,</h6>
                <p>your OTP No is:&nbsp;&nbsp;' . $otp_no . '</p>
             
            <p>Thanks & Regards,</p>
            <p>TrulyEx</p>
            </div>
    
            </main>
    
            </body>
    
            </html>';
    
            $this->load->library('phpmailer_lib');

            /* PHPMailer object */
            $mail = $this->phpmailer_lib->load();
    
            /* SMTP configuration */
            $mail->isSMTP();
            $mail->Host     = 'sg2plzcpnl487141.prod.sin2.secureserver.net';
            $mail->SMTPAuth = true;
            $mail->Username = 'info@trulyex.com';
            $mail->Password = 'Bk0}wPiV2#Hx';
            $mail->SMTPSecure = 'ssl';
            $mail->Port     = 465;
            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );
            $mail->setFrom('info@trulyex.com', 'Trulyex');
            $mail->addReplyTo('info@trulyex.com', 'Trulyex');
    
            /* Add a recipient */
            $mail->addAddress($email);
    
            /* Add cc or bcc */
            //$mail->addCC('cc@example.com');
            //$mail->addBCC('bcc@example.com');
    
            /* Email subject */
             $mail->Subject = "TrulyEx - Forgot Password";
    
            /* Set email format to HTML */
            $mail->isHTML(true);
    
            /* Email body content */
            //$mailContent = "<h1>Send HTML Email using SMTP in CodeIgniter</h1><p>This is a test email sending using SMTP mail server with PHPMailer.</p>";
            $mail->Body = $bodymes;
    
            /* Send email */
            if (!$mail->send()) {
                echo 1;
            } else {
                echo 2;
            }
        } else {
            echo 1;
        }
        
        exit;
    }
    public function verify_otp()
    {
        $this->Website_model->verify_otp();
    }

    public function accountInfo()
    {
        $data['page'] = "settings";
        $data['detail'] = $this->Website_model->udetail($this->session->userdata('tex_user_id'));
        pages('accountInformation', $data);
    }

    public function pendingPost()
    {
        $data['page'] = "settings";
        $data['list'] = $this->Website_model->pendingPostList();
        pages('pendingPost', $data);
    }
    
}
