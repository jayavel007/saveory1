<?php
defined('BASEPATH') or exit('No direct script access allowed');
class checkOnline 
{
    public function tut()
    {
        $CI =& get_instance();
        $CI->load->model('Appapi_model');
        $CI->Appapi_model->onlineActivity();

    }

  
}
