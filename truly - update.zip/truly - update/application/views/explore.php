
  
  <!-- main content -->
  <div class="main-content right-chat-active bg-img">
    <div class="middle-sidebar-bottom">
      <div class="middle-sidebar-left">
        <!-- loader wrapper -->
        <div class="preloader-wrap p-3">
          <div class="box shimmer">
            <div class="lines">
              <div class="line s_shimmer"></div>
              <div class="line s_shimmer"></div>
              <div class="line s_shimmer"></div>
              <div class="line s_shimmer"></div>
            </div>
          </div>
          <div class="box shimmer mb-3">
            <div class="lines">
              <div class="line s_shimmer"></div>
              <div class="line s_shimmer"></div>
              <div class="line s_shimmer"></div>
              <div class="line s_shimmer"></div>
            </div>
          </div>
          <div class="box shimmer">
            <div class="lines">
              <div class="line s_shimmer"></div>
              <div class="line s_shimmer"></div>
              <div class="line s_shimmer"></div>
              <div class="line s_shimmer"></div>
            </div>
          </div>
        </div>
        <!-- loader wrapper -->
        <div class="row feed-body">
          <div class="col-xl-8 col-xxl-9 col-lg-8">

            <span id="appendHome"></span>


            
          </div>
          <!-- <div class="col-xl-4 col-xxl-3 col-lg-4 ps-md-0">
            <div class="card w-100 shadow-xss rounded-xxl border-0 mb-3">
              <div class="card-body d-flex align-items-center p-4">
                <h4 class="fw-700 mb-0 font-xssss text-grey-900">
                  Suggest Group
                </h4>
                <a href="#" class="fw-600 ms-auto font-xssss text-primary">See all</a>
              </div>
              <div class="card-body d-flex pt-4 ps-4 pe-4 pb-0 overflow-hidden border-top-xs bor-0">
                <img src="<?= base_url() ?>images/profile1.jpg" alt="img" class="img-fluid rounded-xxl mb-2" />
              </div>
              <div class="card-body dd-block pt-0 ps-4 pe-4 pb-4">
                <ul class="memberlist mt-1 mb-2 ms-0 d-block">
                  <li class="w20">
                    <a href="#"><img src="<?= base_url() ?>images/pro1.jpg" alt="user" class="w35 d-inline-block" style="opacity: 1" /></a>
                  </li>
                  <li class="w20">
                    <a href="#"><img src="<?= base_url() ?>images/pro2.jpg" alt="user" class="w35 d-inline-block" style="opacity: 1" /></a>
                  </li>
                  <li class="w20">
                    <a href="#"><img src="<?= base_url() ?>images/pro3.jpg" alt="user" class="w35 d-inline-block" style="opacity: 1" /></a>
                  </li>
                  <li class="w20">
                    <a href="#"><img src="<?= base_url() ?>images/pro1.jpg" alt="user" class="w35 d-inline-block" style="opacity: 1" /></a>
                  </li>
                  <li class="last-member">
                    <a href="#" class="bg-greylight fw-600 text-grey-500 font-xssss w35 ls-3 text-center" style="height: 35px; line-height: 35px">+2</a>
                  </li>
                  <li class="ps-3 w-auto ms-1">
                    <a href="#" class="fw-600 text-grey-500 font-xssss">Member apply</a>
                  </li>
                </ul>
              </div>
            </div>

          </div> -->
        </div>
      </div>
    </div>
  </div>
  <!-- main content -->



  <script>
    
   homeFeeds(1);
    var cnt = 4;
    // $(window).scroll(function() {
    //   if ($(window).scrollTop() + $(window).height() > $(document).height()) {
    //     homeFeeds(8);
        
    //   }
    // })

    $(document.body).on('touchmove', onScroll); // for mobile
$(window).on('scroll', onScroll); 


  function onScroll(){ 
    if( $(window).scrollTop() + window.innerHeight >= document.body.scrollHeight ) { 
      if ($(window).scrollTop() + $(window).height() >= $(document).height() || $(window).scrollTop() + $(window).height() + 100 >= $(document).height()) {
        var pagenum = parseInt($(".pagenum:last").val()) + 1;
        homeFeeds(pagenum);

      } 
    }
}

    function homeFeeds(pagenum) {
      var type = $('#groupTypeLoad').val();
      $.ajax({
        url: "<?= base_url('Home/exploreFeedsLoad') ?>",
        method: 'POST',
        data: {
          page: pagenum,
          type: type,
          rowcount:$("#rowcount").val()
        },
        success: function(d) {
          // console.log(d);
          if(d != '')
            $('#appendHome').append(d);
          else
            $('#loader-icon').html('<div class="card w-100 text-center shadow-xss rounded-xxl border-0 p-4 mb-3 mt-3"><div class="snippet mt-2 ms-auto me-auto" data-title=".dot-typing"><div class="stage">No Post Available</div></div></div>');
        }
      });
    }

    function postGroupAppend() {
      var groupType = $('#groupTypeLoad').val();
      var search = $('#groupSearch').val();
      $('#modalTitle').html("Following Groups - <?= $this->session->userdata('selected_group_type_name') ?>");
      $.ajax({
        url: "<?= base_url('Home/postGroupAppend') ?>",
        method: 'POST',
        data: {
          search: search,
          groupType:groupType
        },
        success: function(d) {
          
          $('#postGroupAppend').html(d);
        }
      });
    }

    function selectedGroup(name) {
      var split = name.split("#");
      $('#selectedGroup').html(split[1]);
      $('#selectedGroupId').val(split[0]);
      $('#myModal').modal('hide');
    }

    // 'use strict';
    // let slide = document.querySelector('.slider__items').children;
    // const leftBtn = document.querySelector('.left__slide');
    // const rightBtn = document.querySelector('.right__slide');
    // const totalSlide = slide.length;
    // let idx = 0;

    // function next(direction) {
    //   if (direction === 'next') {
    //     idx++;
    //     if (idx === totalSlide) {
    //       idx = 0;
    //     }
    //   } else {
    //     if (idx === 0) {
    //       idx = totalSlide - 1;
    //     } else {
    //       idx--;
    //     }
    //   }

    //   let i = 0;
    //   for (i = 0; i < slide.length; i++) {
    //     slide[i].classList.remove('active');
    //   }
    //   slide[idx].classList.add('active');
    // }

    // rightBtn.addEventListener('click', () => {
    //   next('next');
    // });
    // leftBtn.addEventListener('click', () => {
    //   next('prev');
    // });
  </script>



  </body>

  </html>