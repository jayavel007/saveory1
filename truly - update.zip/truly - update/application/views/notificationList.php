 <!-- main content -->
 <div class="main-content right-chat-active bg-img">
            
            <div class="middle-sidebar-bottom">
                <div class="middle-sidebar-left pe-0">
                    <div class="row">
                           
                        <div class="col-xl-12">
                            <div class="chat-wrapper p-3 w-100 position-relative scroll-bar bg-white theme-dark-bg">
                                <h2 class="fw-700 mb-4 mt-2 font-md text-grey-900 d-flex align-items-center">Notification
                               <?php 
                                if($list['count'] != 0){
                                    ?>
                                  <span class="circle-count bg-warning text-white font-xsssss rounded-3 ms-2 ls-3 fw-600 p-2  mt-0"><?= $list['count'] ?></span>  
                                    <?php
                                }
                               ?>  
                                   
                                    
                                </h2>
                                
                                <ul class="notification-box">
                                    <?php
                                    if(!empty($list['return'])){

                                        foreach($list['return'] as $row){
                                            ?>
                                         <li>
                                         <?=$row['postData']?>
                                        <a href="#" class="d-flex align-items-center p-3 rounded-3 <?= $row['view_status'] == 1?"bg-lightgrey theme-light-bg":"" ?>">
                                            <img src="<?= ($row['image'] != NULL)?$row['image']:"https://ui-avatars.com/api/?background=random&name=" . $row['username'] ?>" alt="user" class="w45 me-3">
                                            <h6 class="font-xssss text-grey-900 text-grey-900 mb-0 mt-0 fw-500 lh-20"><strong><?= $row['username'] ?></strong> <strong><?= $row['notify_message'] ?></strong> <span class="d-block text-grey-500 font-xssss fw-600 mb-0 mt-0 ms-auto"><?= $row['time'] ?></span> </h6>
                                            <i class="ti-more-alt text-grey-500 font-xs ms-auto"></i>
                                        </a>
                                    </li>   
                                            
                                            <?php
                                        }
                                    }
                                    
                                    ?>
                                </ul>                                 
                            </div>
                        </div>
                    </div>
                </div>
                 
            </div>            
        </div>
        <!-- main content -->