   <!-- main content -->
   <div
        class="main-content bg-lightblue theme-dark-bg right-chat-active bg-img"
      >
        <div class="middle-sidebar-bottom">
          <div class="middle-sidebar-left">
            <div class="middle-wrap">
              <div class="card w-100 border-0 bg-white shadow-xs p-0 mb-4">
                <div
                  class="card-body p-4 w-100 bg-current border-0 d-flex rounded-3"
                >
                  <a href="<?= base_url('settings') ?>" class="d-inline-block mt-2"
                    ><i class="ti-arrow-left font-sm text-white"></i
                  ></a>
                  <h4 class="font-xs text-white fw-600 ms-4 mb-0 mt-2">
                    Account Details
                  </h4>
                </div>
                <?php
                
                if($this->session->userdata('tex_profile_picture') == NULL){
                    $cPic = "https://ui-avatars.com/api/?background=0D8ABC&color=fff&name=".$this->session->userdata('tex_profile_name');
                  }else{
                    $cPic = base_url('admin/images/'.$this->session->userdata('tex_profile_picture'));
                  }

                ?>
                <div class="card-body p-lg-5 p-4 w-100 border-0">
                  <div class="row justify-content-center">
                    <div class="col-lg-4 text-center">
                      <figure class="avatar ms-auto me-auto mb-0 mt-2 w100">
                        <img
                          src="<?= $cPic ?>"
                          alt="image"
                          class="shadow-sm rounded-3 w-100"
                        />
                      </figure>
                      <h2 class="fw-700 font-sm text-grey-900 mt-3">
                      <?= $detail['name'] ?>
                      </h2>
                      
                      <!-- <a href="#" class="p-3 alert-primary text-primary font-xsss fw-500 mt-2 rounded-3">Upload New Photo</a> -->
                    </div>
                  </div>

                  <form action="<?=base_url('Home/acc_info')?>" method="post" enctype="multipart/form-data">
                    <div class="row">
                      <div class="col-lg-6 mb-3">
                        <div class="form-group">
                          <label class="mont-font fw-600 font-xsss"
                            >Profile Name</label
                          >
                          <input type="text" class="form-control" name="pro_name" value="<?= $detail['profile_name'] ?>" />
                        </div>
                      </div>

                      <div class="col-lg-6 mb-3">
                        <div class="form-group">
                          <label class="mont-font fw-600 font-xsss"
                            >Username</label
                          >
                          <input type="text" class="form-control" name="uname"value="<?= $detail['name'] ?>" />
                        </div>
                      </div>
                    </div>
                    <input type="hidden" class="form-control"  name="id" value="<?= $detail['email'] ?>" />
                    <div class="row">
                      <div class="col-lg-6 mb-3">
                        <div class="form-group">
                          <label class="mont-font fw-600 font-xsss"
                            >Email</label
                          >
                          <input type="text" class="form-control"  name="email" value="<?= $detail['email'] ?>" />
                        </div>
                      </div>

                      <div class="col-lg-6 mb-3">
                        <div class="form-group">
                          <label class="mont-font fw-600 font-xsss"
                            >Phone</label
                          >
                          <input type="text" class="form-control" name="phone" value="<?= $detail['mobile_no'] ?>"/>
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <div class="col-lg-6 mb-3">
                        <div class="form-group">
                          <label class="mont-font fw-600 font-xsss"
                            >Date Of Birth</label
                          >
                          <input type="date" class="form-control" name="dob" value="<?= $detail['dob'] ?>" />
                        </div>
                      </div>
                      <div class="col-lg-6 mb-3">
                        <div class="form-group">
                          <label class="mont-font fw-600 font-xsss"
                            >Upload Profile</label
                          >
                          <input type="file" class="form-control" name="profile_picture" />
                        </div>
                      </div>

                      
                    </div>

                    <div class="row">
                      <div class="col-lg-12">
                        <button
                          type="submit"
                          class="bg-current text-center text-white font-xsss fw-600 p-3 w175 rounded-3 d-inline-block"
                          >Save</button
                        >
                      </div>
                    </div>
                  </form>
                </div>
              </div>
              <!-- <div class="card w-100 border-0 p-2"></div> -->
            </div>
          </div>
        </div>
      </div>
      <!-- main content -->