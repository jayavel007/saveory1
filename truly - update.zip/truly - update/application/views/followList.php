    <!-- main content -->
    <div class="main-content right-chat-active bg-img">
        <div class="middle-sidebar-bottom">
          <div class="middle-sidebar-left pe-0">
            <div class="row">
              <div class="col-xl-12">
                <div
                  class="card shadow-xss w-100 d-block d-flex border-0 p-4 mb-3"
                >
                  <div class="card-body d-flex align-items-center p-0">
                    <h2 class="fw-700 mb-0 mt-0 font-md text-grey-900">
                      <?= $page == "following"?"Following":"Followers" ?>
                    </h2>
                    <!-- <div class="search-form-2 ms-auto">
                      <i class="ti-search font-xss"></i>
                      <input
                        type="text"
                        class="form-control text-grey-500 mb-0 bg-greylight theme-dark-bg border-0"
                        placeholder="Search here."
                      />
                    </div>
                    <a
                      href="#"
                      class="btn-round-md ms-2 bg-greylight theme-dark-bg rounded-3"
                      ><i class="feather-filter font-xss text-grey-500"></i
                    ></a> -->
                  </div>
                </div>

                <div class="row ps-2 pe-2">
                  <?php 
                  $j = 0;
                  foreach($list as $detail){
                    if(strpos($detail['image'],'https') !== false){
                      $usrImg  =$detail['image'];
                    }else{
                      $usrImg = $detail['image'] == NULL?"https://ui-avatars.com/api/?background=random&name=".$detail['name']:base_url('admin/'.$details['image']);
                    }
                  
                    ?>
                      <div class="col-md-3 col-sm-4 pe-2 ps-2">
                <div
                  class="card d-block border-0 shadow-xss rounded-3 overflow-hidden mb-3"
                >
                  <div
                    class="card-body d-block w-100 ps-3 pe-3 pb-4 text-center"
                  >
                  <a href="<?= base_url($detail['type'].'Page/'.$detail['id']) ?>">
                    <figure
                      class="avatar ms-auto me-auto mb-0 position-relative w65 z-index-1"
                    >
                      <img
                        src="<?= $usrImg ?>"
                        alt="image"
                        class="float-right p-0 bg-white rounded-circle w-100 shadow-xss"
                      />
                    </figure>
                  </a>
                    <div class="clearfix"></div>
                    <?php
                     
                    ?>
                    <a href="<?= base_url($detail['type'].'Page/'.$detail['id']) ?>">
                    <h4 class="fw-700 font-xsss mt-3 mb-1">
                      <?= $detail['name'] ?>
                    </h4>  
                      </a>
                    
                    <!-- <p class="fw-500 font-xsssss text-grey-500 mt-0 mb-3">
                      @macale343
                    </p> -->
                    <?php 
                    if($detail['type'] == 'group' || $this->session->userdata('tex_user_id') != $detail['id']){
                      ?>
                      <a
                      role="button" onclick="followUserGroup(<?= $detail['id'] ?>,'<?= $detail['type'] ?>','followerslist_<?= $j ?>')"
                      class="<?= $detail['follow_status'] == "Following"?"followed":"follow" ?>"
                      id="followerslist_<?= $j ?>"
                      > <?= $detail['follow_status'] ?></a
                    >
                      <?php
                    } 
                    ?>
                    
                  </div>
                </div>
              </div>
                    
                    <?php
                    $j++;
                  }

                  ?>
              


                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- main content -->
      