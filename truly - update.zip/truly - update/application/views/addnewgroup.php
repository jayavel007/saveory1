<div
        class="main-content bg-lightblue theme-dark-bg right-chat-active bg-img"
      >
        <div class="middle-sidebar-bottom">
          <div class="middle-sidebar-left">
            <div class="middle-wrap">
              <div class="card w-100 border-0 bg-white shadow-xs p-0 mb-4">
                <div class="card-body p-lg-5 p-4 w-100 border-0">
                  <div class="row">
                    <div class="col-lg-12">
                      <h4
                        class="mb-4 font-xxl fw-700 mont-font mb-lg-5 mb-4 font-md-xs"
                      >
                        Add New Group
                      </h4>
                      <div class="group_detail p-3" id="grp_detail">
                        <form action="javascript: void(0)" id="submitGroupForm" enctype="multipart/form-data" method="POST" onsubmit="submitGroupForm()" >
                        <div class="form-floating mb-3">
                        <select name="group_type" id="group_type" class="form-control" required>
                            <option value="">--Select Group--</option>
                            <option value="1">Courses</option>
                            <option value="2">Company</option>
                            <option value="3">Institute</option>
                        </select>
                        </div>
                        <span id="typeCheck"></span>

                        <div class="form-floating mb-3">
                        <input type="input" name="group_name" id="group_name" autocomplete="off" onkeyup="checkName(this.value)" class="form-control" required >
                        <label for="floatingInput">Enter Group Name <sup>*</sup></label>
                        </div>
                        <span id="nameCheck"></span>
                        <div class="form-floating">
                        <textarea class="form-control" id="group_description" name="group_description" required ></textarea>
                        <label for="floatingTextarea">Enter Group Description</label>
                        </div>
                        <div class="form__group col">
                        <label for="group_image mb-3">Group Cover Image</label>
                        <input class="form-control" type="file" name="group_image" id="group_image"  >
                        </div>
                        <button type="submit" id="newGroupSubmit"  class="btn btn-success" style="margin-top: 2%;">Add</button>
                        </form>
                    </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <script>
        function submitGroupForm() {
            event.preventDefault();

            var content = $("#submitGroupForm")[0];
            var data = new FormData(content);
            console.log(data);
            $.ajax({
            url: "<?= base_url('Home/createSettingGroup') ?>",
            type: "post",
            data: data,
            processData: false,
            contentType: false,
            cache: false,
            async: false,
            success: function(data) {

                console.log(data);
                if (data != 0) {
                    $('#submitGroupForm').trigger("reset");
                    toastpopup("Group Created");
                } else {
                    toastpopup("Something Wrong");
                }
            }
            });
        }
        function checkName(value) {
            var type = "group";
            $.ajax({
                url: "<?= base_url('Home/checkName') ?>",
                method: 'POST',
                data: {
                    value: value,
                    type: type
                },
                success: function(d) {
                    var res = JSON.parse(d);
                    console.log(res);
                    $('#nameCheck').html(res.msg);
                    if (res.status) {
                        $('#nameCheck').css("color", "green");
                        $("#newGroupSubmit").attr("disabled", false);
                    } else {
                        $('#nameCheck').css("color", "red");
                        $("#newGroupSubmit").attr("disabled", true);
                    }
                }
            });
        }
    </script>