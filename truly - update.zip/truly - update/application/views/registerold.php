<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>TrulyEX</title>

    <link rel="stylesheet" href="<?= base_url() ?>css/themify-icons.css" />
    <link rel="stylesheet" href="<?= base_url() ?>css/feather.css" />
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png" />
    <!-- Custom Stylesheet -->
    <link rel="stylesheet" href="<?= base_url() ?>css/style.css" />
</head>

<body class="color-theme-blue">
    <div class="preloader"></div>

    <div class="main-wrap">
        <div class="nav-header bg-transparent shadow-none border-0">
            <div class="w-100">
                <a href="default.html">
                    
                    <img src="<?= base_url() ?>images/trulyEx.png" width="50" ; height="50" />
                    <!-- <i class="feather-zap text-success display1-size me-2 ms-0"></i
            > -->
                    <!-- <span
              class="d-inline-block fredoka-font ls-3 fw-600 text-current font-xxl logo-text mb-0"
              >TrulyEX.
            </span> -->
                </a>
                <a href="#" class="mob-menu ms-auto me-2 chat-active-btn"><i class="feather-message-circle text-grey-900 font-sm btn-round-md bg-greylight"></i></a>
                <a href="#" class="mob-menu me-2"><i class="feather-video text-grey-900 font-sm btn-round-md bg-greylight"></i></a>
                <a href="#" class="me-2 menu-search-icon mob-menu"><i class="feather-search text-grey-900 font-sm btn-round-md bg-greylight"></i></a>
                <button class="nav-menu me-0 ms-2"></button>


            </div>
        </div>

        <div class="bg-img">
            <!-- <div
          class="col-xl-5 d-none d-xl-block p-0 vh-100 bg-image-cover bg-no-repeat"
          style="
            background-image: url(./images/trulyEx__bg1.jpg);
            background-position: center;
            opacity: 0.4;
          "
        ></div> -->
            <div class="container">
                <div class="col-xl-12 vh-100 align-items-center d-flex rounded-3 overflow-hidden">
                    <div class="card bx-shadow border-0 login-card">
                        <div class="card-body rounded-0 text-left">
                            <!-- <h2 class="fw-700 display1-size display2-md-size mb-4">
                  Create your account
                </h2> -->
                            <form id="submit" enctype="multipart/form-data" method="POST">
                                <div class="form-group icon-input mb-3">
                                    <div class="profile">
                                        <button class="img__remove">
                                            <img src="<?= base_url() ?>images/close.png" alt="remove" />
                                        </button>
                                        <div class="profile__img">
                                            <img src="<?= base_url() ?>images/profile.png" alt="user" class="img__initial" />
                                            <input type="file" name="file" id="file" class="img__input"  />
                                            <img src="" alt="" class="img__el" />
                                        </div>
                                    </div>
                                </div>
                                <div class="col-1-of-2">
                                    <div class="form-group icon-input mb-3">
                                        <i class="font-sm ti-user text-grey-500 pe-0"></i>
                                        <input type="text" class="style2-input ps-5 form-control text-grey-900 font-xsss fw-600" placeholder="Profile Name" name="profile_name" id="profile_name" required />
                                    </div>
                                    <div class="form-group icon-input mb-3">
                                        <i class="font-sm ti-user text-grey-500 pe-0"></i>
                                        <input type="text" class="style2-input ps-5 form-control text-grey-900 font-xsss fw-600" placeholder="User Name" name="user_name" id="user_name" onkeyup="checkName(this.value)" required />
                                        <span id="nameCheck"></span>
                                    </div>
                                </div>
                                <div class="col-1-of-2">
                                    <div class="form-group icon-input mb-3">
                                        <i class="font-sm ti-calendar text-grey-500 pe-0"></i>
                                        <input type="date" class="style2-input ps-5 form-control text-grey-900 font-xsss fw-600" placeholder="Date of Birth" name="dob" id="dob" required />
                                    </div>
                                    <div class="form-group icon-input mb-3">
                                        <i class="font-sm ti-mobile text-grey-500 pe-0"></i>
                                        <input type="tel" class="style2-input ps-5 form-control text-grey-900 font-xsss fw-600" placeholder="Mobile" name="mobile" id="mobile" onkeyup="checkRegister(this.value,'mobile')" required autocomplete="off" />
                                        <span id="mobileCheck"></span>
                                    </div>
                                </div>
                                <div class="form-group icon-input mb-3">
                                    <i class="font-sm ti-email text-grey-500 pe-0"></i>
                                    <input type="text" class="style2-input ps-5 form-control text-grey-900 font-xsss fw-600" placeholder="Your Email Address" name="email" id="email" onkeyup="checkRegister(this.value,'email')" required autocomplete="off" />
                                    <span id="mailCheck"></span>
                                </div>
                                <div class="col-1-of-2">
                                    <div class="form-group icon-input mb-3">
                                        <input type="Password" class="style2-input ps-5 form-control text-grey-900 font-xss ls-3" placeholder="Password" id="password" name="password" onkeyup="checkPassword()" required />
                                        <i class="font-sm ti-lock text-grey-500 pe-0"></i>
                                    </div>
                                    <div class="form-group icon-input mb-1">
                                        <input type="Password" class="style2-input ps-5 form-control text-grey-900 font-xss ls-3" placeholder="Confirm Password" id="cpassword" onkeyup="checkPassword()" required />
                                        <i class="font-sm ti-lock text-grey-500 pe-0"></i>
                                        <span id="passwordAlert"></span>
                                    </div>
                                </div>
                                <div class="form-group icon-input mb-1">
                                    <input type="text" class="style2-input ps-5 form-control text-grey-900 font-xss ls-3" name="refferal_code" id="refferal_code" value="<?= $code != "new"?$code:"" ?>" placeholder="Referral code (if any)" <?= $code != "new"?"readonly":"" ?> />
                                    <i class="font-sm ti-link text-grey-500 pe-0"></i>
                                </div>
                                <div class="col-1-of-2" style="display: block;">
                                    <div class="form-check text-left mb-3">
                                        <input type="checkbox" class="form-check-input mt-2" id="exampleCheck1" />
                                        <label class="form-check-label font-xsss text-grey-500" for="exampleCheck1">Accept Term and Conditions</label>
                                    </div>
                                    <div class="form-check text-left mb-3">
                                        <input type="checkbox" class="form-check-input mt-2" id="exampleCheck2" />
                                        <label class="form-check-label font-xsss text-grey-500" for="exampleCheck2">WhatsApp consent
                                        </label>

                                    </div>
                                </div>
                                <div class="col-sm-12 p-0 text-left">
                                    <div class="form-group mb-1">
                                        <button id="registerSubmit" type="submit" class="form-control text-center style2-input text-white fw-600 bg-dark border-0 p-0">Register</button>
                                    </div>
                                    <h6 class="text-grey-500 font-xsss fw-500 mt-0 mb-0 lh-32">
                                        Already have account
                                        <a href="<?= base_url('login') ?>" class="fw-700 ms-1">Login</a>
                                    </h6>
                                </div>
                            </form>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        //Image
        const profileImg = document.querySelector('.profile__img');
        const imgInitial = document.querySelector('.img__initial');
        const imgInput = document.querySelector('.img__input');
        const imgEl = document.querySelector('.img__el');
        const imgRemove = document.querySelector('.img__remove');

        function previewImg(input) {
            const file = input.files[0];

            if (file) {
                const reader = new FileReader();
                imgInitial.classList.add('hidden');
                imgEl.classList.add('active');
                imgRemove.classList.add('active');

                reader.addEventListener('load', function() {
                    imgEl.setAttribute('src', this.result);
                });
                reader.readAsDataURL(file);
            } else {
                imgInitial.classList.remove('hidden');
                imgEl.classList.remove('active');
                imgRemove.classList.remove('active');
                imgEl.setAttribute('src', '');
            }
        }

        imgRemove.addEventListener('click', (e) => {
            e.preventDefault();
            imgInitial.classList.remove('hidden');
            imgEl.classList.remove('hidden');
            imgRemove.classList.remove('active');
            imgEl.setAttribute('src', '');
        });

        imgInput.addEventListener('change', function() {
            previewImg(imgInput);
        });
    </script>
    <script src="<?= base_url() ?>js/plugin.js"></script>
    <script src="<?= base_url() ?>js/scripts.js"></script>
</body>

</html>
<script>
    $('#submit').submit(function(e) {
        e.preventDefault();
        if($('#exampleCheck1').is(':checked') && $('#exampleCheck2').is(':checked')){
            $.ajax({
            url: "<?= base_url('Home/registerUser') ?>",
            type: "post",
            data: new FormData(this),
            processData: false,
            contentType: false,
            cache: false,
            async: false,
            success: function(data) {
                console.log(data);
                if (data == 1) {
                    window.location = "<?= base_url('topGroups') ?>";
                }
            }
        });
        }else{
            alert("Accept Terms & Conditions");
        }
       

      
    });

    function checkName(value) {

        if (value.length >= 3) {
            $('#nameCheck').html("");
            var type = "user";

            $.ajax({
                url: "<?= base_url('Home/checkName') ?>",
                method: 'POST',
                data: {
                    value: value,
                    type: type
                },
                success: function(d) {
                    var res = JSON.parse(d);
                    console.log(res);
                    $('#nameCheck').html(res.msg);
                    if (res.status) {
                        $('#nameCheck').css("color", "green");
                        $("#registerSubmit").attr("disabled", false);
                    } else {
                        $('#nameCheck').css("color", "red");
                        $("#registerSubmit").attr("disabled", true);
                    }
                }
            });
        } else {
            $("#registerSubmit").attr("disabled", true);
            $('#nameCheck').html("Minimum 3 Characters Required!");
            $('#nameCheck').css("color", "red");
        }

    }

    function checkRegister(value, type) {
        if (type == 'email') {
            var checkmail = isEmail(value);
            if (!checkmail) {
                $('#mailCheck').html("Enter Vaild email!");
                $('#mailCheck').css("color", "red");
                $("#registerSubmit").attr("disabled", true);
                return false;
            } else {

                $('#mailCheck').html("");
            }
        } else {

            if (value.length < 10 || value.length > 10) {
                $('#mobileCheck').html("Enter Vaild Mobile Number!");
                $('#mobileCheck').css("color", "red");
                $("#registerSubmit").attr("disabled", true);
                return false;
            } else {
                $('#mobileCheck').html("");
            }
        }
        $.ajax({
            url: "<?= base_url('Home/checkRegister') ?>",
            method: 'POST',
            data: {
                value: value,
                type: type
            },
            success: function(d) {
                console.log(d);
                if (d != 1) {
                    if (type == 'email') {
                        $('#mailCheck').html("Email Already Registered!");
                        $('#mailCheck').css("color", "red");
                    } else {
                        $('#mobileCheck').html("Mobile Number Already Registered!");
                        $('#mobileCheck').css("color", "red");
                    }
                    $("#registerSubmit").attr("disabled", true);
                } else {
                    if (type == 'email') {
                        $('#mailCheck').html("");
                    } else {
                        $('#mobileCheck').html("");
                    }
                    $("#registerSubmit").attr("disabled", false);
                }
            }
        });
    }


    function ValidateNo(moNumber) {

        if (moNumber.length < 10 || moNumber.length > 10) {
            $('#mobileCheck').html("Enter Vaild Mobile Number!");
            $('#mobileCheck').css("color", "red");
            return false;
        } else {
            $('#mobileCheck').html("");
            return false;
        }


    }

    function isEmail(email) {
        var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        return regex.test(email);
    }

    function checkPassword() {

        var pass = $("#password").val();
        var cpass = $("#cpassword").val();

        if (cpass != "") {
            if (pass != cpass) {
                $('#passwordAlert').html("Password Mismatching!");
                $('#passwordAlert').css("color", "red");
                $("#registerSubmit").attr("disabled", true);
            } else {
                $('#passwordAlert').html("Password Matching!");
                $('#passwordAlert').css("color", "green");
                $("#registerSubmit").attr("disabled", false);
            }
        }
    }
</script>