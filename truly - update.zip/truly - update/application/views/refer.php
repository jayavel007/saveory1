<div class="main-content right-chat-active bg-img">
        <div class="middle-sidebar-bottom">
          <div class="middle-sidebar-left pe-0">
            <div class="row">
              <div class="col-xl-12">
                <div class="section__refer shadow-md rounded-xxxl">
                  <div class="refer">
                    <div class="refer__content">
                      <div class="left">
                        <h2 class="fw-bold">
                          Refer a Friend <br />
                          & built your Network
                        </h2>
                        Referral Code: <?= $code ?>
                      </div>
                      <div class="right">
                        <img src="images/refer.png" alt="" />
                      </div>
                    </div>
                    <div class="refer__form mt-5">
                      <form action="">
                        <h2 class="mb-3 fw-bold">Send Invitation</h2>
                        <div class="form__group">
                          <input
                            type="email"
                            class="form__input shadow-md"
                            pattern=".+@globex\.com"
                            required
                            placeholder="Type Email addresss here"
                            id="refEmail"
                            onkeyup="mailCheck(this.value)"
                          />
                          
                          <button type="button" onclick="sendMail()" id="sendMailBtn" class="btn btn-secondary">
                            send
                          </button>
                        </div>
                        <span id="mailCheck"></span>
                      </form>
                    </div>
                    <br />
                    <input type="hidden" name="refCodeLink" id="copyLink_1" value="<?= base_url('register/'.$code) ?>">
                    <p class="text-center fw-bold">or</p>
                    <div class="text-center">
                      <button class="btn btn-info" onclick="copyToClipboard(1)">
                        <i class="feather-copy"></i>
                        Copy Invitation Link
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <script>
        function sendMail(){
          var mail = $('#refEmail').val();
          if(mail == ""){
            $('#mailCheck').html("Please Fill Mail!");
                $('#mailCheck').css("color", "red");
                return false;
          }
          $("#sendMailBtn").attr("disabled", true);
       $.ajax({
        url: "<?= base_url('Home/sendMail') ?>",
        method: 'POST',
        data:{
          mail : mail
        },
        success: function(d) {
          console.log(d);
          var res = JSON.parse(d);
          if(res.status == true){
            $('#refEmail').val('');
            toastpopup("Mail Sent Successfully");
          }else{
            toastpopup("Something Wrong");
          }
          $("#sendMailBtn").attr("disabled", false);
        }
    });
        }

        function copyClip(element) {
        
          var $temp = $("<input>");
          $("body").append($temp);
          $temp.val($(element).text()).select();
          document.execCommand("copy");
          $temp.remove(); 
        toastpopup("Link Copied");
      }


      function mailCheck(value){
     
        var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        if(!regex.test(value)){
          $('#mailCheck').html("Enter Vaild email!");
                $('#mailCheck').css("color", "red");
                $("#sendMailBtn").attr("disabled", true);
        }else{
                $("#sendMailBtn").attr("disabled", false);
          $('#mailCheck').html("");
        }
    
      }
        </script>