     <!-- main content -->
     <div class="main-content right-chat-active bg-img">
        <div class="middle-sidebar-bottom">
          <div class="middle-sidebar-left pe-0">
            <div class="row">
              <div class="col-xl-12">
                <div
                  class="card shadow-xss w-100 d-block d-flex border-0 p-4 mb-3"
                >
                  <div class="card-body d-flex align-items-center p-0">
                    <h4
                      class="mb-0 mt-0 font-xs tab__head <?= !empty($list['user']) == true?'active':""  ?> "
                    >
                      User Lists
                    </h4>
                    <h4
                      class="mx-4 mb-0 mt-0 font-xs tab__head <?= empty($list['user']) == true?'active':""  ?>"
                    >
                      Group Lists
                    </h4>
                  </div>
                </div>

                <div class="tab__content <?= !empty($list['user']) == true?'active':""  ?>">
                  <div class="row ps-2 pe-2">
                      <?php
                      
                      if(!empty($list['user'])){
                        foreach($list['user'] as $row){
                          $usrImg = $row['profile_picture'] == NULL?"https://ui-avatars.com/api/?background=random&name=".$row['profile_name']:base_url('admin/'.$row['profile_picture']);
                            ?>
                             <div class="col-md-3 col-sm-4 pe-2 ps-2">
                      <div
                        class="card d-block border-0 shadow-xss rounded-3 overflow-hidden mb-3"
                      >
                        <div
                          class="card-body d-block w-100 ps-3 pe-3 pb-4 text-center"
                        >
                          <figure
                            class="avatar ms-auto me-auto mb-0 position-relative w65 z-index-1"
                          >
                          <a href="<?= base_url('userPage/'.$row['user_id']) ?>">
                            <img
                              src="<?= $usrImg ?>"
                              alt="image"
                              class="float-right p-0 bg-white rounded-circle w-100 shadow-xss"
                            />
                          </a>
                          </figure>
                          <div class="clearfix"></div>
                          <a href="<?= base_url('userPage/'.$row['user_id']) ?>">
                          <h4 class="fw-700 font-xsss mt-3 mb-1">
                            <!-- <a href=""> -->

                              <?= $row['username'] ?>
                            <!-- </a> -->
                          </h4>
                        </a>
                         
                          <?php
                          if($row['user_id'] != $this->session->userdata('tex_user_id')){
                            ?>
                             <a
                          role="button" onclick="followUserGroup(<?= $row['user_id'] ?>,'user','searchuList<?= $row['user_id'] ?>')"
                            class="<?= $row['follow_status'] == "Following"?"followed":"follow" ?>"
                            id="searchuList<?= $row['user_id'] ?>"
                            ><?= $row['follow_status'] ?></a
                          >
                            <?php
                          }
                          ?>
                         
                        </div>
                 
                      </div>

                    </div>
                            <?php
                        }
                      }else{
                        ?>
                        
                        <div class="card d-block border-0 shadow-xss rounded-3 overflow-hidden mb-3">
        <div class="card-body d-block w-100 position-relative group text-center">
              No Data Found             
        </div>
      </div> 
                        <?php
                      }
                      
                      ?>
                   

                   
                  </div>
                </div>
                <div class="tab__content <?= empty($list['user']) == true?'active':""  ?>">
                  <div class="row ps-2 pe-1">
                  <?php
                      
                      if(!empty($list['group'])){
                        foreach($list['group'] as $row){
                          $groupImg = $row['group_image'] == NULL?"https://ui-avatars.com/api/?background=random&name=".$row['group_name']:base_url('admin/'.$row['group_image']);
                            ?>
                          
                    <div class="col-md-6 col-sm-6 pe-2 ps-2">
                      <div
                        class="card d-block border-0 shadow-xss rounded-3 overflow-hidden mb-3"
                      >
                        <div
                          class="card-body d-block w-100 text-left position-relative group"
                        >
                          <figure class="avatar w75">
                          <a href="<?php echo base_url();?>Home/groupPage/<?= $row['group_id'] ?>">
                            <img
                              src="<?= $groupImg ?>"
                              alt="image"
                              class="p-1 bg-white rounded-circle"
                            />
                            </a>
                          </figure>
                          <div class="">
                            <h4 class="fw-700 font-xsss mt-3 mb-1">
                              <a href="<?php echo base_url();?>Home/groupPage/<?= $row['group_id'] ?>">

                                <?= $row['group_name'] ?>
                              </a>
                            </h4>
                            <p
                              class="fw-500 font-xsssss text-grey-500 mt-0 mb-3"
                            >
                            <?= $row['group_description'] ?>
                            </p>
                          </div>
                          <span
                            class="position-absolute d-flex align-items-center"
                          >
                            
                            <a
                          role="button" onclick="followUserGroup(<?= $row['group_id'] ?>,'group','searchgList<?= $row['group_id'] ?>')"
                            class="<?= $row['follow_status'] == "Following"?"followed":"follow" ?>"
                            
                            id="searchgList<?= $row['group_id'] ?>"
                            ><?= $row['follow_status'] ?></a
                          >
                          </span>
                        </div>
                        
                      </div>
                    </div>
                    <?php
                        }
                    
                    }else{
                      ?>
                      
                      <div class="card d-block border-0 shadow-xss rounded-3 overflow-hidden mb-3">
      <div class="card-body d-block w-100 position-relative group text-center">
            No Data Found             
      </div>
    </div> 
                      <?php
                    }
                    
                    ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- main content -->
      <!-- ---------------------------Important----------------------------- -->
      <!-- <div class="card d-block border-0 shadow-xss rounded-3 overflow-hidden mb-3">
        <div class="card-body d-block w-100 text-left position-relative group">
              No Data Found             
        </div>
      </div> -->
      <!-- ---------------------------Important----------------------------- -->
      <script>
      const tabHeads = document.querySelectorAll('.tab__head');
      const tabContents = document.querySelectorAll('.tab__content');

      tabHeads.forEach((head, idx) => {
        head.addEventListener('click', () => {
          tabHeads.forEach((head) => {
            head.classList.remove('active');
          });
          head.classList.add('active');

          tabContents.forEach((content) => {
            content.classList.remove('active');
          });
          tabContents[idx].classList.add('active');
        });
      });
    </script>