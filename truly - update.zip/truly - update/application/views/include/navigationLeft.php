
      <!-- navigation left -->
      <nav class="navigation scroll-bar">
        <div class="container ps-0 pe-0">
          <div class="nav-content">
            <div
              class="nav-wrap bg-white bg-transparent-card rounded-xxl shadow-xss pt-3 pb-1 mb-2 mt-2"
            >
              <div class="profile text-center flex-column my-sm-4">
                <a href="<?= base_url('accountInfo')?>" class="p-0 menu-icon"
                  ><img src="<?php if($this->session->userdata('tex_profile_picture') == NULL){
                    echo "https://ui-avatars.com/api/?background=0D8ABC&color=fff&name=".$this->session->userdata('tex_profile_name');
                  }else{
                    
                     if(strpos($this->session->userdata('tex_profile_picture'),'https') !== false){
                      echo  $this->session->userdata('tex_profile_picture');
                     }else{
                      echo  base_url('admin/images/'.$this->session->userdata('tex_profile_picture'));
                     }
                  }  ?>" alt="user" class="w75 mt--1"
                /></a>
                <a href="<?= base_url('userPage/'.$this->session->userdata('tex_user_id')) ?>"  class="pt-sm-2 fw-bold text-secondary"><?= $this->session->userdata('tex_user_name') ?></a>
              </div>
              <div class="nav-caption fw-600 font-xssss text-grey-500">
                <span>New </span>Feeds
              </div>
              <ul class="mb-1 top-content">
                <li class="logo d-none d-xl-block d-lg-block"></li>
                <li >
                  <a href="<?= base_url('homeFeeds') ?>" class="nav-content-bttn open-font"
                    ><i
                      class="feather-tv btn-round-md bg-blue-gradiant me-3"
                    ></i
                    ><span class="<?= $page == "home" ? "activeSideBar":"" ?>">Newsfeed</span></a
                  >
                </li>
                <li>
                  <a href="<?= base_url('exploreFeeds') ?>" class="nav-content-bttn open-font"
                    ><i
                      class="feather-tv btn-round-md bg-blue-gradiant me-3"
                    ></i
                    ><span class="<?= $page == "explore" ? "activeSideBar":"" ?>">Explore</span></a
                  >
                </li>
                <li>
                  <a
                    href="<?= base_url('groups') ?>"
                    class="nav-content-bttn open-font"
                    ><i
                      class="feather-zap btn-round-md bg-mini-gradiant me-3"
                    ></i
                    ><span class="<?= $page == "groups" ? "activeSideBar":"" ?>">Groups</span></a
                  >
                </li>
                <li>
                  <a href="<?= base_url('refer') ?>" class="nav-content-bttn open-font"
                    ><i
                      class="feather-user btn-round-md bg-primary-gradiant me-3"
                    ></i
                    ><span class="<?= $page == "refer" ? "activeSideBar":"" ?>">Refer friends</span></a
                  >
                </li>
              </ul>
            </div>
            
            <div
              class="nav-wrap bg-white bg-transparent-card rounded-xxl shadow-xss pt-3 pb-1"
            >
              <div class="nav-caption fw-600 font-xssss text-grey-500">
                <span></span> Account
              </div>
              <ul class="mb-1">
                <li class="logo d-none d-xl-block d-lg-block"></li>
                <li>
                  <a
                  href="<?= base_url('settings') ?>"
                    class="nav-content-bttn open-font h-auto pt-2 pb-2"
                    ><i class="font-sm feather-settings me-3 text-grey-500"></i
                    ><span class="<?= $page == "settings" ? "activeSideBar":"" ?>">Settings</span></a
                  >
                </li>
                <li class="list-inline-item d-block me-0">
                          <a
                            href="<?= base_url('Home/logout') ?>"
                            class="pt-2 pb-2 d-flex align-items-center"
                            ><i class="font-sm feather-log-out me-3 text-grey-500"></i
                    ><span class="#">Logout</span></a
                  >
                        </li>
                <!--<li>-->
                <!--  <a-->
                <!--    href="#"-->
                <!--    class="nav-content-bttn open-font h-auto pt-2 pb-2"-->
                <!--    ><i-->
                <!--      class="font-sm feather-message-square me-3 text-grey-500"-->
                <!--    ></i-->
                <!--    ><span>Chat</span-->
                <!--    ><span class="circle-count bg-warning mt-0">23</span></a-->
                <!--  >-->
                <!--</li>-->
              </ul>

            
            </div>
          </div>
        </div>
      </nav>
      <!-- navigation left -->