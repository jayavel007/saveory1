<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="ie=edge" />
  <title>TrulyEX</title>
  <!-- Bootstrap CSS only -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous" />
  <link rel="stylesheet" href="<?= base_url() ?>css/themify-icons.css" />
  <link rel="stylesheet" href="<?= base_url() ?>css/feather.css" />
  <!-- Favicon icon -->
  <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url() ?>images/trulyEx.png" />
  <!-- Splide -->
  <link rel="stylesheet" href="<?= base_url() ?>css/splide.min.css" />
  <!-- Custom Stylesheet -->
  <link rel="stylesheet" href="<?= base_url() ?>css/style.css" />
  <link rel="stylesheet" href="<?= base_url() ?>css/emoji.css" />

  <link rel="stylesheet" href="<?= base_url() ?>css/lightbox.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
  <script src="<?= base_url() ?>js/bootstrap.min.js"></script>
  <script src="<?= base_url() ?>js/plugin.js"></script>

  <script src="<?= base_url() ?>js/lightbox.js"></script>
  <script src="<?= base_url() ?>js/splide.min.js"></script>

  <script src="<?= base_url() ?>js/scripts.js"></script>
</head>

<?php
$CI = &get_instance();
$CI->load->model('Website_model');
$CI->Website_model->checkUserStatus();


?>