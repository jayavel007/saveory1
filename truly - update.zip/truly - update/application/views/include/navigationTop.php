<body class="color-theme-blue mont-font">
  <!-- <div class="preloader"></div> -->

  <div class="main-wrapper">
    <!-- navigation top-->
    <div class="nav-header bg-white shadow-xs border-0">
      <div class="nav-top justify-content-between">
        <a href="<?= base_url('homeFeeds') ?>">
          &nbsp;&nbsp;&nbsp;
          <img src="<?= base_url() ?>images/trulyEx.png" width="70" ; height="70" />
          <!-- <i class="feather-zap text-success display1-size me-2 ms-0"></i
            > -->
          &nbsp;

          <!-- <span
              class="d-inline-block fredoka-font ls-3 fw-600 text-current font-xxl logo-text mb-0"
              >TrulyEX.
            </span> -->
        </a>
        <a href="#" class="mob-menu ms-auto me-2 chat-active-btn hidden"><i class="feather-message-circle text-grey-900 font-sm btn-round-md bg-greylight"></i></a>
        <a href="default-video.html" class="mob-menu me-2 hidden"><i class="feather-video text-grey-900 font-sm btn-round-md bg-greylight"></i></a>
        <div class="d-flex align-items-center"> <a href="#" class="me-2 menu-search-icon mob-menu"><i class="feather-search text-grey-900 font-sm btn-round-md bg-greylight"></i></a>
          <button class="nav-menu me-0 ms-2"></button>
        </div>
      </div>
      <div class="nav__link ms-auto">

        <?php
        $CI = &get_instance();
        $CI->load->model('Website_model');
        $groupTypeList = $CI->Website_model->groupTypeList();
        $groupLoad = 0;
        if (!$this->session->userdata('selected_group_type_id')) {
          $this->session->set_userdata('selected_group_type_id', $groupTypeList[0]['group_type_id']);
          $this->session->set_userdata('selected_group_type_name', $groupTypeList[0]['group_type_name']);
        }
        foreach ($groupTypeList as $row) {
        ?>
          <a href="#" class="p-2 text-center ms-3 menu-icon center-menu-icon <?= $this->session->userdata('selected_group_type_id') == $row['group_type_id'] ? "active" : "" ?> " id="group_type_name_<?= $row['group_type_id'] ?>" onclick="changeGroupType(<?= $row['group_type_id'] ?>,'<?= $row['group_type_name'] ?>','<?php if (isset($page)) {
                                                                                                                                                                                                                                                                                                                              echo $page;
                                                                                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                                                                              echo 'none';
                                                                                                                                                                                                                                                                                                                            } ?>')">
            <?= $row['group_type_name'] ?>
          </a>
        <?php
          $groupLoad++;
        }

        ?>
        <input type="hidden" id="groupTypeLoad" value="<?= $this->session->userdata('selected_group_type_id') ?>">

      </div>
      <form action="<?= base_url('search') ?>" method="POST" class="float-left header-search ms-auto">
        <div class="form-group mb-0 icon-input">
          <i class="feather-search font-sm text-grey-400"></i>
          <input type="text" name="search" autocomplete="off" placeholder="Start typing to search.." class="bg-grey border-0 lh-32 pt-2 pb-2 ps-5 pe-3 font-xssss fw-500 rounded-xl w350 theme-dark-bg" />
        </div>
      </form>
      <a href="#" class="p-2 text-center menu-icon" id="dropdownMenu3" data-bs-toggle="dropdown" aria-expanded="false"><span class="dot-count bg-warning text-white" id="notificationCount"></span><i class="feather-bell font-xl text-current"></i></a>
      <div class="dropdown-menu dropdown-menu-end p-4 rounded-3 border-0 shadow-lg" aria-labelledby="dropdownMenu3">
        <h4 class="fw-700 font-xss mb-4">Notification</h4>
        <span id="notificationListAppend"></span>

      </div>
      <a href="#" class="p-2 text-center ms-3 menu-icon chat-active-btn"><i class="feather-message-square font-xl text-current"></i></a>

      <a href="<?= base_url('userPage/' . $this->session->userdata('tex_user_id')) ?>" class="p-0 ms-3 menu-icon"><img src="<?php if ($this->session->userdata('tex_profile_picture') == NULL) {
                                                                                                                              echo "https://ui-avatars.com/api/?background=0D8ABC&color=fff&name=" . $this->session->userdata('tex_profile_name');
                                                                                                                            } else {

                                                                                                                              if (strpos($this->session->userdata('tex_profile_picture'), 'https') !== false) {
                                                                                                                                echo  $this->session->userdata('tex_profile_picture');
                                                                                                                              } else {
                                                                                                                                echo  base_url('admin/images/' . $this->session->userdata('tex_profile_picture'));
                                                                                                                              }
                                                                                                                            }  ?>" width="50" ; height="40" ; alt="user" class="w40 mt--1" /></a>
    </div>
    <!-- navigation top -->