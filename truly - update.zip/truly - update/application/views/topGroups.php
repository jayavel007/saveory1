<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>TrulyEX</title>

    <link rel="stylesheet" href="<?= base_url() ?>css/themify-icons.css" />
    <link rel="stylesheet" href="<?= base_url() ?>css/feather.css" />
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url() ?>images/favicon.png" />
    <!-- Custom Stylesheet -->
    <link rel="stylesheet" href="<?= base_url() ?>css/style.css" />
</head>

<body class="color-theme-blue">
    <div class="preloader"></div>

    <div class="main-wrap">
        <div class="nav-header bg-transparent shadow-none border-0">
            <div class="w-100">
                <a href="default.html">
                    <img src="<?= base_url() ?>images/trulyEx.png" width="70" ; height="70" />

                </a>
                <a href="#" class="mob-menu ms-auto me-2 chat-active-btn"><i class="feather-message-circle text-grey-900 font-sm btn-round-md bg-greylight"></i></a>
                <a href="default-video.html" class="mob-menu me-2"><i class="feather-video text-grey-900 font-sm btn-round-md bg-greylight"></i></a>
                <a href="#" class="me-2 menu-search-icon mob-menu"><i class="feather-search text-grey-900 font-sm btn-round-md bg-greylight"></i></a>
                <button class="nav-menu me-0 ms-2"></button>
            </div>
        </div>

        <div class="bg-img">
            <!-- <div
          class="col-xl-5 d-none d-xl-block p-0 vh-100 bg-image-cover bg-no-repeat"
          style="
            background-image: url(./images/trulyEx__bg1.jpg);
            background-position: center;
            opacity: 0.4;
          "
        ></div> -->
            <div class="container">
                <div class="col-xl-12 vh-100 align-items-center d-flex rounded-3 overflow-hidden">
                    <div class="card bx-shadow border-0 login-card">
                        <div class="card-body rounded-0 text-left">
                            <h3 class="fw-700 display2-md-size mb-4 text-center">
                                Build Your Network
                            </h3>
                            <div class="tab">
                                <div class="tab__header">

                                    <?php
                                    $CI = &get_instance();
                                    $CI->load->model('Website_model');
                                    $result = $CI->Website_model->groupTypeList();
                                    $i = 0;
                                    foreach ($result as $row) {
                                    ?>
                                        <div class="tab__head <?= $i == 0 ? "active" : "" ?>"><?= $row['group_type_name'] ?></div>


                                    <?php
                                        $i++;
                                    }
                                    ?>
                                </div>
                                <div class="tab__body">
                                    <div class="tab__content active">
                                        <?php
                                        $i = 1;
                                        if (!empty($app)) {

                                            foreach ($app as $row) {
                                                $groupImg = $row['group_image'] == NULL ? "https://ui-avatars.com/api/?background=random&name=" . $row['group_name'] : base_url('admin/' . $row['group_image']);

                                        ?>
                                                <div class="page">
                                                    <div class="page__img">
                                                        <img src="<?= $groupImg ?>" alt="facebook" />
                                                    </div>
                                                    <div class="page__title"><?= $row['group_name'] ?></div>
                                                    <button class="page__btn" id="followbtn_<?= ++$i ?>" onclick="followUserGroup(<?= $row['group_id'] ?>, 'group','followbtn_<?= $i ?>')"><?= $row['follow_status'] ?></button>

                                                </div>
                                        <?php
                                            }
                                        }

                                        ?>

                                    </div>
                                    <div class="tab__content">
                                        <?php

                                        if (!empty($company)) {
                                            foreach ($company as $row) {
                                                $groupImg = $row['group_image'] == NULL ? "https://ui-avatars.com/api/?background=random&name=" . $row['group_name'] : base_url('admin/' . $row['group_image']);

                                        ?>
                                                <div class="page">
                                                    <div class="page__img">
                                                        <img src="<?= $groupImg ?>" alt="facebook" />
                                                    </div>
                                                    <div class="page__title"><?= $row['group_name'] ?></div>
                                                    <button class="page__btn" id="followbtn_<?= ++$i ?>" onclick="followUserGroup(<?= $row['group_id'] ?>, 'group','followbtn_<?= $i ?>')"><?= $row['follow_status'] ?></button>
                                                </div>
                                        <?php
                                            }
                                        }

                                        ?>
                                    </div>
                                    <div class="tab__content">
                                        <?php

                                        if (!empty($institute)) {
                                            foreach ($institute as $row) {
                                                $groupImg = $row['group_image'] == NULL ? "https://ui-avatars.com/api/?background=random&name=" . $row['group_name'] : base_url('admin/' . $row['group_image']);

                                        ?>
                                                <div class="page">
                                                    <div class="page__img">
                                                        <img src="<?= $groupImg ?>" alt="facebook" />
                                                    </div>
                                                    <div class="page__title"><?= $row['group_name'] ?></div>
                                                    <button class="page__btn" id="followbtn_<?= ++$i ?>" onclick="followUserGroup(<?= $row['group_id'] ?>, 'group','followbtn_<?= $i ?>')"><?= $row['follow_status'] ?></button>

                                                </div>
                                        <?php
                                            }
                                        }

                                        ?>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center">
                                <div class="form-group mb-1 col-6">
                                    <a href="#" class="form-control text-center style2-input text-white fw-600 bg-theme border-0 p-0" onclick="callHomePage()">Continue</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="snackbar"></div>
    </div>

    <script>
        const tabHeads = document.querySelectorAll('.tab__head');
        const tabContents = document.querySelectorAll('.tab__content');

        tabHeads.forEach((head, idx) => {
            head.addEventListener('click', () => {
                tabHeads.forEach((head) => {
                    head.classList.remove('active');
                });
                head.classList.add('active');

                tabContents.forEach((content) => {
                    content.classList.remove('active');
                });
                tabContents[idx].classList.add('active');
            });
        });
    </script>
    <script src="<?= base_url() ?>js/plugin.js"></script>
    <script src="<?= base_url() ?>js/scripts.js"></script>
    <script>
        function toastpopup(d) {

            var x = document.getElementById("snackbar");
            x.innerText = d;
            x.className = "show";
            setTimeout(function() {
                x.className = x.className.replace("show", "");
            }, 3000);
        }

        function callHomePage() {
            $.ajax({
                url: "<?= base_url('Home/checkFollowingCount') ?>",
                method: 'POST',
                success: function(d) {
                    console.log(d);
                    if (d > 2) {
                        window.location = "<?= base_url('Home/homePage') ?>";
                    } else {
                        toastpopup("Please Follow Minimum 3 Groups");
                    }

                }
            });

        }

        function followUserGroup(id, type, btnid) {
            //  alert(type);
            $.ajax({
                url: "<?= base_url('Home/followUserGroup') ?>",
                method: 'POST',
                data: {
                    id: id,
                    type: type
                },
                success: function(d) {
                    console.log(d);
                    var responseArr = d.split("@@");
                    $('#' + btnid).html(responseArr[0]);
                }
            });

        }
    </script>
</body>

</html>