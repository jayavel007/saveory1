<!-- main content -->
<div class="main-content right-chat-active bg-img">
        <div class="middle-sidebar-bottom">
          <div class="middle-sidebar-left">
            <div class="row justify-content-center">
              <div class="col-xl-10">
                <div
                  class="card w-100 border-0 p-0 rounded-3 overflow-hidden bg-image-contain bg-image-center"
                  style="background-image: url(./images/help.jpg)"
                >
                  <div
                    class="card-body p-md-5 p-4 text-center"
                    style="background-color: rgba(0, 85, 255, 0.8)"
                  >
                    <h2
                      class="fw-700 display2-size text-white display2-md-size lh-2"
                    >
                      Welcome to the Sociala Commuinity!
                    </h2>
                    <p class="font-xsss ps-lg-5 pe-lg-5 lh-28 text-grey-200">
                      Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                      Morbi nulla dolor, ornare at commodo non, feugiat non
                      nisi. Phasellus faucibus mollis pharetra. Proin blandit ac
                      massa sed rhoncus
                    </p>
                    <div
                      class="form-group w-lg-75 mt-4 border-light border p-1 bg-white rounded-3 ms-auto me-auto"
                    >
                      <div class="row">
                        <div class="col-md-8">
                          <div class="form-group icon-input mb-0">
                            <i class="ti-search font-xs text-grey-400"></i>
                            <input
                              type="text"
                              class="style1-input border-0 ps-5 font-xsss mb-0 text-grey-500 fw-500 bg-transparent"
                              placeholder="Search anythings.."
                            />
                          </div>
                        </div>
                        <div class="col-md-4">
                          <a
                            href="#"
                            class="w-100 d-block btn bg-current text-white font-xssss fw-600 ls-3 style1-input p-0 border-0 text-uppercase"
                            >Search</a
                          >
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  class="card w-100 border-0 shadow-none bg-transparent mt-5"
                >
                  <div id="accordion" class="accordion mb-0">
                    <div class="card shadow-xss">
                      <div class="card-header" id="headingOne">
                        <h5 class="mb-0">
                          <button
                            class="btn btn-link collapsed"
                            data-toggle="collapse"
                            data-target="#collapseOne"
                            aria-expanded="false"
                            aria-controls="collapseOne"
                          >
                         How do I search for groups on TrulyEX?
                          </button>
                        </h5>
                      </div>

                      <div
                        id="collapseOne"
                        class="collapse"
                        aria-labelledby="headingOne"
                        data-parent="#accordion"
                      >
                        <div class="card-body">
                          <p>
                          To search for the groups on TrulyEX you can go to the ‘Groups Section’ on the left side on the home screen and can search for the required group in the Search Bar provided. 
                          </p>
                        </div>
                      </div>
                    </div>
                    <div class="card shadow-xss">
                      <div class="card-header" id="headingTwo">
                        <h5 class="mb-0">
                          <button
                            class="btn btn-link collapsed"
                            data-toggle="collapse"
                            data-target="#collapseTwo"
                            aria-expanded="false"
                            aria-controls="collapseTwo"
                          >
                         How do I share an update or post?
                          </button>
                        </h5>
                      </div>
                      <div
                        id="collapseTwo"
                        class="collapse"
                        aria-labelledby="headingTwo"
                        data-parent="#accordion"
                      >
                        <div class="card-body">
                          <p>
                          To share an update/post, first, you need to select the course/company/institution that you want to post an update about. Then you can click on the ‘What’s on your mind?’ Tab and can post any photo, video, or text of your choice.
                          </p>
                        </div>
                      </div>
                    </div>
                    <div class="card shadow-xss">
                      <div class="card-header" id="headingFour">
                        <h5 class="mb-0">
                          <button
                            class="btn btn-link collapsed"
                            data-toggle="collapse"
                            data-target="#collapseFour"
                            aria-expanded="false"
                            aria-controls="collapseFour"
                          >
                          How can I refer or invite people on the TrulyEx platform?
                          </button>
                        </h5>
                      </div>

                      <div
                        id="collapseFour"
                        class="collapse"
                        aria-labelledby="headingFour"
                        data-parent="#accordion"
                      >
                        <div class="card-body">
                          <p>
                                                  To refer or invite people, you need to click on the ‘Refer Friends’ tab under ‘New Feeds’ on the left column on TrulyEx website, which will have ‘Send Invitation’ highlighted.
                        You can send an invite to other people by typing the email address in the given text box or copy the invitation link and send it to them. 
                        After sending an invite, you can give them the referral code mentioned under ‘Refer a friend & Build your Network’.

                          </p>
                        </div>
                      </div>
                    </div>
                    <div class="card shadow-xss">
                      <div class="card-header" id="headingFive">
                        <h5 class="mb-0">
                          <button
                            class="btn btn-link collapsed"
                            data-toggle="collapse"
                            data-target="#collapseFive"
                            aria-expanded="false"
                            aria-controls="collapseFive"
                          >
                          How do I manage my News Feeds?
                          </button>
                        </h5>
                      </div>

                      <div
                        id="collapseFive"
                        class="collapse"
                        aria-labelledby="headingFive"
                        data-parent="#accordion"
                      >
                        <div class="card-body">
                          <p>
                          The news feed is entirely determined by the groups you follow in each of the three sections. Institutes, Companies, and Courses
                        Simply choose one of the three desired categories from the top pane: Courses, Companies, and Institutes.
                        Select the groups tab from the vertical bar on the left pane.
                        Follow the groups you want to follow, and your news feeds will be updated accordingly.

                          </p>
                        </div>
                      </div>
                    </div>
                    <div class="card shadow-xss">
                      <div class="card-header" id="headingSix">
                        <h5 class="mb-0">
                          <button
                            class="btn btn-link collapsed"
                            data-toggle="collapse"
                            data-target="#collapseSix"
                            aria-expanded="false"
                            aria-controls="collapseSix"
                          >
                          How many groups can I follow on the TrulyEx Platform?
                          </button>
                        </h5>
                      </div>

                      <div
                        id="collapseSix"
                        class="collapse"
                        aria-labelledby="headingSix"
                        data-parent="#accordion"
                      >
                        <div class="card-body">
                          <p>
                          There is no specific limit on the number of groups to follow. You can follow any number of groups that you like on TrulyEx.
                          </p>
                        </div>
                      </div>
                    </div>
                    <div class="card shadow-xss">
                      <div class="card-header" id="headingThree">
                        <h5 class="mb-0">
                          <button
                            class="btn btn-link collapsed"
                            data-toggle="collapse"
                            data-target="#collapseThree"
                            aria-expanded="false"
                            aria-controls="collapseThree"
                          >
                          How to register?
                          </button>
                        </h5>
                      </div>
                      <div
                        id="collapseThree"
                        class="collapse"
                        aria-labelledby="headingThree"
                        data-parent="#accordion"
                      >
                        <div class="card-body">
                          <p>
                          Registration
                                  Click 'Register,' and you will see a registration form. This will take you hardly 2 minutes to fill up. Just submit your information,  and enjoy the various benefits of being a Truly Ex member.

                          </p>
                        </div>
                      </div>
                    </div>
                    <div class="card shadow-xss">
                      <div class="card-header" id="heading1">
                        <h5 class="mb-0">
                          <button
                            class="btn btn-link collapsed"
                            data-toggle="collapse"
                            data-target="#collapse1"
                            aria-expanded="false"
                            aria-controls="collapse1"
                          >
                         What kind of content can I post in TrulyEX?
                          </button>
                        </h5>
                      </div>
                      <div
                        id="collapse1"
                        class="collapse"
                        aria-labelledby="heading1"
                        data-parent="#accordion"
                      >
                        <div class="card-body">
                          <p>
                          Content/Discussion related to Institute, company and courses.

                          </p>
                        </div>
                      </div>
                    </div>
                    <div class="card shadow-xss">
                      <div class="card-header" id="heading2">
                        <h5 class="mb-0">
                          <button
                            class="btn btn-link collapsed"
                            data-toggle="collapse"
                            data-target="#collapse2"
                            aria-expanded="false"
                            aria-controls="collapse2"
                          >
                          How can I join various college groups? Can ONLY the students of that particular college join the group?
                          </button>
                        </h5>
                      </div>
                      <div
                        id="collapse2"
                        class="collapse"
                        aria-labelledby="heading2"
                        data-parent="#accordion"
                      >
                        <div class="card-body">
                          <p>
                          No, any aspirant or interested person in that particular college can join that group and participate in discussion.

                          </p>
                        </div>
                      </div>
                    </div>
                    <div class="card shadow-xss">
                      <div class="card-header" id="heading3">
                        <h5 class="mb-0">
                          <button
                            class="btn btn-link collapsed"
                            data-toggle="collapse"
                            data-target="#collapse3"
                            aria-expanded="false"
                            aria-controls="collapse3"
                          >
                          How can I contact TrulyEX?
                          </button>
                        </h5>
                      </div>
                      <div
                        id="collapse3"
                        class="collapse"
                        aria-labelledby="heading3"
                        data-parent="#accordion"
                      >
                        <div class="card-body">
                          <p>
                          You can contact TrulyEX by writing a mail to info@trulyex.com.

                          </p>
                        </div>
                      </div>
                    </div>
                    <div class="card shadow-xss">
                      <div class="card-header" id="heading4">
                        <h5 class="mb-0">
                          <button
                            class="btn btn-link collapsed"
                            data-toggle="collapse"
                            data-target="#collapse4"
                            aria-expanded="false"
                            aria-controls="collapse4"
                          >
                          How do I stay updated with the latest news?
                          </button>
                        </h5>
                      </div>
                      <div
                        id="collapse4"
                        class="collapse"
                        aria-labelledby="heading4"
                        data-parent="#accordion"
                      >
                        <div class="card-body">
                          <p>
                          You can stay updated by receiving notifications from TrulyEX and by following TrulyEX on various social media handles such as Twitter, etc.

                          </p>
                        </div>
                      </div>
                    </div>
                    <div class="card shadow-xss">
                      <div class="card-header" id="heading5">
                        <h5 class="mb-0">
                          <button
                            class="btn btn-link collapsed"
                            data-toggle="collapse"
                            data-target="#collapse5"
                            aria-expanded="false"
                            aria-controls="collapse5"
                          >
                          How College/course listing is done on TrulyEx. How can I modify it?
                          </button>
                        </h5>
                      </div>
                      <div
                        id="collapse5"
                        class="collapse"
                        aria-labelledby="heading5"
                        data-parent="#accordion"
                      >
                        <div class="card-body">
                          <p>
                          By creating groups by clicking on the “Add new group” option. 

                          </p>
                        </div>
                      </div>
                    </div>
                    <div class="card shadow-xss">
                      <div class="card-header" id="heading6">
                        <h5 class="mb-0">
                          <button
                            class="btn btn-link collapsed"
                            data-toggle="collapse"
                            data-target="#collapse6"
                            aria-expanded="false"
                            aria-controls="collapse6"
                          >
                          Can I add my college/university if not found in the platform?
                          </button>
                        </h5>
                      </div>
                      <div
                        id="collapse6"
                        class="collapse"
                        aria-labelledby="heading6"
                        data-parent="#accordion"
                      >
                        <div class="card-body">
                          <p>
                          Yes , You can add the College of your choice in the platform using the “add new groups “  button which is in select Groups options.

                          </p>
                        </div>
                      </div>
                    </div>
                    <div class="card shadow-xss">
                      <div class="card-header" id="heading7">
                        <h5 class="mb-0">
                          <button
                            class="btn btn-link collapsed"
                            data-toggle="collapse"
                            data-target="#collapse7"
                            aria-expanded="false"
                            aria-controls="collapse7"
                          >
                          	Can I reply to any post to which I may have an answer?
                          </button>
                        </h5>
                      </div>
                      <div
                        id="collapse7"
                        class="collapse"
                        aria-labelledby="heading7"
                        data-parent="#accordion"
                      >
                        <div class="card-body">
                          <p>
                          Yes , You can do it via commenting feature available on the platform

                          </p>
                        </div>
                      </div>
                    </div>
                    <div class="card shadow-xss">
                      <div class="card-header" id="heading8">
                        <h5 class="mb-0">
                          <button
                            class="btn btn-link collapsed"
                            data-toggle="collapse"
                            data-target="#collapse8"
                            aria-expanded="false"
                            aria-controls="collapse8"
                          >
                          Can I edit my post after I have already posted any query?
                          </button>
                        </h5>
                      </div>
                      <div
                        id="collapse8"
                        class="collapse"
                        aria-labelledby="heading8"
                        data-parent="#accordion"
                      >
                        <div class="card-body">
                          <p>
                          No; till now there are no options to edit your post.

                          </p>
                        </div>
                      </div>
                    </div>
                    <div class="card shadow-xss">
                      <div class="card-header" id="heading9">
                        <h5 class="mb-0">
                          <button
                            class="btn btn-link collapsed"
                            data-toggle="collapse"
                            data-target="#collapse9"
                            aria-expanded="false"
                            aria-controls="collapse9"
                          >
                          Why TrulyEx?
                          </button>
                        </h5>
                      </div>
                      <div
                        id="collapse9"
                        class="collapse"
                        aria-labelledby="heading9"
                        data-parent="#accordion"
                      >
                        <div class="card-body">
                          <p>
                          A platform where students can post their queries related to institutions , get queries        resolved and can interact with the alumni’s and faculties.

                          </p>
                        </div>
                      </div>
                    </div>
                    <div class="card shadow-xss">
                      <div class="card-header" id="heading10">
                        <h5 class="mb-0">
                          <button
                            class="btn btn-link collapsed"
                            data-toggle="collapse"
                            data-target="#collapse10"
                            aria-expanded="false"
                            aria-controls="collapse10"
                          >
                          Who will be answering the queries that we post in a particular group?
                          </button>
                        </h5>
                      </div>
                      <div
                        id="collapse10"
                        class="collapse"
                        aria-labelledby="heading10"
                        data-parent="#accordion"
                      >
                        <div class="card-body">
                          <p>
                          Your questions will be answered by domain experts, current students, alumni, or former/current employees of the Institute or company, as appropriate.

                          </p>
                        </div>
                      </div>
                    </div>
                    <div class="card shadow-xss">
                      <div class="card-header" id="headin11">
                        <h5 class="mb-0">
                          <button
                            class="btn btn-link collapsed"
                            data-toggle="collapse"
                            data-target="#collapse11"
                            aria-expanded="false"
                            aria-controls="collapse11"
                          >
                          How are the three sections of TrulyEx different ?
                          </button>
                        </h5>
                      </div>
                      <div
                        id="collapse11"
                        class="collapse"
                        aria-labelledby="headin11"
                        data-parent="#accordion"
                      >
                        <div class="card-body">
                          <p>
                          The 3 sections basically consist of lists of companies, courses and institutions. Under the Companies section, one can find the names of various corporates where they can post their query. Similarly, if someone has any query regarding which courses to go for like B.Tech, MBA etc. they can post their query under the courses section and under that specific course. Same goes with the institutes section.

                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- main content -->