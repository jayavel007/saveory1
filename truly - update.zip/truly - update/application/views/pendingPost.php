      <!-- main content -->
      <div class="main-content right-chat-active bg-img">
        <div class="middle-sidebar-bottom">
          <div class="middle-sidebar-left pe-0">
            <div class="row">
              <div class="col-xl-12">
                  <?php
                  if(!empty($list)){
                    foreach($list as $row){
                      
 $groupImg = $row['group_image'] == NULL?"https://ui-avatars.com/api/?background=random&name=".$row['group_name']:base_url('admin/'.$row['group_image']);

                        ?>
                         <div class="card w-100 shadow-xss rounded-xxl border-0 p-4 mb-3">
                <div class="card-body p-0 d-flex">
                    <figure class="avatar me-3">
                      <img
                        src="<?= $groupImg ?>"
                        alt="image"
                        class="shadow-sm rounded-circle w45"
                      />
                    </figure>
                    <h4 class="fw-700 text-grey-900 font-xssss mt-1">
                    Pending post in <?= $row['group_name'] ?>.
                      <span
                        class="d-block font-xssss fw-500 mt-1 lh-3 text-grey-500"
                        ><?= $row['posted_date']." ".$row['posted_time'] ?> </span
                      >
                    </h4>
                    <a href="#" class="ms-auto" id="dropdownMenu<?= $row['post_id'] ?>" data-bs-toggle="dropdown" aria-expanded="false"
                      ><i
                        class="ti-more-alt text-grey-900 btn-round-md bg-greylight font-xss"
                      ></i
                    ></a>
                    <div class="dropdown-menu dropdown-menu-end p-4 rounded-xxl border-0 shadow-lg" aria-labelledby="dropdownMenu<?= $row['post_id'] ?>">
                   
                     
                    <div class="card-body p-0 d-flex mt-3" data-toggle="modal"
                        data-target="#removePostModal" onclick="removePostId(<?= $row['post_id'] ?>)">
                        <i class="feather-alert-octagon text-grey-500 me-3 font-lg"></i>
                        <h4 class="fw-600 mb-0 text-grey-900 font-xssss mt-0 me-4">
                          Remove Post
                          <span class="d-block font-xsssss fw-500 mt-1 lh-3 text-grey-500">Save to your saved items</span>
                        </h4>
                      </div>
                   
                   

                   
                 </div>
                  </div>
                  <div class="card-body p-0 mb-3 rounded-3 overflow-hidden">
                      <?php
                      
                      foreach($row['post_files']['images'] as $row){
                          ?>
                                        
                    <a href="#" class="video-btn">
                          <img
                            src="<?= base_url($row['img']) ?>"
                            alt=""
                            style="width: 100%"
                          />
                          </a>
                     
                          <?php
                             break;
                      }

                      ?>
                      
                      </div>
                  <div class="card-body p-0 me-lg-5">
                    <?php
                    
                    if(!empty($row['post_detail'])){
                      ?>
                      <p class="fw-500 text-grey-500 lh-26 font-xssss w-100 mb-2">
                      <?= $row['post_detail'] ?>
                      <a href="#" class="fw-600 text-primary ms-2">See more</a>
                    </p>
                      <?php
                    }
                    
                    ?>
                    
                  </div>
                </div>
                        
                        <?php
                    }
                  }
                  ?>
               
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- main content -->