  <!-- Modal -->
  <style>
    .modal-backdrop {
      display: none;
    }
  </style>
  <div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">
            &times;
          </button>
          <h4 class="modal-title" id="modalTitle"></h4>
        </div>
        <div class="modal-body">
          <div class="search__page mb-4">
            <input type="search" id="groupSearch" class="form__input" onkeyup="postGroupAppend()" placeholder="Type the group name here..." />

            <button class="btn btn-secondary">
              <i class="feather-search"></i>
            </button>
          </div>
          <div class="pages" id="postGroupAppend">
            <!-- <div class="page">
                <input type="radio" name="radio" class="page__select" />
                <div class="page__img">
                  <img src="/images/facebook.png" alt="facebook" />
                </div>
                <div class="page__title">Facebook</div>
              </div>
              <div class="page">
                <input type="radio" name="radio" class="page__select" />
                <div class="page__img">
                  <img src="/images/twitter.png" alt="facebook" />
                </div>
                <div class="page__title">Twitter</div>
              </div>
              <div class="page">
                <input type="radio" name="radio" class="page__select" />
                <div class="page__img">
                  <img src="/images/instagram.png" alt="facebook" />
                </div>
                <div class="page__title">Instagram</div>
              </div>
              <div class="page">
                <input type="radio" name="radio" class="page__select" />
                <div class="page__img">
                  <img src="/images/whatsapp.png" alt="facebook" />
                </div>
                <div class="page__title">WhatsApp</div>
              </div>
              <div class="page">
                <input type="radio" name="radio" class="page__select" />
                <div class="page__img">
                  <img src="/images/gmail.png" alt="facebook" />
                </div>
                <div class="page__title">Gmail</div>
              </div> -->
          </div>
        </div>
        <!-- <div class="modal-footer">
          <button type="button" class="btn btn-info" >Select</button>
        </div> -->
      </div>
    </div>
  </div>
  <!-- main content -->
  <div class="main-content right-chat-active bg-img">
    <div class="middle-sidebar-bottom">
      <div class="middle-sidebar-left">
        <!-- loader wrapper -->
        <!-- <div class="preloader-wrap p-3">
          <div class="box shimmer">
            <div class="lines">
              <div class="line s_shimmer"></div>
              <div class="line s_shimmer"></div>
              <div class="line s_shimmer"></div>
              <div class="line s_shimmer"></div>
            </div>
          </div>
          <div class="box shimmer mb-3">
            <div class="lines">
              <div class="line s_shimmer"></div>
              <div class="line s_shimmer"></div>
              <div class="line s_shimmer"></div>
              <div class="line s_shimmer"></div>
            </div>
          </div>
          <div class="box shimmer">
            <div class="lines">
              <div class="line s_shimmer"></div>
              <div class="line s_shimmer"></div>
              <div class="line s_shimmer"></div>
              <div class="line s_shimmer"></div>
            </div>
          </div>
        </div> -->
        <!-- loader wrapper -->
        <div class="row feed-body">
          <div class="col-xl-8 col-xxl-9 col-lg-8">
            <form action="javascript: void(0)" id="postSubmit" method="POST" enctype="multipart/form-data">
              <div class="card w-100 shadow-xss rounded-xxl border-0 ps-4 pt-4 pe-4 pb-3 mb-3">
                <div class="card-body p-0">
                  <!-- <a href="#" class="font-xssss fw-600 text-grey-500 card-body p-0 d-flex align-items-center"><i class="btn-round-sm font-xs text-primary feather-edit-3 me-2 bg-greylight"></i>Create Post</a> -->
                </div>
                <div class="card-body p-0" style="margin-top: 2%;">
                  <a href="#" class="d-flex align-items-center font-xssss fw-600 ls-1 text-grey-700 text-dark pe-4" data-toggle="modal" data-target="#myModal" onclick="postGroupAppend()"><i class="font-md text-success feather-menu me-2"></i><span class="d-none-xs" id="selectedGroup">
                      <?php if ($this->session->userdata('created_group_name')) {
                        echo $this->session->userdata('created_group_name');
                      } else {
                        echo "Select Groups From " . $this->session->userdata('selected_group_type_name');
                      } ?></span></a>
                </div>

                <div class="card-body p-0 mt-3 position-relative">
                  <figure class="avatar position-absolute ms-2 mt-1 top-5">
                    <img src="<?php if ($this->session->userdata('tex_profile_picture') == NULL) {
                                echo "https://ui-avatars.com/api/?background=0D8ABC&color=fff&name=" . $this->session->userdata('tex_profile_name');
                              } else {

                                if (strpos($this->session->userdata('tex_profile_picture'), 'https') !== false) {
                                  echo  $this->session->userdata('tex_profile_picture');
                                } else {
                                  echo  base_url('admin/' . $this->session->userdata('tex_profile_picture'));
                                }
                              }  ?>" alt="image" class="shadow-sm rounded-circle w30" />
                  </figure>
                  <textarea name="post_detail" id="post_detail" class="h100 bor-0 w-100 rounded-xxl p-2 ps-5 font-xssss text-grey-500 fw-500 border-light-md theme-dark-bg" cols="30" rows="10" placeholder="What's on your mind?"></textarea>
                </div>
                <div class="card-body d-flex p-0 mt-0">


                  <span class="d-flex align-items-center font-xssss fw-600 ls-1 text-grey-700 text-dark pe-4 file">
                    <i class="font-md text-success feather-image me-2 cursor-pointer"></i>
                    <span class="d-none-xs cursor-pointer">Photo</span>
                    <input type="file" name="file_pic[]" id="file_pic" accept="image/png, image/jpeg" class="cursor-pointer" multiple />
                  </span>
                  <span class="d-flex align-items-center font-xssss fw-600 ls-1 text-grey-700 text-dark pe-4 file">
                    <i class="font-md text-success feather-video me-2"></i>
                    <span class="d-none-xs">Video</span>
                    <input type="file" name="file_video[]" id="file_video" accept="video/*" />
                  </span>

                  <button type="submit" id="postSubmitBtn" class="btn btn-secondary ms-auto">Post</button>
                </div>
              </div>
              <input type="hidden" id="selectedGroupId" name="selectedGroupId" value="<?php if ($this->session->userdata('created_group_id')) {
                                                                                        echo $this->session->userdata('created_group_id');
                                                                                      } ?>">
            </form>

            <span id="appendHome"></span>
                                                                                    
            <div class="card w-100 text-center shadow-xss rounded-xxl border-0 p-4 mb-3 mt-3" id="loader-icon">
            <div class="snippet mt-2 ms-auto me-auto" data-title=".dot-typing">
              <div class="stage"><div class="dot-typing"></div>
              </div>
            </div>
          </div>                                                           

          </div>
          <!-- <div class="col-xl-4 col-xxl-3 col-lg-4 ps-md-0">
            <div class="card w-100 shadow-xss rounded-xxl border-0 mb-3">
              <div class="card-body d-flex align-items-center p-4">
                <h4 class="fw-700 mb-0 font-xssss text-grey-900">
                  Suggest Group
                </h4>
                <a href="#" class="fw-600 ms-auto font-xssss text-primary">See all</a>
              </div>
              <div class="card-body d-flex pt-4 ps-4 pe-4 pb-0 overflow-hidden border-top-xs bor-0">
                <img src="<?= base_url() ?>images/profile1.jpg" alt="img" class="img-fluid rounded-xxl mb-2" />
              </div>
              <div class="card-body dd-block pt-0 ps-4 pe-4 pb-4">
                <ul class="memberlist mt-1 mb-2 ms-0 d-block">
                  <li class="w20">
                    <a href="#"><img src="<?= base_url() ?>images/pro1.jpg" alt="user" class="w35 d-inline-block" style="opacity: 1" /></a>
                  </li>
                  <li class="w20">
                    <a href="#"><img src="<?= base_url() ?>images/pro2.jpg" alt="user" class="w35 d-inline-block" style="opacity: 1" /></a>
                  </li>
                  <li class="w20">
                    <a href="#"><img src="<?= base_url() ?>images/pro3.jpg" alt="user" class="w35 d-inline-block" style="opacity: 1" /></a>
                  </li>
                  <li class="w20">
                    <a href="#"><img src="<?= base_url() ?>images/pro1.jpg" alt="user" class="w35 d-inline-block" style="opacity: 1" /></a>
                  </li>
                  <li class="last-member">
                    <a href="#" class="bg-greylight fw-600 text-grey-500 font-xssss w35 ls-3 text-center" style="height: 35px; line-height: 35px">+2</a>
                  </li>
                  <li class="ps-3 w-auto ms-1">
                    <a href="#" class="fw-600 text-grey-500 font-xssss">Member apply</a>
                  </li>
                </ul>
              </div>
            </div>

          </div> -->
        </div>
      </div>
    </div>
  </div>
  <!-- main content -->



  <script>
    homeFeeds(1);

    $(document).on('click', '#addNewGroup', function() {
      $('#grp_detail').toggleClass("hidden");
    });
    // console.log($(window).scrollTop() + $(window).height());
    //     console.log($(document).height());
    //var cnt = 4;
    $(document.body).on('touchmove', onScroll); // for mobile
    $(window).on('scroll', onScroll);

    function onScroll() {
      
      if ($(window).scrollTop() + window.innerHeight >= document.body.scrollHeight) {
        if ($(window).scrollTop() + $(window).height() >= $(document).height() || $(window).scrollTop() + $(window).height() + 100 >= $(document).height()) {
          /*if($(".pagenum:last").val() <= $(".rowcount").val()) {
            var pagenum = parseInt($(".pagenum:last").val()) + 1;
            homeFeeds(pagenum);
          }*/
          var pagenum = parseInt($(".pagenum:last").val()) + 1;
            homeFeeds(pagenum);

        }
      }
    }

    // $(window).scroll(function() {

    // else {
    //   console.log($(window).scrollTop() + $(window).height());
    //   console.log($(document).height());
    // }
    // })

    $('#postSubmit').submit(function(e) {
      if ($('#selectedGroupId').val() != "") {
        if ($('#file_pic').get(0).files.length === 0 && $('#file_video').get(0).files.length === 0 &&
          $('#post_detail').val() == "") {
          alert($('#post_detail').val());
          return false;
        }
      } else {
        alert("Select Group");
        return false;
      }


      e.preventDefault();
      $("#postSubmitBtn").attr("disabled", true);
      $.ajax({
        url: "<?= base_url('Home/addPost') ?>",
        type: "post",
        data: new FormData(this),
        processData: false,
        contentType: false,
        cache: false,
        async: false,
        success: function(data) {
          // location.reload();
          console.log(data);
          var res = JSON.parse(data);
          toastpopup(res.msg);
          if (res.status) {
            location.reload();
          }

        }
      });
    });



    function homeFeeds(pagenum) {
      var type = $('#groupTypeLoad').val();
      $.ajax({
        url: "<?= base_url('Home/homeFeeds') ?>",
        method: 'POST',
        data: {
          page: pagenum,
          type: type,
          rowcount:$("#rowcount").val()
        },
        success: function(d) {
          // console.log(d);
          
          if(d != '')
            $('#appendHome').append(d);
          else
            $('#loader-icon').html('<div class="card w-100 text-center shadow-xss rounded-xxl border-0 p-4 mb-3 mt-3"><div class="snippet mt-2 ms-auto me-auto" data-title=".dot-typing"><div class="stage">No Post Available</div></div></div>');

        }
      });
    }

    function postGroupAppend() {
      var groupType = $('#groupTypeLoad').val();
      var search = $('#groupSearch').val();
      var groupName = $('#groupTypeSelected').val();
      $('#modalTitle').html("Following Groups - " + groupName);
      $.ajax({
        url: "<?= base_url('Home/postGroupAppend') ?>",
        method: 'POST',
        data: {
          search: search,
          groupType: groupType
        },
        success: function(d) {

          $('#postGroupAppend').html(d);
        }
      });
    }

    function selectedGroup(name) {
      var split = name.split("#");
      var status = $('#grpFollowStatus_' + split[0]).val();
      if (status == "Following") {
        $('#selectedGroup').html(split[1]);
        $('#selectedGroupId').val(split[0]);
        $('#myModal').removeClass('show');
      } else {
        toastpopup("Please Follow Group To Add Post");
        $('.page__select').prop('checked', false);

      }

    }

    function submitGroupForm() {


      event.preventDefault();

      var content = $("#submitGroupForm")[0];
      var data = new FormData(content);
      $.ajax({
        url: "<?= base_url('Home/createGroup') ?>",
        type: "post",
        data: data,
        processData: false,
        contentType: false,
        cache: false,
        async: false,
        success: function(data) {

          console.log(data);
          if (data != 0) {
            var split = data.split("#");
            $('#selectedGroup').html(split[1]);
            $('#selectedGroupId').val(split[0]);
            $('#myModal').removeClass('show');
            toastpopup("Group Created");
          } else {
            toastpopup("Something Wrong");
          }
        }
      });
    }

    function checkName(value) {



      var type = "group";

      $.ajax({
        url: "<?= base_url('Home/checkName') ?>",
        method: 'POST',
        data: {
          value: value,
          type: type
        },
        success: function(d) {
          var res = JSON.parse(d);
          console.log(res);
          $('#nameCheck').html(res.msg);
          if (res.status) {
            $('#nameCheck').css("color", "green");
            $("#newGroupSubmit").attr("disabled", false);
          } else {
            $('#nameCheck').css("color", "red");
            $("#newGroupSubmit").attr("disabled", true);
          }
        }
      });


    }

    // function addPost(){
    // $.ajax({
    // url:<?= base_url() ?>,
    // method:'POST',
    // data:{},
    // success: function(d){
    // console.log(d);
    // }
    // });
    // }

    // 'use strict';
    // let slide = document.querySelector('.slider__items').children;
    // const leftBtn = document.querySelector('.left__slide');
    // const rightBtn = document.querySelector('.right__slide');
    // const totalSlide = slide.length;
    // let idx = 0;

    // function next(direction) {
    //   if (direction === 'next') {
    //     idx++;
    //     if (idx === totalSlide) {
    //       idx = 0;
    //     }
    //   } else {
    //     if (idx === 0) {
    //       idx = totalSlide - 1;
    //     } else {
    //       idx--;
    //     }
    //   }

    //   let i = 0;
    //   for (i = 0; i < slide.length; i++) {
    //     slide[i].classList.remove('active');
    //   }
    //   slide[idx].classList.add('active');
    // }

    // rightBtn.addEventListener('click', () => {
    //   next('next');
    // });
    // leftBtn.addEventListener('click', () => {
    //   next('prev');
    // });
  </script>



  </body>

  </html>