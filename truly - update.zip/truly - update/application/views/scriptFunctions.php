<div id="snackbar"></div>
<input type="hidden" name="groupTypeSelected" id="groupTypeSelected" value="<?= $this->session->userdata('selected_group_type_name') ?>">
<!-- RemovePost Modal  -->
<div id="removePostModal" class="modal fade" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-body">
            <p>Are you sure?</p>
          </div>
          <input type="hidden" name="remove_id" id="remove_id" >
          <div class="modal-footer">
            <button type="button" class="btn btn-light" data-dismiss="modal">Cancel</button>
            <button type="button" onclick="removePost()" class="btn btn-info">Confirm</button>
          </div>
        </div>
      </div>
    </div>
<!-- Remove Post End -->
<!-- Report Modal -->
<div id="reportModal" class="modal fade" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">
              &times;
            </button>
            <h4 class="modal-title">Report</h4>
          </div>
          <div class="modal-body">
              <input type="hidden" name="postReportId" id="postReportId" >
            <div class="pages" id="reportAppend">
              
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" onclick="reportSubmit()" class="btn btn-info">Select</button>
          </div>
        </div>
      </div>
    </div>
<!-- Report Modal End -->
<script>
    notificationCount();
    notificationTopBar();

  
  
    // $(document).on('click', '.likeBtn', function(event) {
        
    // });


    function toggleClass(){
        $('#reportHideSpan').toggleClass('hidden');
    }

    function openReportModal(id){
        $.ajax({
            url: "<?= base_url('Home/postReportTypes') ?>",
            method: 'POST',
            success: function(d) {
              $('#reportAppend').append(d);
              $('#postReportId').val(id);
            }
        });
    }

    function notificationCount() {
        // do whatever you like here

        $.ajax({
            url: "<?= base_url('Home/notificationCount') ?>",
            method: 'POST',
            success: function(d) {
                // console.log(d);
                if (d != 0) {
                    $('#notificationCount').html(d);
                    notificationTopBar();
                } else {
                    $('#notificationCount').addClass('hidden');
                    // $('#notificationCount').html(0);
                }
            }
        });
        setTimeout(notificationCount, 5000);
    }



    <?php
    if ($this->session->userdata('toastmsg')) {
    ?>
        toastpopup("<?= $this->session->userdata('toastmsg') ?>");
    <?php
        $this->session->unset_userdata('toastmsg');
    }
    ?>



    function toastpopup(d) {

        var x = document.getElementById("snackbar");
        x.innerText = d;
        x.className = "show";
        setTimeout(function() {
            x.className = x.className.replace("show", "");
        }, 3000);
    }

    function followUserGroup(id, type, btnid) {

        $.ajax({
            url: "<?= base_url('Home/followUserGroup') ?>",
            method: 'POST',
            data: {
                id: id,
                type: type
            },
            success: function(d) {
                 console.log(d);
                 
                if(btnid != "postSide"){
                    dataArr = d.split("@@");
                    $('#' + btnid).html(dataArr[0]);
                    $("#totalFollwer").html(dataArr[1])
                    if (btnid == "addPostFollowBtn_" + id) {
                        $('#grpFollowStatus_' + id).val(d);
                        
                    }
                    if (dataArr[0] == "Following") {
                        $('#' + btnid).removeClass("follow");
                        $('#' + btnid).addClass("followed");
                    } else {
                        $('#' + btnid).removeClass("followed");
                        $('#' + btnid).addClass("follow");
                    }
                }else{
                    var text = d == "Following"?"Added To Following List":"Removed From Following List";
                    toastpopup(text);
                }
            }
        });

    }

    function changeGroupType(id, name, page) {
        $('#groupTypeLoad').val(id);
        $('.center-menu-icon').removeClass('active');
        $('#group_type_name_' + id).addClass('active');

        $.ajax({
            url: "<?= base_url('Home/changeGroupType') ?>",
            method: 'POST',
            data: {
                id: id,
                name: name
            },
            success: function(d) {
                if (page == "home" || page == "explore") {
                    if(page == "home"){
                        $('#selectedGroup').html("Select Group From "+name);
                    }
                    $('#appendHome').html('');
                    $(".pagenum:last").val(0)
                    homeFeeds(1);
                } else if (page == "groups") {
                    groupsList();
                }
                $('#groupTypeSelected').val(d);
            }
        });


    }
    function closeCommentSideCard(){
        $("#lightbox").hide();
    }
    function fetchPostData(id) {
        $('#postAddComment').val('')
        $.ajax({
            url: "<?= base_url('Home/fetchPostData') ?>",
            method: 'POST',
            data: {
                id: id
            },
            success: function(d) {
                $('#lightbox').html(d);
                $("#lightbox").show();

            }
        });
    }

    function likePost(id,type,btnid,) {

        $.ajax({
            url: "<?= base_url('Home/likePost') ?>",
            method: 'POST',
            data: {
                id: id
            },
            success: function(d) {

                var res = JSON.parse(d);
                var cnt = res.cnt == 0?"":res.cnt;
                $('#'+btnid+id).html('<i class="feather-thumbs-up text-white bg-primary-gradiant me-1 btn-round-xs font-xss"></i><span class="text-success">'+cnt+' Like');
                //$('#'+btnid+id).toggleClass("text-success");
            }
        });
    }

    function notificationTopBar() {
        $.ajax({
            url: "<?= base_url('Home/notificationTopBar') ?>",
            method: 'POST',
            success: function(d) {
                $('#notificationListAppend').html(d);
            }
        });
    }

    function addComment(id,pageType){
        var cmt = $('#postAddComment').val();
        if(cmt == ""){
            alert('Comment Box Empty');
            return false;
        }
        $.ajax({
            url: "<?= base_url('Home/addComment') ?>",
            data: {cmt:cmt,post_id:id},
            method: 'POST',
            success: function(d) {
                if(d){
                    
                    toastpopup("Comment Added");
                    if(pageType == "share"){
                       location.reload();
                    }else{
                        fetchPostData(id);
                    }
                }else{
                    toastpopup("Something Wrong");
                }
               
                console.log(d);
            }
        });
    }

    function removeComment(comment_id, post_id){
        $.ajax({
            url: "<?= base_url('Home/removeComment') ?>",
            data: {comment_id:comment_id, post_id : post_id},
            method: 'POST',
            success: function(d) {
                if(d){
                    toastpopup("Comment Removed");
                    fetchPostData(post_id);
                }else{
                    toastpopup("Something Wrong");
                }               
                console.log(d);
            }
        });
    }

    function copyToClipboard(element) {
        
  var $temp = $("<input>");
  $("body").append($temp);
  $temp.val($("#copyLink_"+element).val()).select();
  document.execCommand("copy");
  $temp.remove();
  toastpopup("Link Copied");
}


function reportSubmit(){
    
    if($('input[name="report"]:checked').length != 0){
        var report_text = $('#reportTextArea').val();
    var report_id = $('input[name="report"]:checked').val();
    if(report_id == 0){
        if(report_text == ""){
            toastpopup('Please Type Something');
            return false;
        }
    }
    
    var post_id = $('#postReportId').val();
  


    }else{
        toastpopup('Please Select');
        return false;
    }

    $.ajax({
        url: "<?= base_url('Home/addReport') ?>",
        method: 'POST',
        data:{
            report_text : report_text,
            report_id :report_id,
            post_id : post_id,
        },
        success: function(d) {
          var res = JSON.parse(d);
          if(res.status == true){
            $('#reportModal').removeClass('show');
          }
          toastpopup(res.msg);
        }
    });
 
}
    

   function removePostId(id){
        $('#remove_id').val(id);
   } 

   function removePost(){
       var id = $('#remove_id').val();
       $.ajax({
        url: "<?= base_url('Home/removePost') ?>",
        method: 'POST',
        data:{
            post_id : id
        },
        success: function(d) {
          var res = JSON.parse(d);
          if(res.status == true){
            location.reload();
          }else{
            toastpopup("Something Wrong");
          }
        }
    });
   }
</script>