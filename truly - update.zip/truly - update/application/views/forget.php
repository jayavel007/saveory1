<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>TrulyEX</title>

    <link rel="stylesheet" href="<?= base_url() ?>css/themify-icons.css" />
    <link rel="stylesheet" href="<?= base_url() ?>css/feather.css" />
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/trulyEx.png" />
    <!-- Custom Stylesheet -->
    <link rel="stylesheet" href="<?= base_url() ?>css/style.css" />
    <style>
        .login-card {
            min-width: 380px;
            /* max-width: 400px; */
            height: 400px;
            overflow: hidden;
            overflow-y: none !important;
        }
    </style>

</head>

<body class="color-theme-blue">
    <div class="preloader"></div>

    <div class="main-wrap">
        <div class="nav-header bg-transparent shadow-none border-0">
            <div class="w-100">
                <a href="#">
                    <img src="<?= base_url() ?>images/trulyEx.png" width="70" ; height="70" />
                    <!-- <i class="feather-zap text-success display1-size me-2 ms-0"></i
            > -->
                    <!-- <span
              class="d-inline-block fredoka-font ls-3 fw-600 text-current font-xxl logo-text mb-0"
              >TrulyEX.
            </span> -->
                </a>
                <!-- <a href="#" class="mob-menu ms-auto me-2 chat-active-btn"><i class="feather-message-circle text-grey-900 font-sm btn-round-md bg-greylight"></i></a>
                <a href="default-video.html" class="mob-menu me-2"><i class="feather-video text-grey-900 font-sm btn-round-md bg-greylight"></i></a>
                <a href="#" class="me-2 menu-search-icon mob-menu"><i class="feather-search text-grey-900 font-sm btn-round-md bg-greylight"></i></a>
                <button class="nav-menu me-0 ms-2"></button> -->


            </div>
        </div>

        <div class="bg-img vh-100">
            <div class="col-xl-12 vh-100 align-items-center d-flex rounded-3 overflow-hidden">
                <div class="card bx-shadow border-0 ms-auto me-auto login-card">
                    <div class="card-body rounded-0 text-left d-flex justify-content-center flex-column">
                        <h2 class="fw-700 display1-size display2-md-size mb-3 mb-4">
                            Forget <br />your password
                        </h2>
                        <form id="loginform" action="javascript:void(0)" method="post">
                            <span id="loginNotify" style="color:red;"></span>
                            <div class="form-group icon-input mb-3 mb-4">
                                <i class="font-sm ti-email text-grey-500 pe-0"></i>
                                <input type="email" class="style2-input ps-5 form-control text-grey-900 font-xsss fw-600" placeholder="Email" name="email" required />
                            </div>
                            <div class="form-group icon-input mb-4" id="otp_popup"></div>
                            <!-- <div class="form-group icon-input mb-4" id="otp" hidden>
                                <input type="Password" class="style2-input ps-5 form-control text-grey-900 font-xss ls-3" placeholder="New Password" id="id_password" name="password" />
                                <i class="font-sm ti-eye text-grey-500 pe-0" id="togglePassword"></i>
                            </div> -->

                            <div class="col-sm-12 p-0 text-left">
                                <div class="form-group mb-1" id="button">
                                    <button type="submit" class="form-control text-center style2-input text-white fw-600 bg-dark border-0 p-0" onclick="otp()"> Get OTP</button>
                                </div>

                            </div>
                        </form>



                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?= base_url() ?>js/plugin.js"></script>
    <script src="<?= base_url() ?>js/scripts.js"></script>
    <script>
        function verify() {
            //    alert("hi");
            $.ajax({
                url: "<?= base_url('Home/verify_otp') ?>",
                method: "POST",
                data: $("#loginform").serialize(),
                success: function(d) {
                    if (d == '1') {
                        window.location = "<?= base_url('reset') ?>";
                    } else {
                        $("#loginNotify").html("enter correct OTP").show();
                        $("#loginNotify").fadeOut(5000);

                    }
                }
            });
        }

        function otp() {
            // var but = '<button type = "submit"class = "form-control text-center style2-input text-white fw-600 bg-dark border-0 p-0" > Get OTP';
            // $("#button").html(but);
            // alert("hi");
            $.ajax({
                url: "<?= base_url('Home/otp') ?>",
                method: "POST",
                data: $("#loginform").serialize(),
                success: function(d) {
                    // alert(d);
                    if (d == "1") {
                        $("#loginNotify").html("Please Enter Registered email").show();
                        $("#loginNotify").fadeOut(5000);
                        // window.location = "<?= base_url('login') ?>";
                    } else if (d == "2") {
                        var otp = '<i class="font-sm ti-key text-grey-500 pe-0" aria-hidden="true"></i><input type="text" class="style2-input ps-5 form-control text-grey-900 font-xsss fw-600"  name="otp" placeholder="Please Enter OTP NO" required /> ';
                        var but = '<button type = "submit" onclick="verify()" class = "form-control text-center style2-input text-white fw-600 bg-dark border-0 p-0" > Submit';
                        //toastr.options.timeOut = 1500; // 1.5s
                        // $("#loginNotify").html("Wrong Mobile No").fadeOut(5000);
                        $("#otp_popup").html(otp);
                        $("#button").html(but);
                        //alert("Wrong Mobile No");
                        //window.location = "<?= base_url('forget') ?>";
                    }
                }
            });
        }
    </script>
</body>



<!-- <script>
    const togglePassword = document.querySelector('#togglePassword');
    const password = document.querySelector('#id_password');

    togglePassword.addEventListener('click', function(e) {
        // toggle the type attribute
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);
        // toggle the eye slash icon
        this.classList.toggle('fa-eye-slash');
    });
</script> -->

</html>