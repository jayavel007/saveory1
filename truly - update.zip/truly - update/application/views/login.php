<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>TrulyEX</title>

    <link rel="stylesheet" href="<?= base_url() ?>css/themify-icons.css" />
    <link rel="stylesheet" href="<?= base_url() ?>css/feather.css" />
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/trulyEx.png" />
    <!-- Custom Stylesheet -->
    <link rel="stylesheet" href="<?= base_url() ?>css/style.css" />
</head>

<body class="color-theme-blue">
    <div class="preloader"></div>

    <div class="main-wrap">
        <div class="nav-header bg-transparent shadow-none border-0">
            <div class="w-100">
                <a href="#">
                    <img src="<?= base_url() ?>images/trulyEx.png" width="70" ; height="70" />
                    <!-- <i class="feather-zap text-success display1-size me-2 ms-0"></i
            > -->
                    <!-- <span
              class="d-inline-block fredoka-font ls-3 fw-600 text-current font-xxl logo-text mb-0"
              >TrulyEX.
            </span> -->
                </a>
                <!-- <a href="#" class="mob-menu ms-auto me-2 chat-active-btn"><i class="feather-message-circle text-grey-900 font-sm btn-round-md bg-greylight"></i></a>
                <a href="default-video.html" class="mob-menu me-2"><i class="feather-video text-grey-900 font-sm btn-round-md bg-greylight"></i></a>
                <a href="#" class="me-2 menu-search-icon mob-menu"><i class="feather-search text-grey-900 font-sm btn-round-md bg-greylight"></i></a>
                <button class="nav-menu me-0 ms-2"></button> -->


            </div>
        </div>

        <div class="bg-img">
            <div class="col-xl-12 vh-100 align-items-center d-flex rounded-3 overflow-hidden">
                <div class="card bx-shadow border-0 ms-auto me-auto login-card">
                    <div class="card-body rounded-0 text-left">
                        <h2 class="fw-700 display1-size display2-md-size mb-3">
                            Login into <br />your account
                        </h2>
                        <form id="loginform" action="javascript:void(0)" method="post" onsubmit="return userLogin()">
                            <span id="loginNotify"></span>
                            <div class="form-group icon-input mb-3">
                                <i class="font-sm ti-user text-grey-500 pe-0"></i>
                                <input type="text" class="style2-input ps-5 form-control text-grey-900 font-xsss fw-600" placeholder="User Name / Mobile Number" name="name" />
                            </div>
                            <div class="form-group icon-input mb-1">
                                <input type="Password" class="style2-input ps-5 form-control text-grey-900 font-xss ls-3" placeholder="Password" name="password" />
                                <i class="font-sm ti-lock text-grey-500 pe-0"></i>
                            </div>
                            <div class="form-check text-left mb-3">
                                <input type="checkbox" class="form-check-input mt-2" id="exampleCheck1" />
                                <label class="form-check-label font-xsss text-grey-500" for="exampleCheck1">Remember me</label>
                                <a href="<?= base_url('forget') ?>" class="fw-600 font-xsss text-grey-700 mt-1 float-right">Forgot your Password?</a>
                            </div>
                            <div class="col-sm-12 p-0 text-left">
                                <div class="form-group mb-1">
                                    <button type="submit" class="form-control text-center style2-input text-white fw-600 bg-dark border-0 p-0">Login</button>
                                </div>
                                <h6 class="text-grey-500 font-xsss fw-500 mt-0 mb-0 lh-32">
                                    Dont have account
                                    <a href="<?= base_url('register/new') ?>" class="fw-700 ms-1">Register</a>
                                </h6>
                            </div>
                        </form>


                        <div class="col-sm-12 p-0 text-center mt-2">
                            <h6 class="mb-0 d-inline-block bg-white fw-500 font-xsss text-grey-500 mb-3">
                                Or, Sign in with your social account
                            </h6>
                            <div class="form-group mb-1">
                                <a href="<?= base_url('Home/googleLogin') ?>" class="form-control text-left style2-input text-white fw-600 bg-facebook border-0 p-0 mb-2"><img src="images/icon-1.png" alt="icon" class="ms-2 w40 mb-1 me-5" />
                                    Sign in with Google</a>
                            </div>
                            <!-- <div class="form-group mb-1">
                  <a
                    href="#"
                    class="form-control text-left style2-input text-white fw-600 bg-twiiter border-0 p-0"
                    ><img
                      src="images/icon-3.png"
                      alt="icon"
                      class="ms-2 w40 mb-1 me-5"
                    />
                    Sign in with Facebook</a
                  >
                </div> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?= base_url() ?>js/plugin.js"></script>
    <script src="<?= base_url() ?>js/scripts.js"></script>
    <script>
        function userLogin() {

            $.ajax({
                url: "<?= base_url('Home/checkLogin') ?>",
                method: "POST",
                data: $("#loginform").serialize(),
                success: function(d) {

                    if (d == "1") {
                        window.location = "<?= base_url('homeFeeds') ?>";
                    } else if (d == "2") {
                        window.location = "<?= base_url('topGroups') ?>";
                    } else {
                        $('#loginNotify').html("Invalid Credentials");
                    }
                }
            });
        }
    </script>
</body>

</html>