      <!-- main content -->
      <div class="main-content right-chat-active">
          <div class="middle-sidebar-bottom">
              <div class="middle-sidebar-left pe-0">
                  <div class="row">
                      <div class="col-xl-12">
                          <div class="card shadow-xss w-100 d-block d-flex border-0 p-4 mb-3">
                              <div class="card-body d-flex align-items-center p-0">
                                  <h2 class="fw-700 mb-0 mt-0 font-md text-grey-900">
                                      Groups
                                  </h2>
                                  <div class="search-form-2 ms-auto">
                                      <i class="ti-search font-xss"></i>
                                      <input type="text" class="form-control text-grey-500 mb-0 bg-greylight theme-dark-bg border-0" placeholder="Search here." id="search" onkeyup="groupsList()" />
                                  </div>

                                  <a href="#" class="btn-round-md ms-2 bg-greylight theme-dark-bg rounded-3" id="dropdownMenu2" data-bs-toggle="dropdown" aria-expanded="true"><i class="feather-filter font-xss text-grey-500"></i></a>
                                  <div class="dropdown-menu dropdown-menu-end p-3 rounded-3 border-0 shadow-lg" aria-labelledby="dropdownMenu2" onclick="event.stopPropagation()">
                                      <h4 class="fw-700 font-xss mb-2">Filters</h4>
                                      <div class="form-check align-items-center d-flex">
                                          <input class="form-check-input font-xssss me-4 text-secondary" type="radio" name="filter" value="0" id="default" onclick="groupsList()" checked>
                                          <label class="form-check-label font-xsss text-secondary  fw-700" for="default">
                                              Default
                                          </label>
                                      </div>
                                      <div class="form-check align-items-center d-flex">
                                          <input class="form-check-input font-xssss me-4 text-secondary" type="radio" name="filter" value="1" id="atoz" onclick="groupsList()">
                                          <label class="form-check-label font-xsss text-secondary  fw-700" for="atoz">
                                              A to Z
                                          </label>
                                      </div>
                                      <div class="form-check align-items-center d-flex">
                                          <input class="form-check-input font-xssss me-4 text-secondary" type="radio" name="filter" value="2" id="ztoa" onclick="groupsList()">
                                          <label class="form-check-label font-xsss  text-secondary  fw-700" for="ztoa">
                                              Z to A
                                          </label>
                                      </div>
                                      <div class="form-check align-items-center d-flex">
                                          <input class="form-check-input font-xssss me-4 text-secondary" type="radio" name="filter" value="3" id="hightolow" onclick="groupsList()">
                                          <label class="form-check-label font-xsss text-secondary  fw-700" for="hightolow">
                                              High - Low Followers
                                          </label>
                                      </div>
                                     


                                  
                              </div>
                          </div>

                          <div class="row ps-2 pe-1 mt-4" id="groupsList">
                              <!-- <div class="col-md-6 col-sm-6 pe-2 ps-2">
                                  <div class="card d-block border-0 shadow-xss rounded-3 overflow-hidden mb-3">
                                      <div class="card-body position-relative h100 bg-image-cover bg-image-center" style="background-image: url(./images/group1.jpg)"></div>
                                      <div class="card-body d-block w-100 pl-10 pe-4 pb-4 pt-0 text-left position-relative">
                                          <figure class="avatar position-absolute w75 z-index-1" style="top: -40px; left: 15px">
                                              <img src="./images/pro1.jpg" alt="image" class="float-right p-1 bg-white rounded-circle w-100" />
                                          </figure>
                                          <div class="clearfix"></div>
                                          <h4 class="fw-700 font-xsss mt-3 mb-1">
                                              Victor Exrixon
                                          </h4>
                                          <p class="fw-500 font-xsssss text-grey-500 mt-0 mb-3">
                                              support@gmail.com
                                          </p>
                                          <span class="position-absolute right-15 top-0 d-flex align-items-center">
                                              <a href="#" class="d-lg-block d-none"><i class="feather-video btn-round-md font-md bg-primary-gradiant text-white"></i></a>
                                              <a href="#" class="text-center p-2 lh-24 w100 ms-1 ls-3 d-inline-block rounded-xl bg-current font-xsssss fw-700 ls-lg text-white">FOLLOW</a>
                                          </span>
                                      </div>
                                  </div>
                              </div>
                              <div class="col-md-6 col-sm-6 pe-2 ps-2">
                                  <div class="card d-block border-0 shadow-xss rounded-3 overflow-hidden mb-3">
                                      <div class="card-body position-relative h100 bg-image-cover bg-image-center" style="background-image: url(./images/group2.jpg)"></div>
                                      <div class="card-body d-block w-100 pl-10 pe-4 pb-4 pt-0 text-left position-relative">
                                          <figure class="avatar position-absolute w75 z-index-1" style="top: -40px; left: 15px">
                                              <img src="./images/pro2.jpg" alt="image" class="float-right p-1 bg-white rounded-circle w-100" />
                                          </figure>
                                          <div class="clearfix"></div>
                                          <h4 class="fw-700 font-xsss mt-3 mb-1">
                                              Surfiya Zakir
                                          </h4>
                                          <p class="fw-500 font-xsssss text-grey-500 mt-0 mb-3">
                                              support@gmail.com
                                          </p>
                                          <span class="position-absolute right-15 top-0 d-flex align-items-center">
                                              <a href="#" class="d-lg-block d-none"><i class="feather-video btn-round-md font-md bg-primary-gradiant text-white"></i></a>
                                              <a href="#" class="text-center p-2 lh-24 w100 ms-1 ls-3 d-inline-block rounded-xl bg-current font-xsssss fw-700 ls-lg text-white">FOLLOW</a>
                                          </span>
                                      </div>
                                  </div>
                              </div>

                              <div class="col-md-6 col-sm-6 pe-2 ps-2">
                                  <div class="card d-block border-0 shadow-xss rounded-3 overflow-hidden mb-3">
                                      <div class="card-body position-relative h100 bg-image-cover bg-image-center" style="background-image: url(./images/group1.jpg)"></div>
                                      <div class="card-body d-block w-100 pl-10 pe-4 pb-4 pt-0 text-left position-relative">
                                          <figure class="avatar position-absolute w75 z-index-1" style="top: -40px; left: 15px">
                                              <img src="./images/pro1.jpg" alt="image" class="float-right p-1 bg-white rounded-circle w-100" />
                                          </figure>
                                          <div class="clearfix"></div>
                                          <h4 class="fw-700 font-xsss mt-3 mb-1">Goria Coast</h4>
                                          <p class="fw-500 font-xsssss text-grey-500 mt-0 mb-3">
                                              support@gmail.com
                                          </p>
                                          <span class="position-absolute right-15 top-0 d-flex align-items-center">
                                              <a href="#" class="d-lg-block d-none"><i class="feather-video btn-round-md font-md bg-primary-gradiant text-white"></i></a>
                                              <a href="#" class="text-center p-2 lh-24 w100 ms-1 ls-3 d-inline-block rounded-xl bg-current font-xsssss fw-700 ls-lg text-white">FOLLOW</a>
                                          </span>
                                      </div>
                                  </div>
                              </div>

                              <div class="col-md-6 col-sm-6 pe-2 ps-2">
                                  <div class="card d-block border-0 shadow-xss rounded-3 overflow-hidden mb-3">
                                      <div class="card-body position-relative h100 bg-image-cover bg-image-center" style="background-image: url(./images/group2.jpg)"></div>
                                      <div class="card-body d-block w-100 pl-10 pe-4 pb-4 pt-0 text-left position-relative">
                                          <figure class="avatar position-absolute w75 z-index-1" style="top: -40px; left: 15px">
                                              <img src="./images/pro2.jpg" alt="image" class="float-right p-1 bg-white rounded-circle w-100" />
                                          </figure>
                                          <div class="clearfix"></div>
                                          <h4 class="fw-700 font-xsss mt-3 mb-1">Hurin Seary</h4>
                                          <p class="fw-500 font-xsssss text-grey-500 mt-0 mb-3">
                                              support@gmail.com
                                          </p>
                                          <span class="position-absolute right-15 top-0 d-flex align-items-center">
                                              <a href="#" class="d-lg-block d-none"><i class="feather-video btn-round-md font-md bg-primary-gradiant text-white"></i></a>
                                              <a href="#" class="text-center p-2 lh-24 w100 ms-1 ls-3 d-inline-block rounded-xl bg-current font-xsssss fw-700 ls-lg text-white">FOLLOW</a>
                                          </span>
                                      </div>
                                  </div>
                              </div>

                              <div class="col-md-6 col-sm-6 pe-2 ps-2">
                                  <div class="card d-block border-0 shadow-xss rounded-3 overflow-hidden mb-3">
                                      <div class="card-body position-relative h100 bg-image-cover bg-image-center" style="background-image: url(./images/group1.jpg)"></div>
                                      <div class="card-body d-block w-100 pl-10 pe-4 pb-4 pt-0 text-left position-relative">
                                          <figure class="avatar position-absolute w75 z-index-1" style="top: -40px; left: 15px">
                                              <img src="./images/pro1.jpg" alt="image" class="float-right p-1 bg-white rounded-circle w-100" />
                                          </figure>
                                          <div class="clearfix"></div>
                                          <h4 class="fw-700 font-xsss mt-3 mb-1">David Goria</h4>
                                          <p class="fw-500 font-xsssss text-grey-500 mt-0 mb-3">
                                              support@gmail.com
                                          </p>
                                          <span class="position-absolute right-15 top-0 d-flex align-items-center">
                                              <a href="#" class="d-lg-block d-none"><i class="feather-video btn-round-md font-md bg-primary-gradiant text-white"></i></a>
                                              <a href="#" class="text-center p-2 lh-24 w100 ms-1 ls-3 d-inline-block rounded-xl bg-current font-xsssss fw-700 ls-lg text-white">FOLLOW</a>
                                          </span>
                                      </div>
                                  </div>
                              </div>

                              <div class="col-md-6 col-sm-6 pe-2 ps-2">
                                  <div class="card d-block border-0 shadow-xss rounded-3 overflow-hidden mb-3">
                                      <div class="card-body position-relative h100 bg-image-cover bg-image-center" style="background-image: url(./images/group2.jpg)"></div>
                                      <div class="card-body d-block w-100 pl-10 pe-4 pb-4 pt-0 text-left position-relative">
                                          <figure class="avatar position-absolute w75 z-index-1" style="top: -40px; left: 15px">
                                              <img src="./images/pro2.jpg" alt="image" class="float-right p-1 bg-white rounded-circle w-100" />
                                          </figure>
                                          <div class="clearfix"></div>
                                          <h4 class="fw-700 font-xsss mt-3 mb-1">Seary Victor</h4>
                                          <p class="fw-500 font-xsssss text-grey-500 mt-0 mb-3">
                                              support@gmail.com
                                          </p>
                                          <span class="position-absolute right-15 top-0 d-flex align-items-center">
                                              <a href="#" class="d-lg-block d-none"><i class="feather-video btn-round-md font-md bg-primary-gradiant text-white"></i></a>
                                              <a href="#" class="text-center p-2 lh-24 w100 ms-1 ls-3 d-inline-block rounded-xl bg-current font-xsssss fw-700 ls-lg text-white">FOLLOW</a>
                                          </span>
                                      </div>
                                  </div>
                              </div> -->
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
      <!-- main content -->

      <script>
          $(document).ready(function() {
              groupsList();
          });

          function groupsList() {
              var groupType = $('#groupTypeLoad').val();
              var filter = $('input[name="filter"]:checked').val();  
              var search = $('#search').val();
              $.ajax({
                  url: "<?= base_url('Home/groupsListContents') ?>",
                  method: 'POST',
                  data: {
                      search: search,
                      groupType: groupType,
                      filter: filter,
                  },
                  success: function(d) {
                      //   console.log(d);
                      $('#groupsList').html(d);
                  }
              });
          }
      </script>