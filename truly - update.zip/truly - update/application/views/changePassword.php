<div class="main-content bg-lightblue theme-dark-bg right-chat-active">
        <div class="middle-sidebar-bottom">
          <div class="middle-sidebar-left">
            <div class="middle-wrap">
              <div class="card w-100 border-0 bg-white shadow-xs p-0 mb-4">
                <div
                  class="card-body p-4 w-100 bg-current border-0 d-flex rounded-3"
                >
                  <a href="<?= base_url('settings') ?>" class="d-inline-block mt-2"
                    ><i class="ti-arrow-left font-sm text-white"></i
                  ></a>
                  <h4 class="font-xs text-white fw-600 ms-4 mb-0 mt-2">
                    Change Password
                  </h4>
                </div>
                <div class="card-body p-lg-5 p-4 w-100 border-0">
                  <form action="#" id="passwordForm">
                    <div class="row">
                      <div class="col-lg-12 mb-3">
                        <div class="form-gorup">
                          <label class="mont-font fw-600 font-xssss"
                            >Current Password</label
                          >
                          <input
                            type="text"
                            name="current"
                            id="current"
                            class="form-control"
                          />
                        </div>
                      </div>

                      <div class="col-lg-12 mb-3">
                        <div class="form-gorup">
                          <label class="mont-font fw-600 font-xssss"
                            >Change Password</label
                          >
                          <input
                            type="text"
                            name="newp"
                            id="newp"
                            class="form-control"
                            onkeyup="checkPassword()"
                          />
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <div class="col-lg-12 mb-3">
                        <div class="form-gorup">
                          <label class="mont-font fw-600 font-xssss"
                            >Confirm Change Password</label
                          >
                          <input
                            type="text"
                            name="newc"
                            id="newc"
                            class="form-control"
                            onkeyup="checkPassword()"
                          />
                        </div>
                      </div>
                    </div>
                    <span id="passwordAlert"></span>
                    <div class="row">
                      <div class="col-lg-12 mb-0">
                        <button
                          type="button"
                          onclick="savePassword()"
                          id="clickBtn"
                          class="bg-current text-center text-white font-xsss fw-600 p-3 w175 rounded-3 d-inline-block"
                          >Save</button
                        >
                      </div>
                    </div>
                  </form>
                </div>
              </div>
              <!-- <div class="card w-100 border-0 p-2"></div> -->
            </div>
          </div>
        </div>
      </div>

      <script>
          function savePassword(){
              var old = $('#current').val();
              var newp = $('#newp').val();
            $.ajax({
            url: "<?= base_url('Home/updatePassword') ?>",
            method: 'POST',
            data: {old:old,newp:newp},
            success: function(d) {
               toastpopup(d);
               $('#passwordForm')[0].reset();
            }
        });
          }

          function checkPassword() {

var pass = $("#newp").val();
var cpass = $("#newc").val();

if (cpass != "") {
    if (pass != cpass) {
        $('#passwordAlert').html("Password Mismatching!");
        $('#passwordAlert').css("color", "red");
        $("#clickBtn").attr("disabled", true);
    } else {
        $('#passwordAlert').html("Password Matching!");
        $('#passwordAlert').css("color", "green");
        $("#clickBtn").attr("disabled", false);
    }
}
}
            
          </script>