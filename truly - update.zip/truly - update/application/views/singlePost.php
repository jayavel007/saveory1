      <!-- main content -->
      <div class="main-content right-chat-active bg-img">
        <div class="middle-sidebar-bottom">
          <div class="middle-sidebar-left pe-0">
            <div class="row">
              <div class="col-xl-12">
                <div
                  class="card w-100 shadow-xss rounded-xxl border-0 p-4 mb-3"
                >
                  <div class="card-body p-0 d-flex">
                    <figure class="avatar me-3">
                      <img
                        src="<?= $list['profile_picture'] ?>"
                        alt="image"
                        class="shadow-sm rounded-circle w45"
                      />
                    </figure>
                    <h4 class="fw-700 text-grey-900 font-xssss mt-1">
                    <?= $list['username'] ?> posted in <?= $list['group_name'] ?>.
                      <span
                        class="d-block font-xssss fw-500 mt-1 lh-3 text-grey-500"
                        ><?= $list['posted_date']." ".$list['posted_time'] ?> </span
                      >
                    </h4>
                    <a href="#" class="ms-auto"
                      ><i
                        class="ti-more-alt text-grey-900 btn-round-md bg-greylight font-xss"
                      ></i
                    ></a>
                  </div>
                  <div class="card-body p-0 mb-3 rounded-3 overflow-hidden">
                      <?php
                      
                      foreach($list['post_files']['images'] as $row){
                          ?>
                                        
                    <a href="#" class="video-btn">
                          <img
                            src="<?= base_url($row['img']) ?>"
                            alt=""
                            style="width: 100%"
                          />
                          </a>
                     
                          <?php
                             break;
                      }

                      ?>
                      
                      </div>
                  <div class="card-body p-0 me-lg-5">
                    <?php
                    
                    if(!empty($list['post_detail'])){
                      ?>
                      <p class="fw-500 text-grey-500 lh-26 font-xssss w-100 mb-2">
                      <?= $list['post_detail'] ?>
                      <a href="#" class="fw-600 text-primary ms-2">See more</a>
                    </p>
                      <?php
                    }
                    
                    ?>
                    
                  </div>
                  <div class="card-body d-flex p-0">
                  <a role="button" onclick="likePost(<?= $list['post_id'] ?>,'post')"  class="emoji-bttn d-flex align-items-center fw-600 text-grey-900 text-dark lh-26 font-xssss me-2">
                        <span class="likeBtn <?= $list['like_status'] == true?"text-success":"";?>"><i class="feather-thumbs-up text-white bg-primary-gradiant me-1 btn-round-xs font-xss"></i><?= $list['likes_count'] != 0?$list['likes_count']:"" ?> Like</span></a>
                    
                  
                    <a
                      href="#"
                      class="d-flex align-items-center fw-600 text-grey-900 text-dark lh-26 font-xssss"
                      ><i
                        class="feather-message-circle text-dark text-grey-900 btn-round-sm font-lg"
                      ></i
                      ><span class="d-none-xss"><?= $list['comments_count'] != 0?$list['comments_count']:"" ?> Comment</span></a
                    >
                    <a
                      href="#"
                      class="ms-auto d-flex align-items-center fw-600 text-grey-900 text-dark lh-26 font-xssss"
                      ><i
                        class="feather-share-2 text-grey-900 text-dark btn-round-sm font-lg"
                      ></i
                      ><span class="d-none-xs">Share</span></a
                    >
                  </div>
                  <div class="card w-100 border-0 shadow-none right-scroll-bar post-comment" >
                    
                  <?php
                  
                  if(!empty($list['comments']['owncmt'])){
                      foreach($list['comments']['owncmt'] as $row){

                      
                    ?>
                    
                    <div class="card-body pt-0 pb-3 pe-4 d-block ps-5">
                      <figure class="avatar position-absolute left-0 ms-2 mt-1">
                        <img
                          src="<?= $row['commented_profile']  ?>"
                          alt="image"
                          class="shadow-sm rounded-circle w35"
                        />
                      </figure>
                      <div
                        class="chat p-3 bg-greylight rounded-xxl d-block text-left theme-dark-bg"
                      >
                        <h4 class="fw-700 text-grey-900 font-xssss mt-0 mb-1">
                          <?= $row['commented_person'] ?>
                          <a href="#" class="ms-auto"
                            ><i
                              class="ti-more-alt float-right text-grey-800 font-xsss"
                            ></i
                          ></a>
                        </h4>
                        <p
                          class="fw-500 text-grey-500 lh-20 font-xssss w-100 mt-2 mb-0"
                        >
                        <?= $row['comment'] ?>
                        </p>
                      </div>
                    </div>

                    <?php
                     if(!empty($row['comment_replies'])){
                      foreach($row['comment_replies'] as $sRow){
                    ?>
 <div
                      class="card-body pt-0 pb-3 pe-4 d-block ps-5 ms-5 position-relative"
                    >
                      <figure class="avatar position-absolute left-0 ms-2 mt-1">
                        <img
                          src="<?= $sRow['reply_profile_picture'];  ?>"
                          alt="image"
                          class="shadow-sm rounded-circle w35"
                        />
                      </figure>
                      <div
                        class="chat p-3 bg-greylight rounded-xxl d-block text-left theme-dark-bg"
                      >
                        <h4 class="fw-700 text-grey-900 font-xssss mt-0 mb-1">
                        <?= $sRow['reply_commented_person'] ?>
                          <a href="#" class="ms-auto"
                            ><i
                              class="ti-more-alt float-right text-grey-800 font-xsss"
                            ></i
                          ></a>
                        </h4>
                        <p
                          class="fw-500 text-grey-500 lh-20 font-xssss w-100 mt-2 mb-0"
                        >
                         <?= $sRow['reply_comment'] ?>
                        </p>
                      </div>
                    </div>
                    <?php
                      }
                    }
                    ?>
                   

                    <?php
                  }
                }
                  ?>

<?php
                  
                  if(!empty($list['comments']['otherscmt'])){
                      foreach($list['comments']['otherscmt'] as $row){

                      
                    ?>
                    
                    <div class="card-body pt-0 pb-3 pe-4 d-block ps-5">
                      <figure class="avatar position-absolute left-0 ms-2 mt-1">
                        <img
                          src="<?= $row['commented_profile']  ?>"
                          alt="image"
                          class="shadow-sm rounded-circle w35"
                        />
                      </figure>
                      <div
                        class="chat p-3 bg-greylight rounded-xxl d-block text-left theme-dark-bg"
                      >
                        <h4 class="fw-700 text-grey-900 font-xssss mt-0 mb-1">
                          <?= $row['commented_person'] ?>
                          <a href="#" class="ms-auto"
                            ><i
                              class="ti-more-alt float-right text-grey-800 font-xsss"
                            ></i
                          ></a>
                        </h4>
                        <p
                          class="fw-500 text-grey-500 lh-20 font-xssss w-100 mt-2 mb-0"
                        >
                        <?= $row['comment'] ?>
                        </p>
                      </div>
                    </div>

                    <?php
                     if(!empty($row['comment_replies'])){
                      foreach($row['comment_replies'] as $sRow){
                    ?>
 <div
                      class="card-body pt-0 pb-3 pe-4 d-block ps-5 ms-5 position-relative"
                    >
                      <figure class="avatar position-absolute left-0 ms-2 mt-1">
                        <img
                          src="<?= $sRow['reply_profile_picture']  ?>"
                          alt="image"
                          class="shadow-sm rounded-circle w35"
                        />
                      </figure>
                      <div
                        class="chat p-3 bg-greylight rounded-xxl d-block text-left theme-dark-bg"
                      >
                        <h4 class="fw-700 text-grey-900 font-xssss mt-0 mb-1">
                        <?= $sRow['reply_commented_person'] ?>
                          <a href="#" class="ms-auto"
                            ><i
                              class="ti-more-alt float-right text-grey-800 font-xsss"
                            ></i
                          ></a>
                        </h4>
                        <p
                          class="fw-500 text-grey-500 lh-20 font-xssss w-100 mt-2 mb-0"
                        >
                         <?= $sRow['reply_comment'] ?>
                        </p>
                      </div>
                    </div>
                    <?php
                      }
                    }
                    ?>
                   

                    <?php
                  }
                }
                  ?>
                    
                   
                    <?php 
                      if($this->session->userdata('tex_profile_picture') == NULL){
                        $profile_picture = "https://ui-avatars.com/api/?background=0D8ABC&color=fff&name=".$this->session->userdata('tex_profile_name');
                      }else{
                        $profile_picture = base_url('admin/'.$this->session->userdata('tex_profile_picture'));
                      }
                    ?>
                    
                    <div class="card-body">
                      <div class="comment">
                        <figure class="avatar">
                          <img
                            src="<?=$profile_picture?>"
                            alt="image"
                            class="shadow-sm rounded-circle w35"
                          />
                        </figure>
                        <input type="text" class="text"  id="postAddComment"/>
                        <button class="btn" onclick="addComment(<?= $list['post_id'] ?>,'share')">Comment</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- main content -->