<?php

function pages($page,$data){

	$CI =& get_instance();
	$CI->load->model('Website_model');
	$bottom['online']=$CI->Website_model->onlineUsersList();
	// $cat['popularLocation']=$CI->Home_model->getPopLocations();
	// $cat['authURL'] =  $CI->facebook->login_url(); 
	// //print_r($CI);
	if(!empty($page)){
		

		$CI->load->view('include/head');
		$CI->load->view('scriptFunctions');
		$CI->load->view('include/navigationTop',$data);
		$CI->load->view('include/navigationLeft');
		
		$CI->load->view($page);
		$CI->load->view('include/bottom',$bottom);
		
		
	}
}
