<?php

class Currykrave_website_model extends CI_Model{
	function __construct(){
		parent::__construct();
		$this->load->library('session');
		$this->load->helper(array('form', 'url'));
	}

    function generate_otp(){
     	$mobile_no = $this->input->post('mobile_no');
		if($mobile_no==''){
			$msg = 'Mobile Number Must be filled';
			$status = false;
			$user_type="";
			$otp_num='';
		}else{
			//$otp_no = mt_rand(100000, 999999);
			$otp_no="123456";
			$data['otp_number'] = $otp_no;
	
		    $this->db->where('mobile_no',$mobile_no);
		    $count = $this->db->get('customer')->num_rows();
		    
		    if($count>0){
		    	$msg = 'Mobile Number Already exits';
			    $status = false;
			    $user_type="old";
			    $otp_num='';
		    }
		    else{
		    	$data['mobile_no'] = $mobile_no;
		    	    $this->db->where('mobile_no',$mobile_no);
		           $cont = $this->db->get('generate_otp')->num_rows();
		           if($cont>0){
		                $this->db->where('mobile_no',$mobile_no);
		               $qry = $this->db->update('generate_otp',$data);
		           }else{
		               $qry = $this->db->insert('generate_otp',$data);
		           }
		    	
				//echo "new mobile number";
				if($qry){
				    $msg = 'OTP has been sent form your mobile number';
			        $status = true;
			        $otp_num="$otp_no";
			         $user_type="new";
					
				}else{
					$msg = 'OTP Generation Failed';
			        $status = false;
			        $otp_num='';
			        $user_type='';
				}
		    }
			
		}
		$response[] = array("msg"=>$msg,'status'=>$status,'user_type'=>$user_type,'otp_no'=>$otp_num);
		echo json_encode($response);
    }
    // function register(){
    //     $firstname = $this->input->post('first_name');
    //     $lastname = $this->input->post('last_name');
    //     $email = $this->input->post('email');
    //     $mobile_no = $this->input->post('mobile_no');
    //     //$latitude=$this->input->post('latitude');
    //     //$longtitude=$this->input->post('longtitude');
    //     //$device_id=$this->input->post('device_id');
    //     $user_type = $this->input->post('user_type');
    //    //echo $mobile_no.' Work';
    //     $password = md5($this->input->post('password'));
    //     if($mobile_no==''){
    //         $msg = "Please Enter the Mobile Number";
    //         $error =true;
    //         echo json_encode(array('error'=>$error,'message'=>$msg));
    //     }
    //     else if($firstname==''){
    //         $msg = "Please Enter the Firstname";
    //         $error =true;
    //         echo json_encode(array('error'=>$error,'message'=>$msg));
    //     }
    //     else if($email==''){
    //         $msg = "Please Enter the Email";
    //         $error =true;
    //         echo json_encode(array('error'=>$error,'message'=>$msg));
    //     }
    //     else if($lastname==''){
    //         $msg = "Please Enter the lastname";
    //         $error =true;
    //         echo json_encode(array('error'=>$error,'message'=>$msg));
    //     }
        
    //     else if($password==''){
    //         $msg = "Please Enter the Password";
    //         $error =true;
    //         echo json_encode(array('error'=>$error,'message'=>$msg));
    //     }else if($user_type==''){
    //         $msg = "Please Enter the User type";
    //         $error =true;
    //         echo json_encode(array('error'=>$error,'message'=>$msg));
    //     }else{
    //     	$this->db->where('mobile_no',$mobile_no);
	// 		$num_count = $this->db->get('customer')->num_rows();
	
	// 		$this->db->where('email',$email);
	// 		$email_count = $this->db->get('customer')->num_rows();
	 
	// 		if($num_count>0){
	// 			$error = false;
	// 		    $msg = 'This Mobile Number Already exits';
	// 		    $datas = array();
	// 		}else if($email_count>0){
	// 			$error = false;
	// 		    $msg = 'This Email Already exits';
	// 		    $datas = array();
	// 		}else if($user_type == 'holesale'){
    //             $data['mobile_no'] = $mobile_no;
    //             $data['password'] =  $password;
    //             $data['firstname'] =  $firstname;
    //             $data['lastname'] =  $lastname;
    //             $data['email'] =  $email;
    //             $data['image'] = 'upload/dummy_image/dummy.png';
    //             // $data['latitude']=$latitude;
    //             // $data['longtitude']=$longtitude;
    //             // $data['device_id']=$device_id;
	// 			$data['user_type']=$user_type;
	// 			$data['approval_status']='0';

				
                

    //         $query = $this->db->insert('customer',$data);
		
	// 		}else{
				
	// 			$data['mobile_no'] = $mobile_no;
    //             $data['password'] =  $password;
    //             $data['firstname'] =  $firstname;
    //             $data['lastname'] =  $lastname;
    //             $data['email'] =  $email;
    //             $data['image'] = 'upload/dummy_image/dummy.png';
    //             // $data['latitude']=$latitude;
    //             // $data['longtitude']=$longtitude;
    //             // $data['device_id']=$device_id;
	// 			$data['user_type']=$user_type;

				
                

    //         $query = $this->db->insert('customer',$data);
	// 	}
	// 		//print_r($this->db->last_query());

    //         if($query){
    //            // $error =true;
    //             $msg = "Register Successfully";
    //             // $datas=array();    
    //                 $datas[]=array( 
    //               'customer_id' => $this->db->insert_id(),
    //               'name' => $firstname,
    //               //'lastname'=>$last_name,
    //               'mobile_no'=>$mobile_no,
    //               'email'=>$email,
    //               'image'=> $data['image'],
    //               );
    //         }else{
    //             $msg = "Register Failed";
    //            // $error =false;
    //             $datas=array();    
    //         }
		
            
         
    //         $response[] = array('msg'=>$msg,'status'=>$error,'customer'=>$datas);
    //      echo json_encode($response);
    //     }
		
    // }	
    function register(){
        $first_name = $this->input->post('first_name');
        $last_name = $this->input->post('last_name');
        $email = $this->input->post('email');
        $mobile_no = $this->input->post('mobile_no');
		$user_type = $this->input->post('user_type');
        // $latitude=$this->input->post('latitude');
        // $longtitude=$this->input->post('longtitude');
        // $device_id=$this->input->post('device_id');
       
        $password = md5($this->input->post('password'));
        if($mobile_no==''){
            $msg = "Please Enter the Mobile Number";
            $error =true;
             json_encode(array('message'=>$msg));
        }
        else if($first_name==''){
            $msg = "Please Enter the Firstname";
            $error =true;
            echo json_encode(array('message'=>$msg));
        }
        else if($email==''){
            $msg = "Please Enter the Email";
            $error =true;
            echo json_encode(array('message'=>$msg));
        }
        else if($last_name==''){
            $msg = "Please Enter the lastname";
            $error =true;
            echo json_encode(array('message'=>$msg));
        }
         else if($password==''){
            $msg = "Please Enter the Password";
            $error =true;
            echo json_encode(array('message'=>$msg));
        }
		else if($user_type==''){
            $msg = "Please select the user type";
            $error =true;
            echo json_encode(array('message'=>$msg));
        }else{
        	$this->db->where('mobile_no',$mobile_no);
			$num_count = $this->db->get('customer')->num_rows();
	
			$this->db->where('email',$email);
			$email_count = $this->db->get('customer')->num_rows();
	 
			if($num_count>0){
				$error = false;
			    $msg = 'This Mobile Number Already exits';
			    $datas = array();
			}else if($email_count>0){
				$error = false;
			    $msg = 'This Email Already exits';
			    $datas = array();
			}else if($user_type=='holesale'){
				$data['mobile_no'] = $mobile_no;
				$data['password'] =  $password;
				$data['firstname'] =  $first_name;
				$data['lastname'] =  $last_name;
				$data['email'] =  $email;	
				$data['approval_status'] =  '0';
				$data['user_type'] =  $user_type;
				   $data['image'] = 'upload/dummy_image/dummy.png';
				
				$query = $this->db->insert('customer',$data);
				if($query){
					// $error =true;
					$msg = "Register Successfully";
					// $datas=array();    
						$datas[]=array( 
					  'customer_id' => $this->db->insert_id(),
					  'name' => $first_name,
					  //'lastname'=>$last_name,
					  'mobile_no'=>$mobile_no,
					  'email'=>$email,
					  'user_type'=>$user_type,
					  'image'=> $data['image']
					  );
				
				}else{
					$msg = "Register Failed";
					// $error =false;
					$datas=array();    
				}
			}else{
				
            $data['mobile_no'] = $mobile_no;
            $data['password'] =  $password;
             $data['firstname'] =  $first_name;
              $data['lastname'] =  $last_name;
               $data['email'] =  $email;	
			   $data['user_type'] =  $user_type;
			   $data['approval_status'] =  '1';
               $data['image'] = 'upload/dummy_image/dummy.png';
            //    $data['latitude']=$latitude;
            //    $data['longtitude']=$longtitude;
            //    $data['device_id']=$device_id;
			   
            $query = $this->db->insert('customer',$data);
			// $this->db->last_query(); 
			// exit;
            if($query){
                // $error =true;
                $msg = "Register Successfully";
                // $datas=array();    
                    $datas[]=array( 
                  'customer_id' => $this->db->insert_id(),
                  'name' => $first_name,
                  //'lastname'=>$last_name,
                  'mobile_no'=>$mobile_no,
                  'email'=>$email,
				  'user_type'=>$user_type,
                  'image'=> $data['image']
                  );
			
            }else{
                $msg = "Register Failed";
                // $error =false;
                $datas=array();    
            }
        }
	}
         $response[] = array("msg"=>$msg);
		 return json_encode($response);
		
    }
 
   function check_login(){
        $mobile_no = $this->input->post('mobile_no');
        $password = md5($this->input->post('password'));
        if($mobile_no==''){
            $msg = "Please Enter the Mobile Number";
            $error =true;
             json_encode(array('error'=>$error,'message'=>$msg));

        }else if($password==''){
            $msg = "Please Enter the Password";
            $error =true;
             json_encode(array('error'=>$error,'message'=>$msg));
        }else{
            $data['mobile_no'] = $mobile_no;
            $data['password'] =  $password;
            $this->db->where('status',"1");
            $query = $this->db->get_where('customer',$data);
            if($query->num_rows()>0){
                $error =true;
                $msg = "Customer Login Successfully";
                  $datas=array();
                foreach ($query->result() as $key => $row) {
                    $customer_id=$row->customer_id;
                    $datas[]=array( 
                   'customer_id' => $row->customer_id,
                   'name' => $row->firstname,
                   'mobile_no'=> $row->mobile_no,
                   'image' => $row->image,
                   'cart_count'=>$this->get_cart_count($customer_id),
                   );	
                }
				$this->session->set_userdata(array('mobile_no'=>$mobile_no));
				$this->load->view('index');

			}
        else{
                // $msg = "Username and Password does not match";
                // $error =false;
                // $datas=array(); 
				$data['error'] ='Username and Password does not match';  
				$this->load->view('login', $data);     
            }
        } 
        //$response[] = array("msg"=>$msg,'status'=>$error,'customer'=>$datas);
		//echo json_encode($response);
		
		
 }
 
 function forgot_password(){
     	$mobile_no = $this->input->post('mobile_no');
		if($mobile_no==''){
			$msg = 'Mobile Number Must be filled';
			$status = false;
			$otp_num='';
		}else{
			//$otp_no = mt_rand(100000, 999999);
			$otp_no="123456";
			$data['otp_number'] = $otp_no;
	
		    $this->db->where('mobile_no',$mobile_no);
		    $count = $this->db->get('customer')->num_rows();
		    
		    if($count>0){
		    	$data['mobile_no'] = $mobile_no;
		    	    $this->db->where('mobile_no',$mobile_no);
		           $cont = $this->db->get('generate_otp')->num_rows();
		           if($cont>0){
		                $this->db->where('mobile_no',$mobile_no);
		               $qry = $this->db->update('generate_otp',$data);
		           }else{
		               $qry = $this->db->insert('generate_otp',$data);
		           }
		     	if($qry){
				    // $msg = 'OTP has been sent form your mobile number';
			        // $status = true;
			        // $otp_num="$otp_no";
					$this->session->set_userdata(array('mobile_no'=>$mobile_no));
					$this->load->view('otp_verification');
				 
			}else{
					// $msg = 'OTP Generation Failed';
			        // $status = false;
			        // $otp_num='';
					$data['error'] = 'OTP Generation Failed';  
				$this->load->view('login', $data); 
			       
				}
		    }
		    
		}
		// $response[] = array("msg"=>$msg,'status'=>$status,'otp_no'=>$otp_num);
		// echo json_encode($response);
 }
 
 function otp_verification(){
     	$mobile_no = $this->input->post('mobile_no');
     	$otp_number = $this->input->post('otp');
		if($mobile_no==''){
			// $msg = 'Mobile Number Must be filled';
			// $status = false;
			
		}else{
			
	        $this->db->where('otp_number',$otp_number);
		    $this->db->where('mobile_no',$mobile_no);
		    $count = $this->db->get('generate_otp')->num_rows();
		    
		    if($count>0){	
		            //  $msg = 'OTP verified';
			        //  $status = true;
				$this->session->set_userdata(array('mobile_no'=>$mobile_no));
				//$this->session->set_userdata(array('otp'=>$otp_number));
				$this->load->view('reset_password');
			         
			       }else{
		            //  $msg = 'OTP is wrong';
			        //  $status = false;
			    $data['error'] = 'OTP is wrong';  
				$this->load->view('login',$data); 
		           }
			
		}
		// $response[] = array("msg"=>$msg,'status'=>$status);
		// echo json_encode($response);
 }
 function change_forgot_password(){
        $mobile_no = $this->input->post('mobile_no');
       	$data['password'] = md5($this->input->post('password'));
      
		 	$this->db->where('mobile_no',$mobile_no);
	        $query = $this->db->update('customer',$data);
		    //print_r($this->db->last_query());
		    if($query){
		     	// $msg = 'Password Changed Successfully';
			    // $status = true;
				$this->session->set_userdata(array('mobile_no'=>$mobile_no));
				$this->load->view('index');
		    }else{
		    	
		    	// $msg = 'Password Changed Failed';
			    // $status = false;
				$data['error'] = 'Password Changed Failed';  
				$this->load->view('login', $data); 
		    }   
		
	
        
    // $response[] = array("msg"=>$msg,'status'=>$status);
    // echo json_encode($response);
 }
 function list_category(){
        $query = $this->db->get('category');
        if($query->num_rows()>0){
	    foreach($query->result() as $key=>$row){
	        $datas[]=array(
	            'category_id'=>$row->category_id,
	            'category_name'=>$row->category_name,
	            'category_image'=>$row->category_image,
	            );
	    }
	    }else{
	         $datas[]=array(
	            'category_id'=>"0",
	            'category_name'=>"No Catagory",
	            'category_image'=>"upload/category/dummy/noimage.jpg",
	            );
	    }
	    echo json_encode($datas);
 }
function list_product(){
     $customer_id = $this->input->post('customer_id');
      $query = $this->db->get('product');
	    foreach($query->result() as $key=>$row){
	        $product_id=$row->product_id;
	        $datas[]=array(
	           "product_id"=>$row->product_id,
               "product_name"=>$row->product_name,
               "image"=>$row->pro_image,
                //"price"=>$row->price,
                //"unit"=>$row->unit,
                "gross_weight"=>$row->gross_weight,
                "net_weight"=>$row->net_weight,
                "piece"=>$row->piece,
                "variant"=>$this->get_product_variant($product_id),
                "rating"=>$row->rating,
                "star_value"=>$row->star_value,
                "wishlist"=>$this->get_wish($customer_id,$product_id),
	            );
	    }
	    echo json_encode($datas);
}
function list_banner(){
    
      $query = $this->db->get('banner');
      if($query->num_rows()>0){
	    foreach($query->result() as $key=>$row){
	        $datas[]=array(
	           "banner_id"=>$row->banner_id,
               "banner_name"=>$row->banner_name,
               "banner_image"=>$row->banner_image,
	            );
	    }
      }else{
          $datas[]=array(
	           "banner_id"=>"1",
               "banner_name"=>"Dummy Banner",
               "banner_image"=>"upload/banner/dummy/nobanner.jpg",
	            );
      }
	    echo json_encode($datas);
}

function list_category_product(){
       $customer_id = $this->input->post('customer_id');
       $query = $this->db->get('product');
         $datas=array();
	    foreach($query->result() as $key=>$row){
	        $product_id=$row->product_id;
	       $datas[]=array(
	           "product_id"=>$row->product_id,
               "product_name"=>$row->product_name,
               "image"=>$row->pro_image,
                //"price"=>$row->price,
                //"unit"=>$row->unit,
                "gross_weight"=>$row->gross_weight,
                "net_weight"=>$row->net_weight,
                "piece"=>$row->piece,
                "variant"=>$this->get_product_variant($product_id),
                "rating"=>$row->rating,
                "star_value"=>$row->star_value,
                "wishlist"=>$this->get_wish($customer_id,$product_id),
	            );
	    }
	    echo json_encode($datas);
}
function search_product(){
    $product = $this->input->post('product');
    $this->db->select('*');
	$this->db->from('product');
	$this->db->where("product_name",$product);
	$query = $this->db->get();
	if($query->num_rows()>0){
	    $status="Product details";
	    $category_id="0";
	    foreach($query->result() as $key=>$row){
	        $product_id=$row->product_id;
	        }
	}else{
	   $this->db->select('*');
	   $this->db->from('product');
	   $this->db->where("product_name LIKE '%$product%'");
	   $qry = $this->db->get();
	    $datas=array();
	   if($qry->num_rows()>0){
	       foreach($qry->result() as $key=>$row){
	           $status="Product List";
	           $product_id[]=$row->product_id;
	       }
	       $category_id = implode(',',$product_id);
	       $product_id="0";
	   }else{
	       $category_id="0";
	       $status="Product List";
	   }
	}
	$response[] = array('status'=>$status,'category_id'=>$category_id,'product_id'=>$product_id);
	echo json_encode($response);
}
	
	function get_category(){
	           //  	$type = $this->input->post('type');
	    		    $this->db->select('*');
	                $this->db->from('category');
	                 $this->db->where('status',1);
	               
	                $query = $this->db->get();
	                //print_r($this->db->last_query());
	                  $datas = array();
	    if($query->num_rows()>0){
	        foreach($query->result() as $key=>$row){
	              $datas[] = array(
	                  "category_id"=>$row->category_id,
	                  "category_name"=>$row->category_name,  
	                  "category_image"=>$row->category_image,  
	                );
	        }
	    }
	   
        echo json_encode($datas);
	}
function get_sub_category(){
      	$category_id = $this->input->post('category_id');
	    		    $this->db->select('*');
	                $this->db->from('sub_category');
	                 $this->db->where('category_id',$category_id);
	               
	                $query = $this->db->get();
	                //print_r($this->db->last_query());
	                  $datas = array();
	    if($query->num_rows()>0){
	        foreach($query->result() as $key=>$row){
	              $datas[] = array(
	                "sub_cat_id"=>$row->sub_cat_id,
	                  "sub_cat_name"=>$row->sub_cat_name,  
	                  "sub_cat_image"=>$row->sub_cat_image,  
	                );
	        }
	    }
	   
        echo json_encode($datas);
}
    function get_product(){
        $customer_id = $this->input->post('customer_id');
        $category_id = $this->input->post('category_id');
	    $this->db->select('*');
	    $this->db->from('product');
	    $find = ",";
        $mystring = $category_id;
        if(strpos($mystring, $find) !== false){
            $cat_id=explode(',',$category_id);
            $this->db->where_in('category_id',$cat_id);
        } else{
            $this->db->where('category_id',$category_id);
        }
	    $query = $this->db->get();
	    //print_r($this->db->last_query());
	    $datas = array();
	    if($query->num_rows()>0){
	        foreach($query->result() as $key=>$row){
	            $product_id=$row->product_id;

	              $datas[] = array(
	                "product_id"=>$row->product_id,
                    "product_name"=>$row->product_name,
                    "image"=>$row->pro_image,
                    //"price"=>$row->price,
                    //"unit"=>$row->unit,
                    "variant"=>$this->get_product_variant($product_id),
                    "price_type"=>"kg",
                    // "gross_weight"=>$row->gross_weight,
                    // "net_weitht"=>$row->net_weight,
                    // "piece"=>$row->piece,
                    "rating"=>$row->rating,
                    "star_value"=>$row->star_value, 
                    "wishlist"=>$this->get_wish($customer_id,$product_id),
	                );
	        }
	    }
	   
        echo json_encode($datas); 
    }

	function get_product_details($id){
		$this->db->select('*');
		$this->db->from('product');
		 $this->db->join('products_variant','products_variant.product_id=product.product_id');
		 //$this->db->join('add_to_cart','products_variant.product_id=product.product_id');
		 $this->db->join('category','category.category_id=product.category_id');
		$this->db->where('product.product_id',$id);
		$this->db->where('product.status',1);
		$query = $this->db->get();
		//print_r($this->db->last_query());
		return $query->result_array(); 
	}
	
function get_related_product($cat){
	$this->db->select('*');
	$this->db->from('product');
	$this->db->limit(4);
	$this->db->join('products_variant','products_variant.product_id=product.product_id');
	$this->db->where('product.category_id',$cat);
	$this->db->where('product.status',1);
	$query = $this->db->get();
	//print_r($this->db->last_query());
	return $query->result(); 
}
function get_reviews($product_id){
    	    $this->db->select('*');
	    $this->db->from('product_reviews');
	    $this->db->join('customer','customer.customer_id=product_reviews.customer_id');
	    $this->db->where('product_reviews.product_id',$product_id);
	    $this->db->where('product_reviews.status',1);
	    $que = $this->db->get();
	    if($que->num_rows()>0){
	       foreach($que->result() as $key=>$row){
	           $dates = $row->date;
	           $dateses = date('d-m-Y', strtotime($dates));
	           $review[] = array(
	               'image'=>$row->image,
	               	'name'=>$row->firstname,
	               	'rate'=>$row->rate,
	               	'message'=>$row->reviews,
	               	'date'=>$dateses,
	              
	               );
	       }
	   }else{
	       $review = array();
	   }
	   return $review;
}
function get_wish($customer_id,$product_id){
    	$this->db->select('*');
	    $this->db->from('wishlist');
	    $this->db->where('customer_id',$customer_id);
	     $this->db->where('product_id',$product_id);
	    $que = $this->db->get();
	  //  print_r($this->db->last_query());
	    if($que->num_rows()>0){
	       $status="true";
	   }else{
	       $status ="false";
	   }
	   return $status;
}
function get_slider_images($product_id){
    $data['product_id'] = $product_id;
    $data['status']=1;
    $query = $this->db->get_where('additional_image',$data);
    if($query->num_rows()>0){
        foreach($query->result() as $key=>$row){
            $datas[] = array(
            "image"=>$row->add_image
            );
        }
    }else{
        $datas = "NOK";
    }
    return $datas;
}
function add_basket(){
    	$data['customer_id'] = $customer_id= $this->input->post('customer_id');
		$data['basket_id'] =$basket_id= $this->input->post('basket_id');
		
			 $this->db->select('*');
		     $this->db->from('cart_basket');
		     $this->db->where('customer_id',$data['customer_id'] );
			 $this->db->where('basket_id',$data['basket_id'] );
			 $sql = $this->db->get();
			 if($sql->num_rows() > 0){
			     	$datas['basket_id'] =$basket_id= $this->input->post('basket_id');
			        $this->db->where('customer_id',$customer_id );
			        //$this->db->where('basket_id',$basket_id);
			     	$query = $this->db->update('cart_basket',$datas);
			 }else{
			    	$query = $this->db->insert('cart_basket',$data);
			 }
	       
	
	    if($query){
		  $status = "true";
	      $msg = "Basket Added Successfully";
		}else{
		  $status = "false";
	      $msg = "Basket Added Failed";
		}
			     
		$response[] = array("msg"=>$msg,'status'=>$status);
        //echo json_encode($datas);
        	echo json_encode($response); 
}
  function add_to_cart(){

    $customer_id= $this->input->post('customer_id');
	$product_id = $this->input->post('product_id');
	$qty = $this->input->post('qty');
    $type = $this->input->post('type');
    $variant_id = $this->input->post('variant_id');
	$price = $this->input->post('price');
	 if($qty==0){
	   $qty=1;
	 }
    $data['customer_id']=$customer_id;
	$data['product_id']=$product_id;
	$data['qty']=$qty;
	$data['type']=$type;
	$data['price']=$price;
	$data['varient_id']=$variant_id;
  
    $this->db->select('*');
	$this->db->from('add_to_cart');
    $this->db->where('product_id', $product_id);
	$this->db->where('customer_id', $customer_id);
	$this->db->where('order_status', 1);
	$this->db->where('type',$type);
	$query = $this->db->get();
	if($query->num_rows() > 0 ){
        $msg = "This product already added cart";
        $status = "false";
        $cart_count = $this->get_cart_count($customer_id);
    }else{
      if($type=='checkout'){
		$this->db->where('customer_id', $customer_id);
		$this->db->where('type','checkout');
		$this->db->delete('add_to_cart');
	 }  
	$query = $this->db->insert('add_to_cart',$data);

    if($query){
	   $status = true;
	   $msg = "Cart Added Successfully";
	   $cart_count = $this->get_cart_count($customer_id);
	}else{
	   $status = false;
	   $msg = "Cart Added Failed";
	   $cart_count = $this->get_cart_count($customer_id);
	}
    }  
	$response[] = array("msg"=>$msg,'status'=>$status, 'cart_count'=>$cart_count);
    echo json_encode($response);
	        
	        
	}
// 	function get_cart(){
//       	$customer_id = $this->input->post('customer_id');
// 	    $this->db->select('*');
// 	    $this->db->from('add_to_cart');
// 	    $this->db->join('products_variant','products_variant.variant_id=add_to_cart.product_id');
// 	    $this->db->join('product','product.product_id=add_to_cart.product_id');
// 	    $this->db->where('add_to_cart.customer_id',$customer_id);
// 	    $this->db->where('add_to_cart.type','cart');
// 	   $this->db->where('add_to_cart.order_status',1);
	               
// 	                 $query = $this->db->get();
// 	                //print_r($this->db->last_query());
// 	                  $datas = array();
// 	    if($query->num_rows()>0){
// 	        foreach($query->result() as $key=>$row){
// 	            $product_id=$row->product_id; 
	          
// 	            $amount[]=$this->get_price($product_id,$customer_id)*$row->qty;
// 	             	 $totals = array_sum($amount);
// 	              $items[] = array(
// 	                "cart_id"=>$row->cart_id,
// 	                  "product_id"=>$row->product_id,  
// 	                  "product_name"=>$row->product_name, 
// 	                  "product_image"=>$row->pro_image, 
// 	                  "unit_name"=>$row->unit_name, 
// 	                  "price"=>$this->get_price($product_id,$customer_id),  
// 	                  "qty"=>$row->qty,  
// 	                  "unit"=>$row->unit, 
	                  
// 	                );
// 	        }
// 	        $datas[]=array(
// 	            "items"=>$items,
// 	            "total"=>"$totals",
// 	            );
// 	    }else{
// 	        $datas[]=array(
// 	            "items"=>array(),
// 	            "total"=>"0",
// 	            ); 
// 	    }
	   
//         echo json_encode($datas);
// }
function get_wishlist_price($varient_id){

	    		    $this->db->select('*');
	                $this->db->from('products_variant');
	                //$this->db->where('customer_id',$customer_id);
	                $this->db->where('variant_id',$varient_id);
	                $query = $this->db->get();
	                 //print_r($this->db->last_query());
	                  $datas = array();
	    if($query->num_rows()>0){
	        foreach($query->result() as $key=>$row){
	             $price=$row->price;
	            
	        }
	        return $price;
	    }
	   
	     
}

function get_price($product_id,$customer_id){

	    		    $this->db->select('*');
	                $this->db->from('add_to_cart');
	                $this->db->where('product_id',$product_id);
	                $this->db->where('customer_id',$customer_id);
	                $query = $this->db->get();
	                 //print_r($this->db->last_query());
	                 //exit;
	                  $datas = array();
	    if($query->num_rows()>0){
	        foreach($query->result() as $key=>$row){
	            $price=$row->price;
	        }
	        return $price;
	    }
	   
	     
}
function checkout(){
    $customer_id = $this->input->post('customer_id');
    $address_id = $this->input->post('address_id');
    $type = $this->input->post('type');
   // $price = $this->input->post('price');
    $addresss = $this->check_address($address_id,$customer_id);
    $this->db->select('*');
	$this->db->from('add_to_cart');
	$this->db->join('product','product.product_id=add_to_cart.product_id');
	$this->db->where('customer_id',$customer_id);
	$this->db->where('add_to_cart.type',$this->input->post('type'));
	$this->db->where('add_to_cart.order_status',1);
	$query = $this->db->get();   
	
	
	
    if($query->num_rows()>0){
        foreach($query->result() as $key=>$row){
             $product_id=$row->product_id; 
             $var['variant_id']=$row->varient_id; 
             $querys = $this->db->get_where('products_variant',$var);
             if($querys->num_rows()>0){
                 foreach($querys->result() as $key=>$rows){
                     $unit = $rows->unit;
                     $unit_name = $rows->unit_name;
                 }
             }
            $amount[]=$row->price*$row->qty;
            $items[] = array(
	                  "cart_id"=>$row->cart_id,
	                  "product_id"=>$row->product_id,  
	                  "product_name"=>$row->product_name, 
	                  "product_image"=>$row->pro_image, 
	                  "unit_name"=>$unit_name,
	                  "price"=>$this->get_price($product_id,$customer_id),  
	                  "qty"=>$row->qty,  
	                  "unit"=>$unit, 
	                  
	                );
        }
        //print_r($amount);
        $totals = array_sum($amount);
 
	   //print_r($items);
        $datas[]=array(
			"address"=>$addresss,
			"items"=>$items,
			"cart_value"=>$totals,
			"discount"=>"00.00",
			"taxes"=>"00.00",
			"delivery_charges"=>"00.00",
			"total_pay"=>$totals,
		);

    }else{
	    $datas[]=array(
	            "address"=>array(),
	            "items"=>array(),
	            "subscribtion"=>array(),
	            "cart_value"=>"",
	            "discount"=>"",
	            "taxes"=>"",
	            "delivery_charges"=>"",
	            "total_pay"=>"",
	        );
	        
	}
	
		

    echo json_encode($datas);
    //print_r($address);
    
}
function check_address($address_id,$customer_id){
    $data['customer_id']    = $customer_id;
    if($address_id!='0'){
	  $data['address_id']     = $address_id;
	}else{
	    $this->db->limit(1, 0);
	}
    $data['status']=1;
    $query = $this->db->get_where('address',$data);
    //print_r($this->db->last_query());
    if($query->num_rows()>0){
        foreach($query->result() as $key=>$row){
            $address[] = array(
	               'customer_id'=>$row->customer_id,
	               'address_id'=>$row->address_id,
	               'name'=>$row->name,
	               'door_no'=>$row->door_no,
	               'street'=>$row->street,
	               'landmark'=>$row->landmark,
	               'city'=>$row->city,
	               'state'=>$row->state,
	               'pincode'=>$row->pincode,
	               "district"=>$row->district,
	               'country'=>$row->country,
	               'mobile'=>$row->mobile,
	               'address_type'=>$row->address_type,
	                  
	               );
        }
    }else{
        $address = array();
    }
    return $address;
}
    function delete_cart(){
        $customer_id = $this->input->post('customer_id');
		$cart_id = $this->input->post('cart_id');
		$this->db->where('cart_id',$cart_id);
		$query= $this->db->delete('add_to_cart');
	   // print_r($this->db->last_query());
			if($query){
		  $status = "false";
	      $msg = "Cart Deleted Successfully";
	      $cart_count = $this->get_cart_count($customer_id);
		}else{
		  $status = "false";
	      $msg = "Cart Deleted Failed";
	      $cart_count = $this->get_cart_count($customer_id);
		}
           $response[] = array("msg"=>$msg,'status'=>$status,'cart_count'=>$cart_count);
        //echo json_encode($datas);
        	echo json_encode($response);
	} 
	   function delete_subscribtion(){
        $subscribtion_id = $this->input->post('subscribtion_id');
	     $customer_id = $this->input->post('customer_id');
		$this->db->where('subscribers_id',$subscribtion_id);
		$this->db->where('customer_id',$customer_id);
		$query= $this->db->delete('subscribers_list');
	   // print_r($this->db->last_query());
			if($query){
		  $status = "true";
	      $msg = "subscribtion Deleted Successfully";
	      
	      $cart_count = $this->get_cart_count($customer_id);
		}else{
		  $status = "false";
	      $msg = "subscribtion Deleted Failed";
	      $cart_count = $this->get_cart_count($customer_id);
		}
           $response[] = array("msg"=>$msg,'status'=>$status,'cart_count'=>$cart_count);
        //echo json_encode($datas);
        	echo json_encode($response);
	} 
	public function update_qtys(){
		$cart_id = $this->input->post('cart_id');
		$customer_id = $this->input->post('customer_id');
	    $qty= $this->input->post('qty');
	    $data['qty'] = $qty;
    	$this->db->where('cart_id',$cart_id);
		$query = $this->db->update('add_to_cart',$data);
		if($query){
		  $status = "true";
	      $msg = "Quantity Updated";
	      $cart_count = $this->get_cart_count($customer_id);
		}else{
		  $status = "false";
	      $msg = "Quantity Updated Failed";
	       $cart_count = $this->get_cart_count($customer_id);
		}
    	    $response[] = array("msg"=>$msg,'status'=>$status,'cart_count'=>$cart_count);
        //echo json_encode($datas);
        	echo json_encode($response);
	}
	function add_address(){
	   	$data['customer_id'] = $this->input->post('customer_id');
		$data['name'] = $this->input->post('name');
		$data['mobile'] = $this->input->post('mobile');
		$data['door_no'] = $this->input->post('door_no');	
		$data['street'] = $this->input->post('street');	
		$data['landmark'] = $this->input->post('landmark');
		$data['address_type'] = $this->input->post('address_type');
		$data['pincode'] = $this->input->post('pincode');
		$data['city'] = $this->input->post('city');
		$data['district'] = $this->input->post('district');
		$data['state'] = $this->input->post('state');
		$data['country'] = $this->input->post('country');
		$pincode = $this->input->post('pincode');
		
		  $this->db->select('*');
	$this->db->from('pincode_map');
	$this->db->where("pincode",$pincode);
	$this->db->where("status",'1');
	$query = $this->db->get();
	if($query->num_rows()>0){
	  foreach($query->result() as $key=>$row){
	        $shop_id=$row->shop_id;
	        }
	}
	$data['shop_id'] = $shop_id;
	
		$query = $this->db->insert('address',$data);
		
		if($query){
		  $status = "true";
	      $msg = "Address Added Successfully";
		}else{
		  $status = "false";
	      $msg = "Address Added Failed";
		}
           $response[] = array("msg"=>$msg,'status'=>$status);
        //echo json_encode($datas);
        	echo json_encode($response); 
	}
	function get_address(){
	     	        $customer_id = $this->input->post('customer_id');
      	   
	    		    $this->db->select('*');
	                $this->db->from('address');
	                $this->db->limit(1);
	                $this->db->where('customer_id',$customer_id);
	                $this->db->where('status',1);
	                $query = $this->db->get();
	                //print_r($this->db->last_query());
	                  $datas = array();
	    if($query->num_rows()>0){
	        foreach($query->result() as $key=>$row){
	              $datas[] = array(
	                "customer_id"=>$row->customer_id,
	                "address_id"=>$row->address_id,
	                "door_no"=>$row->door_no,
                    "street"=>$row->street,
                    "country"=>$row->country,
                    "state"=>$row->state,
                    "district"=>$row->district,
                    "city"=>$row->city,
                    "pincode"=>$row->pincode,
                    "status"=>true,
                    "message"=>""
	                );
	        }
	    }else{
	        $datas[] = array(
	                "customer_id"=>"",
	                "address_id"=>"",
	                "door_no"=>"",
                    "street"=>"",
                    "country"=>"",
                    "state"=>"",
                    "district"=>"",
                    "city"=>"",
                    "pincode"=>"",
                    "status"=>true,
                    "message"=>"Please add address"
	                );
	    }
	   
        echo json_encode($datas); 
	}
	
	function my_address(){
	     	        $customer_id = $this->input->post('customer_id');
      	   
	    		    $this->db->select('*');
	                $this->db->from('address');
	                $this->db->where('customer_id',$customer_id);
	                 $this->db->where('status',1);
	                $query = $this->db->get();
	                //print_r($this->db->last_query());
	                  $datas = array();
	    if($query->num_rows()>0){
	        foreach($query->result() as $key=>$row){
	              $datas[] = array(
	                "customer_id"=>$row->customer_id,
	                "address_id"=>$row->address_id,
	                "name"=>$row->name,
	                "mobile"=>$row->mobile,
	                "door_no"=>$row->door_no,
                    "street"=>$row->street,
                    "country"=>$row->country,
                    "state"=>$row->state,
                    "district"=>$row->district,
                    "landmark"=>$row->landmark,
                    "city"=>$row->city,
                    "pincode"=>$row->pincode,
                     "address_type"=>$row->address_type,
	                );
	        }
	    }
	   
        echo json_encode($datas); 
	}
	function add_wishlist(){
	         $data['customer_id'] = $this->input->post('customer_id');
		     $data['product_id'] = $this->input->post('product_id');
		     $data['varient_id'] = $this->input->post('varient_id');
	       	 $this->db->select('*');
		     $this->db->from('wishlist');
		     $this->db->where('customer_id',$data['customer_id'] );
			 $this->db->where('product_id',$data['product_id'] );
			 $sql = $this->db->get();
			 if($sql->num_rows() > 0){
			   $this->db->where('customer_id',$data['customer_id'] );
		       $this->db->where('product_id',$data['product_id']);
			   $qry = $this->db->delete('wishlist',$data);
			   $status = "false";
	           $msg = "Wishlist Removed Successfully";
			  }else{
			 	$query = $this->db->insert('wishlist',$data);
	    if($query){
		  $status = "true";
	      $msg = "Wishlist Added Successfully";
		}else{
		  $status = "false";
	      $msg = "Wishlist Added Failed";
		}
			  
			  }
	
	
           $response[] = array("msg"=>$msg,'status'=>$status);
        //echo json_encode($datas);
        	echo json_encode($response); 
	}
	function get_wishlist(){
	    $customer_id = $this->input->post('customer_id');
      	   
	    $this->db->select('*');
		$this->db->from('wishlist');
		$this->db->where('wishlist.customer_id',$customer_id);
		$this->db->join('product','wishlist.product_id=product.product_id');
		$query = $this->db->get();
	   //print_r($this->db->last_query());
	     $datas = array();
	    if($query->num_rows()>0){
	        foreach($query->result() as $key=>$row){
	            $product_id=$row->product_id;
	           $datas[]=array(
	           "product_id"=>$row->product_id,
               "product_name"=>$row->product_name,
               "image"=>$row->pro_image,
                //"price"=>$row->price,
                //"unit"=>$row->unit,
                "gross_weight"=>$row->gross_weight,
                "net_weight"=>$row->net_weight,
                "piece"=>$row->piece,
                "variant"=>$this->get_product_variant($product_id),
                "rating"=>$row->rating,
                "star_value"=>$row->star_value,
                "wishlist"=>$this->get_wish($customer_id,$product_id),
	            );
	        }
	    }
	   
        echo json_encode($datas);
	}
	function get_baskets(){
	    	   
	    $this->db->select('*');
		$this->db->from('baskets');
		$this->db->where('status',1);
		$query = $this->db->get();
	                //print_r($this->db->last_query());
	                  $datas = array();
	    if($query->num_rows()>0){
	        foreach($query->result() as $key=>$row){
	              $datas[] = array(
	                "basket_id"=>$row->basket_id,
	                "basket_weight"=>$row->basket_weight,
	                "basket_image"=>$row->basket_image,
                   
	                );
	        }
	    }
	   
        echo json_encode($datas);
	}
	function get_all_products(){
	    $customer_id = $this->input->post('customer_id');
	    	   
	    $this->db->select('*');
		$this->db->from('product');
		$this->db->where('status',1);
		$query = $this->db->get();
	                //print_r($this->db->last_query());
	                  $datas = array();
	    if($query->num_rows()>0){
	        foreach($query->result() as $key=>$row){
	            $product_id=$row->product_id;
	              $datas[] = array(
	          "product_id"=>$row->product_id,
               "product_name"=>$row->product_name,
               "image"=>$row->pro_image,
                //"price"=>$row->price,
                //"unit"=>$row->unit,
                "gross_weight"=>$row->gross_weight,
                "net_weight"=>$row->net_weight,
                "piece"=>$row->piece,
                "variant"=>$this->get_product_variant($product_id),
                "rating"=>$row->rating,
                "star_value"=>$row->star_value,
                "wishlist"=>$this->get_wish($customer_id,$product_id),
	           
	                );
	        }
	    }
	   
        echo json_encode($datas);
	}
function edit_address(){
        $address_id = $this->input->post('address_id');
       	$data['name'] = $this->input->post('name');
		$data['mobile'] = $this->input->post('mobile');
		$data['door_no'] = $this->input->post('door_no');	
		$data['street'] = $this->input->post('street');	
		$data['landmark'] = $this->input->post('landmark');
		$data['address_type'] = $this->input->post('address_type');
		$data['pincode'] = $this->input->post('pincode');
		$data['city'] = $this->input->post('city');
		$data['district'] = $this->input->post('district');
		$data['state'] = $this->input->post('state');
		$data['country'] = $this->input->post('country');
        	$this->db->where('address_id',$address_id);
		    $qry = $this->db->update('address',$data);
		    //print_r($this->db->last_query());
		    if($qry){
		     	$msg = 'Address updated Successfully';
			    $status = true;
		    }else{
		    	
		    	$msg = 'Address updated Failed';
			    $status = false;
		    }
    $response[] = array("msg"=>$msg,'status'=>$status);
    echo json_encode($response);
}

function change_password(){
      $customer_id = $this->input->post('customer_id');
       	$datas['password'] = md5($this->input->post('old_password'));
       	$pass=$datas['password']; 
       	
       	    $this->db->where('password',$pass);
		    $count = $this->db->get('customer')->num_rows();
       	
       	$data['password'] = md5($this->input->post('new_password'));
		$datas['confirm_password'] = $this->input->post('confirm_password');	
	
		
		if($count>0){
		 	$this->db->where('customer_id',$customer_id);
	        $query = $this->db->update('customer',$data);
		    //print_r($this->db->last_query());
		    if($query){
		     	$msg = 'Password Changed Successfully';
			    $status = true;
		    }else{
		    	
		    	$msg = 'Password Changed Failed';
			    $status = false;
		    }   
		}else{
		   $msg = 'Old Password Wrong';
		   $status = false; 
		}
	
        
    $response[] = array("msg"=>$msg,'status'=>$status);
    echo json_encode($response);
}
function get_orders(){
                	$customer_id = $this->input->post('customer_id');
	    		      $this->db->select('*');
	                  $this->db->from('add_to_cart');
	                  $this->db->join('orders','add_to_cart.order_id=orders.order_id');
	                  $this->db->group_by('add_to_cart.order_id');
	                  $this->db->where('add_to_cart.customer_id',$customer_id);
	                  $this->db->where('add_to_cart.status','1');
	                  $query = $this->db->get();
	             //  print_r($this->db->last_query());
	               
	               	  
	    if($query->num_rows()>0){
	        foreach($query->result() as $key=>$row){
	            $product_id=$row->product_id;
	            $order_id=$row->order_id;
	          //  $amount=$row->price*$row->quantity;
	                 $dates = $row->order_date;
	               $dateses = date('d-m-Y', strtotime($dates));
	                $dat = $row->estimate_del;
	               $da = date('d-m-Y', strtotime($dat));
	               $datas[] = array(
	                  "customer_id"=>$row->customer_id,
	                  "order_id"=>$row->order_id,
	                  "order_unique_id"=>$row->unique_id,
	                  "order_date"=>$dateses.' | '.$row->order_time,
	                  "estimation_delivery"=>$da,
	                  "products"=>$this->get_products($order_id,$row->del_status),
	                  
	                  
	                );
	        }
	  
	    }else{
	          $datas[] = array(
	               "customer_id"=>$customer_id,
	                  "order_id"=>"",
	                  "order_unique_id"=>"",
	                  "order_date"=>"",
	                  "estimation_delivery"=>"",
	                  "products"=>array(),          
	                  );
	    }
	   
        echo json_encode($datas);
}
function get_products($order_id,$order_status){
   
	                  $this->db->select('*');
	                  $this->db->from('add_to_cart');
	                  $this->db->join('product','product.product_id=add_to_cart.product_id');
	                  $this->db->where('add_to_cart.order_id',$order_id);
	                  $this->db->where('add_to_cart.status','1');
	                  $qry = $this->db->get();
	                  
	                  $datas = array();
	    if($qry->num_rows()>0){
	        foreach($qry->result() as $key=>$row){
	               if($row->cancel_status=="Ordered"){
	               	        $ord_status="";
	               	    }else{
	               	        $ord_status=$row->cancel_status;
	               	    }
	              $amount=$row->price*$row->qty;
	              $product_id=$row->product_id;
	              $customer_id=$row->customer_id;
	              $review = $this->get_product_review($product_id,$customer_id);
	              $product[] = array(
	                  "cart_id"=>$row->cart_id,
	                   "product_id"=>$row->product_id,
	                  "product_name"=>$row->product_name, 
	                  "image"=>$row->pro_image,
	                  "price"=>$row->price,  
	                   "price_type"=>"kg",
	                  "qty"=>$row->qty, 
	                  "status"=>$ord_status,
	                    "rating"=>$review['rating'],
		     	        "review"=>$review['reviews'],
		     	        "order_status"=>$order_status
	                  
	                  
	                );
	        }
	   
	    }
	    return $product;
}
function my_order_details(){
     $order_id= $this->input->post('order_id');
        	$this->db->where('order_id',$order_id);
	     	$count = $this->db->get('orders')->num_rows();
		     if($count>0){
                    $this->db->select('*');
	                $this->db->from('orders');
	                $this->db->join('address','address.address_id=orders.address_id');
	                $this->db->where('orders.order_id',$order_id);
	                $query = $this->db->get();
	              // print_r($this->db->last_query());
	                  $datas = array();
	                  
	            
	                
	 
	    if($query->num_rows()>0){
	        foreach($query->result() as $key=>$row){
	           
	            $dates = $row->order_date;
	            $date = date('j F Y', strtotime($dates));
	            $datas[] = array(
	                     "order_id"=>$row->order_id,
	                     "unique_id"=>$row->unique_id,
	                     "date_time"=>$date.",".$row->order_time,
	                     "products"=>$this->orders_info($row->order_id,$row->del_status),
	                     "total_payable"=>$row->order_value,
	                     "estimated_delivery"=>$row->estimate_del,
	                     "order_status"=>$row->del_status,
	               "name"=>$row->name,
	               "door_no"=>$row->door_no,
	               "street"=>$row->street,
	               "landmark"=>$row->landmark,
	               "city"=>$row->city,
	               "state"=>$row->state,
	               "pincode"=>$row->pincode,
	               "district"=>$row->district,
	               "country"=>$row->country,
	               "mobile"=>$row->mobile,
	                         
	                    );
	                }
	              }
		     }else{
		         $datas[] = array(  
	                     
	                     "order_id"=>$order_id,
	                     "unique_id"=>'',
	                     "date_time"=>'', 
	                     "products"=>'',
	                     "order_status"=>'',
	                     "total_payable"=>'',
	                     "order_status"=>'',
	                     "estimated_delivery"=>'',
	                     "name"=>'',
	                     "door_no"=>'',
	                     "street"=>'',
	                     "landmark"=>'',
	                     "city"=>'',
	                     "state"=>'',
	                     "pincode"=>'',
	                     "district"=>'',
	                     "country"=>'',
	                     "mobile"=>'',
	                       );
	                   
		     }
	    //$response[] = array("msg"=>$msg,'status'=>$status);
        echo json_encode($datas);
}
function orders_info($order_id,$order_status){
          
	                $this->db->select('*');
	                $this->db->from('add_to_cart');
	                $this->db->join('product','product.product_id=add_to_cart.product_id');
	                $this->db->where('add_to_cart.order_id',$order_id);
	                $qry = $this->db->get();
	               	foreach ($qry->result() as $key => $row) {
	               	    if($row->cancel_status=="Ordered"){
	               	        $ord_status="";
	               	    }else{
	               	        $ord_status=$row->cancel_status;
	               	    }
	               	    $product_id=$row->product_id;
	               	    $customer_id=$row->customer_id;
	               	    $price=$row->qty*$row->price;
	               	    $review = $this->get_product_review($product_id,$customer_id);
		              	$product[]=array(
		              	  "cart_id"=>$row->cart_id,
		              	  "product_id"=>$row->product_id,
		     	          "product_name"=>$row->product_name,
		     	          "image"=>$row->pro_image,
		     	          "qty"=>$row->qty,
		     	          "price"=>$price,
		     	          "rating"=>$review['rating'],
		     	          "review"=>$review['reviews'],
		     	          "status"=>$ord_status,
		     	          "order_status"=>$order_status
		     	          );
		              
			         }
			         return $product;
}

function get_product_review($product_id,$customer_id){
    	$this->db->select('*');
	    $this->db->from('product_reviews');
	   // $this->db->join('customer','customer.customer_id=product_reviews.customer_id');
	    $this->db->where('product_reviews.customer_id',$customer_id);
	    $this->db->where('product_reviews.product_id',$product_id);
	    $this->db->where('product_reviews.status',1);
	    $que = $this->db->get();
	    if($que->num_rows()>0){
	       foreach($que->result() as $key=>$row){
	            $review['rating']= $row->rate;
	            $review['reviews']= $row->reviews;       
	       }
	   }else{
	      $review['rating']= '0';
	      $review['reviews']= ''; 
	   }
	  return $review; 
}
function get_subscribtion(){
       $this->db->select('*');
		$this->db->from('subscribtion');
		$this->db->where('status',1);
		$query = $this->db->get();
	                //print_r($this->db->last_query());
	                  $datas = array();
	    if($query->num_rows()>0){
	        foreach($query->result() as $key=>$row){
	              $datas[] = array(
	           "subscribtion_id"=>$row->sub_id,
               "subscribtion_name"=>$row->sub_name,
               "image"=>$row->sub_image,
               "validity"=>$row->validity,
                
	           
	                );
	        }
	    }
	   
        echo json_encode($datas);
}
function get_subscribtion_details(){
     $sub_id= $this->input->post('subscribtion_id');
                      $this->db->select('*');
	                  $this->db->from('subscribtion');
	                  $this->db->where('sub_id',$sub_id);
	                  $this->db->where('status','1');
	                  $qry = $this->db->get();
	                  $datas = array();
	    if($qry->num_rows()>0){
	        foreach($qry->result() as $key=>$row){
	       
	              $datas[]= array(
	                  "subscribtion_id"=>$row->sub_id,
	                  "subscribtion_name"=>$row->sub_name,
	                  "products"=>$row->products,
	                  "weight_amount"=>$this->get_weights($sub_id)
	                 
	                  
	                );
	        }
	   
	    }else{
	          $datas[]= array(
	                  "subscribtion_id"=>"",
	                  "products"=>"",
	                  "weight_amount"=>"",
	                  
	                );
	    }
	     echo json_encode($datas);
}
function get_weights($sub_id){
                      $this->db->select('*');
	                  $this->db->from('subscribtion');
	                  $this->db->where('sub_id',$sub_id);
	                  $this->db->where('status','1');
	                  $qry = $this->db->get();
	                  $datas = array();
	    if($qry->num_rows()>0){
	        foreach($qry->result() as $key=>$row){
	            $weights = explode(',', $row->weights);
	                $amounts = explode(',', $row->amounts);
	               for($i=0;$i<count($weights);$i++){
	               $weight[]= array('weights'=>$weights[$i],
                                    'amounts'=>$amounts[$i]);
	              } 
	           
	        }
	   
	    }else{
	          $weight= array(
	                  "weights"=>"",
	                  "amounts"=>"",
	             );
	    }
	    return $weight;
}
function add_subscribers(){
        $data['customer_id'] = $this->input->post('customer_id');
		$data['sub_id'] = $this->input->post('subscribtion_id');
		
		$data['weight'] = $this->input->post('weight');
		$data['amount'] =$this->input->post('amount');
	    
		$data['expiry_date'] = date('Y-m-d', strtotime('+7 days'));
	     
		$query = $this->db->insert('subscribers_list',$data);
		if($query){  
		  $status = "true";
	      $msg = "Subscribtion Added,Please check your cart";
	      $subscribtion_id= $this->db->insert_id();
		}else{
		  $status = "false";
	      $msg = "Subscribtion Added Failed";
		}
           $response[] = array("msg"=>$msg,'status'=>$status,'subscribtion_id'=>$subscribtion_id);
        //echo json_encode($datas);
        	echo json_encode($response); 
}

function get_add_subscribtion(){
                	 $customer_id = $this->input->post('customer_id');
	    		     $this->db->select('*');
	                 $this->db->from('subscribers_list');
	                 $this->db->join('subscribtion','subscribtion.sub_id=subscribers_list.sub_id');
	                 $this->db->where('customer_id',$customer_id);
	                 $query = $this->db->get();
	                //print_r($this->db->last_query());
	                  $datas = array();
	    if($query->num_rows()>0){
	        foreach($query->result() as $key=>$row){
	              $amount[]=$row->amount;
	              $totals = array_sum($amount);
	              $items[] = array(
	                  "subscribtion_id"=>$row->subscribers_id,
                      "subscribtion_name"=>$row->sub_name,
                      "image"=>$row->sub_image,
                      "products"=>$row->products,
                      "weight"=>$row->weight,
                      "amount"=>$row->amount,
	                 );
	        }
	        $datas[]=array(
	            "items"=>$items,
	            "total"=>"$totals",
	            );
	    }else{
	        $datas[]=array(
	            "items"=>array(),
	            "total"=>"0",
	            ); 
	    }
	   
        echo json_encode($datas);
}

function add_reviews(){
      $customer_id = $data['customer_id'] = $this->input->post('customer_id');
	  $product_id =	$data['product_id'] = $this->input->post('product_id');
		$data['rate'] = $this->input->post('rate');
		$data['reviews'] = $this->input->post('reviews');
		$data['date'] = date('Y-m-d');
	       	 $this->db->select('*');
		     $this->db->from('product_reviews');
		     $this->db->where('customer_id',$data['customer_id'] );
			 $this->db->where('product_id',$data['product_id'] );
			 $sql = $this->db->get();
			 if($sql->num_rows() > 0){
			        $this->db->where('customer_id',$customer_id );
			        $this->db->where('product_id',$product_id);
			     	$query = $this->db->update('product_reviews',$data);
			 }else{
			    	$query = $this->db->insert('product_reviews',$data); 
			 }
	
		if($query){
		  $status = "true";
	      $msg = "Reviews Added Successfully";
		}else{
		  $status = "false";
	      $msg = "Reviews Added Failed";
		}
           $response[] = array("msg"=>$msg,'status'=>$status);
        //echo json_encode($datas);
        	echo json_encode($response); 
}

   
function delete_address(){
        $address_id = $this->input->post('address_id');
        $data['status']='0';
       	$this->db->where('address_id',$address_id);
		    $qry = $this->db->update('address',$data);
		    //print_r($this->db->last_query());
		    if($qry){
		     	$msg = 'Address deleted Successfully';
			    $status = true;
		    }else{
		    	
		    	$msg = 'Address deleted Failed';
			    $status = false;
		    }
    $response[] = array("msg"=>$msg,'status'=>$status);
    echo json_encode($response);
}
function search_product_list(){
    $product_name = $this->input->post('product');
    $this->db->like('product_name',$product_name);
    $query = $this->db->get_where('product');
   // print_r($this->db->last_query());  
    if($query->num_rows()>0){
        foreach($query->result() as $row){
            $datas[] = array(
                "product_id"=>$row->product_id,
                "product_name"=>$row->product_name
                );
        }
    }else{
        //echo "work";
            $datas = array();
    }
    echo json_encode($datas);
}
function change_order_status(){
    	$cart_id = $this->input->post('cart_id');
		$this->db->where('cart_id',$cart_id);
		$order =$data['cancel_status'] = $this->input->post('status');
		$query = $this->db->update('add_to_cart',$data);
		
	
		 
		if($query){
		  $status = "true";
	      $msg = "Your Order is ".$order;
	      $this->order_cancelled($cart_id);
		}else{
		  $status = "false";
	      $msg = "Your Order is ".$order. "Failed";
		}
		
		
		
           $response[] = array("msg"=>$msg,'status'=>$status);
        //echo json_encode($datas);
        	echo json_encode($response);
}

function order_cancelled($cart_id){
    
   	         $this->db->select('*');
		     $this->db->from('add_to_cart');
		     $this->db->where('cart_id',$cart_id);
		     $query = $this->db->get();
		     //print_r($this->db->last_query());
    if($query->num_rows()>0){
        // echo "ok";
        foreach($query->result() as $row){
            $order_id=$row->order_id;
           
        }
        
        $this->order_cancel($order_id);
        
    }else{
       // echo "nok";
    }
    
}

function order_cancel($order_id){
             $this->db->select('*');
		     $this->db->from('add_to_cart');
		     $this->db->where('order_id',$order_id);
		     $this->db->where('cancel_status',"cancel");
		     $query = $this->db->get();
		   // print_r($this->db->last_query());
		    
		    $i=1;
		    $j=1;
		if($query->num_rows()>0){
        foreach($query->result() as $row){
            if($row->cancel_status == "cancel"){
                $j++;
            }     
           $i++;
        }
	 if($i==$j){
		$this->db->where('order_id',$order_id);
		$data['cancel_order'] = "0";
		$data['del_status'] = "Cancelled";
		$qry = $this->db->update('orders',$data); 
		  }  
		}
		
}
function cancel_order(){
    	$order_id = $this->input->post('order_id');
		$this->db->where('order_id',$order_id);
		$data['cancel_order'] = "0";
		$data['del_status'] = "Cancelled";
		$query = $this->db->update('orders',$data);
	//	print_r($this->db->last_query());
		if($query){
		    //echo "ok";
		$this->db->where('order_id',$order_id);
		$datas['order_status'] = "0";
		$datas['cancel_status'] = "Cancelled";
		$qry = $this->db->update('add_to_cart',$datas);   
		//print_r($this->db->last_query());
		
		  $status = "true";
	      $msg = "Your Order is Cancelled";
		}else{
		  $status = "false";
	      $msg = "Your Order Doest Cancel";
		}
		
		
		
        $response[] = array("msg"=>$msg,'status'=>$status);
        //echo json_encode($datas);
        echo json_encode($response);
}
function get_cart_count($customer_id){
    $this->db->select('*');
    $this->db->from('add_to_cart');
    $this->db->where('order_status','1');
    $this->db->where('type','cart');
    $this->db->where('customer_id',$customer_id);
    $count=$this->db->count_all_results();
    return $count;
   // print_r($this->db->last_query());
}



function get_product_variant($product_id){
                      $this->db->select('*');
	                  $this->db->from('products_variant');
	                  $this->db->where('product_id',$product_id);
	                  $this->db->where('status','1');
	                  $qry = $this->db->get();
	                  $datas = array();
	    if($qry->num_rows()>0){
	        foreach($qry->result() as $key=>$row){
	           
	              $product[]= array(
	                  "variant_id"=>$row->variant_id,
	                  "price"=>$row->price,
	                  "unit"=>$row->unit,
	                  "unit_name"=>$row->unit_name,
	                  
	                );
	        }
	   
	    }else{
	          $product[]= array(
	                  "price"=>"",
	                  "unit"=>"",
	                  "unit_name"=>"",
	                  
	                );
	    }
	    return $product;
}
function get_qty_count($customer_id){
    $this->db->select_sum('qty');
    $this->db->from('add_to_cart');
    $this->db->where('order_status','1');
    $this->db->where('type','cart');
    $this->db->where('customer_id',$customer_id);
    $result=$this->db->get()->row();
    //print_r($this->db->last_query());
    //echo $result->qty;
    return $result->qty;
}

function get_about(){
    $data['status'] = 1;
    $query = $this->db->get_where('about',$data);
    if($query->num_rows()>0){
        foreach($query->result() as $key=>$row){
            $result[]= array(
                'about_id'=>$row->about_id,
                'about'=>$row->about,
                );
        }
    }else{
        $result[]= array(
                'about_id'=>"",
                'about'=>"",
                );
    }
    echo json_encode($result);
    
}
function check_available(){
    $data['pincode'] = $this->input->post('pincode');
    $data['status'] = 1;
    $query = $this->db->get_where('pincode',$data);
    if($query->num_rows()>0){
        $msg ="Delivery Available";
        $status=true;
    }else{
        $msg ="Delivery Not Available for this Pincode";
        $status=false;
    }
    $response[] = array("msg"=>$msg,'status'=>$status);
        //echo json_encode($datas);
    echo json_encode($response);
}
function get_terms(){
    $data['status'] = 1;
    $query = $this->db->get_where('terms',$data);
    if($query->num_rows()>0){
        foreach($query->result() as $key=>$row){
            $result[]= array(
                'term_id'=>$row->term_id,
                'terms'=>$row->terms,
                );
        }
    }else{
        $result[]= array(
                'term_id'=>"",
                'terms'=>"",
                );
    }
    echo json_encode($result);
 
}
function get_policy(){
    $data['status'] = 1;
    $query = $this->db->get_where('privacy_policy',$data);
    if($query->num_rows()>0){
        foreach($query->result() as $key=>$row){
            $result[]= array(
                'privacy_policy_id'=>$row->privacy_policy_id,
                'policy'=>$row->policy,
                );
        }
    }else{
        $result[]= array(
                'privacy_policy_id'=>"",
                'policy'=>"",
                );
    }
    echo json_encode($result);
 
}

function addtocart(){
	$customer_id = $this->input->post('customer_id');
	$product_id = $this->input->post('id');
	$datas['qty'] = 1;


	//print_r($datas);
	// exit;

	$data['customer_id'] = $customer_id;
	$data['product_id'] = $product_id;
	$data['order_status'] = 1;
	$data['type'] = 'cart';

	$datas['customer_id'] = $customer_id;
	$datas['product_id'] = $product_id;
	$datas['type'] = 'cart';
	$datas['qty'] = 1;
	
	$query = $this->db->get_where('add_to_cart',$data);
	if($query->num_rows()>0){
		$msg = "This product already added cart";
		$status = "nok";
	}else{
		$query = $this->db->insert('add_to_cart',$datas);
		if($query){
			$msg = "Cart Added Successfully";
			$status = "ok";
		}else{
			$msg = "Cart Added Failed";
			$status = "nok";
		}
	}
	echo json_encode(array("msg"=>$msg,"color"=>$status));
}
function addtocartproduct(){
	$customer_id = $this->input->post('customer_id');
	$product_id = $this->input->post('id');
	$qty = $this->input->post('qty');


	//print_r($datas);
	// exit;

	$data['customer_id'] = $customer_id;
	$data['product_id'] = $product_id;
	$data['order_status'] = 1;
	$data['type'] = 'cart';

	$datas['customer_id'] = $customer_id;
	$datas['product_id'] = $product_id;
	$datas['type'] = 'cart';
	$datas['qty'] = $qty;
	
	$query = $this->db->get_where('add_to_cart',$data);
	if($query->num_rows()>0){
		$msg = "This product already added cart";
		$status = "nok";
	}else{
		$query = $this->db->insert('add_to_cart',$datas);
		if($query){
			$msg = "Cart Added Successfully";
			$status = "ok";
		}else{
			$msg = "Cart Added Failed";
			$status = "nok";
		}
	}
	echo json_encode(array("msg"=>$msg,"color"=>$status));
}
function get_cart(){
	$customer_id = $this->session->userdata('customer_id');
        $this->db->select('*');
	    $this->db->from('add_to_cart');
	    $this->db->join('products_variant','products_variant.variant_id=add_to_cart.product_id');
	    $this->db->join('product','product.product_id=add_to_cart.product_id');
	    $this->db->where('add_to_cart.customer_id',$customer_id);
	    $this->db->where('add_to_cart.type','cart');
	    $this->db->where('add_to_cart.order_status',1);
	    $query = $this->db->get();
            if($query->num_rows() > 0){
                	return $query->result_array();
            }else{
                return "no";
            }
			//print_r($customer_id);
		// print_r($this->db->last_query());
 
}


}
?>