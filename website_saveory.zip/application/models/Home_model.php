<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home_model extends CI_Model {
    function __construct(){
		parent::__construct();
        $this->load->library('session');
		$this->load->helper(array('form', 'url'));
	}

    function get_products(){
	    $this->db->select('*');
	    $this->db->from('product');
	    $this->db->join('products_variant','products_variant.product_id=product.product_id');
	    $this->db->where('product.status',1);
	     $this->db->where('product.active_id',1);
	    $query = $this->db->get();
        //print_r($this->db->last_query());
        return $query->result_array();
        //print_r($query);
        //exit;
    }
	
    function get_latest_products(){
		$this->db->select('*');
	    $this->db->from('product');
		$this->db->order_by('product.product_id','desc');
        $this->db->join('products_variant','products_variant.product_id=product.product_id');
		$customer_id = $this->session->userdata('customer_id');
	    $this->db->where('product.status',1);
	      $this->db->where('product.active_id',1);
	    $query = $this->db->get();
        return $query->result_array();
        //print_r($query);
        // exit; 
	}
	function get_banner(){
        $data['status'] = 1;
        $query = $this->db->get_where('banner',$data);
        return $query->result_array();
		//   print_r($query);
        //  exit; 
       }

	   function get_about(){
		$this->db->select('*');
	    $this->db->from('about');
	    //$this->db->join('products_variant','products_variant.product_id=product.product_id');
	    $this->db->where('status',1);
	    $query = $this->db->get();
        return $query->result_array();
	}
	function get_terms(){
		$this->db->select('*');
	    $this->db->from('terms');
	    //$this->db->join('products_variant','products_variant.product_id=product.product_id');
	    $this->db->where('status',1);
	    $query = $this->db->get();
        return $query->result_array();
	}
	function get_policy(){
		$this->db->select('*');
	    $this->db->from('privacy_policy');
	    //$this->db->join('products_variant','products_variant.product_id=product.product_id');
	    $this->db->where('status',1);
	    $query = $this->db->get();
        return $query->result_array();
	}


    function get_categorys(){
	    $this->db->select('*');
	    $this->db->from('category');
	    //$this->db->join('products_variant','products_variant.product_id=category.category_id');
	    $this->db->where('category.status',1);
	    $query = $this->db->get();
        return $query->result_array();
        //print_r($query);
        //exit;
    }
	function update_qty(){
		$id = $this->input->post('id');
		$this->db->where('cart_id',$id);
		$data['qty'] = $this->input->post('qty');
		$query = $this->db->update('add_to_cart',$data);
		//print_r($this->db->last_query());
		if($query){
			$msg = "Quantity Updated Successfully";
			$status = "ok";
			header("Refresh:0");
		}else{
			$msg = "Quantity Updated  Failed";
			$status = "nok";
		}
		echo json_encode(array("msg"=>$msg,"color"=>$status));
	}


	function get_address(){
		$customer_id = $this->session->userdata('customer_id');
		$this->db->select('*');
		$this->db->from('address');
		$this->db->where('customer_id',$customer_id);
		$this->db->where('address.status',1);
		$query = $this->db->get();
		//print_r($this->db->last_query());
		return $query->result_array(); 
	}
	function search_book(){
		$book = $this->input->post('product_name');
		$this->db->select('*');
	   $this->db->from('product');
	   $this->db->like('product_name',$book);
	   $query = $this->db->get();

	  if($query->num_rows()>0){
	   foreach ($query->result() as $key => $val) {
		   $product_id=$val->product_id;
		   $product_name=$val->product_name;
		   ?>
		   
		   <option onclick="book_names()"><?php echo $product_name; ?> </option>
		   
	   
		   <?php
	   }
	   //return $query->result_array();
   
   }
}

	function add_wishlist(){
		$customer_id=$data['customer_id'] = $this->input->post('customer_id');
		$product_id=$data['product_id'] = $this->input->post('id');                                                  
		    // $p_id =
	       	// $user_id=
	    //$data['customer_id'] = $this->input->post('customer_id');
		  //$data['product_id'] = $this->input->post('product_id');
		     $data['varient_id'] = $this->input->post('varient_id');
	       	 $this->db->select('*');
		     $this->db->from('wishlist');
		     $this->db->where('customer_id',$customer_id);
			 $this->db->where('product_id',$product_id);
			 //$this->db->where('varient_id',$data);
			 $sql = $this->db->get();
			 if($sql->num_rows() > 0){
			   $this->db->where('customer_id',$customer_id);
		       $this->db->where('product_id',$product_id);
			  // $this->db->where('varient_id',$data);
			   $qry = $this->db->delete('wishlist',$data);
			   $status = "false";
	           $msg = "Wishlist Removed Successfully";
			  }else{
			 	$query = $this->db->insert('wishlist',$data);
	    if($query){
		  $status = "true";
	      $msg = "Wishlist Added Successfully";
		}else{
		  $status = "false";
	      $msg = "Wishlist Added Failed";
		}
			  
			  }
	
	
           $response[] = array("msg"=>$msg,'status'=>$status);
        //echo json_encode($datas);
        	echo json_encode($response); 
	}
	function delete_wishlist(){
    	$wish_id = $this->input->post('wish_id');
	
		$this->db->where('wish_id',$wish_id);
		$sql= $this->db->delete('wishlist');
		//print_r($this->db->last_query());
 if($sql){
    $this->session->set_userdata('type','success');
    $this->session->set_userdata('msg','Cart Deleted Successfully');
    return true;
  }else{
   $this->session->set_userdata('type','error');
   $this->session->set_userdata('msg','Cart Deleted Failed');
   return false;
}

	}
	function get_cart_count(){
		$customer_id = $this->session->userdata('customer_id');
		$this->db->select('*');
		$this->db->from('add_to_cart');
		$this->db->where('order_status','1');
		$this->db->where('type','cart');
		$this->db->where('customer_id',$customer_id);
		$count=$this->db->count_all_results();
		 // print_r($this->db->last_query());
		return $count;
	}
	function get_category_products($category_id){
    	
		$this->db->where('category_id', $category_id);
	   $this->db->join('products_variant','products_variant.product_id=product.product_id');
	   $this->db->where('product.status',1);
	   $query = $this->db->get('product');
	  return $query->result_array();
	   }
	function get_wishlist(){
		$customer_id = $this->session->userdata('customer_id');
      	   
	    $this->db->select('*');
		$this->db->from('wishlist');
		$this->db->where('wishlist.customer_id',$customer_id);
		$this->db->join('product','wishlist.product_id=product.product_id');
		$this->db->join('products_variant','products_variant.product_id=wishlist.product_id');
		$query = $this->db->get();
	  //print_r($this->db->last_query());
	    
		return $query->result_array();
	}

    function place_order(){
		$id=$this->input->post('customer_id');
		$amounts=$_SESSION['payable_amount'];
		
	 	
		 $add['customer_id'] =$id;
		 $add['unique_id'] =rand();
		 
		 $add['address_id'] =$_SESSION['address_id'];
		 
		 $add['payment_status'] ="COD";
		 $add['payment_method'] ="Cash";
 
		 $add['order_value'] =$amounts;
		 $add['order_date'] =date('Y-m-d');
		 $add['order_time'] =date('H:i:s');
	  
		 $query=$this->db->insert('orders',$add);
		 $order=$this->db->insert_id();
		 if($query){
		 $customer_id=$id;
		 $order_id=$order;
		 $datas['order_id'] =$order_id;
		 $datas['order_status'] =0;
		 $this->db->where('customer_id',$customer_id);
		 $this->db->where('order_status',1);
		 $qry=$this->db->update('add_to_cart',$datas);
		 }
		 if($qry){
			if($query){
				$msg = "Your Order Placed";
				$status = "ok";
				//redirect(base_url('Home'));
			}else{
				$msg = "Your Order Cannot Placed";
				$status = "nok";
			}
			echo json_encode(array("msg"=>$msg,"color"=>$status));
		}
	}


	function my_orders(){
		$customer_id = $this->session->userdata('customer_id');
		$this->db->select('*');
		$this->db->from('add_to_cart');
		$this->db->join('orders','add_to_cart.order_id=orders.order_id');
		$this->db->group_by('add_to_cart.order_id');
		$this->db->where('add_to_cart.customer_id',$customer_id);
		$this->db->where('add_to_cart.order_status','0');
		
		$query = $this->db->get();
         //print_r($this->db->last_query());
        return $query->result_array();
	}

	function get_order_details(){
	      $id = $this->input->post('order_id');
		$this->db->select('*');
		$this->db->from('orders');
		$this->db->join('address','address.address_id=orders.address_id');
		$this->db->join('add_to_cart','add_to_cart.order_id=orders.order_id');
		$this->db->where('orders.order_id',$id);
		$this->db->where('add_to_cart.order_status','0');
		$query = $this->db->get();
		print_r($this->db->last_query());
		return $query->result_array();
	}

	function get_order_products($id){
		$this->db->select('*');
		$this->db->from('add_to_cart');
		$this->db->join('products','products.product_id=add_to_cart.product_id');
		$this->db->where('add_to_cart.order_id',$id);
		$this->db->where('add_to_cart.order_status','0');
		$query = $this->db->get();
		return $query->result_array();
	}

	function get_profile(){
		$customer_id = $this->session->userdata('customer_id');
		$this->db->select('*');
		$this->db->from('customer');
		$this->db->where('customer_id',$customer_id);
		$this->db->where('customer.status',1);
		$query = $this->db->get();
		//print_r($this->db->last_query());
		return $query->result_array(); 
	}
	
	
	function add_address(){

	$updateid =  $this->input->post('update_id');
	$data['customer_id'] = $this->session->userdata('customer_id');
	$data['name'] = $this->input->post('name');
	$data['mobile'] = $this->input->post('mobile_no');
	$data['door_no'] = $this->input->post('door_no');	
	$data['street'] = $this->input->post('street');	
	$data['landmark'] = $this->input->post('landmark');
	$data['pincode'] = $this->input->post('pincode');
	$data['city'] = $this->input->post('city');
	$data['district'] = $this->input->post('district');
	$data['state'] = $this->input->post('state');
	$data['country'] = $this->input->post('country');


	if($updateid == ""){
		  $query = $this->db->insert('address',$data);
		    
		}else{
		    $this->db->where('address_id',$updateid);
		    $query = $this->db->update('address',$data);
		}
	
    if($query){
            $this->session->set_userdata('type','success');
            $this->session->set_userdata('msg','Address Added Successfully');
            redirect('profile');
            
            return true;
        
        }else{
           $this->session->set_userdata('type','error');
            $this->session->set_userdata('msg','Address Added Failed');
            return false;
        }
        	
    if($query){
            $this->session->set_userdata('type','success');
            $this->session->set_userdata('msg','Address Updated Successfully');
            redirect('profile');
            return true;
        }else{
           $this->session->set_userdata('type','error');
            $this->session->set_userdata('msg','Address Updated Failed');
            return false;
        }
}



function validate_pincode(){
 
    if ($this->input->post('submit')) {
  $pincode=  $data['pincode'] = $this->input->post('pincode');
    $data['status'] = 1;
    $query = $this->db->get_where('pincode',$data);
    print_r($this->db->last_query());
    if($query->num_rows()>0){
        
          $this->session->set_userdata('type','success');
          $this->session->set_userdata('msg','Delivery Available');
          $this->session->set_userdata('pincode',$pincode);
          return true;
        
       
    }else{
       
         $this->session->set_userdata('type','error');
         $this->session->set_userdata('msg','Delivery Not Available for this Pincode');
         return false;
          
    }
    
    }
}

function delete_cart(){
    	$cart_id = $this->input->post('id');
	
		$this->db->where('cart_id',$cart_id);
		$sql= $this->db->delete('add_to_cart');
		//print_r($this->db->last_query());
 if($sql){
    $this->session->set_userdata('type','success');
    $this->session->set_userdata('msg','Cart Deleted Successfully');
    return true;
  }else{
   $this->session->set_userdata('type','error');
   $this->session->set_userdata('msg','Cart Deleted Failed');
   return false;
}

	}
function get_address_edit(){
    	$id=$this->input->post('id');
	$this->db->select('*');
	$this->db->from('address');
	$this->db->where('address_id',$id);
	$query = $this->db->get();
	//print_r($this->db->last_query());
	foreach($query->result() as $row){
		   $datas=array(
			    'address_id' => $row->address_id,
			    'name' =>  $row->name,
				'mobile' => $row->mobile,
				'door_no' => $row->door_no,
				'street' => $row->street,
				'landmark' => $row->landmark,
				'city' => $row->city,
				'district' => $row->district,
				'state' => $row->state,
				'country' => $row->country,
				'pincode' => $row->pincode
			   );			     
	}
	echo json_encode($datas);
}
     function get_logo(){
	$data['status'] = 1;
	$query = $this->db->get_where('logo',$data);
	return $query->result_array();
   }
   
}