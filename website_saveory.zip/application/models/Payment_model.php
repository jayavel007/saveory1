<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Payment_model extends CI_Model {

    public function __construct() {
        $this->load->database('default');
        $this->load->library('session');

        // Call the Model constructor
        parent::__construct();
    }

    public function get_user(){

         $logged_in = $this->session->userdata('customer_id');
         $this->db->select('*');
         $this->db->from('customer');
         $this->db->where('customer_id',$logged_in);
         $query = $this->db->get();
         return $query->result_array();

    }

    
}

?>