<?php
defined('BASEPATH') OR exit('No direct script access allowed');

  class Savoury_website_controller extends CI_Controller {

   public function __construct()
   {
       parent::__construct();
       $this->load->library('session');
       $this->load->model('Currykrave_website_model');
    
       $this->load->model('Home_model');
    
   }

   
  function register_post(){
          $data['category']=$this->Home_model->get_categorys();
          $data['count']=$this->Home_model->get_cart_count();
          
                  $data['logo']=$this->Home_model->get_logo();
        $this->load->view('include/header',$data);
  
   $alert=$this->Currykrave_website_model->register();
   $data1['data'] = json_decode($alert, true);
 
   $this->load->view('login',$data1);
   $this->load->view('include/footer');

 }
 function cart(){


   $this->load->view('include/header');
   $this->load->view('cart','');
   $this->load->view('include/footer');
     
  
}
 function check_login(){
   if ($this->input->post('submit')) {
      $data['mobile_no'] = $this->input->post('mobile_no');
        $data['password'] = md5($this->input->post('password'));
        $data['approval_status'] = '1';
        //print_r($data['email']);
        $query = $this->db->get_where('customer',$data);
      if($query->num_rows()>0){
     foreach ($query->result() as $key => $row) {
         $this->session->set_userdata('customer_id',$row->customer_id);
         $this->session->set_userdata('username',$row->username);
         $this->session->set_userdata('email',$row->email);
         $this->session->set_userdata('user_type',$row->user_type);
        // $this->session->set_userdata('approval_status','1');
        redirect(base_url('Home'));
                      
     }
     
      }else{
        $this->session->set_userdata('type','error');
        $this->session->set_userdata('msg','Username and Password does not match');
        redirect(base_url('login'));
  }
    }
   
 }

function addtocart(){
   $this->Currykrave_website_model->addtocart();
}
function addtocartproduct(){
   $this->Currykrave_website_model->addtocartproduct();
}
 function forgot_password_post(){
    $this->Currykrave_website_model->forgot_password();
    $data['category']=$this->Home_model->get_categorys();
   $this->load->view('include/header',$data);
   $this->load->view('forgot_password');
   $this->load->view('include/footer');
    
 }
 function otp_verification_post(){
    $this->Currykrave_website_model->otp_verification();
    $this->load->view('otp_verfication');
 }
  function change_forgot_password_post(){
    $this->Currykrave_website_model->change_forgot_password();
    $this->load->view('reset_password');
 }
  function list_category_get(){
    $this->Currykrave_website_model->list_category();
 }
 function search_product_list_post(){
    $this->Currykrave_website_model->search_product_list();
 }
 function list_product_post(){
    $this->Currykrave_website_model->list_product();
 }
 function list_banner_get(){
    $this->Currykrave_website_model->list_banner();
 }
function search_product_post(){
    $this->Currykrave_website_model->search_product();
 }
 function get_category_get(){
    $this->Currykrave_website_model->get_category();
 }
  function get_sub_category_post(){
    $this->Currykrave_website_model->get_sub_category();
 }
  function get_product_post(){
    $this->Currykrave_website_model->get_product();
 }
  function product_details($id,$cat){
   //$data['category']=$this->Home_model->get_categorys();
   $data['product1']=$this->Currykrave_website_model->get_product_details($id); 
   $data['category']=$this->Currykrave_website_model->get_related_product($cat); 
   //print_r($data['category']);
   $this->load->view('include/header',$data);
     $this->load->view('product_details',$data);
    $this->load->view('include/footer');
 }
  function add_to_cart_post(){
    $this->Currykrave_website_model->add_to_cart();
 }
 function add_basket_post(){
    $this->Currykrave_website_model->add_basket();
 }
  function get_cart_post(){
    $this->Currykrave_website_model->get_cart();
 }
 function checkout_post(){
    $this->Currykrave_website_model->checkout();
 }
  function delete_cart_post(){
    $this->Currykrave_website_model->delete_cart();
 }
  function delete_subscribtion_post(){
    $this->Currykrave_website_model->delete_subscribtion();
 }
  function update_qty_post(){
    $this->Currykrave_website_model->update_qtys();
 }
  function add_address_post(){
    $this->Currykrave_website_model->add_address();
 }
 function get_address_post(){
    $this->Currykrave_website_model->get_address();
 }
  function my_address_post(){
    $this->Currykrave_website_model->my_address();
 }
 function add_wishlist_post(){
    $this->Currykrave_website_model->add_wishlist();
 }
  function get_wishlist_post(){
    $this->Currykrave_website_model->get_wishlist();
 }
 
 function list_category_product_post(){
     $this->Currykrave_website_model->list_category_product();
 }
function get_baskets_get(){
    $this->Currykrave_website_model->get_baskets();
 }
function edit_address_post(){
    $this->Currykrave_website_model->edit_address();
 }
 function change_password_post(){
    $this->Currykrave_website_model->change_password();
 }
  function my_orders_post(){
    $this->Currykrave_website_model->get_orders();
 }
 function my_order_details_post(){
    $this->Currykrave_website_model->my_order_details();
 }
  function add_reviews_post(){
    $this->Currykrave_website_model->add_reviews();
 }
 
  function get_all_products_post(){
    $this->Currykrave_website_model->get_all_products();
 }
 function get_subscribtion_get(){
    $this->Currykrave_website_model->get_subscribtion();
 }
 function get_subscribtion_details_post(){
   $this->Currykrave_website_model->get_subscribtion_details();
 }
  function add_subscribers_post(){
    $this->Currykrave_website_model->add_subscribers();
 }
 function get_add_subscribtion_post(){
     $this->Currykrave_website_model->get_add_subscribtion();
 }
  function delete_address_post(){
    $this->Currykrave_website_model->delete_address();
 }
 function change_order_status_post(){
      $this->Currykrave_website_model->change_order_status();
 }
 function cancel_order_post(){
      $this->Currykrave_website_model->cancel_order();
 }
  
  

function get_about_get(){
    $this->Currykrave_website_model->get_about();
}
function get_terms_get(){
    $this->Currykrave_website_model->get_terms();
}
function check_available_post(){
     $this->Currykrave_website_model->check_available();
}

function get_policy_get(){
    $this->Currykrave_website_model->get_policy();
}

}