<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once(APPPATH."libraries/razorpay/razorpay-php/Razorpay.php");
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;
class Payment extends CI_Controller {
  /**
   * This function loads the registration form
   */

  public function __construct() {
    parent::__construct();
    $this->load->helper('form');
    $this->load->helper('url');
}
  public function index()
  {
    $this->load->view('razorypay');
  }
  /**
   * This function creates order and loads the payment methods
   */
  public function pay()
  {
  
    $api = new Api(RAZOR_KEY, RAZOR_SECRET_KEY);
    /**
     * You can calculate payment amount as per your logic
     * Always set the amount from backend for security reasons
     */
    $amounts=$_SESSION['payable_amount'];
    $razorpayOrder = $api->order->create(array(
      'receipt'         => rand(),
      'amount'          => $_SESSION['payable_amount'] * 100, // 2000 rupees in paise
      'currency'        => 'INR',
      'payment_capture' => 1 // auto capture
    ));
    $amount = $razorpayOrder['amount'];
    $razorpayOrderId = $razorpayOrder['id'];
    $_SESSION['razorpay_order_id'] = $razorpayOrderId;
    
    $login = $this->session->userdata('customer_id');
    
        $add['customer_id'] =$login;
        $add['unique_id'] =rand();
        
        	$address_id11 = $_SESSION['address_id'];
	 				$this->db->select('*');
		$this->db->from('address');
		$this->db->where('address.address_id', $address_id11);
	$query = $this->db->get();
	 foreach ($query->result() as $row)
{
    $pincode11= $row->pincode;
}

	 				$this->db->select('*');
		$this->db->from('pincode_map');
		$this->db->where('pincode_map.pincode', $pincode11);
	$query1 = $this->db->get();
	 foreach ($query1->result() as $row1)
{
    $shop_id11= $row1->shop_id;
}

//  print_r($query);
//  die();
         $add['shop_id'] =$shop_id11;
         
        $add['address_id'] =$_SESSION['address_id'];
        $add['razorpay_id '] =$razorpayOrderId;
        $add['payment_status'] ="Processing";
        $add['payment_method'] ="Online";
        $add['order_value'] =$amounts;
        $add['order_date'] =date('Y-m-d');
        $add['order_time'] =date('H:i:s');
     
        $this->db->insert('orders',$add);
    

    $data = $this->prepareData($amount,$razorpayOrderId);
    $this->load->view('razorpay',array('data' => $data));
  }
  /**
   * This function verifies the payment,after successful payment
   */
  public function verify()
  {
    $success = true;
    $error = "payment_failed";
    if (empty($_POST['razorpay_payment_id']) === false) {
      $api = new Api(RAZOR_KEY, RAZOR_SECRET_KEY);
    try {
        $attributes = array(
          'razorpay_order_id' => $_SESSION['razorpay_order_id'],
          'razorpay_payment_id' => $_POST['razorpay_payment_id'],
          'razorpay_signature' => $_POST['razorpay_signature']
        );
        $api->utility->verifyPaymentSignature($attributes);
      } catch(SignatureVerificationError $e) {
        $success = false;
        $error = 'Razorpay_Error : ' . $e->getMessage();
      }
    }

      
       if($success === true) {
            $razorpayId= $_SESSION['razorpay_order_id'];
        $_SESSION['razorpay_order_id']= $razorpayId;
        $data['payment_status'] ="Completed";
        $data['order_status'] ="1";
        $data['estimate_del'] =date("Y/m/d");
		$this->db->where('razorpay_id',$razorpayId);
		$this->db->update('orders',$data);
		 
		$dat['razorpay_id'] =$razorpayId;
		$query = $this->db->get_where('orders',$dat);
      
		//print_r($this->db->last_query()); 
	
		$data = array();
		foreach ($query->result() as $key => $row) {
		     	$customer_id=$row->customer_id;
		     	$order_id=$row->order_id;
			}
			
		$datas['order_id'] =$order_id;
		$this->db->where('customer_id',$customer_id);
		$this->db->where('order_status',1);
		$qry=$this->db->update('add_to_cart',$datas);
		
		if($qry){
		    $order['order_status'] ="0";
	    	$this->db->where('customer_id',$customer_id);
	    	$qry1=$this->db->update('add_to_cart',$order); 
		}
		
	   $this->setRegistrationData();
      redirect(base_url().'Payment/success');
    }
    else{
        $data['payment_status'] ="Cancel";
        $data['order_status'] ="0";
		$this->db->where('razorpay_id',$razorpayId);
		$this->db->update('orders',$data);
        redirect(base_url().'Payment/paymentFailed');
    }
  }
  /**
   * This function preprares payment parameters
   * @param $amount
   * @param $razorpayOrderId
   * @return array
   */
  public function prepareData($amount,$razorpayOrderId)
  {
    $this->load->model('Payment_model');
    $detail = $this->Payment_model->get_user();
    // print_r($detail);
    // exit;
    $data = array(
      "key" => RAZOR_KEY,
      "amount" => $amount,
      "name" => "Burgeon Impex Private Limited ",
      "description" => "Meat Shop",
      "image" => "https://eezaa.teckzy.in/website/admin/upload/logo/Eezaa_app.png",
      "prefill" => array(
        // "name"  => $this->input->post('name'),
        // "email"  => $this->input->post('email'),
        // "contact" => $this->input->post('contact'),
        "name"  => $this->input->post('name'),
        "email"  => $detail[0]['email'],
        "contact" => $detail[0]['mobile_no'],
      ),
     
      "theme"  => array(
        "color"  => "#ffc107"
      ),
      "order_id" => $razorpayOrderId,
    );
    return $data;
  }
  /**
   * This function saves your form data to session,
   * After successfull payment you can save it to database
   */
  public function setRegistrationData()
  {

    $this->load->model('Payment_model');
    
    $name = $this->input->post('name');
    $email = $this->input->post('email');
    $contact = $this->input->post('contact');
    $amount = $_SESSION['payable_amount'];
    $registrationData = array(
      'order_id' => $_SESSION['razorpay_order_id'],
      'name' => $name,
      'email' => $email,
      'contact' => $contact,
      'amount' => $amount,
    );
    // save this to database
  }
  /**
   * This is a function called when payment successfull,
   * and shows the success message
   */
  public function success()
  {
    redirect('home');
  }
  /**
   * This is a function called when payment failed,
   * and shows the error message
   */
  public function paymentFailed()
  {
    $this->load->view('error');
  }  
}