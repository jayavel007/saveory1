<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Home_model');
        $this->load->model('Currykrave_website_model');
    }

    // public function index(){
    //     $data['category']=$this->Home_model->get_categorys();
    //     $data['product1']=$this->Home_model->get_latest_products();
    //     //$this->session->set_userdata('username','Nathim');
    //     $this->load->view('include/header',$data);
    //     $this->load->view('index');
    //     $this->load->view('include/footer');
    // }
    // public function search(){
    //     $search = $this->input->post('search');
    //     $data['users'] =  $this->Home_model->search($search);
    //     $this->load-view('header');
    // }
    public function search_book(){
		$this->Home_model->search_book();
	
	}
    public function search_book_1(){
        //$this->load->view('include/head');
        $data['category']=$this->Home_model->get_categorys();
        $data['count']=$this->Home_model->get_cart_count();
        $book = $this->input->post('search_book');
$this->db->select('*');
$this->db->from('product');
$this->db->join('products_variant','products_variant.product_id=product.product_id');
$this->db->where('product.product_name',$book);
$query = $this->db->get();
$data['product_id11']= $query->result_array();
//print_r($data['product_id11']);

$this->load->view('include/header', $data);

// print_r($result['product_id']);

$this->load->view('search');


$this->load->view('include/footer');


}


    public function index(){
        $data['category']=$this->Home_model->get_categorys();
        $data['count']=$this->Home_model->get_cart_count();
        $data['product1']=$this->Home_model->get_latest_products();
        $data['banner']=$this->Home_model->get_banner();
        $data['logo']=$this->Home_model->get_logo();
       // $data['count']=$this->Home_model->get_cart_count();
        //print_r( $data['count']);
        //$data['product_1122']=$this->Home_model->get_products1122();
        //print_r( $data['banner']);
        //$this->session->set_userdata('username','Nathim');
        $this->load->view('include/header',$data);
        $this->load->view('index');
        $this->load->view('include/footer');
    }
    
    public function logout(){
        $this->session->sess_destroy();
         redirect(base_url());
	}

    public function about(){
        $data['category']=$this->Home_model->get_categorys();
        $data['count']=$this->Home_model->get_cart_count();
         $data['about']=$this->Home_model->get_about();
                 $data['logo']=$this->Home_model->get_logo();
        $this->load->view('include/header',$data);
        $this->load->view('about');
        $this->load->view('include/footer');
    }
    
    
       public function terms(){
        $data['category']=$this->Home_model->get_categorys();
        $data['count']=$this->Home_model->get_cart_count();
        $data['terms']=$this->Home_model->get_terms();
                $data['logo']=$this->Home_model->get_logo();
        $this->load->view('include/header',$data);
        $this->load->view('terms');
        $this->load->view('include/footer');
    }
    
    
       public function policy(){
        $data['category']=$this->Home_model->get_categorys();
        $data['count']=$this->Home_model->get_cart_count();
         $data['policy']=$this->Home_model->get_policy();
                 $data['logo']=$this->Home_model->get_logo();
                 
        $this->load->view('include/header',$data);
        $this->load->view('policy');
        $this->load->view('include/footer');
    }
    
    
    public function product(){
        $data['category']=$this->Home_model->get_categorys();
        $data['count']=$this->Home_model->get_cart_count();
                $data['logo']=$this->Home_model->get_logo();
        $this->load->view('include/header',$data);
        $this->load->view('product');
        //$this->Home_model->get_products();
        $this->load->view('include/footer');
    }
    
     public function get_category1($category_id){
        $data['category']=$this->Home_model->get_categorys();
        $data['count']=$this->Home_model->get_cart_count();
        $data['products_list']=$this->Home_model->get_category_products($category_id);
                $data['logo']=$this->Home_model->get_logo();
        $this->load->view('include/header',$data);
        $this->load->view('category');
        $this->load->view('include/footer');

       
    }
    
    public function profile(){
        $data['category']=$this->Home_model->get_categorys();
        $data['count']=$this->Home_model->get_cart_count();
        $data['orders'] = $this->Home_model->my_orders();
        $data['address']=$this->Home_model->get_address();
        $data['profile']=$this->Home_model->get_profile();
        $data['logo']=$this->Home_model->get_logo();
      //  $data['count']=$this->Home_model->get_cart_count();
        $data['wishlist']=$this->Home_model->get_wishlist();
        //$data['order_details']=$this->Home_model->get_order_details();
        
        // $data['order_details'] = $this->Order_model->my_order_details($id);
        // $data['product_details'] = $this->Order_model->get_order_products($id);
       
        $this->load->view('include/header',$data);
        $this->load->view('profile');
        //$this->Home_model->get_products();
        $this->load->view('include/footer');
    }

    function add_wishlist(){
        // $product_id = $_GET['id'];
        // $customer_id = $_GET['customer_id'];
       //$varient_id = $_GET['$varient_id'];
        // print_r($user_id);
        $data['wishlist']=$this->Home_model->add_wishlist();
        $data['logo']=$this->Home_model->get_logo();
       // $data['wishlist']=$this->Home_model->delete_wishlist();
        // $this->load->view('profile');
     
    }
    // function delete_wishlist($id){
    //     $this->Home_model->delete_wishlist($id);
    // }
    function product_details($id,$cat){
        // $id = $_GET['id'];
        // $cat = $_GET['cat'];
        $data['category']=$this->Home_model->get_categorys();
        $data['count']=$this->Home_model->get_cart_count();
        $data1['product1']=$this->Currykrave_website_model->get_product_details($id); 
        $data1['products']=$this->Currykrave_website_model->get_related_product($cat); 
        $data['logo']=$this->Home_model->get_logo();
      //  print_r($data1['product1']);
        $this->load->view('include/header',$data);
        $this->load->view('product_details',$data1);
        $this->load->view('include/footer');
      }
    public function register(){
        $data['category']=$this->Home_model->get_categorys();
        $data['count']=$this->Home_model->get_cart_count();
        $data['logo']=$this->Home_model->get_logo();
        $this->load->view('include/header',$data);
        $this->load->view('register');
        $this->load->view('include/footer');
    }
    public function login(){
          $data['category']=$this->Home_model->get_categorys();
          $data['count']=$this->Home_model->get_cart_count();
          
                  $data['logo']=$this->Home_model->get_logo();
        $this->load->view('include/header',$data);
        $this->load->view('login');
        $this->load->view('include/footer');
    }
    public function get_product(){
        $data['category']=$this->Home_model->get_categorys();
        $data['count']=$this->Home_model->get_cart_count();
                $data['logo']=$this->Home_model->get_logo();
        $this->load->view('include/header',$data);
        $data['product']=$this->Home_model->get_products();
        //$data['product_variant']=$this->Home_model->get_products();
        // print_r($data);
        // exit;
        $this->load->view('product',$data);
        $this->load->view('include/footer');
    }
    public function get_latest_product(){
        $data['category']=$this->Home_model->get_categorys();
        $data['count']=$this->Home_model->get_cart_count();
        
                $data['logo']=$this->Home_model->get_logo();
        //print_r($data['product1']);
        $this->load->view('include/header',$data);
        
        $this->load->view('index',$data);
        $this->load->view('include/footer');
    }
    
   
    public function cart(){
        $data['category']=$this->Home_model->get_categorys();
        $data['count']=$this->Home_model->get_cart_count();
                $data['logo']=$this->Home_model->get_logo();
       
        $this->load->view('include/header',$data);
        $data['cart']=$this->Currykrave_website_model->get_cart();
        //    print_r($data['cart']);
        $this->load->view('cart',$data);
        $this->load->view('include/footer');
    }

    function checkout(){
        $data['category']=$this->Home_model->get_categorys();
        $data['count']=$this->Home_model->get_cart_count();
        $data['address']=$this->Home_model->get_address();
        $data['checkout']=$this->Currykrave_website_model->get_cart();
        //print_r($data['address']);
               $data['logo']=$this->Home_model->get_logo();
        $this->load->view('include/header',$data);
        $this->load->view('checkout');
        $this->load->view('include/footer');
    }

    public function update_qty()
	{
        $this->Home_model->update_qty();
        //$data['qty']=$this->Home_model->qty();
	}
    public function contact(){
        $data['category']=$this->Home_model->get_categorys();
        $data['count']=$this->Home_model->get_cart_count();
                $data['logo']=$this->Home_model->get_logo();
        $this->load->view('include/header',$data);
        $this->load->view('contact');
        $this->load->view('include/footer');
    }

    function placeOrder(){
        $this->Home_model->place_order();
      // redirect('index');
    }
    
    function get_order_details(){
        $this->Home_model->get_order_details(); 
       
    }
      function add_address(){
        $this->Home_model->add_address(); 
        redirect(base_url('checkout'));
       
       
    }
    
    function validate_pincode(){
        $this->Home_model->validate_pincode(); 
        redirect('Home');
      
    }
    
    function delete_cart(){
         $this->Home_model->delete_cart(); 
    }
    function delete_wishlist(){
        $this->Home_model->delete_wishlist(); 
   }
    
    function get_address_edit(){
          $this->Home_model->get_address_edit(); 
          // redirect('profile');
    }
}   