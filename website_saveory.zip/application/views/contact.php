  
        <!--Page Title-->
        <section class="page-title" style="background-image: url(admin/upload/banner/mutton.png);">
            <div class="auto-container">
                <div class="content-box">
                    <div class="title-box">
                        <h1>Contact Us</h1>
                    </div>
                    <ul class="bread-crumb clearfix">
                        <li><a href="">Home</a></li>
                        <li>Contact Us</li>
                    </ul>
                </div>
            </div>
        </section>
        <!--End Page Title-->


     

        <!-- contact-info-section -->
        <section class="contact-info-section centred">
            <div class="auto-container">
                <div class="inner-container">
                    <div class="row clearfix">
                        <div class="col-lg-4 col-md-6 col-sm-12 info-column">
                            <div class="single-info">
                                <div class="inner-box">
                                    <div class="big-icon"><i class="flaticon-telephone"></i></div>
                                    <div class="icon-box"><i class="flaticon-telephone"></i></div>
                                    <h3>Phone Number</h3>
                                    <p>9398370985</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 info-column">
                            <div class="single-info">
                                <div class="inner-box">
                                    <div class="big-icon"><i class="flaticon-mail"></i></div>
                                    <div class="icon-box"><i class="flaticon-mail"></i></div>
                                    <h3>Email Address</h3>
                                    <p></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-6 col-sm-12 info-column">
                            <div class="single-info">
                                <div class="inner-box">
                                    <a href="https://goo.gl/maps/TfUBAqTs3AY9NiuC7" target="_blank" rel="noopener noreferrer">
                                    <div class="big-icon"><i class="flaticon-maps-and-flags"></i></div>
                                    <div class="icon-box"><i class="flaticon-maps-and-flags"></i></div>
                                    <h3>Shop Address</h3>
                                    <p>Savoury Meat </p>
                                    <p>No.13-4-561/19/B, New Ganga Nagar, Giaguda, Hyderabad - 500006, India</p>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- contact-info-section end -->


        <!-- contact-section -->
        <!--<section class="contact-section centred">-->
        <!--    <div class="auto-container">-->
        <!--        <div class="sec-title">-->
        <!--            <span>Contact</span>-->
        <!--            <h2>Get In Touch</h2>-->
        <!--        </div>-->
        <!--        <div class="form-inner">-->
        <!--            <form method="post" action="http://azim.commonsupport.com/Carneshop/assets/inc/sendemail.php" id="contact-form" class="default-form"> -->
        <!--                <div class="row clearfix">-->
        <!--                    <div class="col-lg-6 col-md-6 col-sm-12">-->
        <!--                        <div class="form-group">-->
        <!--                            <i class="far fa-user"></i>-->
        <!--                            <input type="text" name="username" placeholder="Name" required="">-->
        <!--                        </div>-->
        <!--                    </div>-->
        <!--                    <div class="col-lg-6 col-md-6 col-sm-12">-->
        <!--                        <div class="form-group">-->
        <!--                            <i class="far fa-envelope"></i>-->
        <!--                            <input type="email" name="email" placeholder="Email" required="">-->
        <!--                        </div>-->
        <!--                    </div>-->
        <!--                    <div class="col-lg-6 col-md-6 col-sm-12">-->
        <!--                        <div class="form-group">-->
        <!--                            <i class="fas fa-phone-volume"></i>-->
        <!--                            <input type="text" name="phone" required="" placeholder="Phone">-->
        <!--                        </div>-->
        <!--                    </div>-->
        <!--                    <div class="col-lg-6 col-md-6 col-sm-12">-->
        <!--                        <div class="form-group">-->
        <!--                            <i class="far fa-file-alt"></i>-->
        <!--                            <input type="text" name="subject" required="" placeholder="Subject">-->
        <!--                        </div>-->
        <!--                    </div>-->
        <!--                    <div class="col-lg-12 col-md-12 col-sm-12">-->
        <!--                        <div class="form-group">-->
        <!--                            <i class="far fa-comment-alt"></i>-->
        <!--                            <textarea name="message" placeholder="Message"></textarea>-->
        <!--                        </div>-->
        <!--                    </div>-->
        <!--                    <div class="col-lg-12 col-md-12 col-sm-12 form-group message-btn centred">-->
        <!--                        <button class="theme-btn" type="submit" name="submit-form">-->
        <!--                            SEND MESSAGE -->
        <!--                        </button>-->
        <!--                    </div>-->
        <!--                </div>-->
        <!--            </form>-->
        <!--        </div>-->
        <!--    </div>-->
        <!--</section>-->
        <!-- contact-section end -->


        <!-- clients-section -->
        <!-- <section class="clients-section">
            <div class="auto-container">
                <div class="clients-carousel owl-carousel owl-theme owl-dots-none owl-nav-none">
                    <figure class="logo-image"><a href=""><img src="assets/images/clients/clients-logo-1.png" alt=""></a></figure>
                    <figure class="logo-image"><a href=""><img src="assets/images/clients/clients-logo-2.png" alt=""></a></figure>
                    <figure class="logo-image"><a href=""><img src="assets/images/clients/clients-logo-3.png" alt=""></a></figure>
                    <figure class="logo-image"><a href=""><img src="assets/images/clients/clients-logo-4.png" alt=""></a></figure>
                    <figure class="logo-image"><a href=""><img src="assets/images/clients/clients-logo-5.png" alt=""></a></figure>
                </div>
            </div>
        </section> -->
        <!-- clients-section end -->


       
