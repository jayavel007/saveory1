<?php 
 $logged_in = $this->session->userdata('customer_id');
 $user_type = $this->session->userdata('user_type');

 $pincode = $this->session->userdata('pincode');
 

 
if(!empty($logged_in)){
   $customer_id=$this->session->userdata('customer_id');
   if($customer_id==''){
   $customer_id=0; 
   }

}else{
    $customer_id=0;
}


?>

<style>
/*    .shop-block-one .inner-box .image-box .short_describtion {*/
/*    position: absolute!important;*/
/*    bottom: 0!important;*/
/*    right: 0!important;*/
/*    border: #000!important;*/
/*    background: red!important;*/
/*    overflow: overlay!important;*/
/*    width: 80%!important;*/
/*    float: right!important;*/
/*    color: #fff!important;*/
/*    padding: 0px 6px!important;*/
/*    font-size: 11px !important;*/
/*    top: auto !important;*/
/*}*/

.shop-block-one .inner-box .image-box .short_describtion {
    position: absolute!important;
    bottom: 0!important;
    right: 0!important;
    border: #000!important;
    background: red!important;
    overflow: overlay!important;
    width: 88%!important;
    float: right!important;
    color: #fff!important;
    padding: 0px 6px!important;
    font-size: 11px !important;
    top: auto !important;
}
.shop-block-one .inner-box .image-box .list {
    position: absolute;
    top: 50%;
    /* left: 50%; */
    /* left: 50%; */
    /* bottom: -50px; */
    visibility: hidden;
    transition: all 500ms ease;
    text-align: center;
    margin-left: 55px;
    /* margin-top: -4px; */
    /* right: 50%; */
}
</style>
      <!-- main-slider -->
      <section class="main-slider">
        <div class="main-slider-carousel owl-theme owl-carousel owl-dots-none">
        <?php
                  $i=1; 
                 foreach($banner as $ban1) {
                                                                            
                  ?>
          <div class="slide-item">
            <div class="image-layer">
         
                    <img src="<?php echo base_url('admin/');?><?php echo $ban1['banner_image']; ?>">
                       
              </div>
              </div>
              <?php $i++; } ?>
          </div>
      
      </section>
      <!-- main-slider end -->

   
  
      <!-- clients-section -->
      <section class="clients-section">
        <div class="auto-container">
          <div
            class="
              clients-carousel
              owl-carousel owl-theme owl-dots-none owl-nav-none
            "
          >
            <figure class="logo-image">
              <a href="<?php echo base_url();?>"
                ><img src="" alt=""
              /></a>
            </figure>
            <figure class="logo-image">
              <a href="<?php echo base_url();?>"
                ><img src="" alt=""
              /></a>
            </figure>
            <figure class="logo-image">
              <a href="<?php echo base_url();?>"
                ><img src="" alt=""
              /></a>
            </figure>
            <figure class="logo-image">
              <a href="<?php echo base_url();?>"
                ><img src="" alt=""
              /></a>
            </figure>
            <figure class="logo-image">
              <a href="<?php echo base_url();?>"
                ><img src="" alt=""
              /></a>
            </figure>
          </div>
        </div>
      </section>
      <!-- clients-section end -->

      <!-- service-section -->
      <!-- <section class="service-section bg-color-1">
        <div
          class="icon-layer"
          style="background-image: url(assets/images/icons/bg-icon-1.png)"
        ></div>
        <div class="auto-container">
          <div class="sec-title text-center">
            <span>What we do</span>
            <h2>Services for You</h2>
          </div>
          <div
            class="
              three-item-carousel
              owl-carousel owl-theme owl-dots-none owl-nav-none
            "
          >
            <div class="service-block-one">
              <div class="inner-box">
                <div class="icon-box"><i class="flaticon-meat-4"></i></div>
                <h3><a href="">Veal Entrecote</a></h3>
                <p>Lorem ipsum dolor sit amet, consec tetur adipis</p>
                <div class="btn-box">
                  <a href="" class="theme-btn">Read More</a>
                </div>
              </div>
            </div>
            <div class="service-block-one">
              <div class="inner-box">
                <div class="icon-box"><i class="flaticon-hang"></i></div>
                <h3><a href="">Beef Tenderloin</a></h3>
                <p>Lorem ipsum dolor sit amet, consec tetur adipis</p>
                <div class="btn-box">
                  <a href="" class="theme-btn">Read More</a>
                </div>
              </div>
            </div> 
            <div class="service-block-one">
              <div class="inner-box">
                <div class="icon-box"><i class="flaticon-meat-5"></i></div>
                <h3><a href="">Beaf ribs</a></h3>
                <p>Lorem ipsum dolor sit amet, consec tetur adipis</p>
                <div class="btn-box">
                  <a href="" class="theme-btn">Read More</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section> -->
      <!-- service-section end -->

      <!-- shop-section -->
      <section class="shop-section">
        <div class="auto-container">
          <div class="sec-title style-two text-center">
          
            <h2>Bestselling Products</h2>
          </div>
          <div class="row clearfix">
          <?php
                           $i=1; 
                           foreach($product1 as $ban) {
                             $id=$ban['product_id'];
                             $cat=$ban['category_id'];
                              //$type=$ban['type'];
                             ?>
                              
            <div class="col-lg-3 col-md-6 col-sm-12 shop-block">
              <div
                class="shop-block-one wow fadeInUp animated animated"
                data-wow-delay="00ms"
                data-wow-duration="1500ms"
              >
            
                <div class="inner-box">
                  
                  <figure class="image-box">
                  <img src="<?php echo base_url('');?>admin/<?php echo $ban['pro_image']; ?>" alt='' width='' height=''>
                  <ul class="list clearfix">
                    <!-- <li><button type="button" class="btn"><i class="flaticon-cart"></i></button></li> -->
                      <li><button type="button" onclick="addProduct(<?php echo $id; ?>,<?php echo $customer_id; ?>);" class="theme-btn" >Add to cart</button>
                         </ul>
                           <!-- <div style="" class="short_describtion"> <?php echo $ban['short_description'];?></div> -->
                         <!-- <?php if($type=='new') { ?>  
                    <div class='new'>
                        NEW
                    </div>
                    <?php } ?> -->
                  </figure>
                  <p onclick="wishList(<?php echo $id; ?>,<?php echo $customer_id; ?>);"></a><i class="fas fa-heart" style="
    color: red;
"></i></p>
                  <div class="lower-content">
                    <h6><a href="<?php echo base_url();?>product_details/<?php echo $id; ?>/<?php echo $cat; ?>"><?php echo $ban['product_name']; ?></a></h6>
                    <h6 id="mrp">MRP : ₹<?php 
                    if($user_type=="holesale"){
                      echo $ban['holesale_price']; 
                    }else{
                      echo $ban['price'];
                    }
                    
                    
                    
                  ?></h6> 
                    <!-- <h6> Grs wt : <?php echo $ban['gross_weight']; ?>&nbsp;&nbsp;&nbsp;  Net wt : <?php echo $ban['net_weight']; ?></h6> -->
                    <h6>   <?php echo $ban['description']; ?></h6>
                  </div>
                </div>
               
              </div>
            </div>
            <?php $i++; } ?>
          </div>
          <div class="more-btn centred">
            <a href="<?php echo base_url('product') ?>" class="theme-btn">View More Products</a>
          </div>
     
     </div>
        </div>
      </section>
     
      <?php if(empty($pincode)) { ?>
<div class="modal fade " id="myLargeModalLabel" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle" style="color:#000"><strong>Choose Delivery Location</strong></h5>
        <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button> -->
      </div>
      <div class="modal-body">
        <form action="<?php echo base_url() ?>Home/validate_pincode" method="post">
          <div class="form-group">
            <input type="text" style="" class="form-control" name="pincode" id="DelLocation" value="" aria-describedby="pinocdeHelp" placeholder="Please Enter Delivery Pincode" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1')" minlength="6" maxlength="6">
          </div>
          
         <div class="location">
         <br>
         <p><strong style="color:#000">Serviceable Locations :   </strong></p>
         <p style="color:#000">Note - Please enter a valid pincode to check service availability. </p>
         </div>
          <div class="modal-footer">
        <button type="submit" name="submit" value="submit" class="btn btn-warning text-white">Save</button>
         </div>
        </form>
      </div>
    
    </div>
  </div>
</div>

<?php } ?>

      <script>
       function addProduct(id,customer_id){
  
  // var size = $('#sizes').val();


  if(customer_id==0){
    toastr.error('Please Login');
    redirect('login');
  }else{
      $.ajax({
     method:"POST",
     url:"<?php echo base_url('Savoury_website_controller/addtocart') ?>",
     data:{id:id,
       customer_id:customer_id
     },
   
     success:function(data){

       console.log(data);
       datas = JSON.parse(data);

       if(datas.color=='ok'){
                    toastr.success(datas.msg);
                    location.reload(true);
                  }else{
                    toastr.error(datas.msg);
                  }
        
     }
 });

  }
 }
        </script>
        <script>
function myFunction() {
   $(window).on('load', function() {
        $('#myLargeModalLabel').modal('show');
    });
}


</script>



  <script>
  $(document ).ready(function() {
    <?php
    $msg = $this->session->userdata('msg');
    if(isset($msg)){
    ?>
    toastr.options.timeOut = 1500; // 1.5s
    toastr.<?php echo $this->session->userdata('type'); ?>("<?php echo $msg; ?>");
    <?php
    }
    $this->session->unset_userdata('msg'); 
    ?>
  });

  function wishList(id,customer_id){
  
  // var size = $('#sizes').val();


  if(customer_id==0){
    toastr.error('Please Login');
    redirect('login');
  }else{
      $.ajax({
     method:"POST",
     url:"<?php echo base_url('Home/add_wishlist') ?>",
     data:{id:id,
       customer_id:customer_id
     },
   
     success:function(data){

       console.log(data);
       datas = JSON.parse(data);

       if(datas.color=='ok'){
                    toastr.success(datas.msg);
                    location.reload(true);
                  }else{
                    // toastr.error(datas.msg);
                    location.reload(true);
                  }
        
     }
 });

  }
 }
 
        </script>
        <script>
function myFunction() {
   $(window).on('load', function() {
        $('#myLargeModalLabel').modal('show');
    });
}


</script>



      