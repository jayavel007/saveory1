<!-- <style>
    
p {
    position: relative;
    font-size: 16px;
    line-height: 30px;
    font-family: "Rubik", sans-serif;
    color: #ffffff;
    margin: 0px;
    transition: all 500ms ease;
}


#content_block_1 .content-box .list li {
    position: relative;
    display: block;
    font-size: 16px;
    font-family: "Heebo", sans-serif;
    font-weight: 700;
    color: #ffffff;
    margin-bottom: 10px;
    padding-left: 30px;
}
</style> -->
        
        <!--Page Title-->
        <section class="page-title" style="background-image: url(admin/upload/banner/mutton.png);">
            <div class="auto-container">
                <div class="content-box">
                    <div class="title-box">
                        <h1>Privacy Policy</h1>
                    </div>
                    <ul class="bread-crumb clearfix">
                        <li><a href="<?php echo base_url() ?>">Home</a></li>
                        <li>Privacy Policy</li>
                    </ul>
                </div>
            </div>
        </section>
        <!--End Page Title-->


        <!-- about-section -->
        <section class="about-section sec-pad">
            <div class="auto-container">
                <div class="inner-container mr-0 clearfix">
                    <div class="row clearfix">
                        <!-- <div class="col-lg-6 col-md-6 col-sm-12 video-column">
                            <div id="video_block_1">
                                <div class="video-inner" style="background-image: url(assets/images/resource/about-1.jpg);">
                                    <a href="" class="lightbox-image video-btn" data-caption=""><i class="fas fa-play"></i></a>
                                </div>
                            </div>
                        </div> -->
                        <div class="col-lg-12 col-md-6 col-sm-12 content-column">
                            <div id="content_block_1"  style="">
                                <div class="content-box">
                                <?php
                                                                       
                                                                       foreach($policy as $ban) {
                                                                           
                                                                           ?>
                                    <!--<div class="sec-title">-->
                                    <!--    <span>About Us</span>-->
                                    <!--    <h2>We Provide Best Meat</h2>-->
                                    <!--</div>-->
                                    <div class="text">
                                        <p><strong></strong><?php echo $ban['policy']; ?></strong></p>
                               

                                    </div>
                                    <!--<ul class="list clearfix">-->
                                    <!--    <li>100% Organic Meat</li>-->
                                    <!--    <li>Payment Securation</li>-->
                                    <!--</ul>-->
                                    <!--<div class="btn-box">-->
                                    <!--    <a href="" class="theme-btn">View More<i class="fas fa-long-arrow-alt-right"></i></a>-->
                                    <!--</div>-->
                                </div>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- about-section end -->







