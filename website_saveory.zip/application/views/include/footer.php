<!-- main-footer -->
<style>
 .main-footer {
    position: relative;
    background: #ffffff;
    margin-top: 30px;
    background-color: #daddeb;
}  
}
.icon ul .social-links clearfix pt-4{
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;"
}
.toast{
    color:#fff !important;
}
h1, h2, h3, h4, h5, h6 {
    position: relative;
    font-family: "Heebo", sans-serif;
    font-weight: 400;
    color: #000000;
    margin: 0px;
    transition: all 500ms ease;
}
.main-footer .footer-top .logo-widget p {
    font-size: 16px;
    line-height: 30px;
    color: #000;
    margin: 0px;
}
.a11 {
    color: #000000 !important;
  
}
body {
    font-size: 16px;
    color: #000000;

}
</style>

<footer class="main-footer">
            <div class="auto-container">
                <div class="footer-top">
                    <div class="widget-section">
                        <div class="row clearfix align">
                            <div class="col-lg-4 col-md-4 col-sm-12 footer-column">
                                <div class="footer-widget logo-widget">
                                    <!--<figure class="footer-logo"><img style="width: 60%;" src="<?php echo base_url() ; ?>admin/upload/logo/logo.png" alt=""></figure>-->
                                    <div class="text" style="
    color: #000;
">
                                        <br>
                                        <br>
                                      
                                        <p>“Savoury meats is your one-stop farm fresh meat online shop. The freshest meat &amp; seafood delivered directly to your doorstep. Now you can buy meat online anytime at your convenience. Our exclusive selection of Chicken, Mutton, Fish, Prawns, Crabs and Marinades.
                                        <!--All our products are completely natural and healthy. Once you have experienced with Savoury meats, you will never go back to the old way of buying seafood and meats.-->
                                        .”</p>     
                                    </div>
                                   
                                </div>
                            </div>
                             <div class="col-lg-3 col-md-3 col-sm-12 footer-column">
                                <div class="footer-widget logo-widget">
                            <figure class="footer-logo"><h5>STAY CONNECTED</h5></figure>
                                    <div class="text">
                                        
                            <ul class="info-list clearfix">
                          
    <!--                        <li style="-->
    <!--                        font-size: 27px;-->
    <!--font-style: bold;-->
    <!--font-style: bold !important;-->
    <!--color: #000;">Savoury Meat</li>-->
                            <li><i class="flaticon-location-pin"></i><a>No.13-4-561/19/B, New Ganga Nagar, Giaguda, Hyderabad - 500006, India</a></li>
                            <li>
                                <i class="flaticon-envelope"></i>
                               
                            </li>
                            <li class="phone">
                                <i class="flaticon-dial"></i><a>
                               +91- 9398370985</a>
                            </li>
                        </ul>
                                    </div> 
                    
                                   
                                </div>
                            </div>
                             <div class="col-lg-2 col-md-2 col-sm-12 footer-column">
                                <div class="footer-widget logo-widget">
                          <figure class="footer-logo" ><h5>COMPANY</h5></figure>
                                    <div class="text">
                         <!--<div class="copyright pull-left"><h5>&copy;2021 CopyRight <a href="">Savoury meats</a>. All rights reserved.</h5></div>-->
                    <ul class="footer-nav pull-right clearfix">
                        <li><a href="<?php echo base_url() ?>home" class="a11">Home</a></li>
                        <li><a href="<?php echo base_url() ?>about" class="a11">About</a></li>
                        
                        <li><a href="<?php echo base_url() ?>contact" class="a11">Contact</a></li>
                         <li><a href="<?php echo base_url() ?>terms" class="a11">Terms & Conditions</a></li>
                          <li><a href="<?php echo base_url() ?>policy" class="a11">Privacy Policy</a></li>
                    </ul>
                                    </div> 
                    
                                   
                                </div>
                            </div>
                            
                            <div class="col-lg-3 col-md-3 col-sm-12 footer-column">
                <figure class="footer-logo" style="margin-top: -30px;"><h5 style="
    margin-left: 51px;
">DOWNLOAD APP</h5></figure>
                                <ul>
                                    <li><a href="" target="_blank" rel="noopener noreferrer"> <img src="<?php echo base_url() ; ?>admin/upload/icon/playstore.png" alt="" title="" style="
                                        border-radius: 50%;
    display: flex;
    align-items: center;
    margin-left: 56px;
    justify-content: center;width: 160px"></a></li>
                    
</ul>
                                  
</div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                
                <div class="footer-bottom clearfix">
              
                </div>
            
        </footer>

        <!--Scroll to top-->
        <button class="scroll-top scroll-to-target" data-target="html">
            <span class="fa fa-arrow-up"></span>
        </button>
    </div>


    <!-- jequery plugins -->
    <script src="<?php echo base_url('');?>assets/js/jquery.js"></script>
    <script src="<?php echo base_url('');?>assets/js/popper.min.js"></script>
    <script src="<?php echo base_url('');?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url('');?>assets/js/owl.js"></script>
    <script src="<?php echo base_url('');?>assets/js/wow.js"></script>
    <script src="<?php echo base_url('');?>assets/js/validation.js"></script>
    <script src="<?php echo base_url('');?>assets/js/jquery.fancybox.js"></script>
    <script src="<?php echo base_url('');?>assets/js/appear.js"></script>
    <script src="<?php echo base_url('');?>assets/js/scrollbar.js"></script>
    <script src="<?php echo base_url('');?>assets/js/nav-tool.js"></script>

    <!-- main-js -->
    <script src="<?php echo base_url('');?>assets/js/script.js"></script>

</body><!-- End of .page_wrapper -->

<!-- Mirrored from azim.commonsupport.com/Carneshop/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 23 Nov 2021 05:43:09 GMT -->
</html>
<script>
  $(document ).ready(function() {
    <?php
    $msg = $this->session->userdata('msg');
    if(isset($msg)){
    ?>
    toastr.options.timeOut = =1500; // 1.5s
    toastr.<?php echo $this->session->userdata('type'); ?>("<?php echo $msg; ?>");
    <?php
    }
    $this->session->unset_userdata('msg'); 
    ?>
  });


</script>