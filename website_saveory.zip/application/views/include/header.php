<?php 
 $logged_in = $this->session->userdata('customer_id');

 $pincode = $this->session->userdata('pincode');
 

 
 if($pincode==''){
     $msg="Delivery Not availbale for this Location";
 }else{
     $msg="Delivery Available";
 }

if(!empty($logged_in)){
   $customer_id=$this->session->userdata('customer_id');
   if($customer_id==''){
   $customer_id=0; 
   }

}else{
    $customer_id=0;
}


   if($logged_in==""){
                   $login="style='display:block'";
                   $profile="style='display:none'";
              }else{
                  $login="style='display:none'";
                  $profile="style='display:block'";
              }

?>
    
<!DOCTYPE html>

<html lang="en" style="
    overflow-x: hidden;
" >
    

<!-- Mirrored from azim.commonsupport.com/Carneshop/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 23 Nov 2021 05:42:24 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

<title>Savoury Meat</title>

<!-- Fav Icon -->
<link rel="icon" href="<?php echo base_url() ?>admin/upload/logo/logo.png" type="image/x-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Heebo:wght@100;300;400;500;700;800;900&amp;display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300;0,400;0,500;0,700;0,900;1,300;1,400;1,500;1,700;1,900&amp;display=swap" rel="stylesheet">

<!-- Stylesheets -->
<link href="<?php echo base_url('');?>assets/css/font-awesome-all.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/flaticon.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/owl.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/bootstrap.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/jquery.fancybox.min.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/animate.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/color.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/style.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/responsive.css" rel="stylesheet">

<script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet"/>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>

<style>
    .main-menu .navigation > li.dropdown > .megamenu {
    position: absolute;
    width: 400px;
    padding: 30px;
    left: auto;
}


  .contact-section .form-inner .form-group input[type='text'], .contact-section .form-inner .form-group input[type='password'], .contact-section .form-inner .form-group textarea {
    position: relative;
    display: block;
    width: 100%;
    height: 60px;
    background: #fff;
    border: 2px solid #ededed;
    padding: 10px 50px 10px 20px;
    font-size: 16px;
    color: #565872;
    transition: all 500ms ease;
}



.logo a img {
  display: inline-block;
  max-width: 68% ;
  height: auto;
  transition-delay: .1s;
  transition-timing-function: ease-in-out;
  transition-duration: .7s;
  transition-property: all;
}


.shop-block-one .inner-box .image-box img {
    width: 100%;
    height: 200px !important;
}


.shop-block-one .inner-box .image-box {
    position: relative;
    display: block;
    background: #fff;
    border: 2px solid #fff;
    overflow: hidden;
    transition: all 500ms ease;
}
.shop-block-one .inner-box .image-box .short_describtion{
    position: absolute;
    top: 0;
    right: 0;
    border: #000;
     background: red;
     overflow: overlay;
     width: 30%;
     float: right;
     color: #fff;
     padding: 0px 6px;r
}
.fixed-header .sticky-header {
    z-index: 999;
    opacity: 1;
    visibility: visible;
    -ms-animation-name: fadeInDown;
    -moz-animation-name: fadeInDown;
    -op-animation-name: fadeInDown;
    -webkit-animation-name: fadeInDown;
    animation-name: fadeInDown;
    -ms-animation-duration: 500ms;
    -moz-animation-duration: 500ms;
    -op-animation-duration: 500ms;
    -webkit-animation-duration: 500ms;
    animation-duration: 500ms;
    -ms-animation-timing-function: linear;
    -moz-animation-timing-function: linear;
    -op-animation-timing-function: linear;
    -webkit-animation-timing-function: linear;
    animation-timing-function: linear;
    -ms-animation-iteration-count: 1;
    -moz-animation-iteration-count: 1;
    -op-animation-iteration-count: 1;
    -webkit-animation-iteration-count: 1;
    animation-iteration-count: 1;
}
.prawns{
    width: 40% !important;
}

@media only screen and (max-width: 991px)
{
.header-top {
    background: #da292a;
    display: none;
}
}
</style>
<style>.main-header .menu-right-content .cart-box {
    margin: 0px;
}</style>
</head>


<!-- page wrapper -->
<body  onload="myFunction()">

    <div class="boxed_wrapper ltr">

        <!-- preloader -->
        <div class="preloader" style="
        display:none;
        "
      ></div>
        <!-- preloader -->


        <!-- sidebar cart item -->
        <div class="xs-sidebar-group info-group info-sidebar">
            <div class="xs-overlay xs-bg-black"></div>
            <div class="xs-sidebar-widget">
                <div class="sidebar-widget-container">
                    <div class="widget-heading">
                        <a href="#" class="close-side-widget">X</a>
                    </div>
                    <div class="sidebar-textwidget">
                        <div class="sidebar-info-contents">
                            <div class="content-inner">
                                <div class="logo">
                                    <a href=""><img src="<?php echo base_url() ?>admin/upload/logo/logo.png"  alt="" id="logo_img" /></a>
                                </div>
                                <div class="content-box">
                                    <h4>About Us</h4>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                                    <a href="" class="theme-btn">About Us<i class="fas fa-long-arrow-alt-right"></i></a>
                                </div>
                                <div class="contact-info">
                                    <h4>Contact Info</h4>
                                    <ul>
                                        <li>Burgeon Impex Private Limited </li>
                                        <li>No. 5/13, Karunanithi Street, Ambethkar Nagar, Chitlapakkam, Chennai 600063, Tamil Nadu, India</li>
                                        <li><a href="tel:+91- 9398370985">+91- 9398370985</a></li>
                                        <li><a href="mailto:savourymeats@yahoo.com">savourymeats@yahoo.com</a></li>
                                    </ul>
                                </div>
                                <ul class="social-box">
                                    <li class="facebook"><a href="#" class="fab fa-facebook-f"></a></li>
                                    <li class="twitter"><a href="#" class="fab fa-twitter"></a></li>
                                    <li class="linkedin"><a href="#" class="fab fa-linkedin-in"></a></li>
                                    <li class="instagram"><a href="#" class="fab fa-instagram"></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END sidebar widget item -->


        <!-- main header -->
        <header class="main-header">
            <div class="header-top">
                <div class="auto-container">
                    <div class="top-info">
                        <ul class="info-list clearfix">
                            <li  type="button" class="btn" data-toggle="modal" data-target=".bd-example-modal-lg ">
                                <i class="flaticon-location-pin"></i>
                               <?php echo $msg; ?>
                            </li>
                            <li>
                                <i class="flaticon-envelope"></i>
                                <a href="mailto:savourymeats@yahoo.com">savourymeats@yahoo.com</a>
                            </li>
                            <li class="phone">
                                <i class="flaticon-dial"></i>
                                <a href="tel:+91- 9398370985">+91- 9398370985</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="header-upper">
                <div class="auto-container">
                    <div class="outer-box clearfix">
                        <div class="logo-box">
                            <figure class="logo"><a href="">
                                 <!--  <?php
                                $CI =& get_instance();
                                $CI->load->model('Home_model');
                                $result = $CI->Home_model->get_logo();
                                ?>-->
                             
                                    <?php foreach($logo as $bas) {
                     
                                    
                                    ?>
                                                              <img src="<?php echo base_url() ?>admin/<?php echo $bas['logo_image']; ?>" alt="" style="width: 150px;">
                                                           
                                                            <?php  } ?>
                                
                                </a></figure>
                        </div>
                        <div class="menu-area pull-right">
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler">
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                            </div>
                            <nav class="main-menu navbar-expand-md navbar-light">
                                <div class="collapse navbar-collapse show clearfix" id="navbarSupportedContent">
                                   
                                    <ul class="navigation clearfix">
                                            <li>
                                        <div class="search" style="border: 1px solid;
    border-radius: -2px;
    padding: 0 16px;
    background: #efefef;
    border-radius: 20px;">
                                    <form method="post" class="form" action="<?= base_url() ?>Home/search_book_1">
             
              <input type="text" name="search_book" list="book_names" id="names" class="search" onkeyup="searchBook(this.value)" placeholder="Search Products" style="width: 290px;
    height: 33px;  background: #efefef;"/>
              <datalist id="book_names" style="width: 50px;" ></datalist>
            
              <button type="submit" ><i class="fas fa-search"></i></button>
             
             </form>   
</div> 
                                </li>
                                        <li><a href="<?php echo base_url();?>">Home</a>
                                     
                                        </li> 
                                        <li><a href="<?php echo base_url('about');?>">About</a></li> 
                                       
                                      <style>
/*                                            .main-menu .navigation > li > ul > li > a, .main-menu .navigation > li > .megamenu li > a {*/
/*    position: relative;*/
/*    display: block;*/
/*    padding: 15px 30px !important;*/
/*    line-height: 24px;*/
/*    font-weight: 500;*/
/*    font-family: "Rubik", sans-serif;*/
/*    font-size: 15px;*/
/*    text-transform: capitalize;*/
/*    color: #fff;*/
/*    border-bottom: 1px solid rgba(34, 34, 34, 0.1);*/
/*    text-align: left;*/
/*    transition: all 500ms ease;*/
/*    -moz-transition: all 500ms ease;*/
/*    -webkit-transition: all 500ms ease;*/
/*    -ms-transition: all 500ms ease;*/
/*    -o-transition: all 500ms ease;*/
/*}*/
/*.main-menu .navigation li.dropdown .megamenu li h4 {*/
/*    font-size: 20px;*/
/*    line-height: 28px;*/
/*    font-weight: 500;*/
/*    padding: 3px 0px;*/
/*    color: #fff;*/
/*    text-align: left;*/
/*    margin-bottom: 10px;*/
/*}*/

.main-menu .navigation > li.dropdown > .megamenu {
    position: absolute;
    width: 266px;
    padding: 30px;
    left: auto;
}
.theme-btn {
    background: #6863bf;
    color: #fff !important;
}
.header-top .top-info .info-list li {
    position: relative;
    display: inline-block;
    float: left;
    padding-left: 25px;
    font-size: 14px;
    line-height: 26px;
    color: #ffffff;
    margin-right: 25px;
}
.header-top .top-info .info-list li a {
    color: #ffffff;
}
.main-header .menu-right-content .user-box {
    margin-right: 0px;
}

                                        </style>
                                        <li class="dropdown"><a href="<?php echo base_url('product');?>">Products</a>
                                           <div class="megamenu" >
                                                <div class="row clearfix" >
                                                    <div class="col-lg-12 column">
                                                        <ul>
                                                        <!-- <div style="overflow-y: scroll;  height:400px;"> -->
                                                            <li><h4>Category</h4></li>
                                                            
                                                                        <?php
                                                                        $i=1; 
                                                                        foreach($category as $ban) {
                                                                            
                                                                            ?>
                                                                        <li style=" width:100%;"><a href="<?php echo base_url('Home/get_category1').'/'.$ban['category_id'];?>"><?php echo $ban['category_name']; ?></a></li>
                                                        
                                                            <?php $i++; } ?>
                                                                        <!-- </div> -->
                                                        </ul>
                                                    </div>
                                                                                  
                                                </div>                                           
                                            </div>
                                        </li>       
                                       <!-- <li class="dropdown"><a href="">News</a>
                                            <ul>
                                                <li><a href="">Our Blog</a></li>
                                                <li><a href="">Blog Details</a></li>
                                            </ul>
                                        </li>!--> 
                                        <li><a href="<?php echo base_url('contact');?>">Contact</a></li>               
                                    </ul>
                                       
                                </div>
                                
                                 
                            </nav>
                            <ul class="menu-right-content pull-left clearfix">
                                <?php  if($customer_id==0){?>
                                <li class="user-box" style="text-align:center;    color: #000;   
    font-weight: 500;"><a href="<?php echo base_url('login');?>" class="theme-btn" style=" font-size: 13px;padding: 5px 20px;
    margin-top: 11px;">Login/Register
      </a></li>
                               <?php }else{ ?>
                                <li class="user-box" style="margin-top: 11px; text-align:center;    color: #000;
    font-weight: 500;">
                                    <a href="<?php echo base_url('profile');?>"><img src="<?php echo base_url() ?>admin/upload/icon/user.png" style="width:31px; margin-right:10px;" alt="" <?php echo $profile; ?> ></a>
                                    <!--<br>profile-->
                                    </li>
                                 <!-- <li class="cart-box">
                                   
                                     <a href="<?php echo base_url('cart') ?>" > <img src="<?php echo base_url() ?>admin/upload/icon/checkout.png" style="width: 29px;
    margin-right: 9px;
    margin-top: -42px;" alt=""  <?php echo $login;  ?> ></a></li> -->
                               <?php  } ?>
                                        
                                         <li class="cart-box">
                                         
                                   <a href="<?php echo base_url('cart') ?>" ><i class="flaticon-shopping-cart-1"></i>
            <span >  <?php echo $count;?></span></a>
                                                                    
             </li> 
                                
                              
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <nav class="main-menu navbar-expand-md navbar-light" style="width: 100% !important;background: #f7b500;">
              <div class="header-upper" >
              
                        </div>
                    </div>
                </div>
            </div>

            <!--sticky Header-->
           <div class="sticky-header">
                <div class="auto-container">
                    <div class="outer-box clearfix">
                        <figure class="logo-box pull-left"><a href=""><img src="<?php echo base_url() ?>admin/upload/logo/logo.png" alt=""></a></figure>
                        <div class="menu-area pull-right">
                            <nav class="main-menu clearfix">
                            </nav>
                        </div>
                    </div>
                </div>
            </div> 
        </header>
        <!-- main-header end -->

        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><i class="fas fa-times"></i></div>
            
            <nav class="menu-box">
                <div class="nav-logo"><a href=""><img src="<?php echo base_url() ?>admin/upload/logo/logo.png" alt="" title=""></a></div>
                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
                <div class="contact-info">
                    <h4>Contact Info</h4>
                    <ul>
                    <li>Savoury Meat </li>
                                        <li>No.13-4-561/19/B, New Ganga Nagar, Giaguda, Hyderabad - 500006</li>
                        <li><a href="tel:+91- 7305787888,  9884776181">9398370985</a></li>
                        <li><a href="mailto:savourymeats@yahoo.com">savourymeats@yahoo.com</a></li>
                    </ul>
                </div>
                <div class="social-links">
                    <ul class="clearfix">
                        <li><a href=""><span class="fab fa-twitter"></span></a></li>
                        <li><a href=""><span class="fab fa-facebook-square"></span></a></li>
                        <li><a href=""><span class="fab fa-pinterest-p"></span></a></li>
                        <li><a href=""><span class="fab fa-instagram"></span></a></li>
                        <li><a href=""><span class="fab fa-youtube"></span></a></li>
                    </ul>
                </div>
            </nav>
        </div><!-- End Mobile Menu -->


<!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade " id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Choose Delivery Location</h5>
        <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button> -->
      </div>
      <div class="modal-body">
        <form action="<?php echo base_url() ?>Home/validate_pincode" method="post">
          <div class="form-group">
            <input type="text" style="" class="form-control" name="picode" id="DelLocation" value="" aria-describedby="pinocdeHelp" placeholder="Please Enter Delivery Pincode" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1')" minlength="6" maxlength="6">
          </div>
          
         <div class="location">
         <br>
         <p><strong>Serviceable Locations :   </strong></p>
         <p>Note - Please enter a valid pincode to check service availability. </p>
         </div>
          <div class="modal-footer">
        <button type="submit" name="submit" value="submit" class="btn btn-warning text-white">Save</button>
         </div>
        </form>
      </div>
    
    </div>
  </div>
</div>


<!-- Large modal -->
<!-- <button type="button" class="btn" data-toggle="modal" data-target=".bd-example-modal-lg">Large modal</button> -->

<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="">
  <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
  <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalCenterTitle">Choose Delivery Location</h5>
        <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button> -->
      </div>
      <div class="modal-body">
        <form action="<?php echo base_url() ?>Home/validate_pincode" method="post">
          <div class="form-group">
            <input type="text" style="" class="form-control" name="picode" id="DelLocation" value="" aria-describedby="pinocdeHelp" placeholder="Please Enter Delivery Pincode" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1')" minlength="6" maxlength="6">
          </div>
          
         <div class="location">
         <br>
         <p><strong>Serviceable Locations :  </strong></p>
         <p>Note - Please enter a valid pincode to check service availability.</p>
         </div>
          <div class="modal-footer">
        <button type="submit" name="submit" value="submit" class="btn btn-warning text-white">Save changes</button>
     </div>
        </form>
      </div>
    
    </div> 
  </div>
</div>
<style>
    /*section{*/
    /*    padding-top: 84px;*/
    /*}*/
    .shop-block-one .inner-box .lower-content h6 a {
    display: inline-block;
    color: #282932;
    font-size: 18px;
    display: inline-block;
    color: #000 !important;
    font-weight: 600;
}
.product-details-content .product-details h2 {
    position: relative;
    display: block;
    font-size: 40px;
    line-height: 48px;
    color: #ffffff;
    font-weight: 500;
    margin-bottom: 3px;
}
h1, h2, h3, h4, h5, h6 {
    position: relative;
    font-family: "Heebo", sans-serif;
    font-weight: 400;
    color: #ffffff;
    margin: 0px;
    transition: all 500ms ease;
}
.product-details-content .product-details .other-links ul li {
    position: relative;
    display: inline-block;
    font-size: 16px;
    color: #ffffff;
    font-weight: 700;
}
.product-details-content .product-details .other-links ul li a {
    font-weight: 400;
    color: #ffffff;
}
.shop-section {
    position: relative;
    background: #fff;
    padding: 115px 0px 120px 0px;
}
</style>


