<?php 
 $logged_in = $this->session->userdata('customer_id');
 $user_type = $this->session->userdata('user_type');

if(!empty($logged_in)){
   $customer_id=$this->session->userdata('customer_id');
   if($customer_id==''){
   $customer_id=0; 
   }

}else{
    $customer_id=0;
}


?>

<style>
    .shop-block-one .inner-box .image-box .short_describtion {
    position: absolute!important;
    bottom: 0!important;
    right: 0!important;
    border: #000!important;
    background: red!important;
    overflow: overlay!important;
    width: 80%!important;
    float: right!important;
    color: #fff!important;
    padding: 0px 6px!important;
    font-size: 10px !important;
    top: auto !important;
}

.shop-block-one .inner-box .image-box .list {
    position: absolute;
    top: 50%;
    /* left: 50%; */
    /* left: 50%; */
    /* bottom: -50px; */
    visibility: hidden;
    transition: all 500ms ease;
    text-align: center;
    margin-left: 55px;
    /* margin-top: -4px; */
    /* right: 50%; */
}

div.a {
  white-space: nowrap; 
  width: 100px; 
  overflow: hidden;
  text-overflow: ellipsis;
  border: 1px solid #000000;
}

div.a:hover {
  overflow: visible;
}
</style>
    

        <!-- shop-page-section -->
        <section class="shop-page-section sec-pad">
            <div class="auto-container">
                <div class="row clearfix">
                  
                    <div class="col-lg-12 col-md-12 col-sm-12 content-side">
                        <div class="our-shop">
                          <div class="row clearfix">
                            <?php
                           $i=1; 
                           foreach($products_list as $ban) {
                              $id=$ban['product_id'];
                              $cat=$ban['category_id'];
                              // $type=$ban['type'];
                             ?>
                              
                             <div class="col-lg-3 col-md-6 col-sm-12 shop-block">
                                    <div class="shop-block-one">
                               
                                        <div class="inner-box">
                                           
                                            <figure class="image-box">
                                            <img src="<?php echo base_url('');?>admin/<?php echo $ban['pro_image']; ?>" alt='' width='' height=''>
                                          
                                                <ul class="list clearfix">
                                                    <!-- <li><a href=""><i class="flaticon-cart"></i></a></li> -->
                                                    <li><button type="button" onclick="addProduct(<?php echo $id; ?>,<?php echo $customer_id; ?>);" class="theme-btn">Add to cart</button>
                                                </ul>
                                                <!-- <div style="" class="short_describtion"> <?php echo $ban['short_description'];?></div>
                                                  <?php if($type=='new') { ?>  
                                                   <div class='new'>
                                                        NEW
                                                     </div>
                                                    <?php } ?> -->
                                            </figure>
                                            <p onclick="wishList(<?php echo $id; ?>,<?php echo $customer_id; ?>);"></a><i class="fas fa-heart" style="
    color: red;
"></i></p>
                                            <div class="lower-content">
                                                <h6><a href="<?php echo base_url();?>product_details/<?php echo $id; ?>/<?php echo $cat; ?>"><?php echo $ban['product_name']; ?>
                                            </a></h6>
                                            <h6 id="mrp">MRP : ₹<?php 
                    if($user_type=="holesale"){
                      echo $ban['holesale_price']; 
                    }else{
                      echo $ban['price'];
                    }
                    
                    
                    
                  ?></h6> 
                                            <!-- <h6> Grs wt : <?php echo $ban['gross_weight']; ?>&nbsp;&nbsp;&nbsp;  Net wt : <?php echo $ban['net_weight']; ?></h6> -->
                                           <h6 >   <?php echo $ban['description']; ?></h6>
                                            
                                            </div>
                                        </div>
                       
                                    </div>
                                </div>
                                <?php $i++; } ?>


                               
                            </div>
                            <div class="pagination-wrapper centred">
                               <!-- <ul class="pagination clearfix">
                                    <li><a href="" class="active">1</a></li>
                                    <li><a href="">2</a></li>
                                    <li><a href="">3</a></li>
                                </ul>!-->
                           </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> <!-- shop-page-section end -->
        <script>
       function addProduct(id,customer_id){
  
  // var size = $('#sizes').val();


  if(customer_id==0){
    toastr.error('Please Login');
    redirect('login');
  }else{
      $.ajax({
     method:"POST",
     url:"<?php echo base_url('Savoury_website_controller/addtocart') ?>",
     data:{id:id,
       customer_id:customer_id
     },
   
     success:function(data){

       console.log(data);
       datas = JSON.parse(data);

       if(datas.color=='ok'){
                    toastr.success(datas.msg);
                    location.reload(true);
                  }else{
                    toastr.error(datas.msg);
                  }
        
     }
 });

  }
 }

 function wishList(id,customer_id){
  
  // var size = $('#sizes').val();


  if(customer_id==0){
    toastr.error('Please Login');
    redirect('login');
  }else{
      $.ajax({
     method:"POST",
     url:"<?php echo base_url('Home/add_wishlist') ?>",
     data:{id:id,
       customer_id:customer_id
     },
   
     success:function(data){

       console.log(data);
       datas = JSON.parse(data);

       if(datas.color=='ok'){
                    toastr.success(datas.msg);
                  }else{
                    toastr.error(datas.msg);
                  }
        
     }
 });

  }
 }
        </script>

