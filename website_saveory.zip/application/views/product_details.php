<?php 
 $logged_in = $this->session->userdata('customer_id');
 $user_type = $this->session->userdata('user_type');

if(!empty($logged_in)){
   $customer_id=$this->session->userdata('customer_id');
   if($customer_id==''){
   $customer_id=0; 
   }

}else{
    $customer_id=0;
}


?>
    
<style>
    .shop-block-one .inner-box .image-box .short_describtion {
    position: absolute!important;
    bottom: 0!important;
    right: 0!important;
    border: #000!important;
    background: red!important;
    overflow: overlay!important;
    width: 80%!important;
    float: right!important;
    color: #fff!important;
    padding: 0px 6px!important;
    font-size: 10px !important;
    top: auto !important;
}

.shop-block-one .inner-box .image-box .list {
    position: absolute;
    top: 50%;
    /* left: 50%; */
    /* left: 50%; */
    /* bottom: -50px; */
    visibility: hidden;
    transition: all 500ms ease;
    text-align: center;
    margin-left: 55px;
    /* margin-top: -4px; */
    /* right: 50%; */
}

div.a {
  white-space: nowrap; 
  width: 100px; 
  overflow: hidden;
  text-overflow: ellipsis;
  border: 1px solid #000000;
}

div.a:hover {
  overflow: visible;
}
h1, h2, h3, h4, h5, h6 {
    position: relative;
    font-family: "Rubik", sans-serif !important;
    font-weight: 400;
    color: #000;
    margin: 0px;
    transition: all 500ms ease;
}
</style>

        <section class="shop-details sec-pad" style=" padding-top: 160px !important;">
            <div class="auto-container">
                <?php foreach($product1 as $pro) {
                    $id=$pro['product_id'];
                    ?>
                <div class="product-details-content">
                    <div class="row align-items-center clearfix">
                        <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                            <div class="slider-inner">
                                <div class="bxslider">
                                  
                                      
                                        <div class="product-image">
                                            <figure class="image"><a href="<?php echo base_url() ?>admin/<?php echo $pro['pro_image'] ?>" class="lightbox-image" data-fancybox="gallery"><img src="<?php echo base_url() ?>admin/<?php echo $pro['pro_image'] ?>" alt="" style="width:100% ; height:300px;margin-top: -27%;"></a></figure>
                                        </div>
                                   
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                            <div class="product-details">
                                <h2><?php echo $pro['product_name'];?></h2>
                              
                                <div class="item-price"><h6 id="mrp">MRP : ₹<?php 
                    if($user_type=="holesale"){
                      echo $pro['holesale_price']; 
                    }else{
                      echo $pro['price'];
                    }
                    
                    
                    
                  ?>.00</h6>  
                                        <!-- <h6> Grs wt : <?php echo $pro['gross_weight']; ?>&nbsp;&nbsp;&nbsp;  Net wt : <?php echo $pro['net_weight']; ?></h6> -->
                                        </div>
                                <div class="text">
                                    <p><h6>   <?php echo $pro['description']; ?></h6></p>
                                </div>
                                <div class="other-links">
                                    <ul class="category list clearfix">
                                        <li>Category:</li>
                                        <li><a href=""> <?php echo $pro['category_name']; ?></a></li>
                                    </ul>
                                   
                                </div>
                                <div class="othre-options clearfix">
                                    
                                    <div class="item-quantity">
                                        <input class="quantity-spinner" id="qty" type="number" min="1" value="1" name="quantity">
                                    </div>
                                    <div class="btn-box"><button type="button" onclick="addProduct(<?php echo $id; ?>,<?php echo $customer_id; ?>);" class="theme-btn">Add to cart</button></div>
                                    
                                </div>
                                <p  style="
    color: #000;
"onclick="wishList(<?php echo $id; ?>,<?php echo $customer_id; ?>);"></a><i class="fas fa-heart" style="
    color: red;
"></i>Wishlist</p>
                            </div>
                        </div>
                    </div>
                </div>
                <?php } ?>
        
                <div class="related-product">
                    <div class="sec-title style-two centred">
                        <h2>Similar Products</h2>
                    </div>
                    <div class="row clearfix">
                        <?php foreach($products as $pro)  {
                            $id=$pro->product_id;
                            $cat=$pro->category_id;
                            ?>
                        <div class="col-lg-3 col-md-6 col-sm-12 shop-block">
                            <div class="shop-block-one">
                                <div class="inner-box">
                                    <figure class="image-box">
                                        <img src="<?php echo base_url() ?>admin/<?php echo $pro->pro_image; ?>" class="lightbox-image" data-fancybox="gallery">
                                        <ul class="list clearfix">
                                            <!-- <li><a href=""><i class="flaticon-cart"></i></a></li> -->
                                            <li><button type="button" onclick="addProduct(<?php echo $id; ?>,<?php echo $customer_id; ?>);" class="theme-btn">Add to cart</button></li>
                                        </ul>
                                    </figure>
                                    <p onclick="wishList(<?php echo $id; ?>,<?php echo $customer_id; ?>);"></a><i class="fas fa-heart" style="
    color: red;
"></i></p>
                                    <div class="lower-content">
                                        <h6><a href="<?php echo base_url();?>Home/product_details?id=<?php echo $id; ?>&cat=<?php echo $cat; ?>"><?php echo $pro->product_name?></a></h6>
                                        
                                        <!-- <ul class="rating clearfix">
                                            <li><i class="fas fa-star"></i></li>
                                            <li><i class="fas fa-star"></i></li>
                                            <li><i class="fas fa-star"></i></li>
                                            <li><i class="fas fa-star"></i></li>
                                            <li><i class="fas fa-star"></i></li>
                                        </ul> -->
                                       
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php } ?>
                        
                    </div>
                </div>
            </div>
        </section>
        <!-- shop-details end -->
        <script>
      function addProduct(id,customer_id){
  
   var qty = $('#qty').val();
        //alert(qty);

  
      $.ajax({
     method:"POST",
     url:"<?php echo base_url('Savoury_website_controller/addtocartproduct') ?>",
     data:{id:id,
       customer_id:customer_id,
       qty:qty
     },
   
     success:function(data){

       console.log(data);
       datas = JSON.parse(data);

       if(datas.color=='ok'){
                    toastr.success(datas.msg);
                    location.reload(true);
                  }else{
                    toastr.error(datas.msg);
                  }
        
     }
 });

  
 }


//  function wishList(id,customer_id){
  
//   // var size = $('#sizes').val();


//   if(customer_id==0){
//     toastr.error('Please Login');
//     redirect('login');
//   }else{
//       $.ajax({
//      method:"POST",
//      url:"<?php echo base_url('Home/add_wishlist') ?>",
//      data:{id:id,
//        customer_id:customer_id
//      },
   
//      success:function(data){

//        console.log(data);
//        datas = JSON.parse(data);

//        if(datas.color=='ok'){
//                     toastr.success(datas.msg);
//                   }else{
//                     toastr.error(datas.msg);
//                   }
        
//      }
//  });

//   }
//  }
function wishList(id,customer_id){
  
  // var size = $('#sizes').val();


  if(customer_id==0){
    toastr.error('Please Login');
    redirect('login');
  }else{
      $.ajax({
     method:"POST",
     url:"<?php echo base_url('Home/add_wishlist') ?>",
     data:{id:id,
       customer_id:customer_id
     },
   
     success:function(data){

       console.log(data);
       datas = JSON.parse(data);

       if(datas.color=='ok'){
                    toastr.success(datas.msg);
                    location.reload(true);
                  }else{
                    toastr.error(datas.msg);
                  }
        
     }
 });

  }
 }
        </script>
      