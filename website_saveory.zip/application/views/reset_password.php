
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from azim.commonsupport.com/Carneshop/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 23 Nov 2021 05:42:24 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

<title>Currykrave</title>

<!-- Fav Icon -->
<link rel="icon" href="assets/images/currykrave_logo.png" type="image/x-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Heebo:wght@100;300;400;500;700;800;900&amp;display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300;0,400;0,500;0,700;0,900;1,300;1,400;1,500;1,700;1,900&amp;display=swap" rel="stylesheet">

<!-- Stylesheets -->

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="css/style.css" />

<link href="<?php echo base_url('');?>assets/css/font-awesome-all.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/flaticon.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/owl.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/bootstrap.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/jquery.fancybox.min.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/animate.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/color.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/style.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/responsive.css" rel="stylesheet">

<style>
    .main-menu .navigation > li.dropdown > .megamenu {
    position: absolute;
    width: 50%;
    padding: 30px 50px;
    left: auto;
}


  .contact-section .form-inner .form-group input[type='text'], .contact-section .form-inner .form-group input[type='password'], .contact-section .form-inner .form-group textarea {
    position: relative;
    display: block;
    width: 100%;
    height: 60px;
    background: #fff;
    border: 2px solid #ededed;
    padding: 10px 50px 10px 20px;
    font-size: 16px;
    color: #565872;
    transition: all 500ms ease;
}



img {
  display: inline-block;
  max-width: 68%;
  height: auto;
  transition-delay: .1s;
  transition-timing-function: ease-in-out;
  transition-duration: .7s;
  transition-property: all;
}


</style>
<style>
 form i {
    margin-left: -30px;
    cursor: pointer;
}
</style>

</head>


<!-- page wrapper -->
<body>

    <div class="boxed_wrapper ltr">

        <!-- preloader -->
        <div class="preloader" style="
        display:none;
        "
      ></div>
        <!-- preloader -->


        <!-- sidebar cart item -->
        <div class="xs-sidebar-group info-group info-sidebar">
            <div class="xs-overlay xs-bg-black"></div>
            <div class="xs-sidebar-widget">
                <div class="sidebar-widget-container">
                    <div class="widget-heading">
                        <a href="#" class="close-side-widget">X</a>
                    </div>
                    <div class="sidebar-textwidget">
                        <div class="sidebar-info-contents">
                            <div class="content-inner">
                                <div class="logo">
                                    <a href=""><img src="assets/images/currykrave_logo.png"  alt="" /></a>
                                </div>
                                <!-- <div class="content-box">
                                    <h4>About Us</h4>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                                    <a href="" class="theme-btn">About Us<i class="fas fa-long-arrow-alt-right"></i></a>
                                </div> -->
                                <!-- <div class="contact-info">
                                    <h4>Contact Info</h4>
                                    <ul>
                                        <li>Chicago 12, Melborne City, USA</li>
                                        <li><a href="tel:+8801682648101">+88 01682648101</a></li>
                                        <li><a href="mailto:info@example.com">info@example.com</a></li>
                                    </ul>
                                </div> -->
                                <!-- <ul class="social-box">
                                    <li class="facebook"><a href="#" class="fab fa-facebook-f"></a></li>
                                    <li class="twitter"><a href="#" class="fab fa-twitter"></a></li>
                                    <li class="linkedin"><a href="#" class="fab fa-linkedin-in"></a></li>
                                    <li class="instagram"><a href="#" class="fab fa-instagram"></a></li>
                                </ul> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END sidebar widget item -->


        <!-- main header -->
        <header class="main-header">
            <div class="header-top">
                <div class="auto-container">
                    <!-- <div class="top-info">
                        <ul class="info-list clearfix">
                            <li>
                                <i class="flaticon-location-pin"></i>
                                219 Bedford Street Birmingham, AL 35211
                            </li>
                            <li>
                                <i class="flaticon-envelope"></i>
                                <a href="mailto:info@example.com">info@example.com</a>
                            </li>
                            <li class="phone">
                                <i class="flaticon-dial"></i>
                                <a href="tel:234554657345">+234 554 657 345</a>
                            </li>
                        </ul>
                    </div> -->
                </div>
            </div>
            <div class="header-upper">
                <div class="auto-container">
                    <div class="outer-box clearfix">
                        <div class="logo-box">
                            <figure class="logo"><a href=""><img src="assets/images/currykrave_logo.png" alt=""></a></figure>
                        </div>
                        <div class="menu-area pull-right">
                            <!--Mobile Navigation Toggler-->
                            <div class="mobile-nav-toggler">
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                                <i class="icon-bar"></i>
                            </div>
                            <nav class="main-menu navbar-expand-md navbar-light">
                             
                            </nav>
                            <!-- <ul class="menu-right-content pull-left clearfix">
                                <li class="user-box"><a href="<?php echo base_url();?>"><i class="flaticon-user-symbol-of-thin-outline"></i></a><?php echo $this->session->userdata('mobile_no'); ?></li>
                                <li class="search-box-outer">
                                    <div class="dropdown">
                                        <button class="search-box-btn" type="button" id="dropdownMenu3" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="flaticon-search"></span></button>
                                        <ul class="dropdown-menu pull-right search-panel" aria-labelledby="dropdownMenu3">
                                            <li class="panel-outer">
                                                <div class="form-container">
                                                    <form method="post" action="">
                                                        <div class="form-group">
                                                            <input type="search" name="field-name" value="" placeholder="Search...." required="">
                                                            <button type="submit" class="search-btn"><span class="fas fa-search"></span></button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </li>
                                <li class="cart-box"><a href=""><i class="flaticon-shopping-cart-1"></i><span>0</span></a></li>
                                <li class="nav-box">
                                    <div class="nav-btn nav-toggler navSidebar-button clearfix">
                                        <i class="flaticon-list"></i>
                                    </div>
                                </li>
                            </ul> -->
                        </div>
                    </div>
                </div>
            </div>

            <!--sticky Header-->
            <div class="sticky-header">
                <div class="auto-container">
                    <div class="outer-box clearfix">
                        <figure class="logo-box pull-left"><a href=""><img src="assets/images/small-logo.png" alt=""></a></figure>
                        <div class="menu-area pull-right">
                            <nav class="main-menu clearfix">
                                <!--Keep This Empty / Menu will come through Javascript-->
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- main-header end -->

        <!-- Mobile Menu  -->
        
<section class="contact-section centred">
            <div class="auto-container">
                <div class="sec-title">
                <br><br><br>
                    <h2>Change Password</h2>
                </div>
                <div class="form-inner">
                    <form method="post" action="<?php echo base_url("Savoury_website_controller/change_forgot_password_post");?>" id="contact-form" class="default-form"> 
                        <div class="row clearfix">
                           
                             <div class="col-lg-12 col-md-12 col-sm-12">
                              <center>
                              <div class="col-lg-6 col-md-6 col-sm-12">
                                <div class="form-group">
                                <input type="password" name="password" required="" placeholder="password"  autocomplete="current-password" required="" id="password">
                                    <i class="bi bi-eye-slash" id="togglePassword"></i>
                                </div>
                                <center>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12">
                            <center>
                                <div class="form-group">
                                <input type="password" name="confirm_password"  placeholder="Confirm Password" required="" id="confirm_password">
                                    <i class="bi bi-eye-slash" id="togglePassword1"></i> 
                                </div>
                                <center>
                            </div>
                            
                            <div class="col-lg-12 col-md-12 col-sm-12 form-group message-btn centred">
                                <button class="theme-btn" type="submit" name="submit-form">
                                    <a href="<?php echo base_url();?>">Change Password</a>
                                </button> 

                            </div>
                            
                            <div class="col-lg-12 col-md-12 col-sm-12 form-group message-btn centred">
                               <a href="<?php echo base_url();?>">Back</a>
                               
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>
        <script>
        const togglePassword = document.querySelector('#togglePassword');
        const password = document.querySelector('#password');

        togglePassword.addEventListener('click', function (e) {
            // toggle the type attribute
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
            // toggle the eye / eye slash icon
            this.classList.toggle('bi-eye');
});
const togglePassword1 = document.querySelector('#togglePassword1');
        const confirm_password = document.querySelector('#confirm_password');
        
        togglePassword1.addEventListener('click', function (e) {
            // toggle the type attribute
            const type = confirm_password.getAttribute('type') === 'password' ? 'text' : 'password';
            confirm_password.setAttribute('type', type);
            // toggle the eye / eye slash icon
            this.classList.toggle('bi-eye');
});
        </script>