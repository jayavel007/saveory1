
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from azim.commonsupport.com/Carneshop/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 23 Nov 2021 05:42:24 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

<title>Currykrave</title>

<!-- Fav Icon -->
<link rel="icon" href="assets/images/currykrave_logo.png" type="image/x-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Heebo:wght@100;300;400;500;700;800;900&amp;display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300;0,400;0,500;0,700;0,900;1,300;1,400;1,500;1,700;1,900&amp;display=swap" rel="stylesheet">

<!-- Stylesheets -->
<link href="<?php echo base_url('');?>assets/css/font-awesome-all.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/flaticon.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/owl.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/bootstrap.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/jquery.fancybox.min.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/animate.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/color.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/style.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/responsive.css" rel="stylesheet">

<style>
    .main-menu .navigation > li.dropdown > .megamenu {
    position: absolute;
    width: 50%;
    padding: 30px 50px;
    left: auto;
}
.logo a img {
    display: inline-block;
    max-width: 25%;
    height: auto;
    margin-left: -82px;
    margin-top: 53px;
    transition-delay: .1s;
    transition-timing-function: ease-in-out;
    transition-duration: .7s;
    transition-property: all;
}

  .contact-section .form-inner .form-group input[type='text'], .contact-section .form-inner .form-group input[type='password'], .contact-section .form-inner .form-group textarea {
    position: relative;
    display: block;
    width: 100%;
    height: 60px;
    background: #fff;
    border: 2px solid #ededed;
    padding: 10px 50px 10px 20px;
    font-size: 16px;
    color: #565872;
    transition: all 500ms ease;
}



img {
  display: inline-block;
  max-width: 68%;
  height: auto;
  transition-delay: .1s;
  transition-timing-function: ease-in-out;
  transition-duration: .7s;
  transition-property: all;
}


</style>

</head>

<!-- page wrapper -->
<body>

    <div class="boxed_wrapper ltr">

        <!-- preloader -->
        <div class="preloader" style="
        display:none;
        "
      ></div>
        <!-- preloader -->


        <!-- sidebar cart item -->
        <div class="xs-sidebar-group info-group info-sidebar">
            <div class="xs-overlay xs-bg-black"></div>
            <div class="xs-sidebar-widget">
                <div class="sidebar-widget-container">
                    <div class="widget-heading">
                        <a href="#" class="close-side-widget">X</a>
                    </div>
                    <!-- <div class="sidebar-textwidget">
                        <div class="sidebar-info-contents">
                            <div class="content-inner">
                                <div class="logo">
                                    <a href=""><img src="assets/images/currykrave_logo.png"  alt="" /></a>
                                </div>
                                <div class="content-box">
                                    <h4>About Us</h4>
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                                    <a href="" class="theme-btn">About Us<i class="fas fa-long-arrow-alt-right"></i></a>
                                </div>
                                <div class="contact-info">
                                    <h4>Contact Info</h4>
                                    <ul>
                                        <li>Chicago 12, Melborne City, USA</li>
                                        <li><a href="tel:+8801682648101">+88 01682648101</a></li>
                                        <li><a href="mailto:info@example.com">info@example.com</a></li>
                                    </ul>
                                </div>
                                <ul class="social-box">
                                    <li class="facebook"><a href="#" class="fab fa-facebook-f"></a></li>
                                    <li class="twitter"><a href="#" class="fab fa-twitter"></a></li>
                                    <li class="linkedin"><a href="#" class="fab fa-linkedin-in"></a></li>
                                    <li class="instagram"><a href="#" class="fab fa-instagram"></a></li>
                                </ul>
                            </div>
                        </div>
                    </div> -->
                </div>
            </div>
        </div>
        <!-- END sidebar widget item -->


        <!-- main header -->
        <header class="main-header">
            <!-- <div class="header-top">
                <div class="auto-container">
                    <div class="top-info">
                        <ul class="info-list clearfix">
                            <li>
                                <i class="flaticon-location-pin"></i>
                                219 Bedford Street Birmingham, AL 35211
                            </li>
                            <li>
                                <i class="flaticon-envelope"></i>
                                <a href="mailto:info@example.com">info@example.com</a>
                            </li>
                            <li class="phone">
                                <i class="flaticon-dial"></i>
                                <a href="tel:234554657345">+234 554 657 345</a>
                            </li>
                        </ul>
                    </div>
                </div> -->
            </div>
            <div class="header-upper">
               
            </div>

            <!--sticky Header-->
            <div class="sticky-header">
                <div class="auto-container">
                    <div class="outer-box clearfix">
                        <figure class="logo-box pull-left"><a href=""><img src="assets/images/small-logo.png" alt=""></a></figure>
                        <div class="menu-area pull-right">
                            <nav class="main-menu clearfix">
                                <!--Keep This Empty / Menu will come through Javascript-->
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- main-header end -->

        <!-- Mobile Menu  -->
        <div class="mobile-menu">
            <div class="menu-backdrop"></div>
            <div class="close-btn"><i class="fas fa-times"></i></div>
            
            <nav class="menu-box">
                <div class="nav-logo"><a href=""><img src="assets/images/currykrave_logo.png" alt="" title=""></a></div>
                <div class="menu-outer"><!--Here Menu Will Come Automatically Via Javascript / Same Menu as in Header--></div>
                <div class="contact-info">
                    <h4>Contact Info</h4>
                    <ul>
                        <li>Chicago 12, Melborne City, USA</li>
                        <li><a href="tel:+8801682648101">+88 01682648101</a></li>
                        <li><a href="mailto:info@example.com">info@example.com</a></li>
                    </ul>
                </div>
                <div class="social-links">
                    <ul class="clearfix">
                        <li><a href=""><span class="fab fa-twitter"></span></a></li>
                        <li><a href=""><span class="fab fa-facebook-square"></span></a></li>
                        <li><a href=""><span class="fab fa-pinterest-p"></span></a></li>
                        <li><a href=""><span class="fab fa-instagram"></span></a></li>
                        <li><a href=""><span class="fab fa-youtube"></span></a></li>
                    </ul>
                </div>
            </nav>
        </div><!-- End Mobile Menu -->


        <section class="section--profile">
        <div class="container">
          <div class="tab__container">
            <div class="tab__left">
              <div class="tab__heading active" id="tab1">
                <i class="fas fa-pen"></i>
                <span>Profile</span>
              </div>
             
              <div class="tab__heading">
                <i class="fas fa-people-carry"></i>
                <span>My Order</span>
              </div>
              <div class="tab__heading">
                <i class="fas fa-address-book"></i>
                <span>Address Book</span>
              </div>
              <div class="tab__heading">
                <i class="fas fa-heart"></i>
                <span>Wishlist</span>
              </div>
               <a href="<?php echo base_url() ?>logout">
               <div class="tab__heading">
                <i class="fas fa-sign-out-alt"></i>
             <span>Logout</span>
              </div> 
              </a>
            </div>




       <div class="tab__right">
            <div class="tab__content active nathim">
                          <div class="content">
                               <?php foreach($profile as $pro) { ?>
                                   <div class="user">
                                       <div class="user__left">
                                             <div class="user__img">
                                                   <img src="<?php echo base_url() ?>admin/<?php echo $pro['image']; ?>" alt="user" />
                                             </div>
                                             <!-- <div class="user__img_phone">
                                             <img src="<?php echo base_url() ?>admin/upload/icon/phone-call.png" alt="user" title="" />
                                             </div> -->
                                             <div>
                                                  <h3 class="user__name"><?php echo $pro['firstname']; ?> <?php echo $pro['lastname']; ?> </h3>
                                                  <p class="user__id">Mobile : +91 <?php echo $pro['mobile_no']; ?></p>
                                                  <p class="user__id">Email : <?php echo $pro['email']; ?></p>
                                             </div>
                                        </div>
                   
                                      <a href="#">
                                      <span class="product__link"></span>
                                     </a>
                                  </div>
                               <?php } ?>
              
                          </div>
              <!-- </div> -->


             
                  </div>
                  


              <div class="tab__content">
                <div class="content">
                  <div class="lists" id="lists">
                    <?php foreach($orders as $ord) { 
                    $id=$ord['order_id'];
                    ?>
                    <div class="order">
                      <div class="order__left">
                        <!--<div class="order__img">-->
                        <!--  <img src="img/beardo_1.png" alt="user" />-->
                        <!--</div>-->
                        <div>
                          <h3 class="order__name">Order ID : <?php echo $ord['unique_id'] ?></h3>
                          <p class="order__loc">Order amount : <?php echo $ord['order_value'] ?></p>
                          <p class="order__loc">Delivery Status : <?php echo $ord['del_status'] ?></p>
                          
                        </div>
                      </div>
                      <div class="order__right">
                        <small>Self</small>
                        <!--<p class="order__detail" onclick="orderDetails(<?php echo $id; ?>)">Order Detail</p>-->
                        <p><?php echo $ord['order_date'] ?>, <?php echo $ord['order_time'] ?></p>
                      </div>
                      <a href="#">
                        <span class="product__link"></span>
                      </a>
                    </div>
                    <?php } ?>
                 
                  </div>
                      <?php foreach($orders as $ord) { 
                    $id=$ord['order_id'];
                    ?>
                        
                  <div class="detail" id="detail">
                    <div
                      class="
                        user__filter
                        flex
                        jc--between
                        ai-center
                        u-margin-bottom-small
                      "
                    >
                      <h3 style="margin-left: 3.8rem">Order Details</h3>
                    </div>
                 
                    <!--<div class="main__text flex jc--between ai-center">-->
                    <!--  <h4 class="h4">ORDER ID </h4>-->
                    <!--  <span>Total Rs. 880</span>-->
                    <!--</div>-->
                   
                    <!--<div class="progress__container" style="display:none">-->
                    <!--  <div class="circles">-->
                    <!--    <div class="circle active"></div>-->
                    <!--    <div class="circle active"></div>-->
                    <!--    <div class="circle"></div>-->
                    <!--    <div class="progress"></div>-->
                    <!--  </div>-->
                    <!--  <div class="steps flex jc--between ai-center">-->
                    <!--    <div class="step">-->
                    <!--      <p>Order Placed</p>-->
                    <!--    </div>-->
                    <!--    <div class="step">-->
                    <!--      <p>Shipped</p>-->
                    <!--    </div>-->
                    <!--    <div class="step">-->
                    <!--      <p>Delivered</p>-->
                    <!--    </div>-->
                    <!--  </div>-->
                    <!--</div>-->
                    
                    <div class="main__text">
                      <h4 class="h4">Address</h4>
                      <p>Name - <span><?php echo $add['address'] ?></span></p>
                      <p>
                        Address -
                        <span
                          >Kholi no.420, Prem gali, Roopmahal, AAA -
                          600095</span
                        >
                      </p>
                    </div>
                    <table class="order__table">
                      <thead>
                        <tr>
                          <th>Item Name</th>
                          <th>QTY</th>
                          <th>Charges</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>Dermadew Fach Wash</td>
                          <td>01</td>
                          <td>Rs. 220.00</td>
                        </tr>
                        <tr>
                          <td>Dermadew Fach Wash</td>
                          <td>01</td>
                          <td>Rs. 220.00</td>
                        </tr>
                        <tr>
                          <td>Dermadew Fach Wash</td>
                          <td>01</td>
                          <td>Rs. 220.00</td>
                        </tr>
                        <tr>
                          <td>Dermadew Fach Wash</td>
                          <td>01</td>
                          <td>Rs. 220.00</td>
                        </tr>
                      </tbody>
                    </table>
                    <table class="order__table">
                      <thead>
                        <tr>
                          <th>Payment Detail</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>MRP Total</td>
                          <td>Rs. 880.00</td>
                        </tr>
                        <tr>
                          <td>Product Discount</td>
                          <td>Rs. 0.00</td>
                        </tr>
                        <tr>
                          <td>Coupons</td>
                          <td>Rs. 0.00</td>
                        </tr>
                      </tbody>
                    </table>
                    <div class="main__text flex jc--between ai-center">
                      <h4 class="h4">Total</h4>
                      <span> Rs. 880.00</span>
                    </div>
                    <button class="btn__back">
                      <i class="fas fa-reply-all syed"></i>
                    </button>
                  </div>
                      <?php } ?>
                </div>
              </div>
              <div class="tab__content">
                         <div class="content">
                              <?php foreach($address as $add) { 
                                    $id=$add['address_id'];
                  
                  
                                    ?>
                            <div class="address">
                                 <div class="address__left">
                                        <!--<div class="address__img">-->
                                              <!--  <img src="img/21.jpg" alt="user" />-->
                                        <!--</div>-->
                                     <div>
                                         <h3 class="address__name">
                                             <?php echo $add['name']; ?>
                                         </h3>
                                          <p class="address__loc">
                                            <?php echo $add['door_no']; ?>, <?php echo $add['street']; ?>, <br />
                                            <?php echo $add['landmark']; ?>, <?php echo $add['city']; ?> - <?php echo $add['pincode']; ?><br/>
                                            <?php echo $add['district']; ?>,<?php echo $add['state']; ?>,<?php echo $add['country']; ?>
                                         </p>
                                    </div>
                                 </div>
                                        <div class="address__right">
                                             <small><?php echo $add['address_type']; ?></small>
                                         </div>
                                     <a href="#">
                                           <span class="product__link"></span>
                                     </a>
                     
                                      <button type="button" class="btn  text-uppercase dark " data-toggle="modal"data-target="#exampleModal"onclick="choose_address(<?php echo $id; ?>)" >
                                    Edit 
                                      </button>
                           </div>
                                 <?php } ?>
        
                                   <div class="u-text-center">
                                        <div class="add_addres">
                                              <div class="row align-items-center">
                                                   <div class="col-md-auto col-12">
                                                        <div class="para2">
                                                              <span class="d-inline-block align-middle">
                                                                   <button type="button" class="btn  text-uppercase dark " data-toggle="modal" data-target=".bd-example-modal-xl" >
                                                                  + Add New Address 
                                                                   </button>
                                                               </span>
                                                         </div>
                                                     </div>
                                                 </div>
                                         </div>
                                     </div>
                
                
                </div>
              </div>
              
              <!-- <div class="tab__content">tab 7</div> -->
              
          <div class="tab__content">
                <div class="content">
                  <div class="lists" id="lists">
                    <?php foreach($wishlist as $wish) { 
                    $id=$wish['customer_id'];
                    $id1=$wish['product_id'];
                    $cat=$wish['category_id'];
                    $wish_id=$wish['wish_id'];
                    ?>
                    <div class="order">
                      <div class="order__left">
                        <!--<div class="order__img">-->
                        <!--  <img src="img/beardo_1.png" alt="user" />-->
                        <!--</div>-->
                        <!-- <div> -->
                        <div class="user__img">
                        <img src="<?php echo base_url() ?>admin/<?php echo $wish['pro_image']; ?>" alt="user" />
                      </div>
                    <!-- <div class="Wishlist__name"> ID : <?php echo $id;?></br></div> --><ul>
                    <h6 style="height: 50px;!important;"><a style="
    color: #fff;
"href="<?php echo base_url();?>Home/product_details?id=<?php echo $id1; ?>&cat=<?php echo $cat; ?>"><?php echo $wish['product_name']; ?></a></h6>
                        <li class="product__name" style="
    color: #fff;
">Price: <?php echo $wish['price'] ?></li>
                      <button type="button" class="btn"  onclick=deleteWishlist(<?php echo $wish_id ?>) style="
    background: #a91414;
">Delete</button>  
                      </ul>
                          <!-- <p class="order__loc">Order amount : <?php echo $wish['order_value'] ?></p>
                          <p class="order__loc">Delivery Status : <?php echo $wish['del_status'] ?></p> -->
                          
                        </div>
                      </div>
                      <div>
                      <a href="#">
                        <span class="product__link"></span>
                      </a>
                    </div>
                    <?php } ?>
            </div>
          </div>


                 
        <!-- </div> -->


      </section>

      <div class="modal fade bd-example-modal-xl" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl" role="document">
    <div class="modal-content">
    <div class="modal-header">

    </div>
      
      <div class="modal-body">
         <div class="row px-3  space-between">
          <div class="col-6">
                        <div class="form-wrap">
                            <div class="heading">
                               <h4 class="text-uppercase py-2"> add new address</h4> 
                               
                              
                            </div>
                         <form action="<?php echo base_url() ?>Home/add_address" method="post" id="addressfrm" >
                            <div class="content">
                                 <div class="form-group">
                                    <input type="text" class="form-control" id="name" name="name" placeholder="Full Name">
                                </div>
                                 <div class="form-group">
                                    <input type="text" class="form-control" id="mobile_no" name="mobile_no" placeholder="Mobile Number">
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" id="email" name="email" placeholder="Email">
                                </div>
                               
                                <div class="form-group">
                                    <input type="text" class="form-control pac-target-input" id="map_location" name="door_no" placeholder="Door No" autocomplete="off">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="street" name="street" placeholder="Flat No. / Building Name / Street name">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="landmark" name="landmark" placeholder="Landmark (optional)">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="city" id="city" placeholder="City">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="district" id="district" placeholder="district">
                                </div>
                                 <div class="form-group">
                                    <input type="text" class="form-control" name="state" id="state" placeholder="State">
                                </div>
                                 <div class="form-group">
                                    <input type="text" class="form-control" name="country" id="country" placeholder="Country">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="pincode" id="pincode" placeholder="Pincode" maxlength="6" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');">
                                </div>
                               
                                
                                <div class="btn-group">
                                    <!-- <input type="button" class="action secondary" value="Cancel"> -->
                                    <input type="hidden" name="customer_lat" id="addr_customer_lat" value="13.068410950763795">
                                    <input type="hidden" name="customer_long" id="addr_customer_long" value="80.25600805878639">
                                    <input type="hidden" name="checkout_pincode" id="checkout_pincode" value="600035">
                                    <input type="hidden" name="address_id" id="address_id">
                                    <button type="submit" class="action submit primary text-uppercase" id="checkout_address_btn">Submit</button>
                                </div>
                                <div>
                                    <p id="form_addr_error_msg" style="color:red"></p>
                                </div>
                                
                            </div>
                            </form>
                        </div>
                    </div> 
                    <div class="col-6">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d415.5958562604937!2d80.255884!3d13.068391!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xda6aa4e76bdf2cbe!2sFountain%20Plaza!5e1!3m2!1sen!2sus!4v1640171656661!5m2!1sen!2sus" width="500" height="500" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                      </div>
            </div>
  
    </div> 
  </div>
    </div>
  </div>
  
  
  
    <div class="modal fade" id="exampleModal"  tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true" >
  <div class="modal-dialog modal-xl" role="document">
    <div class="modal-content">
    <div class="modal-header">

    </div>
      
      <div class="modal-body">
         <div class="row px-3  space-between">
          <div class="col-6">
                        <div class="form-wrap">
                            <div class="heading">
                               <h4 class="text-uppercase py-2">Edit Address</h4> 
                               
                              
                            </div>
                         <form action="<?php echo base_url() ?>Home/add_address" method="post" id="addressfrm" >
                            <div class="content">
                                 <div class="form-group">
                                      <input type="hidden" class="form-control" id="update_ids" name="update_id" placeholder="Full Name">
                                    <input type="text" class="form-control" id="names" name="name" placeholder="Full Name">
                                </div>
                                 <div class="form-group">
                                    <input type="text" class="form-control" id="mobiles" name="mobile_no" placeholder="Mobile Number">
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" id="emails" name="email" placeholder="Email">
                                </div>
                               
                                <div class="form-group">
                                    <input type="text" class="form-control pac-target-input" id="door" name="door_no" placeholder="Door No" autocomplete="off">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="streets" name="street" placeholder="Flat No. / Building Name / Street name">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="landmarks" name="landmark" placeholder="Landmark (optional)">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="city" id="citys" placeholder="City">
                                </div>
                                 <div class="form-group">
                                    <input type="text" class="form-control" name="district" id="district" placeholder="district">
                                </div>
                                 <div class="form-group">
                                    <input type="text" class="form-control" name="state" id="states" placeholder="State">
                                </div>
                                 <div class="form-group">
                                    <input type="text" class="form-control" name="country" id="countrys" placeholder="Country">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="pincode" id="pincodes" placeholder="Pincode" maxlength="6" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');">
                                </div>
                               
                                
                                <div class="btn-group">
                                    <!-- <input type="button" class="action secondary" value="Cancel"> -->
                                    <input type="hidden" name="customer_lat" id="addr_customer_lat" value="13.068410950763795">
                                    <input type="hidden" name="customer_long" id="addr_customer_long" value="80.25600805878639">
                                    <input type="hidden" name="checkout_pincode" id="checkout_pincode" value="600035">
                                    <input type="hidden" name="address_id" id="address_id">
                                    <button type="submit" class="action submit primary text-uppercase" id="checkout_address_btn">Submit</button>
                                </div>
                                <div>
                                    <p id="form_addr_error_msg" style="color:red"></p>
                                </div>
                                
                            </div>
                            </form>
                        </div>
                    </div> 
                    <div class="col-6">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d415.5958562604937!2d80.255884!3d13.068391!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xda6aa4e76bdf2cbe!2sFountain%20Plaza!5e1!3m2!1sen!2sus!4v1640171656661!5m2!1sen!2sus" width="500" height="500" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                      </div>
            </div>
  
    </div> 
  </div>
    </div>
  </div>
  
  <script>
      function orderDetails(id){
                 $.ajax({
            method:"POST",
            url:"<?php echo base_url('Home/get_order_details') ?>",
            data:{order_id:id},
            success:function(data){
              console.log(data);
              
            }
        });
      }
      
      function deleteWishlist(wish_id){
	      		   $.ajax({
            method:"POST",
            url:"<?php echo base_url('Home/delete_wishlist') ?>",
            data:{wish_id:wish_id,
            
            },
          
            success:function(data){
     location.reload(); 
             console.log(data);
             
           
                   datas = JSON.parse(data);
                   if(datas.color=='ok'){
                    toastr.success(datas.msg);
                  }else{
                    toastr.error(datas.msg);
                  }

            
           
            }
        });
	  }
      function choose_address(id){
               $.ajax({
                "url":"<?php echo base_url(); ?>Home/get_address_edit",
                "method":"POST",
                data:{id:id},
                success:function(data){
                
                   console.log(data);
                     
                     var res = JSON.parse(data);
                       $('#update_ids').val(res.address_id);
                     $('#names').val(res.name);
                       $('#mobiles').val(res.mobile);
                         $('#door').val(res.door_no);
                           $('#streets').val(res.street);
                           $('#landmarks').val(res.landmark);
                           $('#citys').val(res.city);
                           $('#districts').val(res.district);
                           $('#states').val(res.state);
                           $('#countrys').val(res.country);
                             $('#pincodes').val(res.pincode);
                   
                }
              });
      }
      
      function clr_frm(){
    $('#updateid').val('');
     document.getElementById('addressheader').innerHTML="Add Address";
    document.getElementById('add_btn').innerHTML="Save";
    document.getElementById('addressfrm').reset();
}
  </script>
  
  
    <script>
  $(document ).ready(function() {
    <?php
    $msg = $this->session->userdata('msg');
    if(isset($msg)){
    ?>
    toastr.options.timeOut = 1500; // 1.5s
    toastr.<?php echo $this->session->userdata('type'); ?>("<?php echo $msg; ?>");
    <?php
    }
    $this->session->unset_userdata('msg'); 
    ?>
  });


 
</script>