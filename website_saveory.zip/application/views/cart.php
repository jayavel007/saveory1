<div class="main-container container">
	
		
		<div class="row">
			<!--Middle Part Start-->
        <div id="content" class="col-sm-12">
          <h2 class="title"></h2></h2>
            <div class="table-responsive form-group">
            <table class="table table-bordered">
                <thead>
                  <tr>
                    <td class="text-center">Image</td>
                    <td class="text-left">Product Name</td>
                    <td class="text-left">Quantity</td>
                    <td class="text-right">Unit Price</td>
                    <td class="text-right">Total</td>
                    <td class="text-right"></td>
                  </tr>
                </thead>
                <tbody>
                    
					<?php 
					$totalss = 0;
					 if($cart != 'no') {
					
					foreach($cart as $ca) {
					  //print_r($cart);
						$id=$ca['cart_id'];
            $price=$ca['price'];
            $qty=$ca['qty'];
						$total=$qty * $price;
						$totals[]=$qty * $price;
					if($totals==''){
					    $totalss=0;
					}else{
					   $totalss = array_sum($totals);
					}
					
						?>
                  <tr>
                    <td class="text-center"><a href="#"><img style="width:70px; height:60px" src="<?php echo base_url() ?>admin/<?php echo $ca['pro_image'] ?>" alt="Aspire Ultrabook Laptop" title="Aspire Ultrabook Laptop" class="img-thumbnail" /></a></td>
                    <td class="text-left"><a href="#"></a><?php echo $ca['product_name']; ?><br />
                     </td>
                    
                   
                    <td class="text-left" width="200px"><div class="input-group btn-block quantity">
                        <input type="text" name="qty" value="<?php echo $ca['qty']; ?>" onkeyup="updateQty(<?php echo $id; ?>,this.value)" size="1" class="form-control" />
                       </div>
                        
                       
                        
                        </td>
                    <td class="text-right"><?php echo $ca['price']; ?></td>
                    <td class="text-right"><?php echo $total; ?></td>
                    <td class="text-right"><button type="button" style="background: #c32a2a;" class="btn"  onclick=deleteCart(<?php echo $id ?>)>Delete</button></td>
                  </tr>
				  
				  <?php }  } ?>
				        <tr>
							<td></td>
							<td></td>
							<td></td>
						
							<td class="text-right">
								<strong>Total:</strong>
							</td>
							<td class="text-right">₹<?php echo $totalss; ?></td>
						</tr>
                </tbody>
              </table>
            </div>
     

            <div class="buttons">
            <div class="pull-left"><a href="<?php echo base_url() ?>" class="theme-btn">Continue Shopping</a></div>
             <?php if(!empty($cart)){ ?>
            <div class="pull-right"><a href="<?php echo base_url() ?>checkout" class="theme-btn">Checkout</a></div>
            <?php } ?>
          </div>
        </div>
        <!--Middle Part End -->
			
		</div>
	</div>


  <script>
      function updateQty(id,val){
           //alert(val);
		   $.ajax({
            method:"POST",
            url:"<?php echo base_url('Home/update_qty') ?>",
            data:{id:id,
              qty:val
            },
          
            success:function(data){
   
             console.log(data);
                   datas = JSON.parse(data);
                   if(datas.color=='ok'){
                    toastr.success(datas.msg);
                  }else{
                    toastr.error(datas.msg);
                  }

             location.reload();
           
            }
        });
	  }
	  
	  function deleteCart(id){
	      		   $.ajax({
            method:"POST",
            url:"<?php echo base_url('Home/delete_cart') ?>",
            data:{id:id,
            
            },
          
            success:function(data){
     location.reload(); 
             console.log(data);
             
           
                   datas = JSON.parse(data);
                   if(datas.color=='ok'){
                    toastr.success(datas.msg);
                  }else{
                    toastr.error(datas.msg);
                  }

            
           
            }
        });
	  }

    </script>
    
    
    
  <script>
  $(document ).ready(function() {
    <?php
    $msg = $this->session->userdata('msg');
    if(isset($msg)){
    ?>
    toastr.options.timeOut = 1500; // 1.5s
    toastr.<?php echo $this->session->userdata('type'); ?>("<?php echo $msg; ?>");
    <?php
    }
    $this->session->unset_userdata('msg'); 
    ?>
  });


</script>
