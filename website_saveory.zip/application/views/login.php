
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from azim.commonsupport.com/Carneshop/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 23 Nov 2021 05:42:24 GMT -->
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

<title>Savoury</title>

<!-- Fav Icon -->
<link rel="icon" href="assets/images/logo.png" type="image/x-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Heebo:wght@100;300;400;500;700;800;900&amp;display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300;0,400;0,500;0,700;0,900;1,300;1,400;1,500;1,700;1,900&amp;display=swap" rel="stylesheet">

<!-- Stylesheets -->

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="css/style.css" />

<link href="<?php echo base_url('');?>assets/css/font-awesome-all.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/flaticon.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/owl.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/bootstrap.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/jquery.fancybox.min.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/animate.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/color.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/style.css" rel="stylesheet">
<link href="<?php echo base_url('');?>assets/css/responsive.css" rel="stylesheet">

<style>
    .main-menu .navigation > li.dropdown > .megamenu {
    position: absolute;
    width: 50%;
    padding: 30px 50px;
    left: auto;
}


  .contact-section .form-inner .form-group input[type='text'], .contact-section .form-inner .form-group input[type='password'], .contact-section .form-inner .form-group textarea {
    position: relative;
    display: block;
    width: 100%;
    height: 60px;
    background: #fff;
    border: 2px solid #ededed;
    padding: 10px 50px 10px 20px;
    font-size: 16px;
    color: #565872;
    transition: all 500ms ease;
}



img {
  display: inline-block;
  /*max-width: 68%;*/
  height: auto;
  transition-delay: .1s;
  transition-timing-function: ease-in-out;
  transition-duration: .7s;
  transition-property: all;
}

.theme-btn {
    background: #6863bf;
    color: #fff !important;
}
.header-top .top-info .info-list li {
    position: relative;
    display: inline-block;
    float: left;
    padding-left: 25px;
    font-size: 14px;
    line-height: 26px;
    color: #ffffff;
    margin-right: 25px;
}
.header-top .top-info .info-list li a {
    color: #ffffff;
}
</style>

</head>


<!-- page wrapper -->
<body>

    <div class="boxed_wrapper ltr">

        <!-- preloader -->
        <div class="preloader" style="
        display:none;
        "
      ></div>
        <!-- preloader -->


<style>
 .centred11 {
   width: 50%;
  }
    @media only screen and (max-width: 600px) {
  .centred11 {
   width: 100% !important;
  }
}
</style>
<style>
 form i {
    margin-left: -30px;
    cursor: pointer;
}
</style>
    

<section class="contact-section centred">
            <div class="auto-container">
                <div class="sec-title">
                <br><br><br>
                    <h2>Login</h2>
                </div>
                <div class="form-inner" >
                    <form method="post" action="<?php echo base_url('Savoury_website_controller/check_login');?>" id="contact-form" class="default-form"> 
                        <div class="row clearfix" >
                           
                             <div class="col-lg-12 col-md-12 col-sm-12">
                              <center>
                                <div class="form-group centred centred11" >
                                    <i class="far fa-user"></i>
                                    <input type="text" name="mobile_no" placeholder="Mobile Number" required=""  >
                                </div>
                              </center>
                            </div>
                            
                            <div class="col-lg-12 col-md-12 col-sm-12">
                              <center>
                                <div class="form-group centred centred11" >
                                <input type="password" name="password" required="" placeholder="password"  autocomplete="current-password" required="" id="password">
                                    <i class="bi bi-eye-slash" id="togglePassword"></i>
                                </div>
                                </center>
                            </div>
                            
                         
                            
                            <div class="col-lg-12 col-md-12 col-sm-12 form-group message-btn centred">
                                <button class="theme-btn" type="submit" name="submit"  value="submit" style="background:#6863bf">
                                    LOGIN 
                                </button>
                                <br>   <br>
                                <a href="<?php echo base_url('register');?>" class="theme-btn" style="background:green">Create New Account</a>

                            </div>
                            <!--<div class="col-lg-12 col-md-12 col-sm-12 form-group message-btn centred">-->
                            <!--   <a href="<?php echo base_url('register');?>">Sign up</a>-->
                               
                            <!--</div>-->
                            <!-- <div class="col-lg-12 col-md-12 col-sm-12 form-group message-btn centred">
                               <a href="<?php echo base_url('Savoury_website_controller/forgot_password_post');?>" style="background:#6863bf">Forgot password?</a>
                               
                            </div> -->
                            <!-- <div class="col-lg-12 col-md-12 col-sm-12 form-group message-btn centred">
                               <a href="<?php echo base_url();?>">Back</a>
                               
                            </div> -->
                        </div>
                    </form>
                </div>
            </div>
        </section>
        <script>
        const togglePassword = document.querySelector('#togglePassword');
const password = document.querySelector('#password');
togglePassword.addEventListener('click', function (e) {
    // toggle the type attribute
    const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
    password.setAttribute('type', type);
    // toggle the eye / eye slash icon
    this.classList.toggle('bi-eye');
});
        </script>