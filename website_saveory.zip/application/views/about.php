<!-- <style>
    
p {
    position: relative;
    font-size: 16px;
    line-height: 30px;
    font-family: "Rubik", sans-serif;
    color: #ffffff;
    margin: 0px;
    transition: all 500ms ease;
}


#content_block_1 .content-box .list li {
    position: relative;
    display: block;
    font-size: 16px;
    font-family: "Heebo", sans-serif;
    font-weight: 700;
    color: #ffffff;
    margin-bottom: 10px;
    padding-left: 30px;
}
</style>
         -->
        <!--Page Title-->
        <section class="page-title" style="background-image: url(admin/upload/banner/mutton.png);">
            <div class="auto-container">
                <div class="content-box">
                    <div class="title-box">
                        <h1>About Us</h1>
                    </div>
                    <ul class="bread-crumb clearfix">
                        <li><a href="<?php echo base_url() ?>">Home</a></li>
                        <li>About Us</li>
                    </ul>
                </div>
            </div>
        </section>
        <!--End Page Title-->


        <!-- about-section -->
        <section class="about-section sec-pad">
            <div class="auto-container">
                <div class="inner-container mr-0 clearfix">
                    <div class="row clearfix">
                        <!-- <div class="col-lg-6 col-md-6 col-sm-12 video-column">
                            <div id="video_block_1">
                                <div class="video-inner" style="background-image: url(assets/images/resource/about-1.jpg);">
                                    <a href="" class="lightbox-image video-btn" data-caption=""><i class="fas fa-play"></i></a>
                                </div>
                            </div>
                        </div> -->
                        <div class="col-lg-12 col-md-6 col-sm-12 content-column">
                            <div id="content_block_1" style="">
                                <div class="content-box">
                                    <div class="sec-title">
                                        <span>About Us</span>
                                        <h2>We Provide Best Meat</h2>
                                       
                                    </div>
                                    <?php
                                                                       
                                                                        foreach($about as $ban) {
                                                                            
                                                                            ?>
                                    <div class="text">
                                        <p><?php echo $ban['about']; ?></p>
                                       
                                    </div>
                                    <ul class="list clearfix">
                                        <li>100% Organic Meat</li>
                                        <li>Payment Securation</li>
                                    </ul>
                                    <!--<div class="btn-box">-->
                                    <!--    <a href="" class="theme-btn">View More<i class="fas fa-long-arrow-alt-right"></i></a>-->
                                    <!--</div>-->
                                    <?php } ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- about-section end -->


        <!-- service-section -->
        <!-- <section class="service-section bg-color-1">
            <div class="icon-layer" style="background-image: url(assets/images/icons/bg-icon-1.png);"></div>
            <div class="auto-container">
                <div class="sec-title text-center">
                    <span>What we do</span>
                    <h2>Services for You</h2>
                </div>
                <div class="row clearfix">
                    <div class="col-lg-4 col-md-6 col-sm-12 service-block">
                        <div class="service-block-one wow fadeInUp animated animated" data-wow-delay="00ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="icon-box"><i class="flaticon-meat-4"></i></div>
                                <h3><a href="">Veal Entrecote</a></h3>
                                <p>Lorem ipsum dolor sit amet, consec tetur adipis</p>
                                <div class="btn-box">
                                    <a href="" class="theme-btn">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 service-block">
                        <div class="service-block-one wow fadeInUp animated animated" data-wow-delay="300ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="icon-box"><i class="flaticon-hang"></i></div>
                                <h3><a href="">Pork Tenderloin</a></h3>
                                <p>Lorem ipsum dolor sit amet, consec tetur adipis</p>
                                <div class="btn-box">
                                    <a href="" class="theme-btn">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 service-block">
                        <div class="service-block-one wow fadeInUp animated animated" data-wow-delay="600ms" data-wow-duration="1500ms">
                            <div class="inner-box">
                                <div class="icon-box"><i class="flaticon-meat-5"></i></div>
                                <h3><a href="">Beaf ribs</a></h3>
                                <p>Lorem ipsum dolor sit amet, consec tetur adipis</p>
                                <div class="btn-box">
                                    <a href="" class="theme-btn">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!-- service-section end -->


        <!-- about-style-two -->
        <!-- <section class="about-style-two">
            <div class="auto-container">
                <div class="row align-items-center clearfix">
                    <div class="col-lg-6 col-md-12 col-sm-12 content-column">
                        <div id="content_block_2">
                            <div class="content-box">
                                <div class="sec-title style-two">
                                    <span>About Us</span>
                                    <h2>About Our Firm’s</h2>
                                </div>
                                <div class="text">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris</p>
                                </div>
                                <ul class="list clearfix">
                                    <li>
                                        <i class="flaticon-call-center-agent"></i>
                                        Expert Customer
                                    </li>
                                    <li>
                                        <i class="flaticon-free-delivery"></i>
                                        Free Shipping
                                    </li>
                                    <li>
                                        <i class="flaticon-return-of-investment"></i>
                                        Free Return
                                    </li>
                                    <li>
                                        <i class="flaticon-winner"></i>
                                        Amazing Deals
                                    </li>
                                </ul>
                                <div class="link-box"><a href="">Learn more about our benefit<i class="flaticon-right"></i></a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-sm-12 image-column">
                        <div id="image_block_1">
                            <div class="image-box">
                                <figure class="image image-1"><img src="assets/images/resource/about-2.jpg" alt=""></figure>
                                <figure class="image image-2"><img src="assets/images/resource/about-3.jpg" alt=""></figure>
                                <figure class="image image-3"><img src="assets/images/resource/about-1.png" alt=""></figure>
                                <figure class="image image-4"><img src="assets/images/resource/about-2.png" alt=""></figure>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!-- about-style-two end -->


        <!-- portfolio-section -->
        <!-- <section class="portfolio-section">
            <div class="auto-container">
                <div class="single-item-carousel owl-carousel owl-theme owl-dots-none">
                    <div class="portfolio-block-one">
                        <div class="inner-box">
                            <figure class="image-box"><img src="assets/images/resource/portfolio-1.jpg" alt=""></figure>
                            <div class="lower-content">
                                <div class="inner">
                                    <span>Meat</span>
                                    <h4><a href="">Pork tenderloin</a></h4>
                                    <div class="link"><a href=""><i class="flaticon-right"></i></a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-block-one">
                        <div class="inner-box">
                            <figure class="image-box"><img src="assets/images/resource/portfolio-2.jpg" alt=""></figure>
                            <div class="lower-content">
                                <div class="inner">
                                    <span>Meat</span>
                                    <h4><a href="">Pork tenderloin</a></h4>
                                    <div class="link"><a href=""><i class="flaticon-right"></i></a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="portfolio-block-one">
                        <div class="inner-box">
                            <figure class="image-box"><img src="assets/images/resource/portfolio-3.jpg" alt=""></figure>
                            <div class="lower-content">
                                <div class="inner">
                                    <span>Meat</span>
                                    <h4><a href="">Pork tenderloin</a></h4>
                                    <div class="link"><a href=""><i class="flaticon-right"></i></a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!-- portfolio-section end -->


        <!-- testimonial-section -->
        <!-- <section class="testimonial-section">
            <div class="auto-container">
                <div class="sec-title style-two">
                    <span>Testimonials</span>
                    <h2>Why People Believe in Us!</h2>
                </div>
                <div class="two-column-carousel owl-carousel owl-theme owl-dots-none">
                    <div class="testimonial-block-one">
                        <div class="inner-box">
                            <div class="icon-box"><i class="flaticon-quote"></i></div>
                            <p>Slore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit</p>
                            <div class="author-box">
                                <figure class="image-box"><img src="assets/images/resource/testimonial-1.png" alt=""></figure>
                                <h5>Richard K. Le</h5>
                                <span class="designation">HD Manager</span>
                            </div>
                        </div>
                    </div>
                    <div class="testimonial-block-one">
                        <div class="inner-box">
                            <div class="icon-box"><i class="flaticon-quote"></i></div>
                            <p>Asi enim ad minim veniam, quis nostrud exerci tation uLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore</p>
                            <div class="author-box">
                                <figure class="image-box"><img src="assets/images/resource/testimonial-2.png" alt=""></figure>
                                <h5>Donnell J. Creech</h5>
                                <span class="designation">Sonographer</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!-- testimonial-section end -->


        <!-- funfact-section -->
        <!-- <section class="funfact-section centred bg-color-2">
            <div class="auto-container">
                <div class="counter-inner wow slideInUp animated animated" data-wow-delay="00ms" data-wow-duration="1500ms">
                    <div class="line"></div>
                    <div class="row clearfix">
                        <div class="col-lg-3 col-md-6 col-sm-12 counter-block">
                            <div class="counter-block-one">
                                <div class="inner-box">
                                    <div class="icon-box"><i class="flaticon-notes"></i></div>
                                    <div class="count-outer count-box">
                                        <span class="count-text" data-speed="1500" data-stop="2490">0</span>
                                    </div>
                                    <span class="text">Finished Projects</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 counter-block">
                            <div class="counter-block-one">
                                <div class="inner-box">
                                    <div class="icon-box"><i class="flaticon-flag"></i></div>
                                    <div class="count-outer count-box">
                                        <span class="count-text" data-speed="1500" data-stop="7410">0</span>
                                    </div>
                                    <span class="text">Creative Materials</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 counter-block">
                            <div class="counter-block-one">
                                <div class="inner-box">
                                    <div class="icon-box"><i class="flaticon-medal"></i></div>
                                    <div class="count-outer count-box">
                                        <span class="count-text" data-speed="1500" data-stop="5240">0</span>
                                    </div>
                                    <span class="text">Experienced Masters</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 counter-block">
                            <div class="counter-block-one">
                                <div class="inner-box">
                                    <div class="icon-box"><i class="flaticon-speaker"></i></div>
                                    <div class="count-outer count-box">
                                        <span class="count-text" data-speed="1500" data-stop="250">0</span>
                                    </div>
                                    <span class="text">Professional Awards</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!-- funfact-section end -->


        <!-- team-section -->
        <!-- <section class="team-section centred">
            <div class="outer-container">
                <div class="pattern-layer">
                    <div class="pattern-1" style="background-image: url(assets/images/shape/shape-1.png);"></div>
                    <div class="pattern-2" style="background-image: url(assets/images/shape/shape-2.png);"></div>
                </div>
                <div class="anim-icon">
                    <div class="icon icon-1 float-bob-y" style="background-image: url(assets/images/icons/anim-icon-1.png);"></div>
                    <div class="icon icon-2" style="background-image: url(assets/images/icons/anim-icon-2.png);"></div>
                </div>
                <div class="auto-container">
                    <div class="sec-title style-two">
                        <span>Meet Our Team</span>
                        <h2>Our Creative Team</h2>
                    </div>
                    <div class="four-item-carousel owl-carousel owl-theme owl-nav-none">
                        <div class="team-block-one">
                            <div class="inner-box">
                                <figure class="image-box">
                                    <img src="assets/images/team/team-1.jpg" alt="">
                                    <ul class="social-links clearfix">
                                        <li><a href=""><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href=""><i class="fab fa-twitter"></i></a></li>
                                        <li><a href=""><i class="fab fa-instagram"></i></a></li>
                                        <li><a href=""><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </figure>
                                <div class="lower-content">
                                    <h3><a href="">David Smith</a></h3>
                                    <p>Design Expert</p>
                                </div>
                            </div>
                        </div>
                        <div class="team-block-one">
                            <div class="inner-box">
                                <figure class="image-box">
                                    <img src="assets/images/team/team-2.jpg" alt="">
                                    <ul class="social-links clearfix">
                                        <li><a href=""><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href=""><i class="fab fa-twitter"></i></a></li>
                                        <li><a href=""><i class="fab fa-instagram"></i></a></li>
                                        <li><a href=""><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </figure>
                                <div class="lower-content">
                                    <h3><a href="">Barbara Smith</a></h3>
                                    <p>painting director</p>
                                </div>
                            </div>
                        </div>
                        <div class="team-block-one">
                            <div class="inner-box">
                                <figure class="image-box">
                                    <img src="assets/images/team/team-3.jpg" alt="">
                                    <ul class="social-links clearfix">
                                        <li><a href=""><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href=""><i class="fab fa-twitter"></i></a></li>
                                        <li><a href=""><i class="fab fa-instagram"></i></a></li>
                                        <li><a href=""><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </figure>
                                <div class="lower-content">
                                    <h3><a href="">Robert Pineda</a></h3>
                                    <p>Project Manager</p>
                                </div>
                            </div>
                        </div>
                        <div class="team-block-one">
                            <div class="inner-box">
                                <figure class="image-box">
                                    <img src="assets/images/team/team-4.jpg" alt="">
                                    <ul class="social-links clearfix">
                                        <li><a href=""><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href=""><i class="fab fa-twitter"></i></a></li>
                                        <li><a href=""><i class="fab fa-instagram"></i></a></li>
                                        <li><a href=""><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </figure>
                                <div class="lower-content">
                                    <h3><a href="">Jenna Sue</a></h3>
                                    <p>Manager</p>
                                </div>
                            </div>
                        </div>
                        <div class="team-block-one">
                            <div class="inner-box">
                                <figure class="image-box">
                                    <img src="assets/images/team/team-1.jpg" alt="">
                                    <ul class="social-links clearfix">
                                        <li><a href=""><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href=""><i class="fab fa-twitter"></i></a></li>
                                        <li><a href=""><i class="fab fa-instagram"></i></a></li>
                                        <li><a href=""><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </figure>
                                <div class="lower-content">
                                    <h3><a href="">David Smith</a></h3>
                                    <p>Design Expert</p>
                                </div>
                            </div>
                        </div>
                        <div class="team-block-one">
                            <div class="inner-box">
                                <figure class="image-box">
                                    <img src="assets/images/team/team-2.jpg" alt="">
                                    <ul class="social-links clearfix">
                                        <li><a href=""><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href=""><i class="fab fa-twitter"></i></a></li>
                                        <li><a href=""><i class="fab fa-instagram"></i></a></li>
                                        <li><a href=""><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </figure>
                                <div class="lower-content">
                                    <h3><a href="">Barbara Smith</a></h3>
                                    <p>painting director</p>
                                </div>
                            </div>
                        </div>
                        <div class="team-block-one">
                            <div class="inner-box">
                                <figure class="image-box">
                                    <img src="assets/images/team/team-3.jpg" alt="">
                                    <ul class="social-links clearfix">
                                        <li><a href=""><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href=""><i class="fab fa-twitter"></i></a></li>
                                        <li><a href=""><i class="fab fa-instagram"></i></a></li>
                                        <li><a href=""><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </figure>
                                <div class="lower-content">
                                    <h3><a href="">Robert Pineda</a></h3>
                                    <p>Project Manager</p>
                                </div>
                            </div>
                        </div>
                        <div class="team-block-one">
                            <div class="inner-box">
                                <figure class="image-box">
                                    <img src="assets/images/team/team-4.jpg" alt="">
                                    <ul class="social-links clearfix">
                                        <li><a href=""><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href=""><i class="fab fa-twitter"></i></a></li>
                                        <li><a href=""><i class="fab fa-instagram"></i></a></li>
                                        <li><a href=""><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </figure>
                                <div class="lower-content">
                                    <h3><a href="">Jenna Sue</a></h3>
                                    <p>Manager</p>
                                </div>
                            </div>
                        </div>
                        <div class="team-block-one">
                            <div class="inner-box">
                                <figure class="image-box">
                                    <img src="assets/images/team/team-1.jpg" alt="">
                                    <ul class="social-links clearfix">
                                        <li><a href=""><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href=""><i class="fab fa-twitter"></i></a></li>
                                        <li><a href=""><i class="fab fa-instagram"></i></a></li>
                                        <li><a href=""><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </figure>
                                <div class="lower-content">
                                    <h3><a href="">David Smith</a></h3>
                                    <p>Design Expert</p>
                                </div>
                            </div>
                        </div>
                        <div class="team-block-one">
                            <div class="inner-box">
                                <figure class="image-box">
                                    <img src="assets/images/team/team-2.jpg" alt="">
                                    <ul class="social-links clearfix">
                                        <li><a href=""><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href=""><i class="fab fa-twitter"></i></a></li>
                                        <li><a href=""><i class="fab fa-instagram"></i></a></li>
                                        <li><a href=""><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </figure>
                                <div class="lower-content">
                                    <h3><a href="">Barbara Smith</a></h3>
                                    <p>painting director</p>
                                </div>
                            </div>
                        </div>
                        <div class="team-block-one">
                            <div class="inner-box">
                                <figure class="image-box">
                                    <img src="assets/images/team/team-3.jpg" alt="">
                                    <ul class="social-links clearfix">
                                        <li><a href=""><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href=""><i class="fab fa-twitter"></i></a></li>
                                        <li><a href=""><i class="fab fa-instagram"></i></a></li>
                                        <li><a href=""><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </figure>
                                <div class="lower-content">
                                    <h3><a href="">Robert Pineda</a></h3>
                                    <p>Project Manager</p>
                                </div>
                            </div>
                        </div>
                        <div class="team-block-one">
                            <div class="inner-box">
                                <figure class="image-box">
                                    <img src="assets/images/team/team-4.jpg" alt="">
                                    <ul class="social-links clearfix">
                                        <li><a href=""><i class="fab fa-facebook-f"></i></a></li>
                                        <li><a href=""><i class="fab fa-twitter"></i></a></li>
                                        <li><a href=""><i class="fab fa-instagram"></i></a></li>
                                        <li><a href=""><i class="fab fa-google-plus-g"></i></a></li>
                                    </ul>
                                </figure>
                                <div class="lower-content">
                                    <h3><a href="">Jenna Sue</a></h3>
                                    <p>Manager</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->
        <!-- team-section end -->


        <!-- clients-section -->
        <!-- <section class="clients-section about-page">
            <div class="auto-container">
                <div class="clients-carousel owl-carousel owl-theme owl-dots-none owl-nav-none">
                    <figure class="logo-image"><a href=""><img src="assets/images/clients/clients-logo-1.png" alt=""></a></figure>
                    <figure class="logo-image"><a href=""><img src="assets/images/clients/clients-logo-2.png" alt=""></a></figure>
                    <figure class="logo-image"><a href=""><img src="assets/images/clients/clients-logo-3.png" alt=""></a></figure>
                    <figure class="logo-image"><a href=""><img src="assets/images/clients/clients-logo-4.png" alt=""></a></figure>
                    <figure class="logo-image"><a href=""><img src="assets/images/clients/clients-logo-5.png" alt=""></a></figure>
                </div>
            </div>
        </section> -->
        <!-- clients-section end -->


