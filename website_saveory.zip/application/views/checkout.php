<?php 
 $logged_in = $this->session->userdata('customer_id');


if(!empty($logged_in)){
   $customer_id=$this->session->userdata('customer_id');
   if($customer_id==''){
   $customer_id=0; 
   }

}else{
    $customer_id=0;
}


?>

<link href="<?php echo base_url('');?>assets/css/checkout.css" rel="stylesheet">

<style>
    .table-responsive > .table-bordered {
    border: 0;
    background: #fff;
}
.checkout_wrap .shopping_cart .content {
    margin-top: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background: #fff;
}
</style>
<div class="checkout_wrap" style="padding-top: 160px !important;">
    <div id="fipola_my_cart" class="d-none">
        <div class="row">
            <!-- Cart Page Content -->
            <div id="co_shopping_cart" class="col-xl-6">
                <!-- ko foreach: getRegion('steps') -->
                <!-- ko with: getChild('my-cart-step') -->
                <!-- ko template: getTemplate() --><!--The 'step_code' value from the .js file should be used-->

                <!--/ko-->
            </div>
        </div>
    </div>
    <div id="fipola_checkout_address" class="">
        <div class="row">
            <!-- Checkout Page Content -->
            <div id="co_shipping_address" class="col-xl-6">
                <!-- ko foreach: getRegion('steps') -->
                <!-- ko with: getChild('shipping-step') -->
                <!-- ko template: getTemplate() -->
<!-- ko foreach: {data: elems, as: 'element'} -->
    <!-- ko if: hasTemplate() --><!-- ko template: getTemplate() -->
<!-- ko foreach: {data: elems, as: 'element'} --><!-- /ko -->
<!-- /ko --><!-- /ko -->

    <!-- ko if: hasTemplate() --><!-- ko template: getTemplate() -->

<div id="address_block" class="address co_box progressing" style="background:#fff">
    <!-- ko if: rates().length --><form id="co-shipping-method-form" class="form methods-shipping" novalidate="novalidate" data-bind="submit: setShippingInformation">
       


        <div class="heading">
            <span>Shipping Address</span>
                    <!-- Add a new Address -->
            <div class="row align-items-center">
                <div class="col-md-auto col-12">
                    <div class="para2">
                        <span class="d-inline-block align-middle">
                            <button type="button" class="btn  text-uppercase dark " data-toggle="modal" data-target=".bd-example-modal-xl" >
                                + Add New Address 
                            </button>
                            </span>
                    </div>
                </div>
            </div>
        </div>
      
        <div class="content">
         <p>We request to add/select delivery address and proceed.</p>
         <?php foreach($address as $add){
            $id=$add['address_id'];
             ?>
         <div class="adress--detail ">
             <div class="select__add px-3">
               
               <input type="radio" class="form-check-input" name="address_id"  value="" onclick="addAddress(<?php echo $id;?>)" checked>
              
            </div>
             <div class="add__address">
               <div class="address">
                   <h6 style="color: #141414"><?php echo $add['name'] ?>,<br><?php echo $add['door_no'] ?>,<?php echo $add['street'] ?>
                   <?php echo $add['landmark'] ?>,<?php echo $add['city'] ?>,<?php echo $add['district'] ?>,
                   <br><?php echo $add['state'] ?> <br><?php echo $add['pincode'] ?></h6>
               </div>
             </div>
         </div>
       <?php } ?>
    <!--<div class="col-md col-12 text-right mob_adj finish_one">-->
    <!--            <button data-role="opc-continue" id="expdelaction" onclick="show_hide_me()" type="submit" class="action primary mini text-uppercase">-->
    <!--                <span data-bind="i18n: 'proceed'">proceed</span>-->
    <!--            </button>-->
    <!--        </div>-->
             <!--<div class="col-md col-12 text-right mob_adj" style="text-align: left;">-->
             <!--    <span id="address_choose_error" style="color:red;"></span>-->
             <!--</div>-->
        </div>
        
    </form><!-- /ko -->
</div>

<!-- user form -->


</div>
        <div id="co_shopping_cart" class="col-xl-6">
        

    
    <div id="checkout-step-title" class="step-content" data-role="content">

        <!-- Cart Part Start  -->
        <div class="shopping_cart">
            <div class="heading">
                Your shopping cart
            </div>
            <div class="content">
                <div class="items">
                    <!--  Cart Items -->
                    <!-- ko foreach: { data: cartData.products, as: 'item' } -->
                    <?php foreach($checkout as $check) { 
                        $total=$check['qty']*$check['price'];
						$totals[]=$check['qty']*$check['price'];
						$totalss = array_sum($totals);
                        $amount=$totalss + 50;
                        ?>
                    <div class="item">
                        <div class="row no-gutters align-items-center">
                            <div class="col-xl-auto adjustimage">
                                <div class="img">
                                    <img data-bind="attr: { src: item.gallery_image, alt: item.name }" class="img-fluid" src="<?php echo base_url() ?>admin/<?php echo $check['pro_image'] ?>" alt="Chicken Curry Cut - Skin On">
                                </div>
                            </div>
                            <div class="col-xl col-md-6">
                                <div class="item_data">
                                    <div class="name">
                                        <span data-bind="text: item.name"><?php echo $check['product_name'] ?></span>
                                    </div>
                                    <div class="name">
                                        <span class="old-price" style="padding-left: 10px; color: #a59e9e;font-size: 16px;">QTY: <?php echo $check['qty'] ?></span>
                                      
                                    </div>
                                    <div class="name">
                                        <span class="old-price" style="padding-left: 10px; color: #a59e9e;font-size: 16px;">Price:  ₹<?php echo $check['price'] ?>.00</span>
                                      
                                    </div>
                            
                                </div>
                            </div>
                            <div class="col-xl-auto col-md-3">
                                <div class="price">
                                    <!-- ko if: item.store_special_price  -->
                                            <span class="special-price" data-bind="text: item.store_special_price">₹ <?php echo $total;?>.00</span>
                                            <span class="old-price" style="padding-left: 10px; color: #a59e9e;font-size: 12px;">
                                            
                                            </span>
                                    <!-- /ko -->
                                     <!-- ko ifnot: item.store_special_price --><!-- /ko --> 
                                </div>
                            </div>
                        </div>

                    </div>
                  <?php } ?>

                    <!--/ko-->

                </div>
                <div class="subtotal">
                    <div class="row no-gutters">
                        <div class="col-7">
                            <div class="txt">Subtotal</div>
                        </div>
                        <div class="col-5">
                            <div class="price"><span class="mycart_subtotal" data-bind="text: getSubTotalValue();">₹<?php echo $totalss; ?>.00</span></div>
                        </div>
                        <div class="col-7">
                            <div class="txt">Delivery Charges</div>
                        </div>
                        <div class="col-5">
                            <div class="price"><span class="mycart_subtotal" data-bind="text: getSubTotalValue();">₹50.00</span></div>
                        </div>
                    </div>
                    <!-- <div class="row no-gutters d-none discount_amount_block">
                        <div class="col-6"></div>
                        <div class="col-6">
                            <div class="price discount_design" style="font-size: 12px; color: green;"><span>You
                                    Save: </span><span class="discount_amount"></span></div>
                        </div>
                    </div> -->
                </div>
          
                <div class="subtotal d-none" id="offer_dicount_block">
                </div>
                <div class="total">
                    <div class="row no-gutters">
                        <div class="col-7">
                            <div class="txt">Total</div>
                        </div>
                        <div class="col-5">
                            <div class="price"><span class="mycart_total" data-bind="text: getGrandTotalValue();">₹<?php echo $amount; ?>.00</span>
                            </div>
                        </div>
                    </div>
                </div>
              
            </div>

            <div class="proceed_wrap d-none" id="proceed_of_cart">
                <div class="row">
                    <div class="col-xl-8">
                        <div class="promo_group">
                            <!-- <label for="">Have a Promo code ?</label>
                            <input type="text" class="form-control" value="" placeholder="Enter Promo code">
                            <div class="btn-wrap">
                                <input type="button" class="action secondary" value="apply">
                            </div> -->
                        </div>
                    </div>
                  
                </div>
            </div>
            <?php  $_SESSION['payable_amount']= $amount ?>
            <div class="proceed_wrap" id="proceed_of_checkout" style="float:left">
                <div class="d-flex justify-content-end">
                    <a href="<?php echo base_url()?>Payment/pay" class="action primary">Pay Now</a>



                </div>
            </div>

            <div class="proceed_wrap" id="proceed_of_payment">
                <div class="d-flex justify-content-end">
         <a href="<?php echo base_url('profile');?>">  <input type="button" value="Cash On Delivery" onclick="placeOrder(<?php echo $customer_id;?>)"class="action primary"> </a>
                </div>
            </div>
        </div>

        <!-- Cart Part End -->


    </div>
</li>
<!-- /ko -->
            <!--/ko-->
            <!--/ko-->
        </div>
    </div>
    </div>
</div>

<!-- Extra large modal -->

 <div class="modal fade bd-example-modal-xl" tabindex="-1" role="dialog" aria-labelledby="myExtraLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl" role="document">
    <div class="modal-content">
    <div class="modal-header">

    </div>
      
      <div class="modal-body">
         <div class="row px-3  space-between">
          <div class="col-6">
                        <div class="form-wrap">
                            <div class="heading">
                               <h4 class="text-uppercase py-2"> add new address</h4> 
                            </div>
                         <form action="<?php echo base_url() ?>Home/add_address" method="post" id="addressfrm" >
                            <div class="content">
                                 <div class="form-group">
                                    <input type="text" class="form-control" id="name" name="name" placeholder="Full Name">
                                </div>
                                 <div class="form-group">
                                    <input type="text" class="form-control" id="mobile_no" name="mobile_no" placeholder="Mobile Number">
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" id="email" name="email" placeholder="Email">
                                </div>
                               
                                <div class="form-group">
                                    <input type="text" class="form-control pac-target-input" id="map_location" name="door_no" placeholder="Door No" autocomplete="off">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="street" name="street" placeholder="Flat No. / Building Name / Street name">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="landmark" name="landmark" placeholder="Landmark (optional)">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="city" id="city" placeholder="City">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="district" id="district" placeholder="district">
                                </div>
                                 <div class="form-group">
                                    <input type="text" class="form-control" name="state" id="state" placeholder="State">
                                </div>
                                 <div class="form-group">
                                    <input type="text" class="form-control" name="country" id="country" placeholder="Country">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="pincode" id="pincode" placeholder="Pincode" maxlength="6" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');">
                                </div>
                               
                                
                                <div class="btn-group">
                                    <!-- <input type="button" class="action secondary" value="Cancel"> -->
                                    <input type="hidden" name="customer_lat" id="addr_customer_lat" value="13.068410950763795">
                                    <input type="hidden" name="customer_long" id="addr_customer_long" value="80.25600805878639">
                                    <input type="hidden" name="checkout_pincode" id="checkout_pincode" value="600035">
                                    <input type="hidden" name="address_id" id="address_id">
                                    <button type="submit" class="action submit primary text-uppercase" id="checkout_address_btn">Submit</button>
                                </div>
                                <div>
                                    <p id="form_addr_error_msg" style="color:red"></p>
                                </div>
                                
                            </div>
                            </form>
                        </div>
                    </div> 
                    <div class="col-6">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d415.5958562604937!2d80.255884!3d13.068391!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xda6aa4e76bdf2cbe!2sFountain%20Plaza!5e1!3m2!1sen!2sus!4v1640171656661!5m2!1sen!2sus" width="500" height="500" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                      </div>
            </div>
  
    </div> 
  </div>
    </div>
  </div>
  
  <script>
      function orderDetails(id){
                 $.ajax({
            method:"POST",
            url:"<?php echo base_url('Home/get_order_details') ?>",
            data:{order_id:id},
            success:function(data){
              console.log(data);
              
            }
        });
      }
      
      function clr_frm(){
    $('#updateid').val('');
     document.getElementById('addressheader').innerHTML="Add Address";
    document.getElementById('add_btn').innerHTML="Save";
    document.getElementById('addressfrm').reset();
}
  </script>



  <script>
     
    function addAddress(id){
         
        <?php  $_SESSION['address_id']= $id; ?>
    }
    
    function placeOrder(id){
	$.ajax({
            method:"POST",
            url:"<?php echo base_url('Home/placeOrder') ?>",
            data:{
              customer_id:id
            },
          
            success:function(data){
   
              console.log(data);
                   datas = JSON.parse(data);
              
       if(datas.color=='ok'){
                    toastr.success(datas.msg);
                    redirect(base_url('Home'));
                  }else{
                    toastr.error(datas.msg);
                  }
            
           
            }
        });
  }
  

  </script>
