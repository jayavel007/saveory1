<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'login';

$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['login'] = 'Login/check_login';
$route['products'] = 'Products/products';
$route['category'] = 'Products/category';
$route['subcategory'] = 'Products/sub_category';
$route['baskets'] = 'Baskets/baskets';
$route['banner'] = 'Banners/banners';
$route['logo'] = 'Logo/logo';
$route['term'] = 'Logo/term';
$route['stock'] = 'Stock/stock';
$route['import'] = 'Stock/import';
$route['appuser'] = 'Appuser/appuser';
$route['approvaluser'] = 'Approvaluser/approvaluser';
$route['subscribtion'] = 'Subscribtion/subscribtion';
$route['subscriberslist'] = 'Subscribtion/subscribers_list';
$route['reviews'] = 'Subscribtion/reviews';
$route['orders'] = 'Orders/orders';
$route['orders/(:num)'] = 'Orders/orders/$1';
// $route['orders/(:num)'] = 'Orders/orders/$1';
$route['details/(:num)'] = 'Orders/order_details/$1';
$route['report'] = 'Reports/report';
$route['logout'] = 'Login/logout';

$route['addcategory'] = 'Products/add_category';
$route['addsubcategory'] = 'Products/add_sub_category';
$route['addproducts'] = 'Products/add_products';
$route['updateproduct'] = 'Products/update_products';
$route['addbasket'] = 'Baskets/add_baskets';
$route['addbanner'] = 'Banners/add_banner';
$route['addlogo'] = 'Logo/add_logo';
$route['addterm'] = 'Logo/add_term';
$route['addsubscribtion'] = 'Subscribtion/add_subscribtion';


$route['update_banner'] = 'Banners/update_banner';

$route['shop'] = 'Logo/shop';
$route['add_shop'] = 'Logo/add_shop';
$route['zone_mapping'] = 'Logo/zone_mapping';
