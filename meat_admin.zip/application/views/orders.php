 <div class="main-panel">
          <div class="content-wrapper">
 
  <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          
         <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Orders</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table class="table table-bordered table-striped sortable" id='postsList'>

             <thead>

              <tr>
                            <th> S.No</th>
                            <th> Order Date </th>
                            <th> Order Id</th>
                            <th> Custmer Name</th>
                            <th> Order Value </th>
                            <th> Payment Status</th>
                            <!--new insert-->
                            <th> Delivery Date </th>
                            <th> Delivery Status </th>
                            <th> Action</th>
              </tr>

             </thead>

             <tbody id='postsList'></tbody>

           </table>       
           <!-- Paginate -->
           <div id='pagination'></div>                     
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>



        </div>
        
      </div><!-- /.container-fluid -->
    </section>


<div class="main-panel">
          <div class="content-wrapper">
    
          
          
            </div>
           
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->
      
          <!-- partial -->
        </div>

              </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
   <script>
     var today = new Date();
var dd = today.getDate();
var mm = today.getMonth()+1; //January is 0!
var yyyy = today.getFullYear();
 if(dd<10){
        dd='0'+dd
    } 
    if(mm<10){
        mm='0'+mm
    } 

today = yyyy+'-'+mm+'-'+dd;
document.getElementById("datefield").setAttribute("min", today);
     </script>

    <script>

  $(document ).ready(function() {
    <?php
    $msg = $this->session->userdata('msg');
    if(isset($msg)){
    ?>
    toastr.options.timeOut = 1500; // 1.5s
    toastr.<?php echo $this->session->userdata('type'); ?>("<?php echo $msg; ?>");
    <?php
    }
    $this->session->unset_userdata('msg'); 
    ?>
  });
  function changeStatus(id,val){
   //alert(id+","+val);
    $.ajax({
            method:"POST",
            url:"<?php echo base_url('Orders/set_status') ?>",
            data:{  order_id:id,
                   del_status:val
            },
            success:function(data){
              location.reload();
             }

            });

}
function del_date(id,val){
  //alert(id+","+val);
  $.ajax({
            method:"POST",
            url:"<?php echo base_url('Orders/del_date') ?>",
            data:{order_id:id,
                   estimate_del:val
            },
            success:function(data){
              location.reload();
             }

            });
}
</script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     
<script type='text/javascript'>

   $(document).ready(function(){


     $('#pagination').on('click','a',function(e){

       e.preventDefault(); 

       var pageno = $(this).attr('data-ci-pagination-page');

       loadPagination(pageno);

     });

 

     loadPagination(0);

 

     function loadPagination(pagno){

       $.ajax({

         url: '<?php echo base_url(); ?>Orders/load_orders/'+pagno+'/'+<?=$orders;?>,

         type: 'get',

         dataType: 'json',

         success: function(response){

            $('#pagination').html(response.pagination);

            createTable(response.result,response.row);

         }

       });

     }

 

     function createTable(result,sno){

       sno = Number(sno);

       $('#postsList tbody').empty();
      
       for(index in result){
        //patient_id,user_unique_id,patient_name,patient_mobile_no,patient_email,address,pincode
        var order_date = result[index].order_date;  
        var order_id = result[index].order_id;
           var unique_id = result[index].unique_id;
           var firstname = result[index].firstname;
           var order_value = result[index].order_value;
           var mobile_no = result[index].mobile_no;
           var payment_status = result[index].payment_status;
      
           var estimate_del = result[index].estimate_del;
           var del_status = result[index].del_status;
          content = name.substr(0, 60) + " ...";
          var link = result[index].order_id;
          sno+=1;
          var tr = "<tr>";
          tr += "<td>"+ sno +"</td>";
          tr += "<td>"+order_date+"</td><td>"+unique_id+"</td><td>"+firstname+"</td><td>"+order_value+"</td><td>"+payment_status+"</td><td><input type='date' min='2022-06-01' name='estimate_del' id='datefield' value="+estimate_del+" onchange='del_date("+order_id+",(this.value))'  /></td><td><select id='' name='del_status'  class='' onchange='changeStatus("+order_id+",(this.value))'><option value=''>"+del_status+"</option><option value='Placed'>Placed</option><option value='Shipped'>Shipped</option><option value='Delivered'>Delivered</option><option value='Completed'>Completed</option><option value='Cancelled'>Cancelled</option> </select></td><td><a href='<?php echo base_url('details/')?>"+order_id+"'><button class='btn btn-gradient-success'>View</button></a></td>";

          tr += "</tr>";

          $('#postsList tbody').append(tr);

     

        }

      }

       

    });
</script>
  </body>
</html>