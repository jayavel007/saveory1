<div class="main-panel">
          <div class="content-wrapper">
        
            <div class="row">
          <div class="col-12 grid-margin">
                <div class="card">
                  <div class="card-body">
                    <h1 class="card-title">Add New Shop/Delivery Person</h1>
                 
                    <form class="forms-sample" method="post" action="<?php echo base_url('add_shop') ?>" enctype='multipart/form-data' autocomplete="off">
                    <div class="row">
                           <div class="col-md-6">
                        <div class="form-group">
                        <label for="exampleInputEmail1">Branch/Delivery Person Name</label>
                        <input type="text" class="form-control" id=""  required name="company_name" placeholder="" pattern="(?=.*[a-zA-Z]).{1,}"  title="Maximum 1 Alphabet Character">
                        <!-- <input type="text" class="form-control" id=""  name="company_name" placeholder=""> -->
                       
                      </div>
                        </div> 
                           <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleInputUsername1">Type <span style="color:red">*</span></label>
                        <select class="form-control"  name="branch_name">
                            <option value="shop">shop</option>
                             <option value="delivery_person">Delivery Person</option>
                        </select>
                        <!--<input type="text" class="form-control" id="" required name="branch_name" placeholder="">-->
                      </div>
                      </div>
                        <!--<div class="col-md-6">
                      <div class="form-group">
                      <label for="exampleInputPassword1">Product Image <span style="color:red">*</span></label>
                      <input type="file" class="form-control" id="exampleInputPassword1" required name="pro_image" placeholder="">
                           </div>
                           </div>
                              <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleInputUsername1">Additonal Image </label>
                        <input type="file" class="form-control" id="exampleInputUsername1"  name="add_image" multiple="multiple" placeholder="">
                      </div>
                      </div>-->
                      </div>
                     
                        <div class="row">
                     
                      <div class="col-md-6">
                      <div class="form-group">
                      <label for="exampleInputPassword1">Address<span style="color:red">*</span></label>
                      <input type="text" class="form-control" id=""  required  name="address" placeholder="">
                           </div>
                           </div>
                           <div class="col-md-6">
                      <div class="form-group">
                      <label for="exampleInputPassword1">District/City</label>
                      <input type="text" class="form-control" id=""    name="city" onkeydown="return /[a-z]/i.test(event.key)" placeholder="">
                           </div>
                           </div>
                           <div class="col-md-6">
                      <div class="form-group">
                      <label for="exampleInputPassword1">Pincode</label>
                      <input type="text" class="form-control" id=""    name="pincode" onkeypress='return event.charCode >= 48 && event.
charCode <= 57'  maxlength="6" minlength="6"  placeholder="">
                           </div>
                           </div>
                      
                             <div class="col-md-6">
                      <div class="form-group">    
                        <label for="exampleInputUsername1">Mobile No<span style="color:red">*</span></label>
                        <input type="text" class="form-control" id=""  name="mobile_no"onkeypress='return event.charCode >= 48 && event.
charCode <= 57'  maxlength="10" minlength="10"  placeholder="" required="">
                      </div>
                      </div>
                        </div>
                     
                        <div class="row">
                      
                      <div class="col-md-6">
                      <div class="form-group">
                      <label for="exampleInputPassword1">Email </label>
                      <input type="text" class="form-control" id=""  name="email" placeholder="">
                           </div>
                           </div>
                            <div class="col-md-6">
                      <div class="form-group">
                      <label for="exampleInputPassword1">Contact Name</label>
                      <input  type="text" class="form-control" id=""   name="contact_name" pattern="(?=.*[a-zA-Z]).{1,}"  title="Maximum 1 Alphabet Character" >
                      <!-- <input type="text" class="form-control" id=""   name="contact_name" placeholder=""> -->
                           </div>
                           </div>
                        </div>
                        <div class="row">
                      
                      <div class="col-md-6">
                      <div class="form-group">
                      <label for="exampleInputPassword1">Username<span style="color:red">*</span> </label>
                      <input type="text" class="form-control" id=""  required name="username" placeholder=""pattern="(?=.*[a-zA-Z]).{1,}"  title="Maximum 1 Alphabet Character">
                      <!-- <input type="text" class="form-control" id=""  required name="username" placeholder=""> -->
                           </div>
                           </div>
                            <div class="col-md-6">
                      <div class="form-group">
                      <label for="exampleInputPassword1">Password <span style="color:red">*</span></label>
                      <input type="text" class="form-control" id="" required  name="password">
                           </div>
                           </div>
                        </div>
                  
                        
                        
                        

                      
                      <button type="submit" class="btn btn-gradient-primary mr-2" style="float:right" name="submit">Submit</button>
                      <!-- <button class="btn btn-light">Cancel</button> -->
                    </form>
                  </div>
                </div>
          </div>
            </div>     
     <section class="content">
      <div class="content-wrapper">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          
         <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Shop List</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body" style="overflow: overlay;width: 100%;">
              <table class="table table-bordered table-striped sortable" id='postsList'>

             <thead>

              <tr>
                            <th> S.No</th>
                            <th>Branch name</th>
                            <th>Type</th>
                            <th>Address</th>
                            <th>District/City</th>
                            <th>Pincode</th>
                            <th>Mobile </th>
                            <th>Email </th>
                            <th>Contact </th>
                            <th> Action </th>
              </tr>

             </thead>

             <tbody id='postsList'></tbody>

           </table>       
           <!-- Paginate -->
           <div id='pagination'></div>                     
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>



        </div>
        
      </div><!-- /.container-fluid -->
    </section>
           
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->
      
          <!-- partial -->
       

              </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
  
    <!-- container-scroller -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document" >
    <div class="modal-content" style="padding: 12px;">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Shop</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form class="forms-sample" method="post" action="<?php echo base_url('add_shop') ?>" enctype='multipart/form-data'>
          <input type="hidden" name="update_id" id="update_id" value="">
                    <div class="row">
                           <div class="col-md-6">
                        <div class="form-group">
                        <label for="exampleInputEmail1">Company Name<span style="color:red">*</span></label>
                       <input type="text" class="form-control" id="company_name" required name="company_name" placeholder="">
                       
                      </div>
                        </div> 
                           <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleInputUsername1">Branch Name<span style="color:red">*</span></label>
                        <input type="text" class="form-control" id="branch_name" required name="branch_name" placeholder="">
                      </div>
                      </div>
                      <div class="col-md-6">
                      <div class="form-group">
                      <label for="exampleInputPassword1">District/City</label>
                      <input type="text" class="form-control" id="city"    name="city" onkeydown="return /[a-z]/i.test(event.key)" placeholder="">
                           </div>
                           </div>
                           <div class="col-md-6">
                      <div class="form-group">
                      <label for="exampleInputPassword1">Pincode</label>
                      <input type="text" class="form-control" id="pincode"    name="pincode" onkeypress='return event.charCode >= 48 && event.
charCode <= 57'  maxlength="6" minlength="6"  placeholder="">
                           </div>
                           </div>
                         <div class="col-md-6">
                      <div class="form-group">
                      <label for="exampleInputPassword1">Address<span style="color:red">*</span></label>
                      <input type="text" class="form-control" id="address" required name="address" placeholder="">
                           </div>
                           </div>
                              <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleInputUsername1">Mobile No</label>
                        <input type="text" class="form-control" id="mobile_no"  name="mobile_no" multiple="multiple" placeholder="">
                      </div>
                      </div>
                      </div>
                     
                        <div class="row">
                     
                      <div class="col-md-6">
                      <div class="form-group">
                      <label for="exampleInputPassword1">Email<span style="color:red">*</span></label>
                      <input type="text" class="form-control" id="email" required  name="email" placeholder="">
                           </div>
                           </div>
                            <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleInputUsername1">Contact Name<span style="color:red">*</span></label>
                        <input type="text" class="form-control" id="contact_name" required name="contact_name" placeholder="">
                      </div>
                      </div>
                        </div>
                     
                        <div class="row">
                       
                      <div class="col-md-6">
                      <div class="form-group">
                      <label for="exampleInputPassword1">Username </label>
                     <input type="text" class="form-control" id="username"  name="username" placeholder="">
                           </div>
                           </div>
                           <div class="col-md-6">
                      <div class="form-group">
                      <label for="exampleInputPassword1">Password  <span style="color:red">*</span></label>
                      <input type="text" class="form-control" id="password" required  name="password" placeholder="">
                           </div>
                           </div>
                        </div>
                        
                      
                      <button type="submit" class="btn btn-gradient-primary mr-2" style="float:right" name="submit">Submit</button>
                      <!-- <button class="btn btn-light">Cancel</button> -->
                    </form>
    </div>
  </div>
</div>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   
<script type='text/javascript'>

   $(document).ready(function(){


     $('#pagination').on('click','a',function(e){

       e.preventDefault(); 

       var pageno = $(this).attr('data-ci-pagination-page');

       loadPagination(pageno);

     });

 

     loadPagination(0);

 

     function loadPagination(pagno){

       $.ajax({

         url: '<?php echo base_url(); ?>Logo/load_shop/'+pagno,

         type: 'get',

         dataType: 'json',

         success: function(response){

            $('#pagination').html(response.pagination);

            createTable(response.result,response.row);

         }

       });

     }

 

     function createTable(result,sno){
        
       sno = Number(sno);

       $('#postsList tbody').empty();
      
       for(index in result){
        
          var shop_id = result[index].shop_id;
          var company_name = result[index].company_name;
          var branch_name = result[index].branch_name;
           var address = result[index].address;
           var city = result[index].city;
           var pincode = result[index].pincode;
           var mobile_no = result[index].mobile_no;
          var email = result[index].email;
          var contact_name = result[index].contact_name;
          sno+=1;
          var tr = "<tr>";
          tr += "<td>"+ sno +"</td>";
          tr += "<td>"+company_name+"</td><td>"+branch_name+"</td><td>"+address+"</td><td>"+city+"</td><td>"+pincode+"</td><td>"+mobile_no+"</td><td>"+email+"</td><td>"+contact_name+"</td><td><button type='button' class='btn btn-gradient-danger btn-rounded btn-icon' onclick='updateShop("+shop_id+")' data-toggle='modal' data-target='#exampleModal'><i class='mdi mdi-pencil'></i></button><button type='button' class='btn btn-gradient-warning btn-rounded btn-icon' onclick='deleteShop("+shop_id+")'><i class='mdi mdi-trash-can'></i></button></td>";

          tr += "</tr>";

          $('#postsList tbody').append(tr);

     

        }

      }

       

    });
</script>
<script>
      $(document).ready(function () {
  $('#dtBasicExample').DataTable({
    "paging": false // false to disable pagination (or any other option)
  });
  $('.dataTables_length').addClass('bs-select');
});
</script>
    <script>
  $(document ).ready(function() {
    <?php
    $msg = $this->session->userdata('msg');
    if(isset($msg)){
    ?>
    toastr.options.timeOut = 1500; // 1.5s
    toastr.<?php echo $this->session->userdata('type'); ?>("<?php echo $msg; ?>");
    <?php
    }
    $this->session->unset_userdata('msg'); 
    ?>
  });

  function getSubCategory(id){
    $.ajax({
         url: '<?php echo base_url(); ?>Products/products',
         method: 'POST',
         data: {category_id:id},
         success: function(data){
          $('#sub_cat_list').html(data);
            console.log(data);
         }

       });
 }
 
 
</script>

<script>
    function deleteShop(id){
    var answer = window.confirm("Are you want to delete shop?");
    if(answer){
        $.ajax({
            method:"POST",
            url:"<?php echo base_url('Logo/delete_shop') ?>",
            data:{shop_id:id},
            success:function(data){
             // console.log(data);
            location.reload();
            }
        });
    }
    else {
        return false;
    }
    }
    
    function getCategory(val){
            $.ajax({
            method:"POST",
            url:"<?php echo base_url('Products/get_category_type') ?>",
            data:{category_type:val},
            success:function(data){
                $('#cates').html(data);
           
            }
        });
        
    }

    function updateShop(id){
      $.ajax({
            method:"POST",
            url:"<?php echo base_url('Logo/edit_shop') ?>",
            data:{shop_id:id},
            success:function(data){
             //console.log(data);
             var datas = JSON.parse(data);
              $('#update_id').val(datas.shop_id);
              $('#company_name').val(datas.company_name);
              $('#address').val(datas.address);
              $('#mobile_no').val(datas.mobile_no);
              $('#email').val(datas.email);
              $('#contact_name').val(datas.contact_name);
              $('#username').val(datas.username);
            $('#password').val(datas.password);  
            $('#branch_name').val(datas.branch_name);  
            $('#city').val(datas.city);  
            $('#pincode').val(datas.pincode);  
            }
        });

    }
   
  </script>
  
  </body>
</html>