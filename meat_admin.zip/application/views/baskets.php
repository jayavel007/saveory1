<div class="main-panel">
          <div class="content-wrapper">
                <div class="card">
                  <div class="card-body">
                    <h1 class="card-title">Add Baskets</h1>
                 
                    <form class="forms-sample" method="post" action="<?php echo base_url('addbasket') ?>" enctype='multipart/form-data'>
                    <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputUsername1">Basket Weight <span style="color:red">*</span> </label>
                        <input type="text" class="form-control" id="exampleInputUsername1" name="basket_weight" placeholder="" required>
                      </div>
                     
                      <div class="form-group">
                        <label for="exampleInputPassword1">Basket Image <span style="color:red">*</span> </label>
                        <input type="file" class="form-control" id="exampleInputPassword1"  name="basket_image" placeholder="" required>
                      </div>
                      <button type="submit" class="btn btn-gradient-primary mr-2" style="float:right" name="submit">Submit</button>
                      <!-- <button class="btn btn-light">Cancel</button> -->
                   </div>
                    </form>
                  </div>
                </div>
              </div>
              <div class="row">
              <div class="content-wrapper">
                <div class="card">
                  <div class="card-body">
                    <h1 class="card-title">Baskets</h1>
                    <div class="table-responsive">
                      <table class="table sortable">
                        <thead>
                          <tr>
                            <th> S.No</th>
                            <th> Basket Weight</th>
                            <th> Basket Image </th>
                            <th> Status </th>
                            <th> Action </th>
                          </tr>
                        </thead>
                        <tbody>
                         
                          <?php
                           $i=1; 
                           foreach($baskets as $bas) { 
                             $id=$bas['basket_id'];
                             ?>
                          <tr>
                            <td> <?php echo $i;?> </td>
                            <td> <?php echo $bas['basket_weight']; ?> KG</td>
                            <td> <img src="<?php echo $bas['basket_image']; ?>" alt='' width='70' height='50'></td>
                             <td><label class="badge badge-gradient-info">Active</label> </td>
                            <td> <button type="button" class="btn btn-gradient-danger btn-rounded btn-icon" onclick='updateBasket(<?php echo $id; ?>)' data-toggle='modal' data-target='#exampleModal'>
                            <i class="mdi mdi-pencil"></i>
                          </button>
                          <button type="button" class="btn btn-gradient-warning btn-rounded btn-icon" onclick='deleteBasket(<?php echo $id; ?>)'>
                            <i class="mdi mdi-trash-can"></i>
                          </button>
                          </td>
                          </tr>
                          <?php $i++; } ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>

           
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->
      
          <!-- partial -->
        </div>

              </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Baskets</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo base_url('addbasket') ?>" method="post" enctype='multipart/form-data' >
        <input type="hidden" name="update_id" value="" id="update_id">
      <div class="modal-body">
                  
        <div class="form-group">
          <label for="exampleInputEmail1">Baskets Name</label>
          <input type="text" name="basket_weight" class="form-control" id="baskets" required="">
          <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
        </div>
        <div class="form-group">
          <label for="exampleInputEmail1">Baskets Image</label>
          <input type="file" name="basket_image" class="form-control" id="image" required="">
          <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
        </div>
      </div>
      <div class="modal-footer">
        <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> -->
        <button type="submit" class="btn btn-gradient-primary mr-2">Update</button>
      </div>
      </form>
    </div>
  </div>
</div>
    <script>
  $(document ).ready(function() {
    <?php
    $msg = $this->session->userdata('msg');
    if(isset($msg)){
    ?>
    toastr.options.timeOut = 1500; // 1.5s
    toastr.<?php echo $this->session->userdata('type'); ?>("<?php echo $msg; ?>");
    <?php
    }
    $this->session->unset_userdata('msg'); 
    ?>
  });


</script>

<script>
    function deleteBasket(id){
    var answer = window.confirm("Are you want to delete basket?");
    if(answer){
        $.ajax({
            method:"POST",
            url:"<?php echo base_url('Baskets/delete_basket') ?>",
            data:{basket_id:id},
            success:function(data){
             // console.log(data);
            location.reload();
            }
        });
    }
    else {
        return false;
    }
    }

    function updateBasket(id){
      $.ajax({
            method:"POST",
            url:"<?php echo base_url('Baskets/edit_baskets') ?>",
            data:{basket_id:id},
            success:function(data){
              datas = JSON.parse(data);
              $('#update_id').val(datas.basket_id);
              $('#baskets').val(datas.basket_weight);
              $('#image').val(datas.basket_image);
            }
        });

    }
  </script>
  </body>
</html>