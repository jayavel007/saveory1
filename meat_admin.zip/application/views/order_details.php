 
    <?php 
foreach($orders as $ord){
 
  $customer_name=$ord['customer_name'];
  $mobile_no=$ord['mobile_no'];
  $email=$ord['email'];
  $name=$ord['name'];
  $door_no=$ord['door_no'];
  $street=$ord['street'];
  $landmark=$ord['landmark'];
  $address_type=$ord['address_type'];
  $city=$ord['city'];
  $district=$ord['district'];
  $state=$ord['state'];
  $country=$ord['country'];
  $pincode=$ord['pincode'];
  $order_value=$ord['order_value'];
  $order_id=$ord['order_id'];
  $order_status=$ord['order_status'];
  $order_date=$ord['order_date'];
}

?>
 
     
      <div class="col-md-10 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                  <div class="d-flex justify-content-end ">
                  <a type="button" href="<?php echo base_url('orders');?>" class="btn btn-danger"> Back</a>
</div>
                    <h4 class="card-title">Order Details</h4>
                  
                    <!--<p class="card-description"> Use <code>&lt;address&gt;</code> tag </p>-->
                    <div class="row">
                            <div class="col-md-4">
                        <address>
                          <p class="font-weight-bold">Order ID</p>
                          <p><?php echo $order_id; ?></p>
                          <p class="font-weight-bold">Order Date</p>
                          <p><?php echo $order_date; ?></p>
                          <p class="font-weight-bold">Order Status</p>
                          <p><?php echo $order_status; ?></p>
                           <p class="font-weight-bold">Order Value</p>
                          <p>₹ <?php echo $order_value; ?></p>
                        </address>
                      </div>
                      <div class="col-md-4">
                        <address>
                          <p class="font-weight-bold">Customer Details</p>
                          <p> Name :  <?php echo $customer_name; ?> </p>
                          <p> Mobile No :  <?php echo $mobile_no; ?>  </p>
                          <p> Email :  <?php echo $email; ?>  </p>
                        </address>
                      </div>
                     
                          <div class="col-md-4">
                        <address>
                          <p class="font-weight-bold">Delivery Details</p>
                          <p> Address :  <?php echo $name; ?></p>
                          <p> <?php echo $door_no; ?>, <?php echo $street; ?> </p>
                          <p><?php echo $landmark; ?>, <?php echo $city; ?> </p>
                          <p><?php echo $district; ?>, <?php echo $state; ?> </p>
                          <p><?php echo $country; ?>, Pincode-<?php echo $pincode; ?> </p>
                        </address>
                      </div>
                   
                    </div>
                 <div class="row">
              <div class="col-12 grid-margin">
                <div class="card">
                  <div class="card-body">
                    <h1 class="card-title">Products</h1>
                    <div class="table-responsive">
                      <table class="table sortable">
                        <thead>
                          <tr>
                            <th> S.No</th>
                            <th> Category Name</th>
                            <th> Product Name</th>
                            <th> Quantity</th>
                       
                            <th> Product Value</th>
                            <th> Total Amount</th>
                            <!-- <th> Unit</th> -->
                          
                       
                           
                          </tr>
                        </thead>
                        <tbody>
                         
                          <?php
                           $i=1; 
                           foreach($products as $pro) {
                        
                            ?>
                          <tr>
                            <td> <?php echo $i;?> </td>
                            <td> <?php echo $pro['category_name']; ?></td>
                            <td> <?php echo $pro['product_name']; ?></td>
                            <td> <?php echo $pro['qty']; ?></td>
                            <td> <?php echo $pro['price']; ?></td>
                            <td> <?php echo $pro['price']*$pro['qty']; ?></td>
                            <!-- <td> <?php echo $pro['unit_name']; ?></td> -->
                          
                           
                          
                          </tr>
                          <?php $i++; } ?>
                        </tbody>
                      </table>
                
                    </div>
                    
                  </div>
                 
                </div>
          
              </div>
            </div>
              </div>
              </div>   

              </div>