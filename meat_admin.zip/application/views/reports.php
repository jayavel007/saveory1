<div class="main-panel">
          <div class="content-wrapper">
          <div class="card">
                  <div class="card-body">
                    <h1 class="card-title">Sales Report</h1>
                 
                    <form class="forms-sample" method="post" action="<?php echo base_url('report') ?>" enctype='multipart/form-data'>
                    
                         
                         <div class="row">
                           <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputUsername1">From Date</label>
                        <input type="date" class="form-control" id="exampleInputUsername1" name="from_date" placeholder="">
                      </div>
                    </div>
                      <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputUsername1">To Date</label>
                        <input type="date" class="form-control" id="exampleInputUsername1" name="to_date" placeholder="">
                      </div>
                      </div>
                      </div>
                         <div class="row">
                         <div class="col-md-6">
                     <div class="form-group">
                        <label for="exampleInputUsername1">Customer</label>
                         <select class="form-control" id="" name="customer" >
                              <option value="">Select Customer</option>
                              <?php foreach($customer as $cust){ ?>
                              <option value=<?php  echo $cust['customer_id']; ?> >   <?php echo $cust['firstname']; ?> </option>
                              <?php } ?>
                             
                        </select>
                       
                      </div>
                      </div>
                      <div class="col-md-6">
                     <div class="form-group">
                        <label for="exampleInputUsername1">Products</label>
                         <select class="form-control" id="" name="product" >
                              <option value="">Select Products</option>
                              <?php foreach($products as $pro){ ?>
                              <option value=<?php  echo $pro['product_id']; ?> >   <?php echo $pro['product_name']; ?> </option>
                              <?php } ?>
                             
                        </select>
                       
                      </div>
                      </div>
                           <!-- <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputUsername1">Today Sales</label>
                        <input type="date" class="form-control"id="exampleInputUsername1" name="today" placeholder="" >
                        
                      </div>
                    </div> -->

                    <!-- <select class="form-control" id="select-state" placeholder="Pick a state...">
    <option value="">Select a state...</option>
    <option value="AL">Alabama</option>
    <option value="AK">Alaska</option>
    <option value="AZ">Arizona</option>
    <option value="AR">Arkansas</option>
    <option value="CA">California</option>
    <option value="CO">Colorado</option>
    <option value="CT">Connecticut</option>
    <option value="DE">Delaware</option>
    <option value="DC">District of Columbia</option>
    <option value="FL">Florida</option>
    <option value="GA">Georgia</option>
    <option value="HI">Hawaii</option>
    <option value="ID">Idaho</option>
    <option value="IL">Illinois</option>
    <option value="IN">Indiana</option>
  </select>

                      <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputUsername1">Products</label>
                        <input type="text" class="form-control" id="names"  list="product_names"  name="products" placeholder="" onkeyup="searchProduct(this.value)" >
                        <datalist id="product_names" style="width: 50px" ></datalist>
                      </div>
                      </div>
                      </div> -->
                      <div class="row m-2" >
                   
                      <div class="form-group">
                      <button type="submit" class="btn btn-gradient-primary mr-2" style="float:right" name="submit">Submit</button>
                              </div>
                      <!-- </div>
                       <div class="row">
                       <div class="col-md-6">
                     <div class="form-group">
                        <label for="exampleInputUsername1">From Time</label>
                        <input type="time" class="form-control" id="exampleInputUsername1" name="from_time" placeholder="">
                      </div>
                      </div>
                       <div class="col-md-6">
                       <div class="form-group">
                        <label for="exampleInputUsername1">To Time</label>
                        <input type="time" class="form-control" id="exampleInputUsername1" name="to_time" placeholder="">
                      </div>
                       </div>
                      </div> -->
                      <!--<div class="form-group">-->
                      <!--  <label for="exampleInputUsername1">Products</label>-->
                      <!--  <input type="text" class="form-control" id="exampleInputUsername1" name="product" placeholder="">-->
                      <!--</div>-->
                      
                      <!-- <button class="btn btn-light">Cancel</button> -->
                      
                             
                            
                    </form>
           
                              </div>
                              </div>    
                      
                    
              
       <!-- <section class="content-wrapper"> -->
      <div class="card">
        <!-- Small boxes (Stat box) -->
        <div class="row">
              <div class="col-12 grid-margin">
                <div class="card">
                  <div class="card-body">
                    <h1 class="card-title">Orders</h1>
                    <div class="table-responsive">
                      <table class="table sortable">
                        <thead>
                          <tr>
                            <th> S.No</th>
                            <th> Order Id</th>
                            <th> Order Date</th>
                            <th> Customer Name</th>                      
                            <th> Mobile Number </th>
                            <th> Payment Status </th>
                            <th> Order Value </th>
                            <th> Delivery Status </th>
                           
                          </tr>
                        </thead>
                        <tbody>
                         
                          <?php
                          
                           if(is_array($sales)&&count($sales)) {
                           $i=1; 
                           foreach($sales as $bas) {
                            
                            ?>
                          <tr>
                            <td> <?php echo $i;?> </td>
                            <td> <?php echo $bas['unique_id']; ?></td>
                            <td> <?php echo $bas['order_date']; ?></td>
                            <td> <?php echo $bas['firstname']; ?></td>
                            <td> <?php echo $bas['mobile_no']; ?></td>
                            <td> <?php echo $bas['payment_status']; ?></td>
                            <td> <?php echo $bas['order_value']; ?></td>
                            <td> <?php echo $bas['del_status']; ?></td>
                          
                          </tr>
                          <?php $i++; } } else {?><tr><td colspan="7" style="text-align:center;color:red;">No Data</td> </tr><?php
                        } ?> 
                          
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        
      </div><!-- /.container-fluid -->
    </section>
   </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->
      
          <!-- partial -->
        </div>

              </div>
      <!-- page-body-wrapper ends -->
    </div>
   
                      




<!-- <div class="main-panel">-->
<!--          <div class="content-wrapper">-->
        
<!--<div class="row">-->
<!--        </div>-->

<!--    </div>-->
      <!-- page-body-wrapper ends -->
<!--    </div>-->
    <!-- container-scroller -->
  
    <!-- container-scroller -->
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     
<script type='text/javascript'>

   $(document).ready(function(){


     $('#pagination').on('click','a',function(e){

       e.preventDefault(); 

       var pageno = $(this).attr('data-ci-pagination-page');

       loadPagination(pageno);

     });

 

     loadPagination(0);

 

     function loadPagination(pagno){

       $.ajax({

         url: '<?php echo base_url(); ?>Reports/load_reports/'+pagno,

         type: 'get',

         dataType: 'json',

         success: function(response){

            $('#pagination').html(response.pagination);

            createTable(response.result,response.row);

         }

       });

     }

 

     function createTable(result,sno){

       sno = Number(sno);

       $('#postsList tbody').empty();
      
       for(index in result){
        //patient_id,user_unique_id,patient_name,patient_mobile_no,patient_email,address,pincode
           var order_id = result[index].order_id;
           var unique_id = result[index].unique_id;
           var firstname = result[index].firstname;
           var order_value = result[index].order_value;
           var mobile_no = result[index].mobile_no;
           var payment_status = result[index].payment_status;
           var estimate_del = result[index].estimate_del;
           var del_status = result[index].del_status;
          content = name.substr(0, 60) + " ...";
          var link = result[index].order_id;
          sno+=1;
          var tr = "<tr>";
          tr += "<td>"+ sno +"</td>";
          tr += "<td>"+unique_id+"</td><td>"+firstname+"</td><td>"+mobile_no+"</td><td>"+payment_status+"</td><td>"+order_value+"</td><td>"+del_status+"</td>";

          tr += "</tr>";

          $('#postsList tbody').append(tr);

     

        }

      }

       

    });
</script>
    <script>
  $(document ).ready(function() {
    <?php
    $msg = $this->session->userdata('msg');
    if(isset($msg)){
    ?>
    toastr.options.timeOut = 1500; // 1.5s
    toastr.<?php echo $this->session->userdata('type'); ?>("<?php echo $msg; ?>");
    <?php
    }
    $this->session->unset_userdata('msg'); 
    ?>
  });
    function searchProduct(val){
        //alert(val);
       if(val.length<2){
         return false;
        }
    $.ajax({
            method:"POST",
            url:"<?php echo base_url('Reports/search_product') ?>",
            data:{product_name:val},
            success:function(data){
                console.log(data);
                $('#product_names').html(data);
              }

            });
   }

</script>

  </body>
</html>

