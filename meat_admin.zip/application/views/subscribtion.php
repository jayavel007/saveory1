<div class="main-panel">
          <div class="content-wrapper">
                <div class="card">
                  <div class="card-body">
                    <h1 class="card-title">Add Subscription </h1>
                 
                    <form class="forms-sample" method="post" action="<?php echo base_url('addsubscribtion') ?>" enctype='multipart/form-data'>
                         <div class="row">
                        
                    <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputUsername1">Subscription Name <span style="color:red">*</span></label>
                        <input type="text" class="form-control" id="exampleInputUsername1" required name="sub_name" placeholder="">
                      </div>
                     </div>
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleInputPassword1">Subscription Image <span style="color:red">*</span></label>
                        <input type="file" class="form-control" id="exampleInputPassword1" required name="sub_image" placeholder="">
                      </div>
                      </div>
                      </div>
                         
                      <div class="form-group">
                        <label for="exampleInputPassword1">Products <span style="color:red">*</span></label>
                        <input type="text" class="form-control" id="exampleInputPassword1" required name="products" placeholder="">
                      </div>
                      <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleInputPassword1">Weight <span style="color:red">*</span></label>
                        <input type="text" class="form-control" id="exampleInputPassword1" required name="weight" placeholder="">
                      </div>
                      </div>
                      <div class="col-md-6">
                       <div class="form-group">
                        <label for="exampleInputPassword1">Amount <span style="color:red">*</span></label>
                        <input type="text" class="form-control" id="exampleInputPassword1" required name="amount" placeholder="">
                      </div>
                      </div>
                      </div>
                       
                      <div class="form-group">
                        <label for="exampleInputPassword1">Validity <span style="color:red">*</span></label>
                        <input type="text" class="form-control" id="exampleInputPassword1" required name="validity" placeholder="">
                      </div>
                     <button type="submit" class="btn btn-gradient-primary mr-2" style="float:right" name="submit">Submit</button>
                      <!-- <button class="btn btn-light">Cancel</button> -->
                  
                    </form>
                    </div>
                   
                    
                  </div>
               
                      </div>
              
              <div class="row">
              <div class="content-wrapper">
                <div class="card">
                  <div class="card-body">
                    <h1 class="card-title">Subscription</h1>
                    <div class="table-responsive">
                      <table class="table sortable">
                        <thead>
                          <tr>
                            <th> S.No</th>
                            <th> Subscription </th>
                            <th> Subscription Image </th>
                             <th> Products </th>
                              <th> Weights </th>
                               <th> Amounts </th>
                               <th> Action </th>
                          </tr>
                        </thead>
                        <tbody>
                         
                          <?php
                           $i=1; 
                           foreach($subscribtion as $bas) {
                             $id=$bas['sub_id'];
                             ?>
                          <tr>
                            <td> <?php echo $i;?> </td>
                            <td> <?php echo $bas['sub_name']; ?></td>
                            <td> <img src="<?php echo $bas['sub_image']; ?>" alt='' width='70' height='50'></td>
                            <td> <?php echo $bas['products']; ?></td>
                            <td> <?php echo $bas['weights']; ?></td>
                            <td> <?php echo $bas['amounts']; ?></td>
                            <td> <button type="button" class="btn btn-gradient-danger btn-rounded btn-icon" data-toggle='modal' data-target='#exampleModal' onclick='updateSubscribtion(<?php echo $id; ?>)'>
                            <i class="mdi mdi-pencil"></i>
                          </button>
                          <button type="button" class="btn btn-gradient-warning btn-rounded btn-icon" onclick='deleteSubscribtion(<?php echo $id; ?>)'>
                            <i class="mdi mdi-trash-can"></i>
                          </button>
                          </td>
                          </tr>
                          <?php $i++; } ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
  </div>
           </div>
          </div>
        
        </div>

              </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Subscription</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo base_url('addsubscribtion') ?>" enctype='multipart/form-data' method="post" >
        <input type="hidden" name="update_id" value="" id="update_id">
      <div class="modal-body">
                  
        <div class="form-group">
          <label for="exampleInputEmail1">Subscription Name</label>
          <input type="text" name="sub_name" class="form-control" id="subname" required="">
          <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
        </div>
        <div class="form-group">
          <label for="exampleInputEmail1">Subscription Image</label>
          <input type="file" name="sub_image" class="form-control" id="image" required="">
          
        </div>
        <div class="form-group">
          <label for="exampleInputEmail1">Products</label>
          <input type="text" name="products" class="form-control" id="prod" required="">
         
        </div>
         <div class="form-group">
          <label for="exampleInputEmail1">Weights</label>
          <input type="text" name="weight" class="form-control" id="weigh" required="">
         
        </div>
         <div class="form-group">
          <label for="exampleInputEmail1">Amounts</label>
          <input type="text" name="amount" class="form-control" id="amount" required="">
         
        </div>
      </div>
      <div class="modal-footer">
        <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> -->
        <button type="submit" class="btn btn-gradient-primary mr-2">Update</button>
      </div>
      </form>
    </div>
  </div>
</div>
    <script>
  $(document ).ready(function() {
    <?php
    $msg = $this->session->userdata('msg');
    if(isset($msg)){
    ?>
    toastr.options.timeOut = 1500; // 1.5s
    toastr.<?php echo $this->session->userdata('type'); ?>("<?php echo $msg; ?>");
    <?php
    }
    $this->session->unset_userdata('msg'); 
    ?>
  });


$(function () {
    $('select').selectpicker();
});

</script>
<script>
    function deleteSubscribtion(id){
    var answer = window.confirm("Are you want to delete subscription?");
    if(answer){
        $.ajax({
            method:"POST",
            url:"<?php echo base_url('Subscribtion/delete_subscribtion') ?>",
            data:{sub_id:id},
            success:function(data){
             // console.log(data);
            location.reload();
            }
        });
    }
    else {
        return false;
    }
    }
    
       function updateSubscribtion(id){
         //  alert(id);
      $.ajax({
            method:"POST",
            url:"<?php echo base_url('Subscribtion/edit_subscribtion') ?>",
            data:{sub_id:id},
            success:function(data){
                console.log(data);
              datas = JSON.parse(data);
              $('#update_id').val(datas.sub_id);
              $('#subname').val(datas.sub_name);
             // $('#image').val(datas.sub_image);
              $('#prod').val(datas.products);
              $('#weigh').val(datas.weights);
              $('#amount').val(datas.amounts);
            }
        });

    }
    
  </script>
  </body>
</html>