            <footer class="footer">
            <div class="container-fluid clearfix">
             
              <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">  <strong>Copyright &copy; 2021 <a href="http://teckzy.com" target="_blank" rel="noopener noreferrer">TeckZy</a>.</strong>
                    All rights reserved.</span>
            </div>
          </footer>
