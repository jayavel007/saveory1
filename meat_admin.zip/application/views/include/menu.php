

<div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
<nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
            <li class="nav-item nav-profile">
            <a class="navbar-brand brand-logo" href="<?php echo base_url();?>dashboard"><img src="<?php echo base_url();?>upload/logo/iconsavoury.jpg" alt="logo" style="width: 190px;" /></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url();?>dashboard">
                <span class="menu-title">Dashboard</span>
                <i class=" mdi mdi-dialpad  menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
                <span class="menu-title">Products</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-folder-multiple-image  menu-icon"></i>
              </a>
              <div class="collapse" id="ui-basic">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item"> <a class="nav-link" href="<?php echo base_url('category');?>">Category</a></li>
                  <!-- <li class="nav-item"> <a class="nav-link" href="<?php echo base_url('subcategory');?>">Sub category</a></li> -->
                  <li class="nav-item"> <a class="nav-link" href="<?php echo base_url('products');?>">Products</a></li>
                </ul>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url('appuser');?>">
                <span class="menu-title">Retail Users</span>
                <i class="mdi mdi-account-multiple menu-icon"></i>
              </a>
            </li> 
            <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url('approvaluser');?>">
                <span class="menu-title">Wholesale Users</span>
                <i class="mdi mdi-account-multiple menu-icon"></i>
              </a>
            </li> 
            <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url('banner');?>">
                <span class="menu-title">Banners</span>
                <i class="mdi mdi-checkbox-multiple-blank  menu-icon"></i>
              </a>
            </li> 
            <!-- <li class="nav-item">
              <a class="nav-link" href="pages/icons/mdi.html">
                <span class="menu-title">Icons</span>
                <i class="mdi mdi-contacts menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="pages/forms/basic_elements.html">
                <span class="menu-title">Forms</span>
                <i class="mdi mdi-format-list-bulleted menu-icon"></i>
              </a>
            </li>-->
            <!--<li class="nav-item">-->
            <!--  <a class="nav-link" href="<?php echo base_url('baskets');?>">-->
            <!--    <span class="menu-title">Baskets</span>-->
            <!--    <i class="mdi mdi-basket  menu-icon"></i>-->
            <!--  </a>-->
            <!--</li> -->
            <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url('orders');?>">
                <span class="menu-title">Orders</span>
                <i class=" mdi mdi-cart-outline  menu-icon"></i>
              </a>
            </li> 
            <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url('reviews');?>">
                <span class="menu-title">Reviews</span>
                <i class=" mdi mdi-account-search menu-icon"></i>
              </a>
            </li> 
          
            <!--   <li class="nav-item">-->
            <!--  <a class="nav-link" data-toggle="collapse" href="#ui-bas" aria-expanded="false" aria-controls="ui-basic">-->
            <!--    <span class="menu-title">Stocks</span>-->
            <!--    <i class="menu-arrow"></i>-->
            <!--    <i class=" mdi mdi-stack-exchange menu-icon"></i>-->
            <!--  </a>-->
            <!--  <div class="collapse" id="ui-bas">-->
            <!--    <ul class="nav flex-column sub-menu">-->
            <!--      <li class="nav-item"> <a class="nav-link" href="<?php echo base_url('stock');?>">India Products</a></li>-->
            <!--      <li class="nav-item"> <a class="nav-link" href="<?php echo base_url('import');?>">Import Products</a></li>-->
                  
            <!--    </ul>-->
            <!--  </div>-->
            <!--</li>-->
            <!--<li class="nav-item">-->
            <!--  <a class="nav-link" data-toggle="collapse" href="#ui-basicsss" aria-expanded="false" aria-controls="ui-basic">-->
            <!--    <span class="menu-title">Subcription</span>-->
            <!--    <i class="menu-arrow"></i>-->
            <!--    <i class="mdi mdi-account-multiple-outline menu-icon"></i>-->
            <!--  </a>-->
            <!--  <div class="collapse" id="ui-basicsss">-->
            <!--    <ul class="nav flex-column sub-menu">-->
            <!--      <li class="nav-item"> <a class="nav-link" href="<?php echo base_url('subscribtion');?>">Subscribtion</a></li>-->
            <!--      <li class="nav-item"> <a class="nav-link" href="<?php echo base_url('subscriberslist');?>">Subscribers List</a></li>-->
                  
            <!--    </ul>-->
            <!--  </div>-->
            <!--</li>-->
            <li class="nav-item">
              <a class="nav-link" data-toggle="collapse" href="#ui-basicss" aria-expanded="false" aria-controls="ui-basic">
                <span class="menu-title">Reports</span>
                <i class="menu-arrow"></i>
                <i class="md mdi mdi-sort menu-icon"></i>
              </a>
              <div class="collapse" id="ui-basicss">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item"> <a class="nav-link" href="<?php echo base_url('report');?>">Sales Reports</a></li>
                 
                  
                </ul>
              </div>
            </li>
            <li class="nav-item">
              <a class="nav-link" data-toggle="collapse" href="#ui-basics" aria-expanded="false" aria-controls="ui-basic">
                <span class="menu-title">Settings</span>
                <i class="menu-arrow"></i>
                <i class="mdi mdi-crosshairs-gps menu-icon"></i>
              </a>
              <div class="collapse" id="ui-basics">
                <ul class="nav flex-column sub-menu">
                  <li class="nav-item"> <a class="nav-link" href="<?php echo base_url('logo');?>">Logo</a></li>
                   <li class="nav-item"> <a class="nav-link" href="<?php echo base_url('shop');?>">Shop / Delivery Person</a></li>
                  <li class="nav-item"> <a class="nav-link" href="<?php echo base_url('Logo/add_picode');?>">Add Pincode</a></li>
                  <li class="nav-item"> <a class="nav-link" href="<?php echo base_url('zone_mapping');?>">Zone Mapping</a></li>
                  <li class="nav-item"> <a class="nav-link" href="<?php echo base_url('Logo/terms');?>">Terms and Condition</a></li>
                  <li class="nav-item"> <a class="nav-link" href="<?php echo base_url('Logo/privacy');?>">Privacy Policy</a></li>
                  <li class="nav-item"> <a class="nav-link" href="<?php echo base_url('Logo/about');?>">About Us</a></li>
                </ul>
              </div>
            </li>
          <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url('logout');?>">
                <span class="menu-title">Logout</span>
                <i class=" mdi mdi-arrow-left-bold-circle  menu-icon"></i>
              </a>
            </li> 
          </ul>
        </nav>