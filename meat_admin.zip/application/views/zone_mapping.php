<div class="main-panel">
  <div class="content-wrapper">

    <section class="content">
      <div class="content-wrapper">
        <!-- Small boxes (Stat box) -->
        <div class="row">

          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Zone Mapping</h3>
              </div>
              <!-- /.card-header -->
              <form action="<?php echo  base_url('Logo/pincode_map') ?>" method="POST">
                <input type="hidden" value="" id="shop_id" name="shop_id">
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleInputEmail1">Select Shop/Delivery Person<span style="color:red">*</span></label>
                        <select name="shop_id" id="" class="form-control" required onchange=checkShop(this.value)>
                          <option value="">--CHOOSE SHOP--</option>
                          <?php foreach ($shops as $shop) { ?>
                            <option value="<?php echo $shop->shop_id; ?>"><?php echo $shop->company_name; ?> , <?php echo $shop->branch_name; ?> , <?php echo $shop->contact_name; ?></option>
                          <?php } ?>
                        </select>

                      </div>
                    </div>

                  </div>
                  <table class="table table-bordered table-striped sortable" id='postsList'>

                    <thead>
                      <?php
                      if (!empty($pincodes)) {
                        $i = 1;
                        foreach ($pincodes as $pincodes) {
                          if ($i == 1) {
                            echo "<tr>";
                          }

                      ?>
                          <td><input type="checkbox" id="<?= $pincodes->pincode; ?>" name="pincodes[]" value="<?= $pincodes->pincode; ?>">&nbsp;&nbsp;<label for="vehicle1"> <?= $pincodes->pincode . '-' . $pincodes->area; ?></label></td>

                      <?php

                          if ($i == 4) {
                            echo "</tr>";
                            $i = 0;
                          }


                          $i++;
                        }
                      } ?>

                    </thead>



                  </table>

                </div>
                <button type="submit" class="btn btn-gradient-primary mr-2" style="float:right" name="submit">Submit</button>
                <!-- /.card-body -->

            </div>
            </form>
            <!-- /.card -->
          </div>


        </div>
        <div class="row">

          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Zone Mapping (Shop List)</h3>
              </div>
              <!-- /.card-header -->

              <div class="table-responsive">
                <table class="table table-bordered sortable" id='postsList'>
                  <thead>
                    <tr>
                      <th> S.No</th>
                      <th> Shop Name</th>
                      <th> Zone Mapping </th>
                    </tr>
                  </thead>
                  <tbody id='postsList'></tbody>


                </table>
                <div id='pagination'></div>
              </div>
            </div>
          </div>
        </div>
        <div class="row">

          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Zone Mapping (Delivery Person List)</h3>
              </div>
              <!-- /.card-header -->

              <div class="table-responsive">
                <table class="table table-bordered  sortable" id='listtable'>
                  <thead>
                    <tr>
                      <th> S.No</th>
                      <th>Delivery Person Name</th>
                      <th> Zone Mapping </th>
                    </tr>
                  </thead>
                  <tbody id='listtable'></tbody>


                </table>
                <div id='pagination_new'></div>
              </div>
            </div>
          </div>
        </div>

      </div><!-- /.container-fluid -->
    </section>

  </div>
  <!-- content-wrapper ends -->
  <!-- partial:partials/_footer.html -->

  <!-- partial -->
</div>

</div>
<!-- page-body-wrapper ends -->
</div>
<!-- container-scroller -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script type='text/javascript'>
  $(document).ready(function() {


    $('#pagination_new').on('click', 'a', function(e) {

      e.preventDefault();

      var pageno = $(this).attr('data-ci-pagination-page');

      loadPagination(pageno);

    });



    loadPagination(0);

    function loadPagination(pagno) {

      $.ajax({

        url: '<?php echo base_url(); ?>Logo/load_zone1/' + pagno,

        type: 'get',

        dataType: 'json',

        success: function(response) {

          $('#pagination_new').html(response.pagination);

          createTable(response.result, response.row);

        }

      });

    }



    function createTable(result, sno) {

      sno = Number(sno);

      $('#listtable tbody').empty();

      for (index in result) {

        var shop_id = result[index].shop_id;
        var username = result[index].username;

        var pincode = result[index].pincode;

        sno += 1;
        var tr = "<tr>";
        tr += "<td>" + sno + "</td>";
        tr += "<td>" + username + "</td><td>" + pincode + "</td>";

        tr += "</tr>";

        $('#listtable tbody').append(tr);



      }

    }



  });
</script>
<script type='text/javascript'>
  $(document).ready(function() {


    $('#pagination').on('click', 'a', function(e) {

      e.preventDefault();

      var pageno = $(this).attr('data-ci-pagination-page');

      loadPagination(pageno);

    });



    loadPagination(0);



    function loadPagination(pagno) {

      $.ajax({

        url: '<?php echo base_url(); ?>Logo/load_zone/' + pagno,

        type: 'get',

        dataType: 'json',

        success: function(response) {

          $('#pagination').html(response.pagination);

          createTable(response.result, response.row);

        }

      });

    }



    function createTable(result, sno) {

      sno = Number(sno);

      $('#postsList tbody').empty();

      for (index in result) {

        var shop_id = result[index].shop_id;
        var username = result[index].username;

        var pincode = result[index].pincode;

        sno += 1;
        var tr = "<tr>";
        tr += "<td>" + sno + "</td>";
        tr += "<td>" + username + "</td><td>" + pincode + "</td>";

        tr += "</tr>";

        $('#postsList tbody').append(tr);



      }

    }



  });
</script>

<script>
  $(document).ready(function() {
    $('#dtBasicExample').DataTable({
      "paging": false // false to disable pagination (or any other option)
    });
    $('.dataTables_length').addClass('bs-select');
  });
</script>
<script>
  $(document).ready(function() {
    <?php
    $msg = $this->session->userdata('msg');
    if (isset($msg)) {
    ?>
      toastr.options.timeOut = 1500; // 1.5s
      toastr.<?php echo $this->session->userdata('type'); ?>("<?php echo $msg; ?>");
    <?php
    }
    $this->session->unset_userdata('msg');
    ?>
  });
</script>

<script>
  function checkShop(id) {
    $.ajax({
      url: '<?php echo base_url(); ?>Logo/check_pincode',
      method: 'POST',
      data: {
        shop_id: id
      },
      success: function(data) {
        datas = JSON.parse(data);
        //console.log(datas);
        //console.log(datas.pincode[0]);
        for (let i = 0; i < datas.length; i++) {
          //var pin = datas.[i]pincode;
          //console.log(datas[i].pincode);
          $('#' + datas[i].pincode).prop('checked', true);
          //$('#checkbox').prop('checked', true);
        }
      }

    });
  }
</script>

</body>

</html>