<div class="main-panel">
          <div class="content-wrapper">
                <div class="card">
                  <div class="card-body">
                    <h1 class="card-title">Add Sub Category</h1>
                 
                    <form class="forms-sample" method="post" action="<?php echo base_url('addsubcategory') ?>" enctype='multipart/form-data'>
                    <div class="col-md-6">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Category</label>
                        <select id="" name="category_id" class="form-control">
						  <option value="">--CHOOSE CATEGORY--</option>
                          <?php foreach($category as $cat){ ?>
                          <option value="<?php echo $cat['category_id'];?>"><?php echo $cat['category_name'];?></option>
                          <?php } ?>
                          
                          </select>
                       
                      </div>
                    <div class="form-group">
                        <label for="exampleInputUsername1">SubCategory Name</label>
                        <input type="text" class="form-control" id="exampleInputUsername1" name="subcategory_name" placeholder="">
                      </div>
                      <div class="form-group">
                        <label for="exampleInputPassword1">SubCategory Image</label>
                        <input type="file" class="form-control" id="exampleInputPassword1"  name="subcategory_image" placeholder="">
                      </div>
                      <button type="submit" class="btn btn-gradient-primary mr-2" style="float:right" name="submit">Submit</button>
                      <!-- <button class="btn btn-light">Cancel</button> -->
                    </div>
                    </form>
                  </div>
                </div>
                <div class="row">
              <div class="col-12 grid-margin">
                <div class="card">
                  <div class="card-body">
                    <h1 class="card-title">Category</h1>
                    <div class="table-responsive">
                      <table class="table">
                        <thead>
                          <tr>
                            <th> S.No</th>
                            <th> SubCategory Name </th>
                            <th> SubCategory Image </th>
                            <th> Status </th>
                            <th> Action </th>
                          </tr>
                        </thead>
                        <tbody>
                         
                          <?php
                           $i=1; 
                           foreach($subcategory as $cat) { ?>
                          <tr>
                            <td> <?php echo $i;?> </td>
                            <td> <?php echo $cat['sub_cat_name']; ?></td>
                            <td> <img src="<?php echo $cat['sub_cat_image']; ?>" alt='' width='70' height='50'></td>
                            <td><label class="badge badge-gradient-success">Active</label> </td>
                            <td> <button type="button" class="btn btn-gradient-danger btn-rounded btn-icon">
                            <i class="mdi mdi-email-open"></i>
                          </button>
                          <button type="button" class="btn btn-gradient-warning btn-rounded btn-icon">
                            <i class="mdi mdi-map-marker"></i>
                          </button>
                          </td>
                          </tr>
                          <?php $i++; } ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>

           
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->
      
          <!-- partial -->
        </div>

              </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
  
  
    <script>
  $(document ).ready(function() {
    <?php
    $msg = $this->session->userdata('msg');
    if(isset($msg)){
    ?>
    toastr.options.timeOut = 1500; // 1.5s
    toastr.<?php echo $this->session->userdata('type'); ?>("<?php echo $msg; ?>");
    <?php
    }
    $this->session->unset_userdata('msg'); 
    ?>
  });


</script>
  </body>
</html>