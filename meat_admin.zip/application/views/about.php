<?php 
foreach($abouts as $ter){
   $id= $ter->about_id;
   $termscon= $ter->about;
}

?>


<div class="main-panel">
          <div class="content-wrapper">
                <div class="card">
                  <div class="card-body">
                    <h1 class="card-title">About Us</h1>
                 
                    <form class="forms-sample" method="post" action="<?php echo base_url('Logo/add_about') ?>" enctype='multipart/form-data'>
                    <div class="col-md-12">
                    <div class="form-group">
                        <!--<label for="exampleInputUsername1">Terms : </label>-->
                        <input type="hidden" class="" id="" name="term_id" value="<?php echo $id; ?>" placeholder="">
                        <textarea id="editor" name="abouts" rows="4" cols="50"><?php echo $termscon; ?></textarea>
                      </div>
                      <button type="submit" class="btn btn-gradient-primary mr-2" style="float:right" name="submit">Update</button>
                  </div>
                    </form>
                  </div>
                </div>
              </div>
         </div>
          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->
      
          <!-- partial -->
        </div>

              </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
   
    <script>
   
  $(document ).ready(function() {
    <?php
    $msg = $this->session->userdata('msg');
    if(isset($msg)){
    ?>
    toastr.options.timeOut = 1500; // 1.5s
    toastr.<?php echo $this->session->userdata('type'); ?>("<?php echo $msg; ?>");
    <?php
    }
    $this->session->unset_userdata('msg'); 
    ?>
  });


</script>
  </body>
</html>