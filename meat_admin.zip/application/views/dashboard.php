


        <div class="main-panel">
          <div class="content-wrapper">
           
            <div class="card-grid">
                <a href="<?php echo base_url('orders/1');?>">
              <div class="card-bx">
                <div class="card bg-gradient-danger card-img-holder text-white">
                  <div class="card-body">
                    <img src="<?php echo base_url();?>assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                    <h3 class=" mb-3">Today Orders<i class="mdi mdi-chart-line mdi-24px float-right"></i>
                    </h3>
                    <h2 class=""><?php echo $dashboard[0]['today_orders']; ?></h2>
                  
                  </div>
                </div>
              </div>
              </a>
                <a href="<?php echo base_url('orders/1');?>">
              <div class="card-bx">
                <div class="card bg-gradient-info card-img-holder text-white">
                 <div class="card-body">
                    <img src="<?php echo base_url();?>assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                    <h3 class=" mb-3">Today Earnings<i class="mdi mdi-bookmark-outline mdi-24px float-right"></i>
                    
                    <h2 class="">₹ <?php  echo $dashboard[0]['today_earnings']==''?0:$dashboard[0]['today_earnings'] ?></h2>
                   </div>
                </div>
              </div>
                </a>
                <a href="<?php echo base_url('orders');?>">
              <div class="card-bx">
                <div class="card bg-gradient-success card-img-holder text-white">
                  <div class="card-body">
                    <img src="<?php echo base_url();?>assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                    <h3 class="mb-3">Total Earnings <i class="mdi mdi-diamond mdi-24px float-right"></i>
                    </h3>
                    <h2 class="">₹ <?php echo $dashboard[0]['total_earnings']; ?></h2>
                   
                  </div>
                </div>
              </div>
              </a>
              <a href="<?php echo base_url('appuser');?>">
                  <div class="card-bx">
                <div class="card bg-gradient-success card-img-holder text-white">
                  <div class="card-body">
                    <img src="<?php echo base_url();?>assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                    <h3 class="mb-3">App Users<i class="mdi mdi-chart-line mdi-24px float-right"></i>
                    </h3>
                    <h2 class=""><?php echo $dashboard[0]['app_user']; ?></h2>
                  
                  </div>
                </div>
              </div>
              </a>
              <a href="<?php echo base_url('products');?>">
              <div class="card-bx">
                <div class="card bg-gradient-danger card-img-holder text-white">
                  <div class="card-body">
                    <img src="<?php echo base_url();?>assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                    <h3 class=" mb-3">Products<i class="mdi mdi-bookmark-outline mdi-24px float-right"></i>
                    </h3>
                    <h2 class=""><?php echo $dashboard[0]['total_products']; ?></h2>
                   
                  </div>
                </div>
              </div>
              </a>
              <a href="<?php echo base_url('orders');?>">
              <div class="card-bx">
                <div class="card bg-gradient-info card-img-holder text-white">
                  <div class="card-body">
                    <img src="<?php echo base_url();?>assets/images/dashboard/circle.svg" class="card-img-absolute" alt="circle-image" />
                    <h3 class="mb-3">Total Orders <i class="mdi mdi-diamond mdi-24px float-right"></i>
                    </h3>
                    <h2 class=""><?php echo $dashboard[0]['total_orders']; ?></h2>
                   
                  </div>
                </div>
              </div>
              
              </a>
            </div>
      
            <div class="row">
              <div class="col-12 grid-margin">
                <div class="card">
                  <div class="card-body">
                    <h1 class="card-title">Today Orders List</h1>
                    <div class="table-responsive">
                      <table class="table sortable">
                        <thead>
                          <tr>
                            <th> S.No</th>
                            <th> Order Date</th>
                            <th> Order Id</th>
                            <th> Custmer Name</th>
                            <th> Mobile Number </th>
                            <th> Payment Status </th>
                            <th> Order Value </th>
                            <th> Delivery Date </th>
                            <th> Delivery Status </th>
                           
                          </tr>
                        </thead>
                        <tbody>
                         
                          <?php
                           $i=1; 
                           foreach($orders as $bas) {
                            $dates = $bas['estimate_del'];
                            $dateses = date('d-m-Y', strtotime($dates));
                            ?>
                          <tr>
                            <td> <?php echo $i;?> </td>
                            <td> <?php echo $bas['order_date']; ?></td>
                            <td> <?php echo $bas['unique_id']; ?></td>
                           
                            <td> <?php echo $bas['firstname']; ?></td>
                            <td> <?php echo $bas['mobile_no']; ?></td>
                            <td> <?php echo $bas['payment_status']; ?></td>
                            <td> <?php echo $bas['order_value']; ?></td>
                        
                            <td> <?php echo $dateses=='30-11--0001'?"":($dateses=='01-01-1970'?"":$dateses); ?></td>
                            <td> <?php echo $bas['del_status']; ?></td>
                          
                          </tr>
                          <?php $i++; } ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->
      
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
  
  </body>
</html>