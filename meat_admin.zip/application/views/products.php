<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<div class="main-panel">
          <div class="content-wrapper">
        
            <div class="row">
          <div class="col-12 grid-margin">
                <div class="card">
                  <div class="card-body">
                    <h1 class="card-title">Add Products</h1>
                 
                    <form class="forms-sample" method="post" action="<?php echo base_url('addproducts') ?>" enctype='multipart/form-data'>
                    <div class="row">        
                    <div class="col-md-12">
          <div class="form-group">
                        <label for="exampleInputEmail1">Category Type  <span style="color:red">*</span></label>
                        <select name="category_type" id="category_type" class="form-control" required>
                        <option value="">--CHOOSE CATEGORY TYPE--</option>
                        <?php foreach($category as $cat) { ?>
                         <option value="<?php echo $cat['category_name'].'##'.$cat['category_id']; ?>"><?php echo $cat['category_name']; ?></option>
                         <?php } ?>
                         </select>
                       
                      </div>
                        </div>
                             </div>
                        <div class="row">
                           <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleInputUsername1">Product Name <span style="color:red">*</span></label>
                        <input type="text" class="form-control" id="exampleInputUsername1" required name="product_name" placeholder="">
                      </div>
                      </div>
                         <div class="col-md-6">
                      <div class="form-group">
                      <label for="exampleInputPassword1">Product Image <span style="color:red">*</span></label>
                      <input type="file" class="form-control" id="exampleInputPassword1" required name="pro_image" placeholder="">
                           </div>
                           </div>
                              <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleInputUsername1">Additonal Image </label>
                        <input type="file" class="form-control" id="exampleInputUsername1"  name="add_image" multiple="multiple" placeholder="">
                      </div>
                      </div>

                      <div class="col-md-6">
                      <div class="form-group">
                      <label for="exampleInputPassword1">Description <span style="color:red">*</span></label>
                      <input type="text" class="form-control" id="exampleInputPassword1" required  name="description" placeholder="">
                           </div>
                           </div>
                      </div>
                     
                       <!-- <div class="row">
                     
                      <div class="col-md-6">
                      <div class="form-group">
                      <label for="exampleInputPassword1"> Gross weight <span style="color:red">*</span></label>
                      <input type="text" class="form-control" id="gross_weight"  required  name="gross_weight" placeholder="">
                           </div>
                           </div>
                        </div>!-->
                     
                       
                        <!--<div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleInputUsername1">Net weight<span style="color:red">*</span></label>
                        <input type="text" class="form-control" id="net_weight" required name="net_weight" placeholder="">
                      </div>
                      </div>!-->
                   <!--   <div class="col-md-6">
                      <div class="form-group">
                      <label for="exampleInputPassword1">piece </label>
                      <input type="text" class="form-control" id="piece"  required name="piece" placeholder="">
                           </div>
                           </div>
                        </div>!-->
                       <!-- <div class="row">!-->
                      <!--  <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleInputUsername1">Rate Value </label>
                        <input type="text" class="form-control" onkeypress="return isNumber(event)" id="exampleInputUsername1"  name="rate_value" placeholder="">
                      </div>
                      </div>!-->
                      
                      <div class="row">
                           <div class="col-md-12">
                               
                      <div class="form-group container1 grocery_price" >
                            
                            <div style="display: flex;">
                  
                            <label for="unitprice" style="padding: 10px;">Price</label>
                            <input type="text" class="form-control" id="unitprice"  class="gro_price"  name="unitprice[]" style="width:25%;" placeholder="4" required>
                            <label for="slashedprice" style="padding: 10px;">Slashed Price</label>
                            <input type="text" class="form-control" id="slashedprice"  class="gro_price"  name="slashedprice[]" style="width:25%;" placeholder="4" required>
                            &nbsp;
                            <label for="holesale_price" style="padding: 10px;">Wholesale Price</label>
                            <input type="text" class="form-control" id="holesale_price"   class="gro_price"  name="holesale_price[]" style="width:25%;" placeholder="4" required>
                            &nbsp;
                            <label for="unitprice" style="padding: 10px;">Slashed Wholesale Price</label>
                            <input type="text" class="form-control" id="slashed_whole"  class="gro_price"  name="slashed_whole[]" style="width:25%;" placeholder="4" required>
                            <label for="unit" style="padding: 10px;">Unit</label>
                           <!-- <input type="text" class="form-control" id="user_type" class="gro_price" name="user_type[]" style="width:25%;" placeholder="2"> !--> 
                              <select name="unit[]" id="unit" class="gro_price" style="width:25%;height:45px;" placeholder="2">
                                <option value="KG">KG</option>
                                <option value="G">G</option>
                              </select>
                            &nbsp;
                            <label for="unitvalue" style="padding: 10px;">Unit Value</label>
                            <input type="text" class="form-control" id="unitvalue" class="gro_price" required name="unitvalue[]" style="width:25%;" placeholder="2" required>  
                            &nbsp;
                           <!--    <label for="user_type" style="padding: 10px;">User Type</label>
                         <input type="text" class="form-control" id="user_type" class="gro_price" name="user_type[]" style="width:25%;" placeholder="2"> 
                              <select name="user_type[]" id="user_type" class="gro_price" style="width:25%;" placeholder="2">
                                <option value="wholesale">Whole sale</option>
                                <option value="retail">Retail</option>
                              </select>
                            &nbsp;!--> 
                            <button class="add_form_field" style="height: fit-content;">
                            <span style="font-size:16px; font-weight:bold;">+</span>
                            </button>    
                        </div>
                            <!-- <div><input type="text" name="mytext[]"></div> -->
                       </div>

                           </div>
                        </div>

                      
                      <button type="submit" class="btn btn-gradient-primary mr-2" style="float:right" name="submit">Submit</button>
                      <!-- <button class="btn btn-light">Cancel</button> -->
                    </form>
                  </div>
                </div>
          </div>
                
     <section class="content">
      <div class="content-wrapper">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          
         <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Products</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body"   >
              <table class="table table-bordered table-striped sortable" id='postsList' >

             <thead  >

              <tr>
                            <th> S.No</th>
                            <th> Product Name </th>
                            <th> Product Image </th>
                            <th> Category Type </th>
                            <th>Price </th>
                            <th>Slashed Price </th>
                            <th>Wholesale Price </th>
                            <th>Slashed Wholesale Price </th>
                            <th>unit</th>
                            <th>unit value </th>
                            <th> Stock / Outstock</th>
                            <th> Action </th>
                           
                           
              </tr>

             </thead>

             <tbody id='postsList' >
                 
             </tbody>

           </table>       
           <!-- Paginate -->
           <div id='pagination'></div>                     
             </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>



        </div>
        
      </div><!-- /.container-fluid -->
    </section>
           
          </div>
          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->
      
          <!-- partial -->
        </div>

              </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
  
    <!-- container-scroller -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Products</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form class="forms-sample" method="post" action="<?php echo base_url('updateproduct') ?>" 
      
      enctype='multipart/form-data'>
      <input type="hidden" value="" name="update_id" id="update_id">
      <input type="hidden"  name="update_image" id="update_image">
                  <div class="row">
                        <div class="col-md-6">
                       <div class="form-group">
                        <label for="exampleInputEmail1">Category Type  <span style="color:red">*</span></label>
                        <select name="category_type" id="category_type" class="form-control" required>
                        <option value="">--CHOOSE CATEGORY TYPE--</option>
                        <?php foreach($category as $cat) { ?>
                         <option value="<?php echo $cat['category_id'].'#'.$cat['category_name'] ; ?>"><?php echo $cat['category_name']; ?></option>
                         <?php } ?>
                         </select>
                       
                      </div>
                        </div>
                           <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleInputUsername1">Product Name <span style="color:red">*</span></label>
                        <input type="text" class="form-control" id="pro_name"  name="product_name" placeholder="">
                      </div>
                      </div>
                         <div class="col-md-6">
                      <div class="form-group">
                      <label for="exampleInputPassword1">Product Image <span style="color:red">*</span></label>
                      <input type="file" class="form-control" id="imagess" name="pro_image" placeholder="">
                           </div>
                           </div>
                          
                    </div>
                    <div  class="row">
                              <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleInputUsername1">Additonal Image </label>
                        <input type="file" class="form-control" id="imagess"  name="add_image" multiple="multiple" placeholder="">
                      </div>
                      </div>

                      <div class="col-md-6">
                      
                      <div class="form-group">
                      <label for="exampleInputPassword1">Description <span style="color:red">*</span></label>
                      <input type="text" class="form-control" id="desc" 
                        name="description" placeholder="">
                           </div>
                           </div>
                      </div>
                     
                      <!--  <div class="row">
                     
                      <div class="col-md-6">
                      <div class="form-group">
                      <label for="exampleInputPassword1"> Gross weight <span style="color:red">*</span></label>
                      <input type="text" class="form-control" id="gross_weight" onkeypress="return isNumber(event)" required  name="Gross_weight" placeholder="">
                           </div>
                           </div>
                        </div>
                     !-->
                   <!--     <div class="row">
                        <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleInputUsername1">Net Weight<span style="color:red">*</span></label>
                        <input type="text" class="form-control" id="net_weight" required name="net_weight" placeholder="">
                      </div>
                      </div>
                      <div class="col-md-6">
                      <div class="form-group">
                      <label for="exampleInputPassword1">Piece </label>
                     <input type="text" class="form-control" id="piece" onkeypress="return isNumber(event)"  name="piece" placeholder="">
                           </div>
                           </div>
                        </div>!-->
                       <!-- <div class="row">!-->
                       <!-- <div class="col-md-6">
                      <div class="form-group">
                        <label for="exampleInputUsername1">Rate Value </label>
                        <input type="text" class="form-control" onkeypress="return isNumber(event)" id="star"  name="rate_value" placeholder="">
                      </div>
                      </div>!-->
                      
                           
                        <!--</div>!-->

                      
                      <button type="submit" class="btn btn-gradient-primary mr-2" style="float:right" name="submit">Submit</button>
                      <!-- <button class="btn btn-light">Cancel</button> -->
                    </form>
    </div>
  </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   
   
   <script>
        $(document).ready(function () {
                
          
            $('#pagination').on('click','a',function(e){
   
                e.preventDefault(); 
   
                var pageno = $(this).attr('data-ci-pagination-page');
   
                loadPagination(pageno);
   
            });
            
                loadPagination(0);
                
            function loadPagination(pagno){
            
        
              $.ajax({
       
                url: '<?php echo base_url(); ?>Products/load_products/'+pagno,
       
                type: 'get',
       
                dataType: 'json',
       
                success: function(response){
       
                   $('#pagination').html(response.pagination);
       
                   createTable(response.result,response.row);
       
                }
       
              });
   
            }
       
               function createTable(result,sno){   
                sno = Number(sno);
   
                $('#postsList tbody').empty();
                
                       for(index in result){
                    
                    var product_id = result[index].product_id;
                    var product_name = result[index].product_name;
                    var pro_image = result[index].pro_image;
                    var category_type = result[index].category_type;
        
                    var price = result[index].price;
                    var holesale_price = result[index].holesale_price;
                    var slashedprice = result[index].slashedprice;
                    var slashed_wholesale = result[index].slashed_wholesale;
                    var unit = result[index].unit;
                    var unit_name = result[index].unit_name;
                    var active_id = result[index].active_id;
                    if (active_id == '1') {
                        var active_id1 = "<center><button type='button' class='btn btn-rounded btn-icon btn-gradient-warning' onclick='active_product("+product_id+")'>IN</button></center>";
                    }else{
                        var active_id1 = "<center><button type='button' class='btn btn-rounded btn-icon bg-danger ' onclick='deactive_product("+product_id+")'>Out</button></center>";
                    }
                    content = name.substr(0, 60) + " ...";
                    var link = result[index].product_id;
                    sno+=1;
                    var tr = "<tr>";
                        tr += "<td>"+ sno +"</td>";
                        tr += "<td>"+product_name+"</td><td><center><img src="+pro_image+" alt='' width='70' height='50'></center></td><td><center>"+category_type+"</center></td><td>"+price+"</td><td><center>"+slashedprice+"</center></td><td><center>"+holesale_price+"</center></td><td><center>"+slashed_wholesale+"</center></td><td><center>"+unit+"</center></td><td><center>"+unit_name+"</center></td><td>"+active_id1+"</td><td><button type='button' class='btn btn-gradient-danger btn-rounded btn-icon' onclick='updateProducts("+product_id+")' data-toggle='modal' data-target='#exampleModal'><i class='mdi mdi-pencil'></i></button><button type='button' class='btn btn-gradient-warning btn-rounded btn-icon' onclick='deleteProduct("+product_id+")'><i class='mdi mdi-trash-can'></i></button></td>";
       
                        tr += "</tr>";
       
                    $('#postsList tbody').append(tr);
                }
            }
            
            
                       $('#dtBasicExample').DataTable({
              "paging": false 
             });
             $('.dataTables_length').addClass('bs-select');
             
             
        });
   </script>
       <script>
     $(document).ready(function() {
       <?php
       $msg = $this->session->userdata('msg');
       if(isset($msg)){
       ?>
       toastr.options.timeOut = 1500; // 1.5s
       toastr.<?php echo $this->session->userdata('type'); ?>("<?php echo $msg; ?>");
       <?php
       }
       $this->session->unset_userdata('msg'); 
       ?>
     });
   
    /* function getSubCategory(id){
       $.ajax({
            url: '<?php echo base_url(); ?>Products/products',
            method: 'POST',
            data: {category_id:id},
            success: function(data){
             $('#sub_cat_list').html(data);
               console.log(data);
            }
   
          });
    }
    */
    
   </script>
   
   <script>
       function deleteProduct(id){
       var answer = window.confirm("Are you want to delete product?");
       if(answer){
           $.ajax({
               method:"POST",
               url:"<?php echo base_url('Products/delete_product') ?>",
               data:{product_id:id},
               success:function(data){
                // console.log(data);
               location.reload();
               }
           });
       }
       else {
           return false;
       }
       }
       
            function active_product(id){
       var answer = window.confirm("Do you want to Out of Stock?");
       if(answer){
           $.ajax({
               method:"POST",
               url:"<?php echo base_url('Products/active_product') ?>",
               data:{product_id:id},
               success:function(data){
                console.log(data);
               location.reload();
               }
           });
       }
       else {
           return false;
       }
       }
       
               function deactive_product(id){
       var answer = window.confirm("Do you want to Stock Available?");
       if(answer){
           $.ajax({
               method:"POST",
               url:"<?php echo base_url('Products/deactive_product') ?>",
               data:{product_id:id},
               success:function(data){
                console.log(data);
               location.reload();
               }
           });
       }
       else {
           return false;
       }
       }
       
       
       function stock_product(id){
       var answer = window.confirm("Do you want to activate  product?");
       if(answer){
           $.ajax({
               method:"POST",
               url:"<?php echo base_url('Products/active_product') ?>",
               data:{product_id:id},
               success:function(data){
                console.log(data);
               location.reload();
               }
           });
       }
       else {
           return false;
       }
       }
       
               function outstock_product(id){
       var answer = window.confirm("Do you want to Deactivate product?");
       if(answer){
           $.ajax({
               method:"POST",
               url:"<?php echo base_url('Products/deactive_product') ?>",
               data:{product_id:id},
               success:function(data){
                console.log(data);
               location.reload();
               }
           });
       }
       else {
           return false;
       }
       }
       function getCategory(val){
               $.ajax({
               method:"POST",
               url:"<?php echo base_url('Products/get_category_type') ?>",
               data:{category_type:val},
               success:function(data){
                   $('#cates').html(data);
              
               }
           });
           
       }
   
       function updateProducts(id){
         $.ajax({
               method:"POST",
               url:"<?php echo base_url('Products/edit_products') ?>",
               data:{product_id:id},
               success:function(data){
                console.log(data);
                var datas = JSON.parse(data);
   
                 $('#update_id').val(datas.product_id);
                $('#category_type').val(datas.category_id);
                 $('#pro_name').val(datas.product_name);
                 //$('#imagess').val(datas.pro_image);
                 $('#update_image').val(datas.pro_image);
                 $('#desc').val(datas.description);
                 console.log(datas.gross_weight);
                 //$('#prices').val(datas.price);
                 //$('#gross_weight_edit').val(datas.gross_weight);
                 //$('#net_weight_edit').val(datas.net_weight);
                 //$('#piece_edit').val(datas.piece);
              //   $('#pprices').val(datas.p_price);
               //  $('#dprices').val(datas.d_price);
                // $('#boxprices').val(datas.box_price);
                 //$('#basprices').val(datas.bas_price);
                 //$('#looseprices').val(datas.loose_price);
                 $('#units').val(datas.unit);
                 //$('#rating').val(datas.rating);
                 //$('#star').val(datas.star_value);
                 $('#categ_id').val(datas.category_id);
                 
                 
               }
           });
   
       }
      
     </script>
     
   <script>
        
          $(document).ready(function(){
              
       var max_fields = 10;
       var wrapper = $(".container1");
       var add_button = $(".add_form_field");
   
       var x = 1;
       $(add_button).click(function(e) {
           
           var unitprice = $('#unitprice').val();
           var slashedprice = $('#slashedprice').val();
           var holesale_price=$('#holesale_price').val();
           var slashed_whole=$('#slashed_whole').val();
           var unit=$('#unit').val();
           var unitvalue=$('#unitvalue').val();
           //var user_type=$('#user_type').val();
           e.preventDefault();
           if (x < max_fields) {
               x++;
               $(wrapper).append('<div style="display:flex; margin-top:10px;"><label for="unitprice" style="padding: 10px;">Price</label><input type="text" class="form-control" required name="unitprice[]" value="'+unitprice+'" style="width: 90%;">&nbsp;<label for="slashedprice" style="padding: 10px;">Slashed Price</label><input type="text" class="form-control" required name="slashedprice[]" value="'+slashedprice+'" style="width: 90%;">&nbsp; <label for="holesale_price" style="padding: 10px;">Wholesale Price</label><input type="text" class="form-control" id="holesale_price" value="'+holesale_price+'"class="gro_price"  name="holesale_price[]" style="width:90%;" placeholder="4" required>&nbsp;<label for="slashed_whole" style="padding: 10px;">Slashed Wholesale Price</label><input type="text" class="form-control" id="slashed_whole" value="'+slashed_whole+'"class="gro_price"  name="slashed_whole[]" style="width:90%;" placeholder="4" required>&nbsp;<label for="unit" style="padding: 10px;">Unit</label><select name="unit[]" value="'+unit+'"id="unit" class="gro_price" style="width: 90%;height:45px;" placeholder="2" required><option value="KG" selected>KG</option><option value="G">G</option></select><label for="unitvalue" style="padding: 10px;">Unit Value</label><input type="text" class="form-control" id="unitvalue" required name="unitvalue[]" value="'+unitvalue+'"style="width: 90%;" placeholder="">   <a href="#" class="delete" style="padding: 10px;">Delete</a></div>'); //add input box
           } 
           $('#unitprice').val("");
           $('#slashedprice').val("");
           $('#slashed_whole').val("");
           $('#holesale_price').val("");
          //  $('#unit').val("");
           $('#unitvalue').val("");
          // $('#user_type').val("");
       });
          $(wrapper).on("click", ".delete", function(e) {
           e.preventDefault();
           $(this).parent('div').remove();
           x--;
       })
   });
   </script>
     </body>
   </html>