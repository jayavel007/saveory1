<div class="main-panel">
  <div class="content-wrapper">
    <div class="card">
      <div class="card-body">
        <h1 class="card-title">Add Category</h1>

        <form class="forms-sample" method="post" action="<?php echo base_url('addcategory') ?>" enctype='multipart/form-data'>
          <div class="col-md-6">
            <div class="form-group">
              <label for="exampleInputUsername1">Category Name <span style="color:red">*</span> </label>
              <input type="text" class="form-control" id="exampleInputUsername1" pattern="(?=.*[a-zA-Z]).{1,}" title="Maximum 1 Alphabet Character" required name="category_name" placeholder="">
            </div>

            <!--  <div class="form-group">-->
            <!--    <label for="exampleInputEmail1">Category type <span style="color:red">*</span></label>-->
            <!--    <select id="" name="category_type" class="form-control" required>-->
            <!--<option value="">--SELECT--</option>-->
            <!--      <option value="India">India</option>-->
            <!--      <option value="Import">Imported</option>-->
            <!--      </select>-->

            <!--  </div>-->
            <div class="form-group">
              <label for="exampleInputPassword1">Category Image <span style="color:red">*</span></label>
              <input type="file" class="form-control" id="exampleInputPassword1" required name="category_image" placeholder="">
            </div>
            <button type="submit" class="btn btn-gradient-primary mr-2" style="float:right" name="submit">Submit</button>
            <!-- <button class="btn btn-light">Cancel</button> -->
          </div>
        </form>
      </div>
    </div>
  </div>
  <section class="content">
    <div class="content-wrapper">
      <!-- Small boxes (Stat box) -->
      <div class="row">

        <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Categories</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table class="table table-bordered table-striped sortable" id='postsList'>

                <thead>

                  <tr>
                    <th> S.No</th>
                    <th> Category Name </th>
                    <th> Category Image </th>
                    <!--<th> Category Type </th>-->
                    <th> Action </th>
                  </tr>

                </thead>

                <tbody id='postsList'></tbody>

              </table>
              <!-- Paginate -->
              <div id='pagination'></div>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>



      </div>

    </div><!-- /.container-fluid -->
  </section>


</div>
<!-- content-wrapper ends -->
<!-- partial:partials/_footer.html -->

<!-- partial -->
</div>

</div>
<!-- page-body-wrapper ends -->

<!-- container-scroller -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Category</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?php echo base_url('addcategory') ?>" method="post" enctype='multipart/form-data'>
        <input type="hidden" name="update_id" value="" id="update_id">
        <div class="modal-body">

          <div class="form-group">
            <label for="exampleInputEmail1">Category Name</label>
            <input type="text" name="category_name" class="form-control" id="cat">
            <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
          </div>
          <!--<div class="form-group">-->
          <!--                <label for="exampleInputEmail1">Category type</label>-->
          <!--                <select id="types" name="category_type" class="form-control">-->
          <!--            <option value="">--SELECT--</option>-->
          <!--                  <option value="India">India</option>-->
          <!--                  <option value="Import">Imported</option>-->
          <!--                  </select>-->

          <!--              </div>-->
          <!-- <div class="form-group">
          <label for="exampleInputEmail1">Category Image</label>
          <input type="file" name="category_image" class="form-control" id="image">
          </div> -->
          <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
          <div class="form-group" id="imgfile">
          </div>
          <div class="form-group" id="imgview">
          </div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> -->
          <button type="submit" class="btn btn-gradient-primary mr-2">Update</button>
        </div>
      </form>
    </div>
  </div>
</div>



<!-- <div class="main-panel">-->
<!--          <div class="content-wrapper">-->

<!--<div class="row">-->
<!--        </div>-->

<!--    </div>-->
<!-- page-body-wrapper ends -->
<!--    </div>-->
<!-- container-scroller -->

<!-- container-scroller -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script type='text/javascript'>
  $(document).ready(function() {


    $('#pagination').on('click', 'a', function(e) {

      e.preventDefault();

      var pageno = $(this).attr('data-ci-pagination-page');

      loadPagination(pageno);

    });



    loadPagination(0);



    function loadPagination(pagno) {

      $.ajax({

        url: '<?php echo base_url(); ?>Products/load_category/' + pagno,

        type: 'get',

        dataType: 'json',

        success: function(response) {

          $('#pagination').html(response.pagination);

          createTable(response.result, response.row);

        }

      });

    }



    function createTable(result, sno) {

      sno = Number(sno);

      $('#postsList tbody').empty();

      for (index in result) {
        //patient_id,user_unique_id,patient_name,patient_mobile_no,patient_email,address,pincode
        var category_id = result[index].category_id;
        var category_name = result[index].category_name;
        var category_image = result[index].category_image;
        var category_type = result[index].category_type;
        content = name.substr(0, 60) + " ...";
        var link = result[index].category_id;
        sno += 1;
        var tr = "<tr>";
        tr += "<td>" + sno + "</td>";
        tr += "<td>" + category_name + "</td><td><img src=" + category_image + " alt='' width='70' height='50'></td><td><button type='button' class='btn btn-gradient-danger btn-rounded btn-icon' data-toggle='modal' data-target='#exampleModal' onclick='updateCategory(" + category_id + ")'><i class='mdi mdi-pencil'></i></button><button type='button' class='btn btn-gradient-warning btn-rounded btn-icon' onclick='deleteCategory(" + category_id + ")'><i class='mdi mdi-trash-can'></i></button></td>";

        tr += "</tr>";

        $('#postsList tbody').append(tr);



      }

    }



  });
</script>
<script>
  $(document).ready(function() {
    <?php
    $msg = $this->session->userdata('msg');
    if (isset($msg)) {
    ?>
      toastr.options.timeOut = 1500; // 1.5s
      toastr.<?php echo $this->session->userdata('type'); ?>("<?php echo $msg; ?>");
    <?php
    }
    $this->session->unset_userdata('msg');
    ?>
  });
</script>

<script>
  function deleteCategory(id) {
    var answer = window.confirm("Are you want to delete category?");
    if (answer) {
      $.ajax({
        method: "POST",
        url: "<?php echo base_url('Products/delete_category') ?>",
        data: {
          category_id: id
        },
        success: function(data) {
          // console.log(data);
          location.reload();
        }
      });
    } else {
      return false;
    }
  }

  function remove_image(id) {
    // alert(id);
    $.ajax({
      method: "POST",
      url: "<?php echo base_url('Products/remove_category') ?>",
      data: {
        category_id: id
      },
      success: function(data) {
        updateCategory(id);
      }
    });
  }

  function updateCategory(id) {
    $.ajax({
      method: "POST",
      url: "<?php echo base_url('Products/edit_category') ?>",
      data: {
        category_id: id
      },
      success: function(data) {
        datas = JSON.parse(data);
        $('#update_id').val(datas.category_id);
        $('#cat').val(datas.category_name);
        // $('#types').val(datas.category_type);
        // alert(datas.category_image)
        if (datas.category_image == '') {
          var file = '<label for="exampleInputEmail1">Banner Image</label><input type="file" name="category_image" class="form-control" id="image" required>';
          $("#imgfile").html(file);
          $("#imgview").html('');
        } else {
          // alert(datas.category_image);
          var img = '<img src="' + datas.category_image + '" alt="" width="70" height="50">&nbsp;&nbsp;<button type="button" onclick="remove_image(' + id + ')">delete</button>';
          $("#imgfile").html('');
          $("#imgview").html(img);
        }
        // $('#image').val(datas.category_image);
      }
    });

  }
</script>
</body>

</html>