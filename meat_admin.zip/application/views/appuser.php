<div class="main-panel">
          <div class="content-wrapper">
 
 <section class="content">
      <div class="content">
      <div class="content-wrapper">
        <!-- Small boxes (Stat box) -->
        <div class="row">
          
         <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Activate Users</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table class="table table-bordered table-striped sortable" id='postsList'>

             <thead>

              <tr>
                            <th> S.No</th>
                            <th> Name </th>
                            <th> Mobile </th>
                            <th> Email </th>
                            <!-- <th> Image </th> -->
                            <th> Status </th>
              </tr>

             </thead>

             <tbody id='postsList'></tbody>

           </table>       
           <!-- Paginate -->
           <div id='pagination'></div>                     
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>



        </div>
        </div>
        </div>
        <div class="content">
          <div class="content-wrapper">
        <div class="row">
          
         <div class="col-12">
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">Deactivate Users</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table class="table table-bordered table-striped sortable" id='postsList1'>

             <thead>

              <tr>
                            <th> S.No</th>
                            <th> Name </th>
                            <th> Mobile </th>
                            <th> Email </th>
                            <!-- <th> Image </th> -->
                            <th> Status </th>
              </tr>

             </thead>

             <tbody id='postsList1'></tbody>

           </table>       
           <!-- Paginate -->
           <div id='pagination1'></div>                     
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>



        </div>
      </div><!-- /.container-fluid -->
      </div>
    </section>
</div>

</div>
<!--</div>-->
<!--</div>-->

    <!-- container-scroller -->
  
    <!-- container-scroller -->
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     
<script type='text/javascript'>

   $(document).ready(function(){


     $('#pagination').on('click','a',function(e){

       e.preventDefault(); 

       var pageno = $(this).attr('data-ci-pagination-page');

       loadPagination(pageno);

     });

 

     loadPagination(0);

 

     function loadPagination(pagno){

       $.ajax({

         url: '<?php echo base_url(); ?>Appuser/load_users/'+pagno,

         type: 'get',

         dataType: 'json',

         success: function(response){

            $('#pagination').html(response.pagination);

            createTable(response.result,response.row);

         }

       });

     }

 

     function createTable(result,sno){

       sno = Number(sno);

       $('#postsList tbody').empty();
      
       for(index in result){
        //patient_id,user_unique_id,patient_name,patient_mobile_no,patient_email,address,pincode
          var customer_id = result[index].customer_id;
          var firstname = result[index].firstname;
          var mobile_no = result[index].mobile_no;
          var email = result[index].email;
          // var image = result[index].image;
          content = name.substr(0, 60) + " ...";
          var link = result[index].customer_id;
          sno+=1;
          var tr = "<tr>";
          tr += "<td>"+ sno +"</td>";
          tr += "<td>"+firstname+"</td><td>"+mobile_no+"</td><td>"+email+"</td><td><button  class='btn btn-gradient-danger btn-fw' onclick='deactivate("+customer_id+")'>Deactivate</button></td>";

          tr += "</tr>";

          $('#postsList tbody').append(tr);

     

        }

      }

       

    });
</script>
<script type='text/javascript'>

   $(document).ready(function(){


     $('#pagination1').on('click','a',function(e){

       e.preventDefault(); 

       var pageno = $(this).attr('data-ci-pagination-page');

       loadPagination(pageno);

     });

 

     loadPagination(0);

 

     function loadPagination(pagno){

       $.ajax({

         url: '<?php echo base_url(); ?>Appuser/load_deusers/'+pagno,

         type: 'get',

         dataType: 'json',

         success: function(response){

            $('#pagination1').html(response.pagination);

            createTable(response.result,response.row);

         }

       });

     }

 

     function createTable(result,sno){

       sno = Number(sno);

       $('#postsList1 tbody').empty();
      
       for(index in result){
        //patient_id,user_unique_id,patient_name,patient_mobile_no,patient_email,address,pincode
          var customer_id = result[index].customer_id;
          var firstname = result[index].firstname;
          var mobile_no = result[index].mobile_no;
          var email = result[index].email;
          // var image = result[index].image;
          content = name.substr(0, 60) + " ...";
          var link = result[index].customer_id;
          sno+=1;
          var tr = "<tr>";
          tr += "<td>"+ sno +"</td>";
          tr += "<td>"+firstname+"</td><td>"+mobile_no+"</td><td>"+email+"</td><td><button  class='btn btn-gradient-success btn-fw' onclick='activate("+customer_id+")'>Activate</button></td>";

          tr += "</tr>";

          $('#postsList1 tbody').append(tr);

     

        }

      }

       

    });
</script>
    <script>
  $(document ).ready(function() {
    <?php
    $msg = $this->session->userdata('msg');
    if(isset($msg)){
    ?>
    toastr.options.timeOut = 1500; // 1.5s
    toastr.<?php echo $this->session->userdata('type'); ?>("<?php echo $msg; ?>");
    <?php
    }
    $this->session->unset_userdata('msg'); 
    ?>
  });

 
</script>

<script>
  function deactivate(id){
    // alert(id);
     $.ajax({
                "url":"<?php echo base_url(); ?>appuser/activate",
                "method":"POST",
                data:{id:id,
            
                },
                success:function(data){
                    // console.log(data);
                    window.location.reload();
                }

            });
  }

  function activate(id){
    // alert(id);
     $.ajax({
                "url":"<?php echo base_url(); ?>appuser/deactivate",
                "method":"POST",
                data:{id:id,
            
                },
                success:function(data){
                    // console.log(data);
                    window.location.reload();
                }

            });
  }
  </script>
  
     
  </body>
</html>