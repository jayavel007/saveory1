<?php

class Reports_model extends CI_Model{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('form', 'url'));
	}
  
  

    
    public function sales_report(){
		$from_date = $this->input->post('from_date');
		$to_date = $this->input->post('to_date');
	    $product = $this->input->post('product');
	    $customer_id = $this->input->post('customer');
		$date=date('Y-m-d');
	if(!empty($from_date) && !empty($to_date)){
				$this->db->where('order_date >=', $from_date);
				$this->db->where('order_date <=', $to_date);
			}
		if(!empty($product)){
		    $this->db->where('add_to_cart.product_id', $product); 
		}
		if(!empty($customer_id)){
			$this->db->where('orders.customer_id', $customer_id);
		}
		if(empty($from_date) && empty($to_date)&& empty($product) && empty($customer_id)){
			$this->db->where('order_date', $date);
		}
		$this->db->select('*');
		$this->db->from('add_to_cart');
		$this->db->join('orders','add_to_cart.order_id=orders.order_id');
		$this->db->join('customer','customer.customer_id=orders.customer_id');
$this->db->where('add_to_cart.status','1');
$query = $this->db->get();

return $query->result_array();
		}
		
	  function get_customer(){
		    $data['status'] = 1;
			$this->db->join('orders','customer.customer_id=orders.customer_id');
			$this->db->group_by('customer.firstname'); 
	        $query = $this->db->get_where('customer',$data);
	        return $query->result_array();
		}
		function get_products(){
		    $data['status'] = 1;
	        $query = $this->db->get_where('product',$data);
	        return $query->result_array();
		}
}
?>