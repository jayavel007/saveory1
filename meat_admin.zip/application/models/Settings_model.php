<?php

class Settings_model extends CI_Model{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('form', 'url'));
	}
    function add_logo(){
        $config['upload_path'] = 'upload/logo/';
        $config['allowed_types'] = 'gif|jpg|png|pdf';
        
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('logo_image')) {
            $error = array('error' => $this->upload->display_errors());
            //$this->load->view('files/upload_form', $error);
            $img = "";
        } else {
            $file_info = $this->upload->data();
            $img = 'upload/logo/'.$file_info['file_name'];
            echo $img;
            
        }
        
         $update_id=$this->input->post('update_id');
        $datas['logo_image'] = $img;
        $datas['logo_name'] = $this->input->post('logo_name');
  if($update_id==''){
        $query = $this->db->insert('logo',$datas);
        //print_r($this->db->last_query());  
        if($query){
            $this->session->set_userdata('type','success');
            $this->session->set_userdata('msg','Logo Added Successfully');
            return true;
        }else{
           $this->session->set_userdata('type','error');
            $this->session->set_userdata('msg','Logo Added Failed');
            return false;
        }
    }else{
        $this->db->where('logo_id',$update_id);
        $qry = $this->db->update('logo',$datas);
       }
        if($qry){
            $this->session->set_userdata('type','success');
            $this->session->set_userdata('msg','Logo Updated Successfully');
            return true;
        }else{
           $this->session->set_userdata('type','error');
            $this->session->set_userdata('msg','Logo Updated Failed');
            return false;
        }
       
    }
       
       
       function get_logo(){
        $data['status'] = 1;
        $query = $this->db->get_where('logo',$data);
        return $query->result_array();
       }

       function add_term(){
        $term_id = 1;
        $datas['terms'] = $this->input->post('terms');
        $this->db->where('term_id',$term_id);
        $query = $this->db->update('terms',$datas);
        //print_r($this->db->last_query());  
        if($query){
            $this->session->set_userdata('type','success');
            $this->session->set_userdata('msg','Terms & Condition Updated Successfully');
           // return true;
        }else{
           $this->session->set_userdata('type','error');
            $this->session->set_userdata('msg','Terms & Condition Updated Failed');
            //return false;
        }
       }
       function get_term(){
        $data['status'] = 1;
        $query = $this->db->get_where('terms',$data);
        return $query->result_array();
       }

       function delete_logo(){
        $logo_id = $this->input->post('logo_id');
        $this->db->where('logo_id',$logo_id);
        $data['status'] = 0;
        $query = $this->db->update('logo',$data);
        if($query){
            $this->session->set_userdata('type','success');
            $this->session->set_userdata('msg','Logo Deleted Successfully');
            return true;
        }else{
           $this->session->set_userdata('type','error');
            $this->session->set_userdata('msg','Logo Deleted Failed');
            return false;
        }
       }
       function edit_logo(){
             $data['logo_id'] = $this->input->post('logo_id');
		$query = $this->db->get_where('logo',$data);
		foreach ($query->result() as $key => $row) {
			$value['logo_id'] = $row->logo_id;
			$value['logo_name'] = $row->logo_name;
			
		}
		echo json_encode($value);
       }
       function add_shop(){
           
           
           $update_id = $this->input->post('update_id');
            $data['company_name'] = $this->input->post('company_name');
            $data['branch_name'] = $this->input->post('branch_name');
            $data['address'] = $this->input->post('address');
            $data['city'] = $this->input->post('city');
            $data['pincode'] = $this->input->post('pincode');
            $data['mobile_no'] = $this->input->post('mobile_no');
            $data['email'] = $this->input->post('email');
            $data['contact_name'] = $this->input->post('contact_name');
            $data['username'] = $this->input->post('username');
            $data['password'] = $this->input->post('password');
            if($update_id==''){
                $query=$this->db->insert('shop',$data);
                $msg="Added";
            }else{
                 $msg="Updated";
                $this->db->where('shop_id',$update_id);
                $query=$this->db->update('shop',$data);
            }
            
            if($query){
                $this->session->set_userdata('type','success');
                $this->session->set_userdata('msg','Shop '.$msg.' Successfully');
            }else{
                $this->session->set_userdata('type','error');
                $this->session->set_userdata('msg','Shop '.$msg.' Failed');
            }
       }
       function edit_shops(){
        $data['shop_id'] = $this->input->post('shop_id');
        $query = $this->db->get_where('shop',$data);
        if($query->num_rows()>0){
            foreach($query->result() as $key=>$row){
                $datas['shop_id'] = $row->shop_id;
                $datas['company_name'] = $row->company_name;
                $datas['branch_name'] = $row->branch_name;
                $datas['city'] = $row->city;
                $datas['pincode'] = $row->pincode;
                $datas['address'] = $row->address;
                $datas['mobile_no'] = $row->mobile_no;
                $datas['email'] = $row->email;
                $datas['contact_name'] = $row->contact_name;
                $datas['username'] = $row->username;
                $datas['password'] = $row->password;
                
            }
        }
        echo json_encode($datas);
    }
    function delete_shop(){
        $shop_id = $this->input->post('shop_id');
        $data['status']=0;
        $this->db->where('shop_id',$shop_id);
        $query = $this->db->update('shop',$data);
        if($query){
            $this->session->set_userdata('type','success');
            $this->session->set_userdata('msg','Shop Deleted Successfully');
        }else{
           $this->session->set_userdata('type','error');
            $this->session->set_userdata('msg','Shop Deleted Failed');

        }
    }
    function get_shop(){
        $data['status']=1;
        $query = $this->db->get_where('shop',$data);
        return $query->result();
    }
    function get_zone(){
        $this->db->select('pincode_map.pincode,pincode_map.shop_id,shop.username');
		$this->db->from('pincode_map');
        $this->db->join('shop','shop.shop_id=pincode_map.shop_id');
        $this->db->where('shop.branch_name',"delivery_person");
        $query = $this->db->get();
        return $query->result();
    }
    function get_pincodes(){
        $data['status']=1;
        $query = $this->db->get_where('pincode',$data);
        return $query->result();
    }
    function pincode_map(){
        $shop_id=$this->input->post('shop_id');
        $pincodes=$this->input->post('pincodes');
        $this->db->where('shop_id',$shop_id);
        $query = $this->db->delete('pincode_map');
        if($query){
            $this->session->set_userdata('type','success');
            $this->session->set_userdata('msg','Pincode Assign Successfully');
         for($i=0;$i<count($pincodes);$i++){
              $datas['pincode'] = $pincodes[$i]; 
              $datas['shop_id'] = $shop_id;
              $this->db->insert('pincode_map',$datas);
            }
        }else{
            $this->session->set_userdata('type','error');
            $this->session->set_userdata('msg','Pincode Assign Failed');
        }
    }
    
    function check_pincode(){
        $data['shop_id'] = $this->input->post('shop_id');
        $query = $this->db->get_where('pincode_map',$data);
        if($query->num_rows()>0){
            foreach($query->result() as $key=>$row){
                $datas[]=array('pincode' => $row->pincode);
                
            }
        }else{
           $datas = array(); 
        }
        echo json_encode($datas);
    }
    function get_terms(){
        $data['status']=1;
        $query = $this->db->get_where('terms',$data);
        return $query->result();
    }
    function get_policy(){
        $data['status']=1;
        $query = $this->db->get_where('privacy_policy',$data);
        return $query->result();
    }
    
    function add_policy(){
        $policy = 1;
        $datas['policy'] = $this->input->post('policy');
        $this->db->where('privacy_policy_id',$policy);
        $query = $this->db->update('privacy_policy',$datas);
        //print_r($this->db->last_query());  
        if($query){
            $this->session->set_userdata('type','success');
            $this->session->set_userdata('msg','Privacy Policy Updated Successfully');
           // return true;
        }else{
           $this->session->set_userdata('type','error');
            $this->session->set_userdata('msg','Privacy Policy Updated Failed');
            //return false;
        }
    }
    function get_about(){
        $data['status']=1;
        $query = $this->db->get_where('about',$data);
        return $query->result();
    }
    function add_abouts(){
        $policy = 1;
        $datas['about'] = $this->input->post('abouts');
        $this->db->where('about_id',$policy);
        $query = $this->db->update('about',$datas);
        //print_r($this->db->last_query());  
        if($query){
            $this->session->set_userdata('type','success');
            $this->session->set_userdata('msg','About Us Updated Successfully');
           // return true;
        }else{
           $this->session->set_userdata('type','error');
            $this->session->set_userdata('msg','About Us Updated Failed');
            //return false;
        }
    }
    function save_pincode(){
        
        $update_id=$this->input->post('update_id');
        $datas['pincode'] = $this->input->post('pincode');
        $datas['area'] = $this->input->post('area');
        if($update_id==''){
            $msg="Added";
            $query = $this->db->insert('pincode',$datas);
        }else{
            $msg="Update";
            $this->db->where('picode_id',$update_id);
        $query = $this->db->update('pincode',$datas);    
            }
        
        //print_r($this->db->last_query());  
        if($query){
            $this->session->set_userdata('type','success');
            $this->session->set_userdata('msg','Pincode '.$msg.' Successfully');
        }else{
           $this->session->set_userdata('type','error');
            $this->session->set_userdata('msg','Pincode '.$msg.' Failed');
        }
    
        
    }
    function delete_pincodes(){
        $pincode_id = $this->input->post('pincode_id');
        $data['status']=0;
        $this->db->where('picode_id',$pincode_id);
        $query = $this->db->update('pincode',$data);
        if($query){
            $this->session->set_userdata('type','success');
            $this->session->set_userdata('msg','Pincode Deleted Successfully');
        }else{
           $this->session->set_userdata('type','error');
            $this->session->set_userdata('msg','Pincode Deleted Failed');

        }
    }
    function edit_pincode(){
        $data['picode_id'] = $this->input->post('pincode_id');
        $query = $this->db->get_where('pincode',$data);
        if($query->num_rows()>0){
            foreach($query->result() as $key=>$row){
                $datas['picode_id'] = $row->picode_id;
                $datas['pincode'] = $row->pincode;
                $datas['area'] = $row->area;
               
                
            }
        }
        echo json_encode($datas);
    }
    
}
?>