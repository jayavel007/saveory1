<?php

class Stock_model extends CI_Model{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('form', 'url'));
	}
   
    function get_stocks(){
        $this->db->select('*');
        $this->db->from('stocks');
        $this->db->join('product','product.product_id=stocks.product_id');
        $this->db->where('stocks.status',1);
        $query = $this->db->get();
        //print_r($this->db->last_query());
        return $query->result_array();
    }
    
    function get_india_products(){
       
        $this->db->select('*');
        $this->db->from('product');
        $this->db->where('category_type','india');
        $query = $this->db->get();
        //print_r($this->db->last_query());
        return $query->result_array();
    }
    
      function get_import_products(){
       
        $this->db->select('*');
        $this->db->from('product');
        $this->db->where('category_type','import');
        $query = $this->db->get();
        //print_r($this->db->last_query());
        return $query->result_array();
    }
    
    function updateStock(){
       	$product_id = $this->input->post('product_id');
       $stock = $this->input->post('stock');
       	if($stock=="InStock"){
       	    $data['stock']="In Stock";
       	}elseif($stock=="Outofstock"){
       	    $data['stock']="Out of stock";
       	}
		$this->db->where('product_id',$product_id);
		$query = $this->db->update('product',$data);
	  if($query){
            $this->session->set_userdata('type','success');
            $this->session->set_userdata('msg','Stock Updated Successfully');
            return true;
        }else{
           $this->session->set_userdata('type','error');
            $this->session->set_userdata('msg','Stock Updated Failed');
            return false;
        }
    }
    
}
?>