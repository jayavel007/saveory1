<?php

class Order_model extends CI_Model{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('form', 'url'));
	}


    function get_orders($id){
		$date=date('Y-m-d');
		if($id==1){
			$this->db->where('orders.order_date',$date);
		}
        $this->db->select('*');
	    $this->db->from('orders');
	    $this->db->join('customer','customer.customer_id=orders.customer_id');
	    $this->db->where('orders.order_status',1);
	    $query = $this->db->get();
        return $query->result_array(); 
    }
	public function set_status(){
         
	    $order_id=$this->input->post('order_id');
		$data['del_status']=$this->input->post('del_status');
        $this->db->where('order_id',$order_id);
		$query = $this->db->update('orders',$data);
		if($query){
			$this->session->set_userdata('type','success');
			$this->session->set_userdata('msg','Orders Status Changed');
			return true;
		}else{
		   $this->session->set_userdata('type','error');
			$this->session->set_userdata('msg','Orders Status Changed Failed');
			return false;
		}

	}

	function del_date(){
		$order_id=$this->input->post('order_id');
		$data['estimate_del']=$this->input->post('estimate_del');
		
        $this->db->where('order_id',$order_id);
		$query = $this->db->update('orders',$data);
		if($query){
			$this->session->set_userdata('type','success');
			$this->session->set_userdata('msg','Estimated Delivery Date Changed');
			return true;
		}else{
		   $this->session->set_userdata('type','error');
			$this->session->set_userdata('msg','Estimated Delivery Date Failed');
			return false;
		}
	}
	
	function get_order_details($id){
	    $this->db->select('*');
	    $this->db->from('orders');
	    $this->db->join('customer','customer.customer_id=orders.customer_id');
	    $this->db->join('address','address.customer_id=orders.customer_id');
	    $this->db->where('orders.order_id',$id);
	    $query = $this->db->get();
	   // print_r($this->db->last_query());
	    foreach ($query->result() as $key => $row) {
        $datas[] = array(				
                "customer_name"=>$row->firstname,
                "mobile_no"=>$row->mobile_no,
                "email"=>$row->email,
                "name"=>$row->name,
                "door_no"=>$row->door_no,
                "street"=>$row->street,
                "landmark"=>$row->landmark,
                "address_type"=>$row->address_type,
                "city"=>$row->city,
                "district"=>$row->district,
                "state"=>$row->state,
                "country"=>$row->country,
                "pincode"=>$row->pincode,
                "order_value"=>$row->order_value,
                "order_id"=>$row->unique_id,
                "order_status"=>$row->del_status,
				"order_date"=>$row->order_date,
            );
            
        }
    return $datas;
	}
	
	function get_order_products($id){
	    $this->db->select('*');
	    $this->db->from('add_to_cart');
	    $this->db->join('product','product.product_id=add_to_cart.product_id');
		$this->db->join('category','category.category_id=product.category_id');
	   // $this->db->join('address','address.customer_id=orders.customer_id');
	    $this->db->where('add_to_cart.order_id',$id);
	
	    $query = $this->db->get();
	    //print_r($this->db->last_query());
	    return $query->result_array(); 
	}
}
?>