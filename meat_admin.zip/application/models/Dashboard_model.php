<?php

class Dashboard_model extends CI_Model{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('form', 'url'));
	}
   function get_orders(){
	$date=date('Y-m-d');
        $this->db->select('*');
	    $this->db->from('orders');
	   
	    $this->db->order_by('order_id','desc');
	    $this->db->join('customer','customer.customer_id=orders.customer_id');
		$this->db->where('orders.order_date',$date);
	    $this->db->where('orders.order_status',1);
	    $query = $this->db->get();
        return $query->result_array(); 
    }
    
    function get_mtd(){
        $date = date('Y-m-d');;
        $sql="SELECT (SELECT COUNT(*)  from orders WHERE order_status=1 ) total_orders,
	           (SELECT COUNT(*)  from product WHERE status=1 ) total_products,
	           (SELECT COUNT(*) from customer WHERE status=1) app_user,
	           (SELECT COUNT(*)  from orders WHERE order_status=1 and order_date='$date') today_orders,
	           (SELECT sum(order_value) from orders WHERE order_status=1 ) total_earnings,
	           (SELECT sum(order_value) from orders WHERE order_status=1 and order_date='$date' ) today_earnings";  
	           $query = $this->db->query($sql);
	        //  print_r($this->db->last_query());
    return $query->result_array();
    }
}
?>