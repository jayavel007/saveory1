<?php

class Subscribtion_model extends CI_Model{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('form', 'url'));
	}
    function add_subscribtion(){
        $config['upload_path'] = 'upload/subscribtion/';
        $config['allowed_types'] = 'gif|jpg|png|pdf';
        
        $this->load->library('upload', $config);
        if (!$this->upload->do_upload('sub_image')) {
            $error = array('error' => $this->upload->display_errors());
            //$this->load->view('files/upload_form', $error);
            $img = "";
        } else {
            $file_info = $this->upload->data();
            $img = 'upload/subscribtion/'.$file_info['file_name'];
            //echo $img;
        }
        
        
        $datas['sub_image'] = $img;
        $update_id=$this->input->post('update_id');
        $datas['sub_name'] = $this->input->post('sub_name');
        $datas['products'] = $this->input->post('products');
        $datas['weights'] = $this->input->post('weight');
        $datas['amounts'] = $this->input->post('amount');
        $datas['validity'] = $this->input->post('validity');
         if($update_id==''){
        
        $query = $this->db->insert('subscribtion',$datas);
        //print_r($this->db->last_query());  
        if($query){
            $this->session->set_userdata('type','success');
            $this->session->set_userdata('msg','Subscribtion Added Successfully');
            return true;
        }else{
           $this->session->set_userdata('type','error');
            $this->session->set_userdata('msg','Subscribtion Added Failed');
            return false;
        }
       }else{
            $this->db->where('sub_id',$update_id);
        $query = $this->db->update('subscribtion',$datas);
        //print_r($this->db->last_query());  
        if($query){
            $this->session->set_userdata('type','success');
            $this->session->set_userdata('msg','Subscribtion Updated Successfully');
            return true;
        }else{
           $this->session->set_userdata('type','error');
            $this->session->set_userdata('msg','Subscribtion Updated Failed');
            return false;
        }
       }
    }
       function get_subscribtion(){
        $data['status'] = 1;
        $query = $this->db->get_where('subscribtion',$data);
        return $query->result_array();
       }

       function get_subscribers(){
        $this->db->select('*');
	    $this->db->from('subscribers_list');
	    $this->db->join('customer','customer.customer_id=subscribers_list.customer_id');
        $this->db->join('subscribtion','subscribtion.sub_id=subscribers_list.sub_id');
	    $this->db->where('subscribers_list.status',1);
	    $query = $this->db->get();
        return $query->result_array(); 
       }

       function get_reviews(){
        $this->db->select('*');
	    $this->db->from('product_reviews');
	    $this->db->join('customer','customer.customer_id=product_reviews.customer_id');
	    $this->db->join('product','product.product_id=product_reviews.product_id');
        $this->db->order_by('product_reviews.reviews_id','desc');
	    $this->db->where('product_reviews.view_status',1);
	    $query = $this->db->get();
        return $query->result_array(); 
       }

       function get_deactivereviews(){
        $this->db->select('*');
	    $this->db->from('product_reviews');
	    $this->db->join('customer','customer.customer_id=product_reviews.customer_id');
	    $this->db->join('product','product.product_id=product_reviews.product_id');
        $this->db->order_by('product_reviews.reviews_id','desc');
	    $this->db->where('product_reviews.view_status',0);
	    $query = $this->db->get();
        return $query->result_array(); 
       }

       function delete_subscribtion(){
        $sub_id = $this->input->post('sub_id');
        $this->db->where('sub_id',$sub_id);
        $data['status'] = 0;
        $query = $this->db->update('subscribtion',$data);
        if($query){
            $this->session->set_userdata('type','success');
            $this->session->set_userdata('msg','Subscribtion Deleted Successfully');
            return true;
        }else{
           $this->session->set_userdata('type','error');
            $this->session->set_userdata('msg','Subscribtion Deleted Failed');
            return false;
        } 
       }
    function delete_subscriber(){
        $subscribers_id  = $this->input->post('subscribers_id');
        $this->db->where('subscribers_id',$subscribers_id );
        $data['status'] = 0;
        $query = $this->db->update('subscribers_list',$data);
        if($query){
            $this->session->set_userdata('type','success');
            $this->session->set_userdata('msg','Subscriber Deleted Successfully');
            return true;
        }else{
           $this->session->set_userdata('type','error');
            $this->session->set_userdata('msg','Subscriber Deleted Failed');
            return false;
        } 
    }
       function viewed_review(){
        $reviews_id = $this->input->post('reviews_id');
        $this->db->where('reviews_id',$reviews_id);
        $data['view_status'] = 0;
        // $data['status'] = 1;
        $query = $this->db->update('product_reviews',$data);
        if($query){
            $this->session->set_userdata('type','success');
            $this->session->set_userdata('msg','Reviews Viewed');
            return true;
        }else{
           $this->session->set_userdata('type','error');
            $this->session->set_userdata('msg','Reviews Viewed Failed');
            return false;
        } 
       }
       
       function delete_review(){
        $reviews_id  = $this->input->post('reviews_id');
        $this->db->where('reviews_id',$reviews_id );
        $data['status'] = 0;
        $data['view_status'] = 0;
        $query = $this->db->update('product_reviews',$data);
        if($query){
            $this->session->set_userdata('type','success');
            $this->session->set_userdata('msg','Reviews Deleted Successfully');
            return true;
        }else{
           $this->session->set_userdata('type','error');
            $this->session->set_userdata('msg','Reviews Deleted Failed');
            return false;
        } 
       }
        function edit_subscribtion(){
        $data['sub_id'] = $this->input->post('sub_id');
		$query = $this->db->get_where('subscribtion',$data);
		foreach ($query->result() as $key => $row) {
			$value['sub_id'] = $row->sub_id;
			$value['sub_name'] = $row->sub_name;
			 $value['sub_image'] = $row->sub_image;
            $value['products'] = $row->products;
            $value['weights'] = $row->weights;
            $value['amounts'] = $row->amounts;
			
		}
		echo json_encode($value);
       }
}
?>