<?php

class Banners_model extends CI_Model{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('form', 'url'));
	}
    function add_banner(){
        $update_id=$this->input->post('update_id');
        $config['upload_path'] = 'upload/banner/';
        $config['allowed_types'] = 'gif|jpg|png|pdf';
        
        $this->load->library('upload', $config);
        if(!empty($_FILES['banner_image']['name'])){
   
        if (!$this->upload->do_upload('banner_image')) {
            $error = array('error' => $this->upload->display_errors());
            //$this->load->view('files/upload_form', $error);
            $img = "";
        } else {
            $file_info = $this->upload->data();
            $img = 'upload/banner/'.$file_info['file_name'];
            //echo $img;
        }
    
        $datas['banner_image'] = $img;
        
    }
       
    $datas['banner_name'] = $this->input->post('banner_name');
        if($update_id==''){
       
        $query = $this->db->insert('banner',$datas);
        //print_r($this->db->last_query());  
        if($query){
            $this->session->set_userdata('type','success');
            $this->session->set_userdata('msg','Banner Added Successfully');
            return true;
        }else{
           $this->session->set_userdata('type','error');
            $this->session->set_userdata('msg','Banner Added Failed');
            return false;
        }
    }else{
        $this->db->where('banner_id',$update_id);
        $query = $this->db->update('banner',$datas);
        //print_r($this->db->last_query());  
        if($query){
            $this->session->set_userdata('type','success');
            $this->session->set_userdata('msg','Banner Updated Successfully');
            return true;
        }else{
           $this->session->set_userdata('type','error');
            $this->session->set_userdata('msg','Banner Updated Failed');
            return false;
        }
    }
       }
       function get_banner(){
        $data['status'] = 1;
        $query = $this->db->get_where('banner',$data);
        return $query->result_array();
       }
       function remove_banner(){
            $banner_id=$this->input->post('banner_id');
            $data1['banner_id'] = $banner_id;
            $query = $this->db->get_where('banner',$data1);  
            foreach ($query->result() as $key => $row) {
                unlink($row->banner_image);
            }
            
            $data['banner_image'] = "";
            $this->db->where('banner_id',$banner_id);
            $query = $this->db->update('banner',$data);
            //unlink();
       }
       function delete_banner(){
        $banner_id = $this->input->post('banner_id');
		$this->db->where('banner_id',$banner_id);
		$data['status'] = 0;
		$query = $this->db->update('banner',$data);
        if($query){
            $this->session->set_userdata('type','success');
            $this->session->set_userdata('msg','Banner Deleted Successfully');
            return true;
        }else{
           $this->session->set_userdata('type','error');
            $this->session->set_userdata('msg','Banner Deleted Failed');
            return false;
        }
       }

       function edit_banners(){
        $data['banner_id'] = $this->input->post('banner_id');
		$query = $this->db->get_where('banner',$data);
		foreach ($query->result() as $key => $row) {
			$value['banner_id'] = $row->banner_id;
			$value['banner_name'] = $row->banner_name;
            $value['banner_image'] = $row->banner_image;
			
		}
		echo json_encode($value);
       }

      
   
}
?>