<?php

class Approvaluser_model extends CI_Model{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('form', 'url'));
	}
    function get_customer(){
        //$data['approval_status']= 1;
        //$data['user_type']="holesale";
        $data = array("approval_status" =>1,"user_type"=>"holesale"); 
        $query = $this->db->get_where('customer',$data);
        //print_r($query->result_array());
        return $query->result_array();
       }
      

       function get_deactivate(){
        // $data['approval_status']= 0;
        // $data['user_type']="holesale";
        $data = array("approval_status" =>0,"user_type"=>"holesale"); 
        $query = $this->db->get_where('customer',$data);
        //print_r($query->result_array());
        return $query->result_array(); 
       }

       

       function activate(){
        $customer_id = $this->input->post('id');
		$this->db->where('customer_id',$customer_id);
		$data['approval_status'] = 0;
		$query = $this->db->update('customer',$data);
        if($query){
            $this->session->set_userdata('type','success');
            $this->session->set_userdata('msg','Deactivated Successfully');
            return true;
        }else{
           $this->session->set_userdata('type','error');
            $this->session->set_userdata('msg','Deactivated Failed');
            return false;
        }
       }

       function deactivate(){
        $customer_id = $this->input->post('id');
		$this->db->where('customer_id',$customer_id);
		$data['approval_status'] = 1;
		$query = $this->db->update('customer',$data);
        if($query){
            $this->session->set_userdata('type','success');
            $this->session->set_userdata('msg','Activated Successfully');
            return true;
        }else{
           $this->session->set_userdata('type','error');
            $this->session->set_userdata('msg','Activated Failed');
            return false;
        }
       }
}
?>