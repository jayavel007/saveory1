<?php

class Products_model extends CI_Model
{
	function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form', 'url'));
	}
	function add_category()
	{
		$config['upload_path'] = 'upload/category/';
		$config['allowed_types'] = 'gif|jpg|png|pdf';

		$this->load->library('upload', $config);
		if (!empty($_FILES['category_image']['name'])) {
			if (!$this->upload->do_upload('category_image')) {
				$error = array('error' => $this->upload->display_errors());
				//$this->load->view('files/upload_form', $error);
				$img = "";
			} else {
				$file_info = $this->upload->data();
				$img = 'upload/category/' . $file_info['file_name'];
				//echo $img;
			}
			$update_id = $this->input->post('update_id');
			$datas['category_image'] = $img;
		}
		$datas['category_name'] = $this->input->post('category_name');
		//$datas['category_type'] = $this->input->post('category_type');

		if ($update_id == '') {
			$query = $this->db->insert('category', $datas);
			//print_r($this->db->last_query());  
			if ($query) {
				$this->session->set_userdata('type', 'success');
				$this->session->set_userdata('msg', 'category Added Successfully');
				return true;
			} else {
				$this->session->set_userdata('type', 'error');
				$this->session->set_userdata('msg', 'category Added Failed');
				return false;
			}
		} else {
			$this->db->where('category_id', $update_id);
			$query = $this->db->update('category', $datas);
			//print_r($this->db->last_query());  
			if ($query) {
				$this->session->set_userdata('type', 'success');
				$this->session->set_userdata('msg', 'category Updated Successfully');
				return true;
			} else {
				$this->session->set_userdata('type', 'error');
				$this->session->set_userdata('msg', 'category Updated Failed');
				return false;
			}
		}
	}
	function edit_category()
	{
		$data['category_id'] = $this->input->post('category_id');
		$query = $this->db->get_where('category', $data);
		foreach ($query->result() as $key => $row) {
			$value['category_id'] = $row->category_id;
			$value['category_name'] = $row->category_name;
			$value['category_image'] = $row->category_image;
			//$value['category_type'] = $row->category_type;

		}
		echo json_encode($value);
	}
	function remove_category()
	{
		$category_id = $this->input->post('category_id');
		// echo $category_id;
		// exit;
		$data1['category_id'] = $category_id;
		$query = $this->db->get_where('category', $data1);
		foreach ($query->result() as $key => $row) {
			unlink($row->category_image);
		}

		$data['category_image'] = "";
		$this->db->where('category_id', $category_id);
		$query = $this->db->update('category', $data);
		// print_r($this->db->last_query());
		//unlink();
	}
	function get_category()
	{
		$data['status'] = 1;
		$query = $this->db->get_where('category', $data);
		return $query->result_array();
	}
	function remove_image()
	{
		$banner_id = $this->input->post('category_id');
		$data1['category_id'] = $banner_id;
		$query = $this->db->get_where('category', $data1);
		foreach ($query->result() as $key => $row) {
			unlink($row->banner_image);
		}

		$data['category_image'] = "";
		$this->db->where('category_id', $banner_id);
		$query = $this->db->update('category', $data);
		//unlink();
	}

	/*  function get_subcategory(){
	$data['status'] = 1;
	$query = $this->db->get_where('product',$data);
	return $query->result_array();
   }*/
	/*  function get_category_type(){
   $type= $data['category_type'] = $this->input->post('category_type');
    if($type=='india'){
        $value="0";
    }else{
        $value="23";
    }
	$query = $this->db->get_where('category',$data);
	
	$html= '<select id="cates" name="category_id" class="form-control" >
		    <option value="">--CHOOSE CATEGORY--</option>
		    <option value='.$value.'>NO CATEGORY</option>';
  	foreach ($query->result() as $key => $row) {
    $html .=	'<option value='.$row->category_id.'>'.$row->category_name.'</option>';
	  
		}
		 $html .= '</select>';
		 echo $html;
 }*/
	/*function add_sub_category(){
	$config['upload_path'] = 'upload/sub_category/';
	$config['allowed_types'] = 'gif|jpg|png|pdf';
	
	$this->load->library('upload', $config);
	if (!$this->upload->do_upload('subcategory_image')) {
		$error = array('error' => $this->upload->display_errors());
		//$this->load->view('files/upload_form', $error);
		$img = "";
	} else {
		$file_info = $this->upload->data();
		$img = 'upload/sub_category/'.$file_info['file_name'];
		//echo $img;
	}
	$datas['sub_cat_image'] = $img;
	$datas['sub_cat_name'] = $this->input->post('subcategory_name');
	$datas['category_id'] = $this->input->post('category_id');
	$query = $this->db->insert('sub_category',$datas);
	//print_r($this->db->last_query());  
	if($query){
		$this->session->set_userdata('type','success');
		$this->session->set_userdata('msg','Subcategory Added Successfully');
		return true;
	}else{
	   $this->session->set_userdata('type','error');
		$this->session->set_userdata('msg','Subcategory Added Failed');
		return false;
	}
   }
   function get_sub_category(){
	
	
		$query = $this->db->get_where('sub_category');
		$datas=array();
		foreach ($query->result() as $key => $row) {

			$datas['sub_cat_id'][]= $row->sub_cat_id;
			$datas['sub_cat_name'][]= $row->sub_cat_name;
			$datas['status'][]= $row->status;

		}
		return $datas;
}*/
	function add_products()
	{
		$config['upload_path'] = 'upload/products/';
		$config['allowed_types'] = '*';

		$this->load->library('upload', $config);
		if (!$this->upload->do_upload('pro_image')) {
			$error = array('error' => $this->upload->display_errors());
			//$this->load->view('files/upload_form', $error);
			$img = "";
		} else {
			$file_info = $this->upload->data();
			$img = 'upload/products/' . $file_info['file_name'];
			//echo $img;
		}
		$update_image =	$this->input->post('update_image');
		if ($update_image == '') {
			$datas['pro_image'] = $img;
		} else {
			$datas['pro_image'] = $update_image;
		}


		$datas['category_id'] = $this->input->post('category_id');

		$category_type = explode("##", $this->input->post('category_type'));

		$datas['category_type'] = $category_type[0];
		$datas['category_id'] = $category_type[1];
		$datas['product_name'] = $this->input->post('product_name');

		$datas['gross_weight'] = "0";
		$datas['net_weight'] = "0";
		$datas['piece'] = "0";
		$datas['description'] = $this->input->post('description');
		$update_id = $this->input->post('update_id');
		if ($update_id == '') {
			$qry = $this->db->insert('product', $datas);
			$insert_id = $this->db->insert_id();

			$conf['upload_path'] = 'upload/products/';
			$conf['allowed_types'] = '*';

			$this->load->library('upload', $conf);
			if (!$this->upload->do_upload('add_image')) {
				$error = array('error' => $this->upload->display_errors());
				//$this->load->view('files/upload_form', $error);
				$image = "";
			} else {
				$file_info = $this->upload->data();
				$image = 'upload/products/' . $file_info['file_name'];
				//echo $img;
			}
			$data['add_image'] = $image;
			$data['product_id'] = $insert_id;

			$query = $this->db->insert('additional_image', $data);

			$das['product_id'] = $insert_id;
			$price = $this->input->post('unitprice');
			$holesale_price = $this->input->post('holesale_price');
			$unit = $this->input->post('unit');
			$unit_name = $this->input->post('unitvalue');
			$slashed = $this->input->post('slashedprice');
			$slashed_whole = $this->input->post('slashed_whole');
			// $user_type=$this->input->post('user_type');

			$count = count($price);
			for ($i = 0; $i < $count; $i++) {
				$datas = array(
					'product_id' => $insert_id,
					'price' => $price[$i],
					'holesale_price' => $holesale_price[$i],
					'slashedprice' => $slashed[$i],
					'slashed_wholesale' => $slashed_whole[$i],
					'unit' => $unit_name[$i],
					'unit_name' => $unit[$i],
					//'user_type'=>$user_type[$i],

				);
				$query_1 = $this->db->insert('products_variant', $datas);
			}

			//$query_1 = $this->db->insert('products_variant',$das);
			//print_r($this->db->last_query());  
			if ($query) {
				$this->session->set_userdata('type', 'success');
				$this->session->set_userdata('msg', 'Products Added Successfully');
				return true;
			} else {
				$this->session->set_userdata('type', 'error');
				$this->session->set_userdata('msg', 'Products Added Failed');
				return false;
			}
		} else {


			$das['product_id'] = $update_id;
			$das['price'] = $this->input->post('price');
			$das['unit'] = $this->input->post('unit');
			$das['unit_name'] = $this->input->post('unit_name');
			$holesale_price = $this->input->post('holesale_price');
			//$das['user_type']=$this->input->post('user_type');
			$this->db->where('product_id', $update_id);
			$query_1 = $this->db->update('products_variant', $das);


			$this->db->where('product_id', $update_id);
			$qry = $this->db->update('product', $datas);
			if ($qry) {
				$this->session->set_userdata('type', 'success');
				$this->session->set_userdata('msg', 'Products Updated Successfully');
				return true;
			} else {
				$this->session->set_userdata('type', 'error');
				$this->session->set_userdata('msg', 'Products Updated Failed');
				return false;
			}
		}
	}

	function get_products()
	{
		$data['status'] = 1;
		$query = $this->db->get_where('product', $data);
		return $query->result_array();
		// 	print_r($this->db->last_query()); 
		// 	exit;
	}

	function edit_products()
	{
		$product_id = $this->input->post('product_id');
		//	$query = $this->db->get_where('product',$data);
		$this->db->select('*');
		$this->db->from('product');
		$this->db->join('products_variant', 'products_variant.product_id=product.product_id');
		$this->db->where('product.product_id', $product_id);
		$this->db->where('product.status', 1);
		$query = $this->db->get();
		//print_r($this->db->last_query()); 
		//exit;
		if ($query->num_rows() > 0) {
			foreach ($query->result() as $key => $row) {
				$value['product_id'] = $row->product_id;
				//$value['category_type'] = $row->category_type;
				$value['category_id'] = $row->category_id;
				$value['product_name'] = $row->product_name;
				$value['pro_image'] = $row->pro_image;
				$value['description'] = $row->description;
				$value['price'] = $row->price;
				$value['unit'] = $row->unit;
				$value['rating'] = $row->rating;
				$value['star_value'] = $row->star_value;
			}
		} else {
			$value[] = array();
		}
		echo json_encode($value);
	}
	function update_products()
	{

		$conf['upload_path'] = 'upload/products/';
		$conf['allowed_types'] = 'gif|jpg|png|pdf';

		$this->load->library('upload', $conf);
		if (!$this->upload->do_upload('pro_image')) {
			$error = array('error' => $this->upload->display_errors());
			//$this->load->view('files/upload_form', $error);
			$image = $this->input->post('update_image');
		} else {
			$file_info = $this->upload->data();
			$image = 'upload/products/' . $file_info['file_name'];
			//echo $img;
		}

		$product_id = $this->input->post('update_id');
		$datas['category_type'] = $this->input->post('category_type');

		//$datas['category_type'] =$category_type[0];
		//$datas['category_id'] =$category_type[1];
		$datas['product_name'] = $this->input->post('product_name');
		$datas['pro_image'] = $image;
		//$datas['price'] = $this->input->post('price');
		$datas['gross_weight'] = $this->input->post('gross_weight');
		$datas['net_weight'] = $this->input->post('net_weight');
		$datas['piece'] = $this->input->post('piece');
		$datas['description'] = $this->input->post('description');
		$this->db->where("product_id", $product_id);
		$query = $this->db->update('product', $datas);
		//print_r($datas);
		//print_r($this->db->last_query());
		//exit;
		if ($query) {
			$this->session->set_userdata('type', 'success');
			$this->session->set_userdata('msg', 'Product Update Successfully');
			return true;
		} else {
			$this->session->set_userdata('type', 'error');
			$this->session->set_userdata('msg', 'Product  Not update');
			return false;
		}
	}
	function delete_category()
	{
		$category_id = $this->input->post('category_id');
		$this->db->where('category_id', $category_id);
		$data['status'] = 0;
		$query = $this->db->update('category', $data);
		if ($query) {
			$this->session->set_userdata('type', 'success');
			$this->session->set_userdata('msg', 'Category Deleted Successfully');
			return true;
		} else {
			$this->session->set_userdata('type', 'error');
			$this->session->set_userdata('msg', 'Category Deleted Failed');
			return false;
		}
	}


	function delete_product()
	{
		$product_id = $this->input->post('product_id');
		$this->db->where('product_id', $product_id);
		$data['status'] = 0;

		$query = $this->db->update('product', $data);
		if ($query) {
			$this->session->set_userdata('type', 'success');
			$this->session->set_userdata('msg', 'Product Deleted Successfully');
			return true;
		} else {
			$this->session->set_userdata('type', 'error');
			$this->session->set_userdata('msg', 'Product Deleted Failed');
			return false;
		}
	}

	function active_product()
	{
		$product_id = $this->input->post('product_id');
		$this->db->where('product_id', $product_id);

		$data['active_id'] = 0;
		$query = $this->db->update('product', $data);
		if ($query) {
			$this->session->set_userdata('type', 'success');
			$this->session->set_userdata('msg', 'Out Of Stock');
			return true;
		} else {
			$this->session->set_userdata('type', 'error');
			$this->session->set_userdata('msg', 'Stock Failed');
			return false;
		}
	}
	function deactive_product()
	{
		$product_id = $this->input->post('product_id');
		$this->db->where('product_id', $product_id);

		$data['active_id'] = 1;
		$query = $this->db->update('product', $data);
		if ($query) {
			$this->session->set_userdata('type', 'success');
			$this->session->set_userdata('msg', 'Stock Available');
			return true;
		} else {
			$this->session->set_userdata('type', 'error');
			$this->session->set_userdata('msg', 'Out Of Stock Failed');
			return false;
		}
	}
}
