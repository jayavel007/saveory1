<?php

class Delivery_api_model extends CI_Model{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('form', 'url'));
	}

  	function check_login()
	{
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$datas = array();
		if ($username == '') {
			$msg = "Please Enter the username";
			$error = false;
			echo json_encode(array('status' => $error, 'message' => $msg));
		} else if ($password == '') {
			$msg = "Please Enter the Password";
			$error = false;
			echo json_encode(array('status' => $error, 'message' => $msg));
		} else {
			$data['username'] = $username;
			$data['password'] =  $password;

			$query = $this->db->get_where('shop', $data);
			 //print_r($this->db->last_query());
			if ($query->num_rows() > 0) {
				foreach ($query->result() as $key => $row) {

					$error = true;
					$msg = "Login Successfully";
					$datas = array(
						'shop_id' => $row->shop_id,
				    	'username' => $row->username,
				    	'company_name' => $row->company_name,
			   	        'mobile_no' => $row->mobile_no,
				    	'email' => $row->email,
			    		'branch_name' => $row->branch_name,
					);
				}


				echo json_encode(array('status' => $error, 'message' => $msg, 'delivery' => $datas));
			} else {
				$msg = "Username and Password does not match";
				$error = false;
				echo json_encode(array('status' => $error, 'message' => $msg));
			}
		}
	}
	
	
	function delivery_dashboard()
	{
		$delivery_id = $this->input->post('shop_id');
		$this->db->select('*');
		$this->db->from('orders');
		$this->db->where('orders.shop_id', $delivery_id);
		$query = $this->db->get();

// 		if ($query->num_rows() > 0) {
// 			foreach ($query->result() as $key => $row) {
// 				$manufacture_id = $row->manufacture_id;
// 			}
// 		}


		$datas = array();

		$date = date("Y-m-d");

		$this->db->select('*');
		$this->db->from('orders');
		$this->db->where('orders.order_date', $date);
		$this->db->where('orders.del_status', "placed");
		$this->db->where('orders.shop_id', $delivery_id);
		$today_orders = $this->db->count_all_results();
		// print_r($this->db->last_query());


		$this->db->select('*');
		$this->db->from('orders');
		$this->db->where('orders.del_status', "placed");
		$this->db->where('orders.shop_id', $delivery_id);
		$total_orders = $this->db->count_all_results();


		$this->db->select('*');
		$this->db->from('orders');
// 		$this->db->where('orders.estimate_del', $date);
		$this->db->where('orders.del_status', "placed");
		$this->db->where('orders.shop_id', $delivery_id);
		$to_be_orders = $this->db->count_all_results();

	$this->db->select('*');
		$this->db->from('orders');
// 		$this->db->where('orders.estimate_del', $date);
		$this->db->where('orders.del_status', "Completed");
		$this->db->where('orders.shop_id', $delivery_id);
		$today_completed_delivered = $this->db->count_all_results();

		$datas = array();


		$datas[] = array(
			"shop_id" => $delivery_id,
			"total_orders" => $total_orders,
			"today_orders" => $today_orders,
			"total_pending_delivered" => $to_be_orders,
			"total_completed_delivered" => $today_completed_delivered,
// 			"total_can" => $this->get_manufacture_can($manufacture_id),
// 			"total_empty_can" => $this->get_manufacture_empty($manufacture_id),

		);

		echo json_encode($datas);
	}
	
		function today_orders(){
		$delivery_id = $this->input->post('shop_id');
				$date = date("Y-m-d");
		$this->db->select('*');
		$this->db->from('orders');
		$this->db->join('add_to_cart','add_to_cart.order_id=orders.order_id');
		$this->db->join('address','address.address_id=orders.address_id');
		$this->db->where('orders.estimate_del', $date);
		$this->db->where('orders.del_status', "Placed");
		$this->db->where('orders.shop_id', $delivery_id);
        $qry = $this->db->get();
		  //print_r($this->db->last_query());
		  
if($qry->num_rows()>0){
foreach($qry->result() as $key=>$row){
$product_id=$row->product_id;
   $order_id=$row->order_id;
   $dates = $row->order_date;
   $dateses = date('d-m-Y', strtotime($dates));
   $dat = $row->estimate_del;
   $da = date('d-m-Y', strtotime($dat));
   $datas[] = array(
	  "customer_id"=>$row->customer_id,
	  "customer_name"=>$row->name,
	  "order_id"=>$row->order_id,
	  "order_unique_id"=>$row->unique_id,
	  "order_date"=>$dateses.' | '.$row->order_time,
// 	  "estimation_delivery"=>$da,
	  "order_status"=>'placed',
	  "door_no"=>$row->door_no,
	  "street"=>$row->street,
	  "landmark"=>$row->landmark,
	  "address_type"=>$row->address_type,
	  "city"=>$row->city,
	  "district"=>$row->district,
	  "state"=>$row->state,
	  "country"=>$row->country,
	  "pincode"=>$row->pincode,
	  "mobile"=>$row->mobile,
	  
// 	  "products"=>$this->get_products($order_id),
	  );
}

}else{
$datas[] = array(
   "shop_id"=>$delivery_id,
	  "order_id"=>"",
      "products"=>array(),          
	  );
}
echo json_encode($datas);
	}
	
		
		function orders_list(){
		$delivery_id = $this->input->post('shop_id');
		$order_status = $this->input->post('order_status');
		
		$this->db->select('*');
		$this->db->from('orders');
		$this->db->join('add_to_cart','add_to_cart.order_id=orders.order_id');
		$this->db->join('address','address.address_id=orders.address_id');
	if($order_status != ""){
	   	$this->db->where('orders.del_status', $order_status);
	}
	
		$this->db->where('orders.shop_id', $delivery_id);
        $qry = $this->db->get();
		  //print_r($this->db->last_query());
		  
if($qry->num_rows()>0){
foreach($qry->result() as $key=>$row){
$product_id=$row->product_id;
   $order_id=$row->order_id;
   $dates = $row->order_date;
   $dateses = date('d-m-Y', strtotime($dates));
   $dat = $row->estimate_del;
   $da = date('d-m-Y', strtotime($dat));
   $datas[] = array(
	  "customer_id"=>$row->customer_id,
	  "customer_name"=>$row->name,
	  "order_id"=>$row->order_id,
	  "order_unique_id"=>$row->unique_id,
	  "order_date"=>$dateses.' | '.$row->order_time,
	  "estimation_delivery"=>$da,
	  "order_status"=>$row->del_status,
	  "door_no"=>$row->door_no,
	  "street"=>$row->street,
	  "landmark"=>$row->landmark,
	  "address_type"=>$row->address_type,
	  "city"=>$row->city,
	  "district"=>$row->district,
	  "state"=>$row->state,
	  "country"=>$row->country,
	  "pincode"=>$row->pincode,
	  "mobile"=>$row->mobile,
	  
// 	  "products"=>$this->get_products($order_id),
	  );
}

}else{
$datas[] = array(
   "shop_id"=>$delivery_id,
	  "order_id"=>"",
      "products"=>array(),          
	  );
}
echo json_encode($datas);
	}
	
	
	
		function today_orders_details(){
		
		$delivery_id = $this->input->post('shop_id');
				$date = date("Y-m-d");
		$this->db->select('*');
		$this->db->from('orders');
		$this->db->join('add_to_cart','add_to_cart.order_id=orders.order_id');
		$this->db->join('address','address.address_id=orders.address_id');
		$this->db->where('orders.estimate_del', $date);
		$this->db->where('orders.del_status', "placed");
		$this->db->where('orders.shop_id', $delivery_id);
        $qry = $this->db->get();
		  //print_r($this->db->last_query());
		  
if($qry->num_rows()>0){
foreach($qry->result() as $key=>$row){
$product_id=$row->product_id;
   $order_id=$row->order_id;
   $dates = $row->order_date;
   $dateses = date('d-m-Y', strtotime($dates));
   $dat = $row->estimate_del;
   $da = date('d-m-Y', strtotime($dat));
   $datas[] = array(
	  "customer_id"=>$row->customer_id,
	  "customer_name"=>$row->name,
	  "order_id"=>$row->order_id,
	  "order_unique_id"=>$row->unique_id,
	  "order_date"=>$dateses.' | '.$row->order_time,
	  "estimation_delivery"=>$da,
	  "order_status"=>'placed',
	  "door_no"=>$row->door_no,
	  "street"=>$row->street,
	  "landmark"=>$row->landmark,
	  "address_type"=>$row->address_type,
	  "city"=>$row->city,
	  "district"=>$row->district,
	  "state"=>$row->state,
	  "country"=>$row->country,
	  "pincode"=>$row->pincode,
	  "mobile"=>$row->mobile,
	  
	  "products"=>$this->get_products($order_id),
	  );
}

}else{
$datas[] = array(
   "shop_id"=>$delivery_id,
	  "order_id"=>"",
      "products"=>array(),          
	  );
}
echo json_encode($datas);
	}
	

		function pending_orders(){
		$delivery_id = $this->input->post('shop_id');
				// $date = date("Y-m-d");
		$this->db->select('*');
		$this->db->from('orders');
		$this->db->join('add_to_cart','add_to_cart.order_id=orders.order_id');
		$this->db->join('address','address.address_id=orders.address_id');
// 		$this->db->where('orders.estimate_del', $date);
		$this->db->where('orders.del_status', "placed");
		$this->db->where('orders.shop_id', $delivery_id);
        $qry = $this->db->get();
		  //print_r($this->db->last_query());
		  
if($qry->num_rows()>0){
foreach($qry->result() as $key=>$row){
$product_id=$row->product_id;
   $order_id=$row->order_id;
   $dates = $row->order_date;
   $dateses = date('d-m-Y', strtotime($dates));
   $dat = $row->estimate_del;
   $da = date('d-m-Y', strtotime($dat));
   $datas[] = array(
      "shop_id"=>$delivery_id,
	  "order_id"=>$row->order_id,
	  "order_unique_id"=>$row->unique_id,
	  "order_date"=>$dateses.' | '.$row->order_time,
	  "estimation_delivery"=>$da,
	  "order_status"=>'placed',
	  "door_no"=>$row->door_no,
	  "street"=>$row->street,
	  "landmark"=>$row->landmark,
	  "address_type"=>$row->address_type,
	  "city"=>$row->city,
	  "district"=>$row->district,
	  "state"=>$row->state,
	  "country"=>$row->country,
	  "pincode"=>$row->pincode,
	  "mobile"=>$row->mobile,
	  
// 	  "products"=>$this->get_products($order_id),
	  );
}

}else{
$datas[] = array(
   "shop_id"=>$delivery_id,
	  "order_id"=>"",
      "products"=>array(),          
	  );
}
echo json_encode($datas);
	}
		
	
	
		function completed_orders(){
		$delivery_id = $this->input->post('shop_id');
				// $date = date("Y-m-d");
		$this->db->select('*');
		$this->db->from('orders');
		$this->db->join('add_to_cart','add_to_cart.order_id=orders.order_id');
		$this->db->join('address','address.address_id=orders.address_id');
// 		$this->db->where('orders.estimate_del', $date);
		$this->db->where('orders.del_status', "Completed");
		$this->db->where('orders.shop_id', $delivery_id);
        $qry = $this->db->get();
		  //print_r($this->db->last_query());
		  
if($qry->num_rows()>0){
foreach($qry->result() as $key=>$row){
$product_id=$row->product_id;
   $order_id=$row->order_id;
   $dates = $row->order_date;
   $dateses = date('d-m-Y', strtotime($dates));
   $dat = $row->estimate_del;
   $da = date('d-m-Y', strtotime($dat));
   $datas[] = array(
      "shop_id"=>$delivery_id,
	  "order_id"=>$row->order_id,
	  "order_unique_id"=>$row->unique_id,
	  "order_date"=>$dateses.' | '.$row->order_time,
	  "estimation_delivery"=>$da,
	  "order_status"=>'Completed',
	  "door_no"=>$row->door_no,
	  "street"=>$row->street,
	  "landmark"=>$row->landmark,
	  "address_type"=>$row->address_type,
	  "city"=>$row->city,
	  "district"=>$row->district,
	  "state"=>$row->state,
	  "country"=>$row->country,
	  "pincode"=>$row->pincode,
	  "mobile"=>$row->mobile,
	  
// 	  "products"=>$this->get_products($order_id),
	  );
}

}else{
$datas[] = array(
   "shop_id"=>$delivery_id,
	  "order_id"=>"",
      "products"=>array(),          
	  );
}
echo json_encode($datas);
	}
		
	
	
		function today_completed_orders(){
		    $delivery_id = $this->input->post('shop_id');
		    
		$order_status = $this->input->post('order_id');
				$date = date("Y-m-d");
		$this->db->select('*');
		$this->db->from('orders');
		$this->db->join('add_to_cart','add_to_cart.order_id=orders.order_id');
		$this->db->join('address','address.address_id=orders.address_id');
		$this->db->where('orders.estimate_del', $date);
		$this->db->where('orders.del_status', "Placed");
		$this->db->where('orders.shop_id', $delivery_id);
        $qry = $this->db->get();
		  //print_r($this->db->last_query());
		  
if($qry->num_rows()>0){
foreach($qry->result() as $key=>$row){
$product_id=$row->product_id;
   $order_id=$row->order_id;
   $dates = $row->order_date;
   $dateses = date('d-m-Y', strtotime($dates));
   $dat = $row->estimate_del;
   $da = date('d-m-Y', strtotime($dat));
   $datas[] = array(
	  "customer_id"=>$row->customer_id,
	  "customer_name"=>$row->name,
	  "order_id"=>$row->order_id,
	  "order_unique_id"=>$row->unique_id,
	  "order_date"=>$dateses.' | '.$row->order_time,
// 	  "estimation_delivery"=>$da,
	  "order_status"=>'Placed',
	  "door_no"=>$row->door_no,
	  "street"=>$row->street,
	  "landmark"=>$row->landmark,
	  "address_type"=>$row->address_type,
	  "city"=>$row->city,
	  "district"=>$row->district,
	  "state"=>$row->state,
	  "country"=>$row->country,
	  "pincode"=>$row->pincode,
	  "mobile"=>$row->mobile,
	  
// 	  "products"=>$this->get_products($order_id),
	  );
}

}else{
$datas[] = array(
   "shop_id"=>$delivery_id,
	  "order_id"=>"",
      "products"=>array(),          
	  );
}
echo json_encode($datas);
	}
	
	
	
	
function get_products(){
   	// $order_id = $this->input->post('order_id');
	                  $this->db->select('*');
	                  $this->db->from('add_to_cart');
	                  $this->db->join('product','product.product_id=add_to_cart.product_id');
	                  $this->db->where('add_to_cart.order_id',$order_id);
	                  $this->db->where('add_to_cart.status','1');
	                  $qry = $this->db->get();
	                  
	                  $datas = array();
	    if($qry->num_rows()>0){
	        foreach($qry->result() as $key=>$row){
	               if($row->cancel_status=="Ordered"){
	               	        $ord_status="";
	               	    }else{
	               	        $ord_status=$row->cancel_status;
	               	    }
	              $amount=$row->price*$row->qty;
	              $product_id=$row->product_id;
	              $customer_id=$row->customer_id;
	           //   $review = $this->get_product_review($product_id,$customer_id);
	              $product[] = array(
	                  "cart_id"=>$row->cart_id,
	                   "product_id"=>$row->product_id,
	                  "product_name"=>$row->product_name, 
	                  "image"=>$row->pro_image,
	                  "price"=>$row->price,  
	                   "price_type"=>"kg",
	                  "qty"=>$row->qty, 
	            
	                  
	                  
	                );
	        }
	   
	    }
	    return $product;
}

	
	
  function orders_details(){
   	$order_id = $this->input->post('order_id');
	                  $this->db->select('*');
	                  $this->db->from('add_to_cart');
	                  $this->db->join('product','product.product_id=add_to_cart.product_id');
	                  $this->db->where('add_to_cart.order_id',$order_id);
	                  $this->db->where('add_to_cart.status','1');
	                  $qry = $this->db->get();
	               //   print_r($qry);
	                  $datas = array();
	    if($qry->num_rows()>0){
	        foreach($qry->result() as $key=>$row){
	               if($row->cancel_status=="Ordered"){
	               	        $ord_status="";
	               	    }else{
	               	        $ord_status=$row->cancel_status;
	               	    }
	              $amount=$row->price*$row->qty;
	              $product_id=$row->product_id;
	              $customer_id=$row->customer_id;
	              $product[] = array(
	                  "cart_id"=>$row->cart_id,
	                   "product_id"=>$row->product_id,
	                  "product_name"=>$row->product_name, 
	                  "image"=>$row->pro_image,
	                  "price"=>$row->price,  
	                   "price_type"=>"kg",
	                  "qty"=>$row->qty, 
	            
	                  
	                  
	                );
	        }
	   
	    }
	 echo json_encode($product);
}


function change_status()
	{
		$order_id = $this->input->post('order_id');
		$order_status = $this->input->post('order_status');
		$this->db->select('*');
		$this->db->from('orders');
		$this->db->where('orders.order_id', $order_id);
		 
		$sql = $this->db->get();
		 if($sql->num_rows()>0){
	        foreach($sql->result() as $key=>$row){
	        $del_status=$row->del_status;
	         }
	        }
	        
		 if($order_status == "Completed"){
		     	$this->db->where('orders.order_id', $order_id);
		$data['del_status'] = 'Completed';
	 	$query = $this->db->update('orders',$data);
	 	  $status = "true";
	      $msg = "Order Delivered";
			 }else{
			      if($order_status == "Cancelled"){
		     	$this->db->where('orders.order_id', $order_id);
		$data['del_status'] = 'Cancelled';
	 	$query = $this->db->update('orders',$data);
	 	  $status = "true";
	      $msg = "Order Delivered";
			 }else{
		    $status = "false";
	        $msg = "Order Not Delivered";
			 }
	
			 }
			
           $response[] = array("msg"=>$msg,'status'=>$status);
        //echo json_encode($datas);
        	echo json_encode($response); 

	}

   function company_logo(){
        $this->db->where('status','1');
      $query = $this->db->get('logo');
	    foreach($query->result() as $key=>$row){
	        $datas=array(
	           "logo_image"=>$row->logo_image,
        );
	    }
	    echo json_encode($datas);
}


}
    ?>