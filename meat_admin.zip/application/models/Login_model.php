<?php

class Login_model extends CI_Model{
	function __construct(){
		parent::__construct();
		$this->load->helper(array('form', 'url'));
		$this->load->library('session');
	}

	function check_login(){
		$data['username'] = $this->input->post('email');
		$data['password'] = md5($this->input->post('password'));
		$query = $this->db->get_where('admin_login',$data);
		if($query->num_rows()>0){
			foreach ($query->result() as $key => $row) {
				$this->session->set_userdata('login_id',$row->login_id);
				$this->session->set_userdata('username',$row->username);
			}
			return true;
		}else{
			$this->session->set_userdata('msg','Username and Password does not match');
			return false;
		}
		
	}
}
?>