<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Products extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->load->helper('url');
    $this->load->model('Products_model');
    $this->load->library('pagination');
  }
  function category()
  {
    $data['category'] = $this->Products_model->get_category();

    $this->load->view('include/head');
    $this->load->view('include/header');
    $this->load->view('include/menu');
    $this->load->view('category', $data);
    $this->load->view('include/footer');
    $this->load->view('include/script');
  }
  /*function sub_category(){
    $data['category'] = $this->Products_model->get_category();
    $data['subcategory'] = $this->Products_model->get_subcategory();
   // print_r($data['category']);
    $this->load->view('include/head');
    $this->load->view('include/header');
    $this->load->view('include/menu');
    $this->load->view('sub_category',$data);
    $this->load->view('include/footer');
    $this->load->view('include/script');
}*/
  function products()
  {
    $data['category'] = $this->Products_model->get_category();
    //$data['subcategory'] = $this->Products_model->get_sub_category();
    $data['products'] = $this->Products_model->get_products();

    $this->load->view('include/head');
    $this->load->view('include/header');
    $this->load->view('include/menu');
    $this->load->view('products', $data);
    $this->load->view('include/footer');
    $this->load->view('include/script');
  }

  function add_category()
  {
    $data['category'] = $this->Products_model->add_category();
    redirect(base_url('category'));
  }

  /*function add_sub_category(){
    $data['subcategory'] = $this->Products_model->add_sub_category();
    redirect(base_url('subcategory'));
}*/

  function add_products()
  {
    $data['products'] = $this->Products_model->add_products();
    redirect(base_url('products'));
  }
  function update_products()
  {
    $this->Products_model->update_products();
    redirect(base_url('products'));
  }

  function remove_image()
  {
    $this->Products_model->remove_image();
  }
  function delete_category()
  {
    $this->Products_model->delete_category();
  }
  function delete_product()
  {
    $this->Products_model->delete_product();
  }
  function active_product()
  {
    $this->Products_model->active_product();
  }
  function deactive_product()
  {
    $this->Products_model->deactive_product();
  }
  function remove_category()
  {
    // echo 1;
    // exit;
    $this->Products_model->remove_category();
  }

  function get_category_type()
  {
    $this->Products_model->get_category_type();
  }
  function edit_category()
  {
    $this->Products_model->edit_category();
  }
  function edit_products()
  {
    $this->Products_model->edit_products();
  }
  public function load_category($rowno = 0)
  {
    $rowperpage = 5;
    if ($rowno != 0) {
      $rowno = ($rowno - 1) * $rowperpage;
    }
    $this->db->select('1');
    $this->db->from('category');
    $this->db->where('status', 1);
    $query = $this->db->get();
    $allcount = $query->num_rows();
    // $allcount = $this->db->count_all('category');
    // exit;
    $this->db->limit($rowperpage, $rowno);

    $this->db->select('*');
    $this->db->from('category');
    $this->db->where('status', 1);
    $users_record = $this->db->get()->result_array();
    $config['base_url'] = base_url() . 'Products/load_category';
    $config['use_page_numbers'] = TRUE;
    $config['total_rows'] = $allcount;
    $config['per_page'] = $rowperpage;
    $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
    $config['full_tag_close']   = '</ul></nav></div>';
    $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
    $config['num_tag_close']    = '</span></li>';
    $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
    $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
    $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
    $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
    $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
    $config['prev_tag_close']  = '</span></li>';
    $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
    $config['first_tag_close'] = '</span></li>';
    $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
    $config['last_tag_close']  = '</span></li>';
    $this->pagination->initialize($config);
    $data['pagination'] = $this->pagination->create_links();
    $data['result'] = $users_record;
    $data['row'] = $rowno;
    echo json_encode($data);
  }
  public function load_products($rowno = 0)
  {
    $rowperpage = 10;
    if ($rowno != 0) {
      $rowno = ($rowno - 1) * $rowperpage;
    }
    $allcount = $this->db->count_all('product');
    // exit;
    $this->db->limit($rowperpage, $rowno);
    $this->db->select('*');
    $this->db->from('product');
    $this->db->join('products_variant', 'products_variant.product_id=product.product_id');
    $this->db->where('product.status', 1);
    $users_record = $this->db->get()->result_array();
    $config['base_url'] = base_url() . 'Products/load_products';
    $config['use_page_numbers'] = TRUE;
    $config['total_rows'] = $allcount;
    $config['per_page'] = $rowperpage;
    $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
    $config['full_tag_close']   = '</ul></nav></div>';
    $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
    $config['num_tag_close']    = '</span></li>';
    $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
    $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
    $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
    $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
    $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
    $config['prev_tag_close']  = '</span></li>';
    $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
    $config['first_tag_close'] = '</span></li>';
    $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
    $config['last_tag_close']  = '</span></li>';
    $this->pagination->initialize($config);
    $data['pagination'] = $this->pagination->create_links();
    $data['result'] = $users_record;
    $data['row'] = $rowno;
    echo json_encode($data);
  }
}
