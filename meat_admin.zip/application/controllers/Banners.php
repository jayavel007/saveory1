<?php
defined('BASEPATH') OR exit('No direct script access allowed');



class Banners extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
       $this->load->model('Banners_model');
       
       
    }
 function banners(){
    $data['banner'] = $this->Banners_model->get_banner();
    $this->load->view('include/head');
    $this->load->view('include/header');
    $this->load->view('include/menu');
    $this->load->view('banners',$data);
    $this->load->view('include/footer');
    $this->load->view('include/script');
}
function add_banner(){
    $data['banner'] = $this->Banners_model->add_banner();
    redirect(base_url('banner'));
}

function delete_banner(){
    $this->Banners_model->delete_banner();
}

function edit_banners(){
    $this->Banners_model->edit_banners(); 
}
function update_banner(){
    $this->Banners_model->update_banner(); 
}

function remove_banners(){
    $this->Banners_model->remove_banner();
}



}