<?php
defined('BASEPATH') OR exit('No direct script access allowed');



class Orders extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('pagination');
        $this->load->model('Order_model');
       
       
    }
 function orders($id=''){
    //$data['orders'] = $this->Order_model->get_orders($id);
    $data['orders'] = ($id!=1)?0:$id;
    $this->load->view('include/head');
    $this->load->view('include/header');
    $this->load->view('include/menu');
    $this->load->view('orders',$data);
    $this->load->view('include/footer');
    $this->load->view('include/script');
}
 function order_details($id){
    $data['orders'] = $this->Order_model->get_order_details($id);
    $data['products'] = $this->Order_model->get_order_products($id);
    $this->load->view('include/head');
    $this->load->view('include/header');
    $this->load->view('include/menu');
    $this->load->view('order_details',$data);
    $this->load->view('include/footer');
    $this->load->view('include/script');
}

function set_status(){
    $this->Order_model->set_status();
}

function del_date(){
    $this->Order_model->del_date();
}
	public function load_orders($rowno=0,$pageref){
  
       $rowperpage = 5;
        if($rowno != 0){
          $rowno = ($rowno-1) * $rowperpage;
        }
        $allcount = $this->db->count_all('orders');
        // exit;
      $this->db->limit($rowperpage, $rowno);
      $date=date('Y-m-d');
      if($pageref==1){
        $this->db->where('orders.order_date',$date);
      }
      $this->db->select('*'); 
	     $this->db->from('orders'); 
         $this->db->order_by('orders.order_id','DESC');  
	     $this->db->join('customer', 'customer.customer_id=orders.customer_id');
	     $this->db->where('order_status', 1);
   
	     $users_record = $this->db->get()->result_array();
        $config['base_url'] = base_url().'Orders/load_orders';
        $config['use_page_numbers'] = TRUE;
        $config['total_rows'] = $allcount;
        $config['per_page'] = $rowperpage;
        $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
        $config['full_tag_close']   = '</ul></nav></div>';
        $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
        $config['num_tag_close']    = '</span></li>';
        $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
        $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
        $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
        $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['prev_tag_close']  = '</span></li>';
        $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
        $config['first_tag_close'] = '</span></li>';
        $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['last_tag_close']  = '</span></li>';
        $this->pagination->initialize($config); 
        $data['pagination'] = $this->pagination->create_links();
        $data['result'] = $users_record;
        $data['row'] = $rowno;
        echo json_encode($data); 

  }
}