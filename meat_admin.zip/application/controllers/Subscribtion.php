<?php
defined('BASEPATH') OR exit('No direct script access allowed');



class Subscribtion extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
         $this->load->library('pagination');
       $this->load->model('Subscribtion_model');
       
       
    }
 function subscribtion(){
    $data['subscribtion'] = $this->Subscribtion_model->get_subscribtion();
    //print_r($data['subscribtion']);
    $this->load->view('include/head');
    $this->load->view('include/header');
    $this->load->view('include/menu');
    $this->load->view('subscribtion',$data);
    $this->load->view('include/footer');
    $this->load->view('include/script');
}

function subscribers_list(){
    $data['subscribers'] = $this->Subscribtion_model->get_subscribers();
    //print_r($data['subscribtion']);
    $this->load->view('include/head');
    $this->load->view('include/header');
    $this->load->view('include/menu');
    $this->load->view('subscribers_list',$data);
    $this->load->view('include/footer');
    $this->load->view('include/script');
}

function reviews(){
    $data['reviews'] = $this->Subscribtion_model->get_reviews();
    $data['dereviews'] = $this->Subscribtion_model->get_deactivereviews();
    
    //print_r($data['subscribtion']);
    $this->load->view('include/head');
    $this->load->view('include/header');
    $this->load->view('include/menu');
    $this->load->view('reviews',$data);
    $this->load->view('include/footer');
    $this->load->view('include/script');
}

function add_subscribtion(){
    $data['subscrib'] = $this->Subscribtion_model->add_subscribtion();
    redirect(base_url('subscribtion'));
}

  
function edit_subscribtion(){
    $this->Subscribtion_model->edit_subscribtion(); 
}

function delete_subscribtion(){
    $this->Subscribtion_model->delete_subscribtion();
}
function viewedReview(){
    $this->Subscribtion_model->viewed_review();
}
function delete_subscriber(){
    $this->Subscribtion_model->delete_subscriber(); 
}
function delete_review(){
    $this->Subscribtion_model->delete_review();
}
public function load_subscribtion($rowno=0){
       $rowperpage = 5;
        if($rowno != 0){
          $rowno = ($rowno-1) * $rowperpage;
        }
        $allcount = $this->db->count_all('subscribers_list');
        // exit;
      $this->db->limit($rowperpage, $rowno);
      $this->db->select('*'); 
	     $this->db->from('subscribers_list');   
	     $this->db->join('subscribtion', 'subscribtion.sub_id=subscribers_list.sub_id');
	     $this->db->join('customer', 'customer.customer_id=subscribers_list.customer_id');
	     $this->db->where('subscribers_list.status', 1);
	     $users_record = $this->db->get()->result_array();
        $config['base_url'] = base_url().'Subscribtion/load_subscribtion';
        $config['use_page_numbers'] = TRUE;
        $config['total_rows'] = $allcount;
        $config['per_page'] = $rowperpage;
        $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
        $config['full_tag_close']   = '</ul></nav></div>';
        $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
        $config['num_tag_close']    = '</span></li>';
        $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
        $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
        $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
        $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['prev_tag_close']  = '</span></li>';
        $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
        $config['first_tag_close'] = '</span></li>';
        $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['last_tag_close']  = '</span></li>';
        $this->pagination->initialize($config); 
        $data['pagination'] = $this->pagination->create_links();
        $data['result'] = $users_record;
        $data['row'] = $rowno;
        echo json_encode($data); 

  }
  
  
  	public function load_reviews($rowno=0){
       $rowperpage = 5;
        if($rowno != 0){
          $rowno = ($rowno-1) * $rowperpage;
        }
        $allcount = $this->db->count_all('product_reviews');
        // exit;
      $this->db->limit($rowperpage, $rowno);
         $this->db->select('*');
	    $this->db->from('product_reviews');
	    $this->db->join('customer','customer.customer_id=product_reviews.customer_id');
	    $this->db->join('product','product.product_id=product_reviews.product_id');
        $this->db->order_by('product_reviews.reviews_id','desc');
	    $this->db->where('product_reviews.view_status',1);
	    $users_record = $this->db->get()->result_array();
        $config['base_url'] = base_url().'Subscribtion/load_reviews';
        $config['use_page_numbers'] = TRUE;
        $config['total_rows'] = $allcount;
        $config['per_page'] = $rowperpage;
        $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
        $config['full_tag_close']   = '</ul></nav></div>';
        $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
        $config['num_tag_close']    = '</span></li>';
        $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
        $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
        $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
        $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['prev_tag_close']  = '</span></li>';
        $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
        $config['first_tag_close'] = '</span></li>';
        $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['last_tag_close']  = '</span></li>';
        $this->pagination->initialize($config); 
        $data['pagination'] = $this->pagination->create_links();
        $data['result'] = $users_record;
        $data['row'] = $rowno;
        echo json_encode($data); 

  }
  	public function load_dereviews($rowno=0){
       $rowperpage = 10;
        if($rowno != 0){
          $rowno = ($rowno-1) * $rowperpage;
        }
        $allcount = $this->db->count_all('product_reviews');
        // exit;
      $this->db->limit($rowperpage, $rowno);
    
        $this->db->select('*');
	    $this->db->from('product_reviews');
	    $this->db->join('customer','customer.customer_id=product_reviews.customer_id');
	    $this->db->join('product','product.product_id=product_reviews.product_id');
        $this->db->order_by('product_reviews.reviews_id','desc');
	    $this->db->where('product_reviews.view_status',0);
      $this->db->where('product_reviews.status',1);
	     $users_record = $this->db->get()->result_array();
        $config['base_url'] = base_url().'Subscribtion/load_dereviews';
        $config['use_page_numbers'] = TRUE;
        $config['total_rows'] = $allcount;
        $config['per_page'] = $rowperpage;
        $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
        $config['full_tag_close']   = '</ul></nav></div>';
        $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
        $config['num_tag_close']    = '</span></li>';
        $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
        $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
        $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
        $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['prev_tag_close']  = '</span></li>';
        $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
        $config['first_tag_close'] = '</span></li>';
        $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['last_tag_close']  = '</span></li>';
        $this->pagination->initialize($config); 
        $data['pagination'] = $this->pagination->create_links();
        $data['result'] = $users_record;
        $data['row'] = $rowno;
        echo json_encode($data); 

  }


}