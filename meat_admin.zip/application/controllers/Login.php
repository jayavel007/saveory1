<?php
defined('BASEPATH') OR exit('No direct script access allowed');



class Login extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Login_model');
       
       
    }
 function index(){
    $this->load->view('login');
}
function check_login(){
    $data = $this->Login_model->check_login();
		
		// echo $data;
		if($data==1){
			return redirect(base_url('dashboard'));
		}else{
			return redirect(base_url());
		}	
}

public function logout(){
       
    //       $this->session->unset_userdata('login_id');
		  //$this->session->unset_userdata('username');
          $this->session->sess_destroy();
         redirect(base_url());
	}
}