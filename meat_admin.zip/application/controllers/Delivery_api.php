<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . 'libraries/RestController.php';
use chriskacerguis\RestServer\RestController;


require_once(APPPATH."libraries/razorpay/razorpay-php/Razorpay.php");
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;


class Delivery_api extends RestController {
	public function __construct(){
     parent::__construct();
     // Load model
     $this->load->model('Delivery_api_model');
  }
  
 function check_login_post(){
    $this->Delivery_api_model->check_login();
 }
  function delivery_dashboard_post(){
    $this->Delivery_api_model->delivery_dashboard();
 }
 
  function today_orders_post(){
    $this->Delivery_api_model->today_orders();
 }
  function orders_list_post(){
    $this->Delivery_api_model->orders_list();
 }
 
 
   function orders_details_post(){
    $this->Delivery_api_model->orders_details();
 }
  function pending_orders_post(){
    $this->Delivery_api_model->pending_orders();
 }

  function completed_orders_post(){
    $this->Delivery_api_model->completed_orders();
 }
   function today_completed_orders_post(){
    $this->Delivery_api_model->today_completed_orders();
 }
   function change_status_post(){
    $this->Delivery_api_model->change_status();
 }  
//  function products_de_post(){
//     $this->Delivery_api_model->get_products();
//  }
 
  function company_logo_get(){
      $this->Delivery_api_model->company_logo();
 }
 
}
?>