<?php
defined('BASEPATH') or exit('No direct script access allowed');
require APPPATH . 'libraries/RestController.php';

use chriskacerguis\RestServer\RestController;


require_once(APPPATH . "libraries/razorpay/razorpay-php/Razorpay.php");

use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;


class Api_controller extends RestController
{
   public function __construct()
   {
      parent::__construct();
      // Load model
      $this->load->model('Api_model');
   }
   function generate_otp_post()
   {
      $this->Api_model->generate_otp();
   }
   function register_post()
   {
      $this->Api_model->register();
   }
   //  function approval_post(){
   //      $this->Api_model->approval();
   //   }
   function check_login_post()
   {
      $this->Api_model->check_login();
   }
   function forgot_password_post()
   {
      $this->Api_model->forgot_password();
   }
   function otp_verification_post()
   {
      $this->Api_model->otp_verification();
   }
   function change_forgot_password_post()
   {
      $this->Api_model->change_forgot_password();
   }
   function list_category_get()
   {
      $this->Api_model->list_category();
   }
   function search_product_list_post()
   {
      $this->Api_model->search_product_list();
   }
   function list_product_post()
   {
      $this->Api_model->list_product();
   }
   function list_banner_get()
   {
      $this->Api_model->list_banner();
   }
   function search_product_post()
   {
      $this->Api_model->search_product();
   }
   function get_category_get()
   {
      $this->Api_model->get_category();
   }
   // function get_sub_category_post(){
   // $this->Api_model->get_sub_category();
   // }
   function get_product_post()
   {
      $this->Api_model->get_product();
   }
   function get_product_details_post()
   {
      $this->Api_model->get_product_details();
   }
   function add_to_cart_post()
   {
      $this->Api_model->add_to_cart();
   }
   function add_basket_post()
   {
      $this->Api_model->add_basket();
   }
   function get_cart_post()
   {
      $this->Api_model->get_cart();
   }
   function checkout_post()
   {
      $this->Api_model->checkout();
   }
   function delete_cart_post()
   {
      $this->Api_model->delete_cart();
   }
   function delete_subscribtion_post()
   {
      $this->Api_model->delete_subscribtion();
   }
   function update_qty_post()
   {
      $this->Api_model->update_qtys();
   }
   function add_address_post()
   {
      $this->Api_model->add_address();
   }
   function get_address_post()
   {
      $this->Api_model->get_address();
   }
   function my_address_post()
   {
      $this->Api_model->my_address();
   }
   function get_about_get()
   {
      $this->Api_model->get_about();
   }
   function get_terms_get()
   {
      $this->Api_model->get_terms();
   }
   function get_policy_get()
   {
      $this->Api_model->get_policy();
   }
   function add_wishlist_post()
   {
      $this->Api_model->add_wishlist();
   }
   function add_rating_post()
   {
      $this->Api_model->add_rating();
   }
   function get_wishlist_post()
   {
      $this->Api_model->get_wishlist();
   }

   function list_category_product_post()
   {
      $this->Api_model->list_category_product();
   }
   function get_baskets_get()
   {
      $this->Api_model->get_baskets();
   }
   function edit_address_post()
   {
      $this->Api_model->edit_address();
   }
   function change_password_post()
   {
      $this->Api_model->change_password();
   }
   function my_orders_post()
   {
      $this->Api_model->get_orders();
   }
   function my_order_details_post()
   {
      $this->Api_model->my_order_details();
   }
   function add_reviews_post()
   {
      $this->Api_model->add_reviews();
   }

   function get_all_products_post()
   {
      $this->Api_model->get_all_products();
   }
   function get_subscribtion_get()
   {
      $this->Api_model->get_subscribtion();
   }
   function get_subscribtion_details_post()
   {
      $this->Api_model->get_subscribtion_details();
   }
   function add_subscribers_post()
   {
      $this->Api_model->add_subscribers();
   }
   function get_add_subscribtion_post()
   {
      $this->Api_model->get_add_subscribtion();
   }
   function delete_address_post()
   {
      $this->Api_model->delete_address();
   }
   function change_order_status_post()
   {
      $this->Api_model->change_order_status();
   }
   function cancel_order_post()
   {
      $this->Api_model->cancel_order();
   }
   function get_logo_get()
   {
      $this->Api_model->get_logo();
   }
   public function payment_post()
   {
      $data['data'] = array();
      if ($this->input->post('order_amount') != '') {
         $address_id = $this->input->post('address_id');
         $customer_id = $this->input->post('customer_id');
         $type = $this->input->post('payment_type');
         $amounts = $this->input->post('order_amount');
         $api = new Api(RAZOR_KEY, RAZOR_SECRET_KEY);
         $_SESSION['payable_amount'] = $this->input->post('order_amount');
         $razorpayOrder = $api->order->create(array(
            'receipt'         => rand(),
            'amount'          => $_SESSION['payable_amount'] * 100, // 2000 rupees in paise
            'currency'        => 'INR',
            'payment_capture' => 1 // auto capture
         ));
         $amount = $razorpayOrder['amount'];
         $razorpayOrderId = $razorpayOrder['id'];
         $_SESSION['razorpay_order_id'] = $razorpayOrderId;

         $add['customer_id'] = $customer_id;
         $add['unique_id'] = rand();
         $add['address_id'] = $address_id;

         $address_id11 = $address_id;
         $this->db->select('*');
         $this->db->from('address');
         $this->db->where('address.address_id', $address_id11);
         $query = $this->db->get();
         foreach ($query->result() as $row) {
            $pincode11 = $row->pincode;
         }

         $this->db->select('*');
         $this->db->from('pincode_map');
         $this->db->where('pincode_map.pincode', $pincode11);
         $query1 = $this->db->get();
         foreach ($query1->result() as $row1) {
            $shop_id11 = $row1->shop_id;
         }

         //  print_r($query);
         //  die();
         $add['shop_id'] = $shop_id11;

         $add['payment_type'] = $type;
         $add['razorpay_id'] = $razorpayOrderId;
         $add['payment_status'] = "Processing";
         $add['order_value'] = $amounts;
         $add['order_date'] = date('Y-m-d');
         $add['order_time'] = date('H:i:s');

         $this->db->insert('orders', $add);

         $data = $this->prepareData($customer_id, $amount, $razorpayOrderId);
         // print_r($data);
      }
   }
   public function prepareData($customer_id, $amount, $razorpayOrderId)
   {
      $data['customer_id'] = $customer_id;
      $query = $this->db->get_where('customer', $data);

      //	print_r($this->db->last_query()); 
      $data = array();
      foreach ($query->result() as $key => $row) {
         $name = $row->firstname;
         $email = $row->email;
         $mobile_no = $row->mobile_no;
      }
      $data = array(
         "key" => RAZOR_KEY,
         "amount" => $amount,
         "name" => "SAVOURY",
         "description" => "Meat Shop",
         "image" => "http://fatehfruits.teckzy.co.in/upload/logo/logo.png",
         "customer_name" => $name,
         "email" => $email,
         "contact" => $mobile_no,
         "color"  => "#3E7C17",
         "order_id" => $razorpayOrderId,
      );
      echo json_encode($data);
   }
   function payment_success_post()
   {
      $razor = $this->input->post('razorpay_order_id');
      $cart_type = $this->input->post('cart_type');
      $success = true;
      $error = "payment_failed";
      if (empty($_POST['razorpay_payment_id']) === false) {
         //echo "2";
         $api = new Api(RAZOR_KEY, RAZOR_SECRET_KEY);
         try {
            $attributes = array(
               'razorpay_order_id' => $this->input->post('razorpay_order_id'),
               'razorpay_payment_id' => $this->input->post('razorpay_payment_id'),
               'razorpay_signature' => $this->input->post('razorpay_signature'),
            );
            $api->utility->verifyPaymentSignature($attributes);
            //echo "15475675";
         } catch (SignatureVerificationError $e) {
            $success = false;
            $error = 'Razorpay_Error : ' . $e->getMessage();
         }
      } else {
         echo "15475675";
      }
      // echo $success;
      // exit;
      if ($success === true) {
         $data['payment_status'] = "Completed";
         $data['order_status'] = "1";
         $data['estimate_del'] = date("Y/m/d");
         $this->db->where('razorpay_id', $razor);
         $this->db->update('orders', $data);

         $dat['razorpay_id'] = $razor;
         $query = $this->db->get_where('orders', $dat);

         //	print_r($this->db->last_query()); 

         $data = array();
         foreach ($query->result() as $key => $row) {
            $customer_id = $row->customer_id;
            $order_id = $row->order_id;
         }

         $msg = 'Payment Completed Successfully';
         $status = true;
      } else {
         $data['payment_status'] = "Cancel";
         $data['order_status'] = "0";
         $this->db->where('razor_pay_id', $razor);
         $this->db->update('orders', $data);
         $msg = 'Payment Failed';
         $status = false;
      }
      $datas['order_id'] = $order_id;
      $this->db->where('customer_id', $customer_id);
      $this->db->where('order_status', 1);
      $this->db->where('type', $cart_type);
      $qry = $this->db->update('add_to_cart', $datas);

      if ($qry) {
         $order['order_status'] = "0";
         $this->db->where('customer_id', $customer_id);
         $this->db->where('type', $cart_type);
         $this->db->where('order_status', 1);
         $qry1 = $this->db->update('add_to_cart', $order);
      }

      $response[] = array("msg" => $msg, 'status' => $status);
      echo json_encode($response);
   }
}
