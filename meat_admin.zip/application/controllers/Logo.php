<?php
defined('BASEPATH') OR exit('No direct script access allowed');



class Logo extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Settings_model');
        $this->load->library('pagination');
       
       
    }
 function logo(){
    $data['logo'] = $this->Settings_model->get_logo();
    $this->load->view('include/head');
    $this->load->view('include/header');
    $this->load->view('include/menu');
    $this->load->view('logo',$data);
    $this->load->view('include/footer');
    $this->load->view('include/script');
}
function add_logo(){
    $data['logo'] = $this->Settings_model->add_logo();
    redirect(base_url('logo'));
}
function delete_logo(){
    $this->Settings_model->delete_logo();
  
}
function term(){
    $data['term'] = $this->Settings_model->get_term();
    $this->load->view('include/head');
    $this->load->view('include/header');
    $this->load->view('include/menu');
    $this->load->view('term',$data);
    $this->load->view('include/footer');
    $this->load->view('include/script');
}
function add_term(){
    $data['term'] = $this->Settings_model->add_term();
    redirect(base_url('Logo/terms'));
}
function edit_logo(){
    $this->Settings_model->edit_logo(); 
}
function shop(){
    $this->load->view('include/head');
    $this->load->view('include/header');
    $this->load->view('include/menu');
    $this->load->view('shop');
    $this->load->view('include/footer');
    $this->load->view('include/script');
}
function add_shop(){
    $this->Settings_model->add_shop(); 
    redirect(base_url('Logo/shop'));
}
function load_Zone($rowno=0){
   
    $rowperpage = 5;
        if($rowno != 0){
          $rowno = ($rowno-1) * $rowperpage;
        }
        $this->db->select('1');
      $this->db->from('pincode_map');
      $this->db->join('shop','shop.shop_id=pincode_map.shop_id');
      $this->db->where('shop.branch_name',"shop");   
      $query = $this->db->get();
        $allcount = $query->num_rows();
        // exit;
      $this->db->limit($rowperpage, $rowno);
   
      $this->db->select('pincode_map.pincode,pincode_map.shop_id,shop.username');
      $this->db->from('pincode_map');
      $this->db->join('shop','shop.shop_id=pincode_map.shop_id');
      $this->db->where('shop.branch_name',"shop");
	    //  $this->db->from('pincode_map');   
	    //  $this->db->where('status', 1);
	     $users_record = $this->db->get()->result_array();
        $config['base_url'] = base_url().'Logo/load_Zone';
        $config['use_page_numbers'] = TRUE;
        $config['total_rows'] = $allcount;
        $config['per_page'] = $rowperpage;
        $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
        $config['full_tag_close']   = '</ul></nav></div>';
        $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
        $config['num_tag_close']    = '</span></li>';
        $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
        $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
        $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
        $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['prev_tag_close']  = '</span></li>';
        $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
        $config['first_tag_close'] = '</span></li>';
        $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['last_tag_close']  = '</span></li>';
        $this->pagination->initialize($config); 
        $data['pagination'] = $this->pagination->create_links();
      
     
        $data['result'] = $users_record;
        $data['row'] = $rowno;
        echo json_encode($data);
}
function load_Zone1($rowno=0){
   
    $rowperpage = 5;
        if($rowno != 0){
          $rowno = ($rowno-1) * $rowperpage;
        }
        $this->db->select('1');
      $this->db->from('pincode_map');
      $this->db->join('shop','shop.shop_id=pincode_map.shop_id');
      $this->db->where('shop.branch_name',"delivery_person");   
      $query = $this->db->get();
        $allcount = $query->num_rows();
        // exit;
      $this->db->limit($rowperpage, $rowno);
   
      $this->db->select('pincode_map.pincode,pincode_map.shop_id,shop.username');
      $this->db->from('pincode_map');
      $this->db->join('shop','shop.shop_id=pincode_map.shop_id');
      $this->db->where('shop.branch_name',"delivery_person");
	    //  $this->db->from('pincode_map');   
	    //  $this->db->where('status', 1);
	     $users_record = $this->db->get()->result_array();
        $config['base_url'] = base_url().'Logo/load_Zone';
        $config['use_page_numbers'] = TRUE;
        $config['total_rows'] = $allcount;
        $config['per_page'] = $rowperpage;
        $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
        $config['full_tag_close']   = '</ul></nav></div>';
        $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
        $config['num_tag_close']    = '</span></li>';
        $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
        $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
        $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
        $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['prev_tag_close']  = '</span></li>';
        $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
        $config['first_tag_close'] = '</span></li>';
        $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['last_tag_close']  = '</span></li>';
        $this->pagination->initialize($config); 
        $data['pagination'] = $this->pagination->create_links();
      
     
        $data['result'] = $users_record;
        $data['row'] = $rowno;
        echo json_encode($data);
}
function load_shop($rowno=0){
    $rowperpage = 10;
        if($rowno != 0){
          $rowno = ($rowno-1) * $rowperpage;
        }
        $allcount = $this->db->count_all('shop');
        // exit;
      $this->db->limit($rowperpage, $rowno);
      $this->db->select('*'); 
	     $this->db->from('shop');   
	     $this->db->where('status', 1);
	     $users_record = $this->db->get()->result_array();
        $config['base_url'] = base_url().'Logo/load_shop';
        $config['use_page_numbers'] = TRUE;
        $config['total_rows'] = $allcount;
        $config['per_page'] = $rowperpage;
        $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
        $config['full_tag_close']   = '</ul></nav></div>';
        $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
        $config['num_tag_close']    = '</span></li>';
        $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
        $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
        $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
        $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['prev_tag_close']  = '</span></li>';
        $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
        $config['first_tag_close'] = '</span></li>';
        $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['last_tag_close']  = '</span></li>';
        $this->pagination->initialize($config); 
        $data['pagination'] = $this->pagination->create_links();
        $data['result'] = $users_record;
        $data['row'] = $rowno;
        echo json_encode($data);
}
function edit_shop(){
    $this->Settings_model->edit_shops(); 
}
function delete_shop(){
    $this->Settings_model->delete_shop(); 
}
function zone_mapping(){
    $data['zones'] = $this->Settings_model->get_zone();
    $data['shops'] = $this->Settings_model->get_shop();
    $data['pincodes'] = $this->Settings_model->get_pincodes();
    $this->load->view('include/head');
    $this->load->view('include/header');
    $this->load->view('include/menu');
    $this->load->view('zone_mapping',$data);
    $this->load->view('include/footer');
    $this->load->view('include/script');
}
function pincode_map(){
     $this->Settings_model->pincode_map();
      redirect(base_url('Logo/zone_mapping'));
}
function check_pincode(){
    $this->Settings_model->check_pincode(); 
}
function terms(){
    $data['terms'] = $this->Settings_model->get_terms();
    //print_r($data['terms']);
     $this->load->view('include/head');
    $this->load->view('include/header');
    $this->load->view('include/menu');
    $this->load->view('term',$data);
    $this->load->view('include/footer');
    $this->load->view('include/script');
}
function privacy(){
     $data['policys'] = $this->Settings_model->get_policy();
    //print_r($data['terms']);
     $this->load->view('include/head');
    $this->load->view('include/header');
    $this->load->view('include/menu');
    $this->load->view('privacy',$data);
    $this->load->view('include/footer');
    $this->load->view('include/script');
}
function add_policy(){
    $data['term'] = $this->Settings_model->add_policy();
    redirect(base_url('Logo/privacy'));
}
function about(){
    $data['abouts'] = $this->Settings_model->get_about();
    //print_r($data['terms']);
     $this->load->view('include/head');
    $this->load->view('include/header');
    $this->load->view('include/menu');
    $this->load->view('about',$data);
    $this->load->view('include/footer');
    $this->load->view('include/script');
}
function add_about(){
    $data['term'] = $this->Settings_model->add_abouts();
    redirect(base_url('Logo/about'));
}
function add_picode(){
    $data['pincodes'] = $this->Settings_model->get_pincodes();
    $this->load->view('include/head');
    $this->load->view('include/header');
    $this->load->view('include/menu');
    $this->load->view('add_pincode',$data);
    $this->load->view('include/footer');
    $this->load->view('include/script');
}
function save_pincode(){
    $this->Settings_model->save_pincode();
    redirect(base_url('Logo/add_picode'));
}
function delete_pincode(){
    $this->Settings_model->delete_pincodes(); 
}
function edit_pincode(){
    $this->Settings_model->edit_pincode();
}

}