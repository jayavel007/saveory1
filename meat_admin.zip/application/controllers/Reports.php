<?php
defined('BASEPATH') OR exit('No direct script access allowed');



class Reports extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
       $this->load->model('Reports_model');
       
       
    }
 function report(){
    $data['sales']=$this->Reports_model->sales_report();
    $data['customer']=$this->Reports_model->get_customer();
    $data['products']=$this->Reports_model->get_products();
    // $this->Reports_model->sales_report();
	
    //$data['orders'] = array();
    $this->load->view('include/head');
    $this->load->view('include/header');
    $this->load->view('include/menu');
    $this->load->view('reports',$data);
    $this->load->view('include/footer');
    $this->load->view('include/script');
}

// function search_product(){
// 		$this->Reports_model->search_product();
	
    
// }
}