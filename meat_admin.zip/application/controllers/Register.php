<?php
defined('BASEPATH') OR exit('No direct script access allowed');



class Register extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Register_model');
       
       
    }
 function index(){
    $this->load->view('register');
}
function register(){
    $data=$this->Register_model->register();
    //return redirect(base_url('register'));
}
function check_register(){
    $data = $this->Login_model->check_register();
		
		// echo $data;
		if($data==1){
			return redirect(base_url('dashboard'));
		}else{
			return redirect(base_url());
		}	
}
}