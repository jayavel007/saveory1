<?php
defined('BASEPATH') OR exit('No direct script access allowed');



class Dashboard extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
       $this->load->model('Dashboard_model');
       $this->load->model('Order_model');
       
       
    }
 function index(){
    $data['orders'] = $this->Dashboard_model->get_orders();

    $data['dashboard'] = $this->Dashboard_model->get_mtd();
//print_r($data['dashboard']);
    //$data['orders'] = array();
    $this->load->view('include/head');
    $this->load->view('include/header');
    $this->load->view('include/menu');
    $this->load->view('dashboard',$data);
    $this->load->view('include/footer');
    $this->load->view('include/script');
}
}