<?php
defined('BASEPATH') OR exit('No direct script access allowed');



class Stock extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('pagination');
       $this->load->model('Stock_model');
        $this->load->model('Products_model');
       
    }
 function stock(){
     $data['india'] = $this->Stock_model->get_india_products();
    // $data['import'] = $this->Stock_model->get_import_products();
    $data['stocks'] = $this->Stock_model->get_stocks();
    //print_r($data['stocks']);
    $this->load->view('include/head');
    $this->load->view('include/header');
    $this->load->view('include/menu');
    $this->load->view('stock',$data);
    $this->load->view('include/footer');
    $this->load->view('include/script');
}

 function import(){
     
     $data['import'] = $this->Stock_model->get_import_products();
   
    $this->load->view('include/head');
    $this->load->view('include/header');
    $this->load->view('include/menu');
    $this->load->view('importstock',$data);
    $this->load->view('include/footer');
    $this->load->view('include/script');
}

function updateStock(){
    $this->Stock_model->updateStock(); 
}
	public function load_india($rowno=0){
       $rowperpage = 10;
        if($rowno != 0){
          $rowno = ($rowno-1) * $rowperpage;
        }
        $allcount = $this->db->count_all('product');
        // exit;
      $this->db->limit($rowperpage, $rowno);
      $this->db->select('*'); 
	     $this->db->from('product');  
	     $this->db->where('category_type', 'india');
	     $this->db->where('status', 1);
	     $users_record = $this->db->get()->result_array();
        $config['base_url'] = base_url().'Stock/load_india';
        $config['use_page_numbers'] = TRUE;
        $config['total_rows'] = $allcount;
        $config['per_page'] = $rowperpage;
        $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
        $config['full_tag_close']   = '</ul></nav></div>';
        $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
        $config['num_tag_close']    = '</span></li>';
        $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
        $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
        $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
        $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['prev_tag_close']  = '</span></li>';
        $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
        $config['first_tag_close'] = '</span></li>';
        $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['last_tag_close']  = '</span></li>';
        $this->pagination->initialize($config); 
        $data['pagination'] = $this->pagination->create_links();
        $data['result'] = $users_record;
        $data['row'] = $rowno;
        echo json_encode($data); 

  }
  	public function load_import($rowno=0){
       $rowperpage = 10;
        if($rowno != 0){
          $rowno = ($rowno-1) * $rowperpage;
        }
        $allcount = $this->db->count_all('product');
        // exit;
      $this->db->limit($rowperpage, $rowno);
      $this->db->select('*'); 
	     $this->db->from('product');  
	     $this->db->where('category_type', 'import');
	     $this->db->where('status', 1);
	     $users_record = $this->db->get()->result_array();
        $config['base_url'] = base_url().'Stock/load_import';
        $config['use_page_numbers'] = TRUE;
        $config['total_rows'] = $allcount;
        $config['per_page'] = $rowperpage;
        $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination">';
        $config['full_tag_close']   = '</ul></nav></div>';
        $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
        $config['num_tag_close']    = '</span></li>';
        $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
        $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
        $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['next_tag_close']  = '<span aria-hidden="true"></span></span></li>';
        $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['prev_tag_close']  = '</span></li>';
        $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
        $config['first_tag_close'] = '</span></li>';
        $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['last_tag_close']  = '</span></li>';
        $this->pagination->initialize($config); 
        $data['pagination'] = $this->pagination->create_links();
        $data['result'] = $users_record;
        $data['row'] = $rowno;
        echo json_encode($data); 

  }
}