<?php
defined('BASEPATH') OR exit('No direct script access allowed');



class Baskets extends CI_Controller {
    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
       $this->load->model('Baskets_model');
       
       
    }
 function baskets(){
    $data['baskets'] = $this->Baskets_model->get_baskets();
    $this->load->view('include/head');
    $this->load->view('include/header');
    $this->load->view('include/menu');
    $this->load->view('baskets',$data);
    $this->load->view('include/footer');
    $this->load->view('include/script');
}

function add_baskets(){
    $data['baskets'] = $this->Baskets_model->add_baskets();
    redirect(base_url('baskets'));
}

function delete_basket(){
    $this->Baskets_model->delete_basket();
}
function edit_baskets(){
    $this->Baskets_model->edit_baskets(); 
}

}