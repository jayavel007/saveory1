<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/userguide3/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes with
| underscores in the controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'Login';
// $route['default_controller'] = 'Landing';




$route['movies_list'] = 'Home/movies_list';
$route['series_list'] = 'Home/series_list';

$route['tv_show_home'] = 'Home/tv_show_home';
// $route['more_videos'] = 'Home/more_videos';
$route['single_video'] = 'Home/single_video';



$route['contact_us'] = 'Home/contact_us';
// $route['profile'] = 'Home/profile';




$route['login'] = 'Login';
$route['logout'] = 'Login/logout';
$route['check_login'] = 'Login/check_login';
// $route['home'] = 'Home';
$route['get_register'] = 'Login/get_register';
$route['movie_page'] = 'Movies';
$route['one_time_movie'] = 'Movies/one_time_movie';
$route['pricing'] = 'Pricing';
$route['register'] = 'Login/register';

// home
$route['home'] = 'All_videos';
// movies
// $route['movies_home'] = 'Movies/movies_home';
$route['movies_home'] = 'List_movies';
$route['single_movie'] = 'Movies/single_movie';
// videos
$route['more_videos'] = 'Videos/more_videos';
// Series
$route['series_home'] = 'List_series';

 $route['profile'] = 'Settings';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;


