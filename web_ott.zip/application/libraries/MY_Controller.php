<?php 
class MY_Controller extends CI_Controller{
    public function __construct(){
        parent::__construct();
        $user_id = $this->session->userdata('user_id');

        if($user_id==""){
                 
                   redirect(base_url(""));
               
              }

    }
}

 ?>