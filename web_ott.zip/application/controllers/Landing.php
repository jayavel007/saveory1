<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Landing extends CI_Controller {

	

	public function index(){
		$this->load->view('landing_page');
		// $this->load->view('script');

	}
 //   public function logout(){
 //          $this->session->unset_userdata('user_id');
 //          $this->session->unset_userdata('user_name');
 //          $this->session->sess_destroy();
 //         redirect(base_url());
	// }

	//  function check_login(){

	// 	$data['user_login'] = $this->input->post('user_login');
	// 	$data['user_pass'] = md5($this->input->post('user_pass'));
	// 	 // print_r($this->db->get_where('users_login',$data));
	// 	 $query = $this->db->get_where('users_login',$data);
	// 	// print_r($query);
	// 	if($query->num_rows()>0){
	// 		foreach ($query->result() as $key => $row) {
	// 			//echo $row->name;
	// 			$this->session->set_userdata('user_id', $row->user_id);
	// 			$this->session->set_userdata('user_name', $row->name);
	// 	    redirect(base_url("home"));
	// 		}
	// 	}else{
	// 		$this->session->set_userdata('msg', 'Email and Password deos not match');
	// 		redirect(base_url(""));
	// 	}
	// }
}

