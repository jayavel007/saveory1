<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require(APPPATH.'libraries/MY_Controller.php');
class List_series extends MY_Controller {

	public function __construct(){
     parent::__construct();
     $this->load->model('List_series_model');
  	}

	public function index(){
		 
		 		$this->load->view('include/header');
		 			$data['series_list'] = $this->List_series_model->List();	
		 		$data['english_series_list'] = $this->List_series_model->english_series_list();	
		 		$data['tamil_series_list'] = $this->List_series_model->tamil_series_list();	

		 		
		 		$this->load->view('series_page',$data);
	        	$this->load->view('include/footer');
	        	$this->load->view('script');
	

	}
	



}

