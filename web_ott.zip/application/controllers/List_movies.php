<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require(APPPATH.'libraries/MY_Controller.php');
class List_movies extends MY_Controller {

	public function __construct(){
     parent::__construct();
     $this->load->model('List_movies_model');
  	}

	public function index(){
		 
		 		$this->load->view('include/header');
		 			$data['movies_list'] = $this->List_movies_model->List();	
		 		$data['english_movies_list'] = $this->List_movies_model->english_movies_list();	
		 		$data['tamil_movies_list'] = $this->List_movies_model->tamil_movies_list();	

		 		
		 		$this->load->view('movies_home',$data);
	        	$this->load->view('include/footer');
	        	$this->load->view('script');
	

	}
	



}

