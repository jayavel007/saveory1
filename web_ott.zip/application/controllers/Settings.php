<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require(APPPATH.'libraries/MY_Controller.php');
class Settings extends MY_Controller {


	public function __construct(){
     parent::__construct();
     $this->load->model('Settings_model');
  	}




	 function index(){
	
	       // $this->load->view('include/header');
		 		$data['profile'] = $this->Settings_model->profile_edit();	
		 		$this->load->view('profile',$data);
	        	// $this->load->view('include/footer');
	        	$this->load->view('script');

	}

	   function change_password(){
        if ($this->input->post('submit')) {
         
            $c_user_pass = md5($this->input->post('c_user_pass'));
            $n_user_pass = md5($this->input->post('n_user_pass'));

                  // $this->db->select('*');
                  // $this->db->from('users_login');
                  // $this->db->where('user_pass', $c_user_pass);
                  // $query = $this->db->get();

                  $data['user_pass'] =$c_user_pass;
    
                      $query = $this->db->get_where('users_login',$data);
                    // print_r($c_user_pass);

                  // print_r($this->db->last_query()); exit();

                 if($query->num_rows() > 0 ){
                 	    $data['user_pass'] =$n_user_pass;
                 	    $this->db->update('users_login', $data);

// print_r('yeryerrey');exit();
//    $this->db->where('subscriber_id',$row->subscriber_id );
		
        
                    }


}}


}

