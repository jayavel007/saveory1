<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require(APPPATH.'libraries/MY_Controller.php');
class Movies extends MY_Controller {


	public function __construct(){
     parent::__construct();
     $this->load->model('Single_movie_model');
  	}

	public function one_time_movie(){
		 		$this->load->view('include/header');
		$this->load->view('movie_page');
				 $this->load->view('include/footer');
		   $this->load->view('script');

	}


	 function index(){
	
	 	

       $data['user_id']  = $this->session->userdata('user_id');
	   $data['status'] = '1';
		// $data['user_pass'] = md5($this->input->post('user_pass'));
		 // print_r($this->db->get_where('users_login',$data));
		 $query = $this->db->get_where('subscriber',$data);
		// print_r($query);
		if($query->num_rows()>0){
			foreach ($query->result() as $key => $row) {
				//echo $row->name;
				$this->session->set_userdata('user_id', $row->user_id);
				$this->session->set_userdata('subscriber_id', $row->subscriber_id);
		       redirect(base_url("one_time_movie"));
			}
		}else{
			$this->session->set_userdata('msg', 'Subscriber ');
			redirect(base_url("pricing"));
		}

	}




		public function single_movie(){
		        $this->load->view('include/header');
		 		$data['movies_list'] = $this->Single_movie_model->single_movie();	
		 		$this->load->view('single_movie',$data);
	        	$this->load->view('include/footer');
	        	$this->load->view('script');
	

	}

		public function single_movie_link(){
		        $this->load->view('include/header');
		 		$data['movies_list_link'] = $this->Single_movie_model->single_movie_link();	
		 		$this->load->view('movie_page',$data);
	        	$this->load->view('include/footer');
	        	$this->load->view('script');
	

	}



}

