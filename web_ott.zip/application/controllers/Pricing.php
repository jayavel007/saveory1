<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once(APPPATH."libraries/razorpay/razorpay-php/Razorpay.php");
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;
require(APPPATH.'libraries/MY_Controller.php');

class Pricing extends MY_Controller{

	

	public function index(){
		 
		 		$this->load->view('include/header');
		 		
		 		// $this->load->view('razorpay/razorpay-php/Razorpay');
	        	$this->load->view('pricing');
	        	 // $this->load->view('pay');
				 $this->load->view('include/footer');
				 if($this->input->post('price')!=''){
				 	$this->pay($this->input->post('price'));
				 }
				 
	

	}
	public function pay($price){
    $api = new Api(RAZOR_KEY, RAZOR_SECRET_KEY);

	

    /**
     * You can calculate payment amount as per your logic
     * Always set the amount from backend for security reasons
     */
    $_SESSION['payable_amount'] = $price;
    $razorpayOrder = $api->order->create(array(
      'receipt'         => rand(),
      //'amount'          => $_SESSION['payable_amount'] * 100, // 2000 rupees in paise
      'amount'          => $price * 100, // 2000 rupees in paise
      'currency'        => 'INR',
      'payment_capture' => 1 // auto capture
    ));
    //$amount = $razorpayOrder['amount'];
    $amount = $razorpayOrder['amount'];
    $razorpayOrderId = $razorpayOrder['id'];
    $_SESSION['razorpay_order_id'] = $razorpayOrderId;
    $data = $this->prepareData($amount,$razorpayOrderId);
    $this->load->view('rezorpay',array('data' => $data));
  }
  public function prepareData($amount,$razorpayOrderId)
  {
  		$data['user_id'] = $this->session->userdata('user_id');
        $query = $this->db->get_where('users_login',$data);

        if($query->num_rows()>0){
			foreach ($query->result() as $key => $row) {
				//echo $row->name;
				$user_name = $row->name;
				$email = $row->user_login;
				$phone = $row->phone;

				$this->session->set_userdata('user_name', $row->name);
				$this->session->set_userdata('user_login', $row->user_login);
				$this->session->set_userdata('phone', $row->phone);
				
				
		    }
		}

    $data = array(
      "key" => RAZOR_KEY,
      "amount" => $amount,
      "name" => "OTT",
      "description" => "Learn To Code",
      "image" => "https://demo.codingbirdsonline.com/website/img/coding-birds-online/coding-birds-online-favicon.png",
      "prefill" => array(
        "name"  => $user_name,
        "email"  => $email,
        "contact" => $phone,
      ),
      "notes"  => array(
        "address"  => "Hello World",
        "merchant_order_id" => rand(),
      ),
      "theme"  => array(
        "color"  => "#F37254"
      ),
      "order_id" => $razorpayOrderId,
    );
    return $data;
  }



 public function verify()
  {
    $success = true;
    $error = "payment_failed";
    if (empty($_POST['razorpay_payment_id']) === false) {
      $api = new Api(RAZOR_KEY, RAZOR_SECRET_KEY);
    try {
        $attributes = array(
          'razorpay_order_id' => $_SESSION['razorpay_order_id'],
          'razorpay_payment_id' => $_POST['razorpay_payment_id'],
          'razorpay_signature' => $_POST['razorpay_signature']
        );
        $api->utility->verifyPaymentSignature($attributes);
      } catch(SignatureVerificationError $e) {
        $success = false;
        $error = 'Razorpay_Error : ' . $e->getMessage();
      }
    }
    if ($success === true) {
      /**
       * Call this function from where ever you want
       * to save save data before of after the payment
       */
      $this->setRegistrationData();
      redirect(base_url());
    }
    else {
      redirect(base_url().'register/paymentFailed');
    }
  }

    public function setRegistrationData()
  {
    $name = $this->session->userdata('user_name');
    $email = $this->session->userdata('user_login');
    $contact = $this->session->userdata('phone');
    $amount = $_SESSION['payable_amount'];
    $registrationData = array(
      'order_id' => $_SESSION['razorpay_order_id'],
      'name' => $name,
      'email' => $email,
      'contact' => $contact,
      'amount' => $amount,
    );
    // save this to database
    $response = $this->db->insert('payment_details',$registrationData);

     if($response==true){

              $insert_id = $this->db->insert_id();
               $user_id = $this->session->userdata('user_id');
               $amount = $_SESSION['payable_amount'];
                

               

                   $start_date = date("d-m-Y");


	if($amount=='500'){
               $future_date1 =strtotime("$start_date +30 days");
                $future_date=date("d-m-Y", $future_date1);
                }else if($amount=='1500'){
              $future_date1 =strtotime("$start_date +60 days");
                 $future_date=date("d-m-Y", $future_date1);

                }else if($amount=='5000'){
               $future_date1 =strtotime("$start_date +100 days");
                   $future_date=date("d-m-Y", $future_date1);


                }
// $future_date1 =strtotime("$start_date +30 days");



    $subscriber_list = array(
      'user_id' => $user_id,
      'subscribe_amt' => $amount,
      'payment_id' => $insert_id,
      'subscribe_start' => $start_date,
      'subscribe_end' => $future_date,
    );




    $query = $this->db->insert('subscriber',$subscriber_list);
     if($query==true){

              $insert_id = $this->db->insert_id();

				$this->session->set_userdata('subscriber_id', $insert_id);

            $this->session->set_userdata('color', 'success');
            $this->session->set_userdata('msg', 'Payment Successfully');
            redirect(base_url("home"));
  } 
   }
   }

}

