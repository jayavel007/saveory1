<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require(APPPATH.'libraries/MY_Controller.php');
class Home extends MY_Controller {

 public function __construct()
    {
        parent::__construct();
 
        // load Session Library
        $this->load->library('session');
         
        // load url helper
        $this->load->helper('url');
    }
 
 
public function index()
	{
		$this->load->view('include/header');
		$this->load->view('home/index');
	   $this->load->view('include/footer');
	   $this->load->view('script');
	}
public function movies_home()
	{
		$this->load->view('include/header');
		$this->load->view('movies_home');
	    $this->load->view('include/footer');
	    	   $this->load->view('script');
	}
	public function tv_show_home()
	{
		$this->load->view('include/header');
		$this->load->view('tv_show_home');
	    $this->load->view('include/footer');
	    	   $this->load->view('script');
	}

	public function movies_list()
	{
		$this->load->view('include/header');
		$this->load->view('movies_list');
	    $this->load->view('include/footer');
	    	   $this->load->view('script');
	}
		public function more_videos()
	{
		$this->load->view('include/header');
		$this->load->view('more_videos');
	    $this->load->view('include/footer');
	    	   $this->load->view('script');
	}
		public function single_video()
	{
		$this->load->view('include/header');
		$this->load->view('single_video');
	    $this->load->view('include/footer');
	    	   $this->load->view('script');
	}
			public function single_movie()
	{
		$this->load->view('include/header');
		$this->load->view('single_movie');
	    $this->load->view('include/footer');
	    	   $this->load->view('script');
	}
	
		public function pricing()
	{
		$this->load->view('include/header');
		$this->load->view('pricing');
	    $this->load->view('include/footer');
	    	   $this->load->view('script');
	}
		public function contact_us()
	{
		$this->load->view('include/header');
		$this->load->view('contact_us');
	    $this->load->view('include/footer');
	    	   $this->load->view('script');
	}
			public function profile()
	{
		$this->load->view('include/header');
		$this->load->view('profile');
	    $this->load->view('include/footer');
	    	   $this->load->view('script');
	}
	
					public function login()
	{
	
		$this->load->view('login');
	    
	}
	

}

