<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require(APPPATH.'libraries/MY_Controller.php');
class All_videos extends MY_Controller {



	public function __construct(){
     parent::__construct();
     $this->load->model('Home_model');
     $this->load->model('List_movies_model');
     
  	}

	public function one_time_movie(){
		  $this->load->view('include/header');
		  $this->load->view('movie_page');
		  $this->load->view('include/footer');
		  $this->load->view('script');

	}



	 function index(){
	
	  $this->load->view('include/header');

		 		$data['all_list'] = $this->Home_model->banner_link();	
		 		$data['movies_list'] = $this->List_movies_model->List();	
		 		$data['series_list'] = $this->List_movies_model->series_list();	
		 		$data['hit_video'] = $this->List_movies_model->hit_video();	
		 		
	            $this->load->view('home/index',$data);
		 		// $this->load->view('single_movie',$data);
	        	$this->load->view('include/footer');
	        	$this->load->view('script');

	}



		public function single_movie(){
		        $this->load->view('include/header');

		 		$data['movies_list'] = $this->Single_movie_model->single_movie();	

		 		$this->load->view('single_movie',$data);
	        	$this->load->view('include/footer');
	        	$this->load->view('script');
	

	}

		public function single_movie_link(){
		        $this->load->view('include/header');
		 		$data['movies_list_link'] = $this->Single_movie_model->single_movie_link();	
		 		$this->load->view('movie_page',$data);
	        	$this->load->view('include/footer');
	        	$this->load->view('script');
	

	}



}

