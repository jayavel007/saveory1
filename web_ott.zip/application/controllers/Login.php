<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	

	public function index(){
		$this->load->view('login');
		// $this->load->view('script');

	}
				public function register()
	{
	
		$this->load->view('register');
	    
	}

   public function logout(){
          $this->session->unset_userdata('user_id');
          $this->session->unset_userdata('user_name');
          $this->session->sess_destroy();
         redirect(base_url());
	}

	 function check_login(){

		$data['user_login'] = $this->input->post('user_login');
		$data['user_pass'] = md5($this->input->post('user_pass'));
		 // print_r($this->db->get_where('users_login',$data));
		 $query = $this->db->get_where('users_login',$data);
		// print_r($query);
		if($query->num_rows()>0){
			foreach ($query->result() as $key => $row) {
 
				$this->session->set_userdata('user_id', $row->user_id);
				$this->session->set_userdata('user_name', $row->name);

               // $data1['user_id'] = $row->user_id;
               // $data1['status'] = '1';
               $this->db->where('user_id',$row->user_id );
               $this->db->select('*');
               $this->db->order_by("subscriber_id", "desc");
               $this->db->limit(1);
               $query1 = $this->db->get('subscriber');
               
                // print_r($this->db->last_query()); exit();

					 // print_r($this->db->last_query()); exit();
			if($query1->num_rows()>0){

			foreach ($query1->result() as $key => $row) {

				$subscribe_end = $row->subscribe_end;
           $exp_date = date("d-m-Y");
           //2021-12-02 > 2021-12-30
           if($exp_date > $subscribe_end){
           		$update_rows = array('status' => '0',);
		    $this->db->where('subscriber_id',$row->subscriber_id );
		    $this->db->update('subscriber', $update_rows);

           	$this->session->set_userdata('subscriber_id','0');
           	$this->session->set_userdata('irruku','ila');


           }else{
           	$this->session->set_userdata('subscriber_id', $row->subscriber_id);
           	$this->session->set_userdata('irruku', 'irruku');
           }

            redirect(base_url("home"));
		    $this->load->view('script');
				// $this->session->set_userdata('subscriber_id', $row->subscriber_id);
           }

		}else{
                $this->session->set_userdata('subscriber_id','0');
                redirect(base_url("home"));
		        $this->load->view('script');
		}

		
    
		}
		}else{
			$this->session->set_userdata('msg', 'Email and Password deos not match');
			redirect(base_url(""));
			$this->load->view('script');
		}


	}


	    function get_register(){
        if ($this->input->post('submit')) {
		
            $data['name'] = $this->input->post('first_name');
            // $data['user_login'] = $this->input->post('last_name');
            $data['user_login'] = $this->input->post('user_email');
            $data['phone'] = $this->input->post('user_phone');
            $pass = md5($this->input->post('pass1'));
            $data['user_pass'] = $pass;
            // $data['pass2'] = md5($this->input->post('pass2'));
             // print_r($data['name']);

            $user_email = $this->input->post('user_email');
            $user_phone = $this->input->post('user_phone');
          
            $pass1 = $this->input->post('pass1');
		        $pass2 = $this->input->post('pass2');
		    
		    
			   $this->db->select('*');
			   $this->db->from('users_login');
			   $this->db->where('user_login', $user_email);
			   $query = $this->db->get();
			 
			 	 $this->db->select('*');
			     $this->db->from('users_login');
			     $this->db->where('phone', $user_phone);
			     $que = $this->db->get();

                   // print_r($this->db->last_query());
     
			       if($query->num_rows() > 0 ){
                      $this->session->set_userdata('type','error');
                  echo '<script type="text/javascript">'; 
echo 'alert("Email is Already Exists");'; 
echo 'window.location.href = "'.base_url('register').'"';
echo '</script>';
}elseif($que->num_rows() > 0){
                      $this->session->set_userdata('type','error');
                      // $this->session->set_userdata('msg','Mobile Number is Already Exists');
                        echo '<script type="text/javascript">'; 
echo 'alert("Mobile Number is Already Exists");'; 
echo 'window.location.href = "'.base_url('register').'"';
echo '</script>';
                    }else if($pass1!= $pass2){
                      $this->session->set_userdata('type','error');
                      // $this->session->set_userdata('msg','Password and Confirm password doesnot match');
                            echo '<script type="text/javascript">'; 
echo 'alert("Password and Confirm password doesnot match");'; 
echo 'window.location.href = "'.base_url('register').'"';
echo '</script>';
                    }else{ 
                        $query = $this->db->insert('users_login',$data);
                        redirect(base_url("login"));
                
                    }
  // print_r($query);
                     if($query){
                         foreach ($query->result() as $key => $row) {
                         $this->session->set_userdata('user_id', $row->user_id);
                         }
                         $this->session->set_userdata('type','success');
                         $this->session->set_userdata('msg','Register Successfully');
                     }else{
                         $this->session->set_userdata('type','error');
                         $this->session->set_userdata('msg','Register Unsuccessfull');
                     }
        }
     } 



}

