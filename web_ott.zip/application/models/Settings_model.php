 <?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Settings_model extends CI_Model {

 public function profile_edit(){
  
      $subscriber_id  = $this->session->userdata('subscriber_id');

         // if ($subscriber_id !== '' ) {

            $user_id  = $_GET['user_id'];
     
    $this->db->where('users_login.user_id',$user_id);
    $this->db->where('users_login.status','1');
    $this->db->from('users_login');
    // $this->db->join('video_file','video_list.video_id=video_file.video_list_id');
    // $this->db->join('video_genre_list_merge','video_file.video_list_id=video_genre_list_merge.video_id');
    // $this->db->join('genre_list','genre_list.genre_id=video_genre_list_merge.genre_list_id');
    $query = $this->db->get();   
      // print_r($this->db->last_query()); exit();
   return $query->result();
   
      // } else {
      //       $this->session->set_userdata('msg', 'Subscriber ');
      //    redirect(base_url("pricing"));
      // }

  }

   public function single_movie_link(){
  
      $subscriber_id  = $this->session->userdata('subscriber_id');

         if ($subscriber_id !== '0' ) {

            $video_id  = $_GET['video_id'];
     
    $this->db->where('video_list.video_id',$video_id);
    $this->db->where('video_list.status','1');
    $this->db->from('video_list');
    $this->db->join('video_file','video_list.video_id=video_file.video_list_id');
    $this->db->join('video_genre_list_merge','video_file.video_list_id=video_genre_list_merge.video_id');
    $this->db->join('genre_list','genre_list.genre_id=video_genre_list_merge.genre_list_id');
    $query = $this->db->get();   
     // print_r($this->db->last_query()); exit();
   return $query->result();
   
      } else {
            $this->session->set_userdata('msg', 'Subscriber ');
         redirect(base_url("pricing"));
      }

  }

  

}