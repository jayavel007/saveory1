 <?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home_model extends CI_Model {

 
 

   public function banner_link(){
  
          $this->db->where('video_list.status','1');
    // $this->db->where('video_list.category_id','3');
    $this->db->limit(3);
   $this->db->order_by('video_list.video_id','desc');
    $this->db->select('*');
    $this->db->from('video_list');
    $this->db->join('video_file','video_list.video_id=video_file.video_list_id');
    $this->db->join('video_genre_list_merge','video_file.video_list_id=video_genre_list_merge.video_id');
    $this->db->join('genre_list','genre_list.genre_id=video_genre_list_merge.genre_list_id');

    $query = $this->db->get();
    // print_r($query);
    return $query->result();
    //for

  }

  

}
// video_file video_list video_genre_list_merge genre_list