 <?php  
 defined('BASEPATH') OR exit('No direct script access allowed');

 class Login_models extends CI_Model  
 {  
   
  public function __construct(){
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Login_models');
        $this->load->database();
     }

    function get_register(){
        if ($this->input->post('submit')) {
          
            $data['name'] = $this->input->post('first_name');
            // $data['user_login'] = $this->input->post('last_name');
            $data['user_login'] = $this->input->post('user_email');
            $data['phone'] = $this->input->post('user_phone');
            $pass = md5($this->input->post('pass1'));
            $data['user_pass'] = $pass;
            // $data['pass2'] = md5($this->input->post('pass2'));
             // print_r($data['name']);

            $user_email = $this->input->post('user_email');
            $user_phone = $this->input->post('user_phone');
          
            $pass1 = $this->input->post('pass1');
                  $pass2 = $this->input->post('pass2');
              
              
                  $this->db->select('*');
                  $this->db->from('users_login');
                  $this->db->where('user_login', $user_email);
                  $query = $this->db->get();
                
                     $this->db->select('*');
                    $this->db->from('users_login');
                    $this->db->where('phone', $user_phone);
                    $que = $this->db->get();

                   // print_r($this->db->last_query());
     
                      if($query->num_rows() > 0 ){
                      $this->session->set_userdata('type','error');
                      $this->session->set_userdata('msg','Email is Already Exists');
                    }elseif($que->num_rows() > 0){
                      $this->session->set_userdata('type','error');
                      $this->session->set_userdata('msg','Mobile Number is Already Exists');
                    }else if($pass1!= $pass2){
                      $this->session->set_userdata('type','error');
                      $this->session->set_userdata('msg','Password and Confirm password doesnot match');
                    }
                    else{ 
                        $qry = $this->db->insert('users_login',$data);
                        print_r($qry);
                    }

                    if($qry){
                        foreach ($query->result() as $key => $row) {
                        $this->session->set_userdata('user_id', $row->user_id);
                        }
                        $this->session->set_userdata('type','success');
                        $this->session->set_userdata('msg','Register Successfully');
                    }else{
                        $this->session->set_userdata('type','error');
                        $this->session->set_userdata('msg','Register Unsuccessfull');
                    }
        }
     } 

 }  
 ?>