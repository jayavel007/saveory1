 <?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class List_movies_model extends CI_Model {

 public function list(){
    $data['status'] =1;
    $data['category_id'] =3;
    $query = $this->db->get_where('video_list',$data);
    return $query->result();
    //for
  }
}