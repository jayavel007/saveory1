<?php
require_once(APPPATH."libraries/razorpay/razorpay-php/Razorpay.php");
use Razorpay\Api\Api;
use Razorpay\Api\Errors\SignatureVerificationError;
require(APPPATH.'libraries/MY_Controller.php');
class Api_model extends CI_Model 
{

function generate_otp(){
     	$mobile_no = $this->input->post('mobile_no');
		if($mobile_no==''){
			$msg = 'Mobile Number Must be filled';
			$status = false;
			$user_type="";
			$otp_num='';
		}else{
			//$otp_no = mt_rand(100000, 999999);
			$otp_no="1234";
			$data['otp_number'] = $otp_no;
	
		    $this->db->where('phone',$mobile_no);
		    $count = $this->db->get('users_login')->num_rows();
		    
		    if($count>0){
		    	$msg = 'Mobile Number Already exits';
			    $status = false;
			    $user_type="old";
			    $otp_num='';
		    }
		    else{
		    	$data['mobile_no'] = $mobile_no;
		    	    $this->db->where('mobile_no',$mobile_no);
		           $cont = $this->db->get('generate_otp')->num_rows();
		           if($cont>0){
		                $this->db->where('mobile_no',$mobile_no);
		               $qry = $this->db->update('generate_otp',$data);
		           }else{
		               $qry = $this->db->insert('generate_otp',$data);
		           }
		    	
				//echo "new mobile number";
				if($qry){
				    $msg = 'OTP has been sent form your mobile number';
			        $status = true;
			        $otp_num="$otp_no";
			         $user_type="new";
					
				}else{
					$msg = 'OTP Generation Failed';
			        $status = false;
			        $otp_num='';
			        $user_type='';
				}
		    }
			
		}
		$response[] = array("msg"=>$msg,'status'=>$status,'user_type'=>$user_type,'otp_no'=>$otp_num);
		echo json_encode($response);
    }
    
    
    
       function register(){
        $user_name = $this->input->post('user_name');
        // $last_name = $this->input->post('last_name');
        $email = $this->input->post('email');
        $mobile_no = $this->input->post('mobile_no');
       
        $password = md5($this->input->post('password'));
        if($mobile_no==''){
            $msg = "Please Enter the Mobile Number";
            $error =true;
            echo json_encode(array('error'=>$error,'message'=>$msg));
        }
        else if($user_name==''){
            $msg = "Please Enter the User Name";
            $error =true;
            echo json_encode(array('error'=>$error,'message'=>$msg));
        }
        else if($email==''){
            $msg = "Please Enter the Email";
            $error =true;
            echo json_encode(array('error'=>$error,'message'=>$msg));
        }else if($password==''){
            $msg = "Please Enter the Password";
            $error =true;
            echo json_encode(array('error'=>$error,'message'=>$msg));
        }else{
        	$this->db->where('phone',$mobile_no);
			$num_count = $this->db->get('users_login')->num_rows();
	
			$this->db->where('user_login',$email);
			$email_count = $this->db->get('users_login')->num_rows();
	 
			if($num_count>0){
				$error = false;
			    $msg = 'This Mobile Number Already exits';
			    $datas = array();
			}else if($email_count>0){
				$error = false;
			    $msg = 'This Email Already exits';
			    $datas = array();
			}else{
            $data['phone'] = $mobile_no;
            $data['user_pass'] =  $password;
            $data['name'] =  $user_name;
            $data['user_login'] =  $email;
            $query = $this->db->insert('users_login',$data);
            if($query){
                $error =true;
                $msg = "Register Successfully";
                // $datas=array();    
                    $datas[]=array( 
                  'user_id' => $this->db->insert_id(),
                  'name' => $user_name,
                  'mobile_no'=>$mobile_no,
                  'user_login'=>$email,
                //   'image'=> $data['image'],
                  
                  );
            }else{
                $msg = "Register Failed";
                $error =false;
                $datas=array();    
            }
        }}
         $response[] = array("msg"=>$msg,'status'=>$error,'users'=>$datas);
		echo json_encode($response);
    }
    

 
   function check_login(){
        $email = $this->input->post('email');
        $password = md5($this->input->post('password'));
        if($email==''){
            $msg = "Please Enter the Email";
            $error =true;
            
            echo json_encode(array('error'=>$error,'message'=>$msg ,'cart_count'=>$cart_count));

        }else if($password==''){
            $msg = "Please Enter the Password";
            $error =true;
            
            echo json_encode(array('error'=>$error,'message'=>$msg,'cart_count'=>$cart_count));
        }else{
            $this->db->group_start();
            // $data['user_login'] = $email;
            $this->db->where('user_login',$email);
             $this->db->or_where('phone',$email);
            $this->db->group_end();
            $this->db->where('user_pass',$password);
            // $data['user_pass'] =  $password;
            $this->db->where('status',"1");
            $query = $this->db->get('users_login');
            if($query->num_rows()>0){
                $error =true;
                $msg = "User Login Successfully";
                 
                  $datas=array();
                foreach ($query->result() as $key => $row) {
                    $user_id=$row->user_id;
                    $datas[]=array( 
                   'user_id' => $row->user_id,
                   'name' => $row->name,
                   'mobile_no'=> $row->phone,
                   'email'=> $row->user_login,
                //   'image' => $row->image,
                    // 'cart_count'=>$this->get_cart_count($user_id),
                   
                   );
               
                }
               
            }else{
                $msg = "Username and Password does not match";
                $error =false;
                $datas=array();    
            }
        }
         $response[] = array("msg"=>$msg,'status'=>$error,'users_login'=>$datas);
		echo json_encode($response);
 }
 
 
//  Subscribe Plan


 
 function subscribe_plan_api(){
 
   $this->db->where('status',"1");
            $query = $this->db->get('subscribe_plan');
            if($query->num_rows()>0){
                // $error =true;
                // $msg = "User Login Successfully";
                 
                  $datas=array();
                foreach ($query->result() as $key => $row) {
                    // $user_id=$row->user_id;
                    $datas[]=array( 
                   'plan_id' => $row->plan_id,
                   'plan_name' => $row->plan_name,
                   'plan_days'=> $row->plan_days,
                   'plan_amount'=> $row->plan_amount,
                    );
               
                }
               
            }
            //   $response = array($datas);
		echo json_encode($datas);
 }



 function home_banner_api(){
     
    $this->db->where('video_list.status','1');
    $this->db->from('video_list');
    $this->db->join('video_file','video_list.video_id=video_file.video_list_id');
    $this->db->select('*');
    $this->db->order_by("video_id", "desc");
    $this->db->limit(3);
    $query = $this->db->get();   
    //   $query = $this->db->get('video_list');
	    foreach($query->result() as $key=>$row){
	        $datas[]=array(
	            "video_id"=>$row->video_id,
                "title"=>$row->title,
                "thumbnail"=>'admin/'.$row->thumbnail,
	            );
	    }
	    echo json_encode($datas); 
 }



function home_movies_api(){
     
    $this->db->where('video_list.category_id','3');
    $this->db->from('video_list');
    $this->db->join('video_file','video_list.video_id=video_file.video_list_id');
    $this->db->select('*');
    $this->db->order_by("video_id", "desc");
    $this->db->limit(4);
    $query = $this->db->get();   
    //   $query = $this->db->get('video_list');
	    foreach($query->result() as $key=>$row){
	     
	        if($row->pay_per_view < '0'){
	        $datas[]=array(
	            "video_id"=>$row->video_id,
                "title"=>$row->title,
                "thumbnail"=>'admin/'.$row->thumbnail,
                "ratings"=>$row->ratings,
                "pay_per_view"=> 'false',
                "video_price"=> $row->pay_per_view,
                
                
	            );
	      }else{
	            $datas[]=array(
	            "video_id"=>$row->video_id,
                "title"=>$row->title,
                "thumbnail"=>'admin/'.$row->thumbnail,
                "ratings"=>$row->ratings,
                "pay_per_view"=> 'true',
                "video_price"=> $row->pay_per_view,
                
	            );  
	        }
	    }
	    echo json_encode($datas); 
 }
 
//  nathim
function home_all_movies_api(){
     
    $this->db->where('video_list.category_id','3');
    $this->db->from('video_list');
    $this->db->join('video_file','video_list.video_id=video_file.video_list_id');
    $this->db->select('*');
    $this->db->order_by("video_id", "desc");
   
    $query = $this->db->get();   
    //   $query = $this->db->get('video_list');
        // if($query->num_rows()>0){
            
	    foreach($query->result() as $key=>$row){
	        if($row->pay_per_view < '0'){
	        $datas[]=array(
	            "video_id"=>$row->video_id,
                "title"=>$row->title,
                "thumbnail"=>'admin/'.$row->thumbnail,
                "ratings"=>$row->ratings,
                "pay_per_view"=> 'false',
                "video_price"=> $row->pay_per_view,
                
                
	            );
	      }else{
	            $datas[]=array(
	            "video_id"=>$row->video_id,
                "title"=>$row->title,
                "thumbnail"=>'admin/'.$row->thumbnail,
                "ratings"=>$row->ratings,
                "pay_per_view"=> 'true',
                "video_price"=> $row->pay_per_view,
                
	            );  
	        }
	    }
       
	    
	    echo json_encode($datas); 
 }
 
 function home_all_series_api(){
     
    $this->db->where('video_list.category_id','2');
    $this->db->from('video_list');
    $this->db->join('video_file','video_list.video_id=video_file.video_list_id');
     $this->db->join('languages','video_file.language_id=languages.language_id');
    $this->db->select('*');
    $this->db->order_by("video_id", "desc");
   
    $query = $this->db->get();   
    //   $query = $this->db->get('video_list');
	    foreach($query->result() as $key=>$row){
	        $datas[]=array(
	            "video_id"=>$row->video_id,
                "title"=>$row->title,
                "thumbnail"=>'admin/'.$row->thumbnail,
                "ratings"=>$row->ratings,
                "language_name"=>$row->language_name,
                "pay_per_view"=> 'false',
                "video_price"=> $row->pay_per_view,
                
	            );
	    }
	    echo json_encode($datas); 
 }
 
 function home_series_api(){
     
    $this->db->where('video_list.category_id','2');
    $this->db->from('video_list');
    $this->db->join('video_file','video_list.video_id=video_file.video_list_id');
    $this->db->select('*');
    $this->db->order_by("video_id", "desc");
    $this->db->limit(4);
    $query = $this->db->get();   
    //   $query = $this->db->get('video_list');
	    foreach($query->result() as $key=>$row){
	        $datas[]=array(
	            "video_id"=>$row->video_id,
                "title"=>$row->title,
                "thumbnail"=>'admin/'.$row->thumbnail,
                "ratings"=>$row->ratings,
                   "pay_per_view"=> 'false',
                "video_price"=> $row->pay_per_view,
                
	            );
	    }
	    echo json_encode($datas); 
 }


 function movies_home_api(){
     
    $this->db->where('video_list.category_id','3');
    $this->db->where('video_list.status','1');
    $this->db->from('video_list');
    $this->db->join('video_file','video_list.video_id=video_file.video_list_id');
    $this->db->select('*');
    $this->db->order_by("video_id", "desc");
    $this->db->limit(3);
    $query = $this->db->get();   
    //   $query = $this->db->get('video_list');
	    foreach($query->result() as $key=>$row){
	        $datas=array(
	            "video_id"=>$row->video_id,
                "title"=>$row->title,
                "thumbnail"=>'admin/'.$row->thumbnail,
	            );
	    }
	    echo json_encode($datas); 
 }


 
//  function movies_english_api(){
    
//     $this->db->from('video_list');
//     $this->db->join('video_file','video_list.video_id=video_file.video_list_id');
//      $this->db->join('languages','video_file.language_id=languages.language_id');
//     $this->db->select('*');
//     $this->db->order_by("video_id", "desc");
   
//     $query = $this->db->get();   
  
// 	    foreach($query->result() as $key=>$row){
// 	  $list1 =$this->movies_tamil_api($row->language_id);
// 	        $datas=array(
	     
//                 "language_name"=>$row->language_name,
//                 "videos"=>$list1
                
// 	            );
// 	    }
// 	      $return = array($datas);
// 	    echo json_encode($return); 
//  }
 
// function movies_tamil_api(){
    
//     $this->db->from('video_list');
//     $this->db->join('video_file','video_list.video_id=video_file.video_list_id');
//     $this->db->select('*');
//     $this->db->order_by("video_id", "desc");
//     $this->db->limit(10);
//     $query = $this->db->get();   
// 	    foreach($query->result() as $key=>$row){
// 	        $datas=array(
// 	            "video_id"=>$row->video_id,
//                 "title"=>$row->title,
//                 "thumbnail"=>'admin/'.$row->thumbnail,
//                 "ratings"=>$row->ratings,
                
                
// 	            );
// 	    }
// 	    return array($datas);
//  }
 
 
 

function series_home_api(){
     
    $this->db->where('video_list.category_id','2');
    $this->db->where('video_list.status','1');
    $this->db->from('video_list');
    $this->db->join('video_file','video_list.video_id=video_file.video_list_id');
    $this->db->select('*');
    $this->db->order_by("video_id", "desc");
    $this->db->limit(3);
    $query = $this->db->get();   
    //   $query = $this->db->get('video_list');
	    foreach($query->result() as $key=>$row){
	        $datas[]=array(
	            "video_id"=>$row->video_id,
                "title"=>$row->title,
                "thumbnail"=>'admin/'.$row->thumbnail,
                "pay_per_view"=> 'false',
                "video_price"=> $row->pay_per_view,
                
	            );
	    }
	    echo json_encode($datas); 
 }

function series_tamil_api(){
     
    $this->db->where('video_list.category_id','2');
    $this->db->where('video_file.language_id','1');
    
    $this->db->from('video_list');
    $this->db->join('video_file','video_list.video_id=video_file.video_list_id');
    $this->db->select('*');
    $this->db->order_by("video_id", "desc");
    $this->db->limit(4);
    $query = $this->db->get();   
    //   $query = $this->db->get('video_list');
	    foreach($query->result() as $key=>$row){
	        $datas[]=array(
	            "video_id"=>$row->video_id,
                "title"=>$row->title,
                "thumbnail"=>'admin/'.$row->thumbnail,
                "ratings"=>$row->ratings,
                "pay_per_view"=> 'false',
                "video_price"=> $row->pay_per_view,
                
	            );
	    }
	    echo json_encode($datas); 
 }
 
 function series_english_api(){
     
    $this->db->where('video_list.category_id','2');
    $this->db->where('video_file.language_id','2');
    
    $this->db->from('video_list');
    $this->db->join('video_file','video_list.video_id=video_file.video_list_id');
    $this->db->select('*');
    $this->db->order_by("video_id", "desc");
    $this->db->limit(4);
    $query = $this->db->get();   
    //   $query = $this->db->get('video_list');
        $i=0;
        if($query->num_rows() > 0){
	    foreach($query->result() as $key=>$row){
	         $i++;
	        $datas[]=array(
	            "video_id"=>$row->video_id,
                "title"=>$row->title,
                "thumbnail"=>'admin/'.$row->thumbnail,
                "ratings"=>$row->ratings,
                "pay_per_view"=> 'false',
                "video_price"=> $row->pay_per_view,
                
	            );
	    }
        }else{
            $datas = array();
        }
	    echo json_encode($datas); 
 }
 
 
 
function movies_tamil_api(){
     
    $this->db->where('video_list.category_id','3');
    $this->db->where('video_file.language_id','1');
    
    $this->db->from('video_list');
    $this->db->join('video_file','video_list.video_id=video_file.video_list_id');
    $this->db->select('*');
    $this->db->order_by("video_id", "desc");
    $this->db->limit(4);
    $query = $this->db->get();   
    //   $query = $this->db->get('video_list');
	    foreach($query->result() as $key=>$row){
	      
	        if($row->pay_per_view < '0'){
	        $datas[]=array(
	            "video_id"=>$row->video_id,
                "title"=>$row->title,
                "thumbnail"=>'admin/'.$row->thumbnail,
                "ratings"=>$row->ratings,
                "pay_per_view"=> 'false',
                "video_price"=> $row->pay_per_view,
                
                
	            );
	      }else{
	            $datas[]=array(
	            "video_id"=>$row->video_id,
                "title"=>$row->title,
                "thumbnail"=>'admin/'.$row->thumbnail,
                "ratings"=>$row->ratings,
                "pay_per_view"=> 'true',
                "video_price"=> $row->pay_per_view,
                
	            );  
	        }
	    }
	    echo json_encode($datas); 
 }
 
 function movies_english_api(){
     
    $this->db->where('video_list.category_id','3');
    $this->db->where('video_file.language_id','2');
    
    $this->db->from('video_list');
    $this->db->join('video_file','video_list.video_id=video_file.video_list_id');
    $this->db->select('*');
    $this->db->order_by("video_id", "desc");
    $this->db->limit(4);
    $query = $this->db->get();   
    //   $query = $this->db->get('video_list');
	    foreach($query->result() as $key=>$row){
	        $datas[]=array(
	            "video_id"=>$row->video_id,
                "title"=>$row->title,
                "thumbnail"=>'admin/'.$row->thumbnail,
                "ratings"=>$row->ratings,
                
	            );
	    }
	    echo json_encode($datas); 
 }
 
 
 function movie_preview(){
    
     $video_id = $this->input->post('video_id');
     
     
    $this->db->where('video_list.video_id',$video_id);
   $this->db->from('video_list');
     $this->db->join('video_file','video_list.video_id=video_file.video_list_id');
    $this->db->join('video_genre_list_merge','video_file.video_list_id=video_genre_list_merge.video_id');
    $this->db->join('genre_list','genre_list.genre_id=video_genre_list_merge.genre_list_id');
    
       $this->db->join('languages','video_file.language_id=languages.language_id');
    // $this->db->select('*');
    // $this->db->order_by("video_id", "desc");
    // $this->db->limit(1);
    $query = $this->db->get();   
    //   $query = $this->db->get('video_list');
	    foreach($query->result() as $key=>$row){
	        $datas[]=array(
	            "video_id"=>$row->video_id,
                "title"=>$row->title,
                "description"=>$row->description,
                "genre_name"=>$row->genre_name,
                "language_name"=>$row->language_name,
                "banner_link"=>'admin/'.$row->banner_link,
                "banner_type"=>$row->banner_type,
                "ratings"=>$row->ratings,
                
                
	            );
	    }
	    echo json_encode($datas); 
     
     
 }
 
  function series_preview(){
    
     $video_id = $this->input->post('video_id');
     
     
    $this->db->where('video_list.video_id',$video_id);
    $this->db->from('video_list');
    $this->db->join('video_file','video_list.video_id=video_file.video_list_id');
    $this->db->join('video_genre_list_merge','video_file.video_list_id=video_genre_list_merge.video_id');
    $this->db->join('genre_list','genre_list.genre_id=video_genre_list_merge.genre_list_id');
    $this->db->join('languages','video_file.language_id=languages.language_id');
   
    $query = $this->db->get();   
    
	    foreach($query->result() as $key=>$row){
	        $datas[]=array(
	            "video_id"=>$row->video_id,
                "title"=>$row->title,
                "description"=>$row->description,
                "genre_name"=>$row->genre_name,
                "language_name"=>$row->language_name,
                "banner_link"=>'admin/'.$row->banner_link,
                "banner_type"=>$row->banner_type,
                "ratings"=>$row->ratings,
                
                );
	    }
	    echo json_encode($datas); 
     
     
 }
 
 
 
 
 
 
 
//  all movies

function all_movies_api(){
    
    $this->db->select('*');
    $this->db->from('languages');
    $this->db->where('status',1);
    $query = $this->db->get();
    if($query->num_rows() > 0){
        foreach($query->result() as $row){
            $list = $this->getList($row->language_id);
            $data[]=array(
                'language_name' => $row->language_name,
                'list'=>$list
                );
        }
    }else{
        $data = array();
    }
    echo json_encode($data);
}
 
function getList($id){
     $this->db->select('*');
    $this->db->from('video_list');
    $this->db->where('video_list.category_id','3');
    $this->db->join('video_file','video_list.video_id=video_file.video_list_id');
  
    $this->db->where('video_file.language_id',$id);
   
    $this->db->order_by("video_id", "desc");

    $query = $this->db->get();   

       if($query->num_rows() > 0){
           
           foreach($query->result() as $key=>$row){
	  

        
               $datas[]=array(
	            "video_id"=>$row->video_id,
                "title"=>$row->title,
                "thumbnail"=>'admin/'.$row->thumbnail,
                "ratings"=>$row->ratings,
                // "pay_per_view"=> 'false',
                "video_price"=> $row->pay_per_view
                
	          
	            ); 
           
 
	       // if($row->pay_per_view < '0'){

	         
	       // $datas[]=array(
	       //     "video_id"=>$row->video_id,
        //         "title"=>$row->title,
        //         "thumbnail"=>'admin/'.$row->thumbnail,
        //         "ratings"=>$row->ratings,
        //         "pay_per_view"=> 'false',
        //         "video_price"=> $row->pay_per_view,
        //         "language_name"=>$row->language_name,
                
	          
	       //     );
	        
	   //   }else{
	   //         $datas[]=array(
	   //         "video_id"=>$row->video_id,
    //             "title"=>$row->title,
    //             "thumbnail"=>'admin/'.$row->thumbnail,
    //             "ratings"=>$row->ratings,
    //             "pay_per_view"=> 'true',
    //             "video_price"=> $row->pay_per_view,
    //             "language_name"=>$row->language_name,
                
	   //         );  
	   //     }
	          
	        
	            
	    
	           // }
	        
	        
	    }
       }
	    
	    return $datas;
	   //  $datas12[]=array(
	   //         "language_name"=>$row->language_name,
    //             "list" => $datas,
                
	   //         );
     
	   // echo json_encode($datas12); 
 }
 
 
 
 
 
 
 
 
 
  function video_player(){
    
     $video_id = $this->input->post('video_id');
     
     $user_id = $this->input->post('user_id');
     
    //   $data['user_id']  = $user_id;
	   //$data['status'] = '1';
	   
	           $this->db->where('user_id',$user_id );
	           $this->db->where('status','1' );
               $this->db->select('*');
               $this->db->order_by("subscriber_id", "desc");
               $this->db->limit(1);
               $query = $this->db->get('subscriber');
               
               
               
               
               
               
// 		 $query = $this->db->get_where('subscriber',$data);
		// print_r($query);
		if($query->num_rows()>0){
			foreach ($query->result() as $key => $row) {
			    
		   $subscribe_end = $row->subscribe_end;
           $exp_date = date("d-m-Y");
           
            $subscribe_end = strtotime($subscribe_end);
            $exp_date = strtotime($exp_date);
          
           
           if($exp_date > $subscribe_end){
           		$update_rows = array('status' => '0',);
		    $this->db->where('subscriber_id',$row->subscriber_id );
		    $this->db->update('subscriber', $update_rows);

           	// $this->session->set_userdata('subscriber_id','0');
           	// $this->session->set_userdata('irruku','ila');
	        $msg = "Subscriber Experience";
	        $error =false;
	        $datas1[]=array();

           }else{
   
         
           
		   $msg = "Subscribers";
	        $error =true;
	        
    $this->db->where('video_list.video_id',$video_id);
    $this->db->from('video_list');
    $this->db->join('video_file','video_list.video_id=video_file.video_list_id');
    $this->db->join('video_genre_list_merge','video_file.video_list_id=video_genre_list_merge.video_id');
    $this->db->join('genre_list','genre_list.genre_id=video_genre_list_merge.genre_list_id');
    $this->db->join('languages','video_file.language_id=languages.language_id');
   
    $query = $this->db->get();   
    
	    foreach($query->result() as $key=>$row){
	           
	      
	        $datas1[]=array(
	            "video_id"=>$row->video_id,
                "title"=>$row->title,
                
                "video_link"=>'admin/'.$row->file_name,
              
                );
	  
	    }
           }
		
			}
			
		}else{
    	    $datas1[]=array();
            $msg = "Only Subscribers See Videos";
            $error =false;
                
		}
		
    
        
             
            $datas[] = array("msg"=>$msg,'status'=>$error,'video player'=>$datas1);
            echo json_encode( $datas); 
     
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 function forgot_password(){
     	$phone = $this->input->post('mobile_no');
		if($phone==''){
			$msg = 'Phone Number Must be filled';
			$status = false;
			$otp_num='';
		}else{
			//$otp_no = mt_rand(100000, 999999);
			$otp_no="1234";
			$data['otp_number'] = $otp_no;
	
		    $this->db->where('phone',$phone);
		    $count = $this->db->get('users_login')->num_rows();
		    
		    if($count>0){
		    	$data['mobile_no'] = $phone;
		    	    $this->db->where('mobile_no',$phone);
		           $cont = $this->db->get('generate_otp')->num_rows();
		           if($cont>0){
		                $this->db->where('mobile_no',$phone);
		               $qry = $this->db->update('generate_otp',$data);
		           }else{
		               $qry = $this->db->insert('generate_otp',$data);
		           }
		     	if($qry){
				    $msg = 'OTP has been sent form your Mobile Number';
			        $status = true;
			        $otp_num="$otp_no";
			        
					
				}else{
					$msg = 'OTP Generation Failed';
			        $status = false;
			        $otp_num='';
			       
				}
		    }
		    else{
		        $msg = 'Incorrect Mobile Number';
		          $status = false;
			        $otp_num='';
		    }
			
		}
		$response[] = array("msg"=>$msg,'status'=>$status,'otp_no'=>$otp_num);
		echo json_encode($response);
 }
 
 
 
 function change_forgot_password(){
        $mobile_no = $this->input->post('mobile_no');
       	$data['user_pass'] = md5($this->input->post('password'));
      
		 	$this->db->where('phone',$mobile_no);
	        $query = $this->db->update('users_login',$data);
		    //print_r($this->db->last_query());
		    if($query){
		     	$msg = 'Password Changed Successfully';
			    $status = true;
		    }else{
		    	
		    	$msg = 'Password Changed Failed';
			    $status = false;
		    }   
		
	
        
    $response[] = array("msg"=>$msg,'status'=>$status);
    echo json_encode($response);
 }
     // Nathim completed
     
     
     
     
  public function payments(){
        $data['data'] = array();
        if($this->input->post('amount')!=''){
		$user_id = $this->input->post('user_id');
		$amounts = $this->input->post('amount');
		
    $api = new Api(RAZOR_KEY, RAZOR_SECRET_KEY);

	

    /**
     * You can calculate payment amount as per your logic
     * Always set the amount from backend for security reasons
     */
    $_SESSION['payable_amount'] = $amounts;
    $razorpayOrder = $api->order->create(array(
      'receipt'         => rand(),
      'amount'          => $amounts * 100, // 2000 rupees in paise
      'currency'        => 'INR',
      'payment_capture' => 1 // auto capture
    ));
    //$amount = $razorpayOrder['amount'];
    $amount = $razorpayOrder['amount'];
    $razorpayOrderId = $razorpayOrder['id'];
    $_SESSION['razorpay_order_id'] = $razorpayOrderId;
    $data = $this->prepareData($amount,$razorpayOrderId,$user_id);
    // nathim
    // $data10['user_id'] = $user_id;
    
    	$data14['user_id'] = $user_id;
        $query = $this->db->get_where('users_login',$data14);

        if($query->num_rows()>0){
			foreach ($query->result() as $key => $row) {
				//echo $row->name;
				$user_name = $row->name;
				$email = $row->user_login;
				$contact = $row->phone;
				
				
		    }
		}
    
    $data10['status'] ="1";
    $data10['order_id'] = $razorpayOrderId;
    $data10['amount'] = $amounts;
    $data10['name'] = $user_name;
    $data10['contact'] = $contact;
    $data10['user_id'] = $user_id;
    $data10['email'] = $email;
    $data10['payment_status'] ="Cancel";
    
    $qry = $this->db->insert('payment_details',$data10);
    echo json_encode($data);
        	}
     
    }
 
  public function prepareData($amount,$razorpayOrderId,$user_id)
  {
  		$data['user_id'] = $user_id;
        $query = $this->db->get_where('users_login',$data);

        if($query->num_rows()>0){
			foreach ($query->result() as $key => $row) {
				//echo $row->name;
				$user_name = $row->name;
				$email = $row->user_login;
				$phone = $row->phone;

				// $this->session->set_userdata('user_name', $row->name);
				// $this->session->set_userdata('user_login', $row->user_login);
				// $this->session->set_userdata('phone', $row->phone);
				
				
		    }
		}

    $data = array(
      "key" => RAZOR_KEY,
      "amount" => $amount,
      "name" => "OTT",
      "description" => "Learn To Code",
      "image" => "https://demo.codingbirdsonline.com/website/img/coding-birds-online/coding-birds-online-favicon.png",
    //   "prefill" => array(
      "name"  => $user_name,
      "email"  => $email,
      "contact" => $phone,
    //   ),
    //   "notes"  => array(
        "address"  => "Hello World",
        "merchant_order_id" => rand(),
    //   ),
    //   "theme"  => array(
        "color"  => "#F37254",
    //   ),
      "order_id" => $razorpayOrderId,
    );
    return $data;
  }

 
 
 
  function payment_success(){
  $razor=$this->input->post('razorpay_order_id');
  $get_user['order_id'] = $razor;
$query = $this->db->get_where('payment_details',$get_user);
foreach($query->result() as $key=>$row){
    $user_id = $row->user_id;
    $payment_id = $row->payment_id;
    $amount = $row->amount;
}
  
    $success = true;
    $error = "payment_failed";
    if (empty($_POST['razorpay_payment_id']) === false) {
      $api = new Api(RAZOR_KEY, RAZOR_SECRET_KEY);
    try {
        $attributes = array(
          'razorpay_order_id' =>$this->input->post('razorpay_order_id'),
          'razorpay_payment_id' =>$this->input->post('razorpay_payment_id'),
          'razorpay_signature' =>$this->input->post('razorpay_signature'),
        );
        $api->utility->verifyPaymentSignature($attributes);
      } catch(SignatureVerificationError $e) {
        $success = false;
        $error = 'Razorpay_Error : ' . $e->getMessage();
      }
    }
    if($success === true) {
        $data['payment_status'] ="Completed";
        $data['status'] ="1";
        $data['payment_at'] =date("Y/m/d");
		$this->db->where('order_id',$razor);
		$this->db->update('payment_details',$data);


		
	    $msg = 'Payment Completed Successfully';
		$status = true;
		
		
                $start_date = date("d-m-Y");


	if($amount=='500'){
               $future_date1 =strtotime("$start_date +30 days");
                $future_date=date("d-m-Y", $future_date1);
                }else if($amount=='1500'){
              $future_date1 =strtotime("$start_date +60 days");
                 $future_date=date("d-m-Y", $future_date1);

                }else if($amount=='5000'){
               $future_date1 =strtotime("$start_date +100 days");
                   $future_date=date("d-m-Y", $future_date1);


                }
// $future_date1 =strtotime("$start_date +30 days");



    $subscriber_list = array(
      'user_id' => $user_id,
      'subscribe_amt' => $amount,
      'payment_id' => $payment_id,
      'subscribe_start' => $start_date,
      'subscribe_end' => $future_date,
    );

    $query = $this->db->insert('subscriber',$subscriber_list);
    }
    else{
        $data['payment_status'] ="Cancel";
        $data['status'] ="0";
		$this->db->where('order_id',$razor);
		$this->db->update('payment_details',$data);
        $msg = 'Payment Failed';
		$status = false;
    }
    
    
   
 
  
  
  
    	$response[] = array("msg"=>$msg,'status'=>$status);
		echo json_encode($response);
}
 
 
 
     
 function list_banner(){
    
	     $status ="1";
	     $this->db->where('status',$status);
      $query = $this->db->get('banner');
	    foreach($query->result() as $key=>$row){
	        $datas[]=array(
	           "banner_id"=>$row->banner_id,
               "banner_name"=>$row->banner_name,
               "banner_image"=>$row->banner_image,
	            );
	    }
	    echo json_encode($datas);
}


function change_password(){
      $customer_id = $this->input->post('customer_id');
       	$datas['password'] = md5($this->input->post('old_password'));
       	$pass=$datas['password']; 
       	
       	    $this->db->where('password',$pass);
		    $count = $this->db->get('customer')->num_rows();
       	
       	$data['password'] = md5($this->input->post('new_password'));
		$datas['confirm_password'] = $this->input->post('confirm_password');	
	
		
		if($count>0){
		 	$this->db->where('customer_id',$customer_id);
	        $query = $this->db->update('customer',$data);
		    //print_r($this->db->last_query());
		    if($query){
		     	$msg = 'Password Changed Successfully';
			    $status = true;
		    }else{
		    	
		    	$msg = 'Password Changed Failed';
			    $status = false;
		    }   
		}else{
		   $msg = 'Old Password Wrong';
		   $status = false; 
		}
	
        
    $response[] = array("msg"=>$msg,'status'=>$status);
    echo json_encode($response);
}



function get_about(){
    $data['status'] = 1;
    $query = $this->db->get_where('about',$data);
    if($query->num_rows()>0){
        foreach($query->result() as $key=>$row){
            $result[]= array(
                'about_id'=>$row->about_id,
                'about'=>$row->about,
                );
        }
    }else{
        $result[]= array(
                'about_id'=>"",
                'about'=>"",
                );
    }
    echo json_encode($result);
    
}

function get_terms(){
    $data['status'] = 1;
    $query = $this->db->get_where('terms',$data);
    if($query->num_rows()>0){
        foreach($query->result() as $key=>$row){
            $result[]= array(
                'term_id'=>$row->term_id,
                'terms'=>$row->terms,
                );
        }
    }else{
        $result[]= array(
                'term_id'=>"",
                'terms'=>"",
                );
    }
    echo json_encode($result);
 
}
function get_policy(){
    $data['status'] = 1;
    $query = $this->db->get_where('privacy_policy',$data);
    if($query->num_rows()>0){
        foreach($query->result() as $key=>$row){
            $result[]= array(
                'privacy_policy_id'=>$row->privacy_policy_id,
                'policy'=>$row->policy,
                );
        }
    }else{
        $result[]= array(
                'privacy_policy_id'=>"",
                'policy'=>"",
                );
    }
    echo json_encode($result);
 
}

}
?>