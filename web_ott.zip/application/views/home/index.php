



   <!-- owl-carousel Banner Start -->
   <section class="pt-0 pb-0">
      <div class="container-fluid px-0">
         <div class="row no-gutters">
            <div class="col-12">
               <div class="gen-banner-movies banner-style-2">
                  <div class="owl-carousel owl-loaded owl-drag" data-dots="false" data-nav="true" data-desk_num="1"
                     data-lap_num="1" data-tab_num="1" da
                     ta-mob_num="1" data-mob_sm="1" data-autoplay="true"
                     data-loop="true" data-margin="0">

                         <?php
    if(!empty($all_list)){
                          $i=1;
                        foreach($all_list as $key=>$row){

                      ?> 
                         <div class="item" style="background: url(<?php echo base_url(''); ?>admin/<?= $row->thumbnail; ?>)">
                                <div class="gen-movie-contain h-100">
                                    <div class="container h-100">
                                        <div class="row align-items-center h-100">
                                            <div class="col-xl-6">
                                                <div class="gen-tag-line"><span></span></div>
                                                <div class="gen-movie-info">
                                                    <h3><?= $row->title; ?></h3>
                                                    
                                                </div>
                                                <div class="gen-movie-meta-holder">
                                                    <ul>
                                                        <li class="gen-sen-rating">
                                                         <span><?= $row->genre_list_id; ?> </span>
                                                        </li>
                                                        <li>1hr 44 mins</li>
                                                        <li> <img src="images/asset-2.png" alt="streamlab-image">
                                                            <span>
                                                                0 </span>
                                                        </li>
                                                        <li>
                                                            2018
                                                        </li>
                                                        <li>
                                                            <a href="#"><span><?= $row->genre_name; ?> </span></a>
                                                        </li>
                                                    </ul>
                                                    <p><?= $row->description; ?></p>
                                                </div>
                                                <div class="gen-movie-action">
                                                    <div class="gen-btn-container button-1">
                                                        <a href="#" class="gen-button">
                                                            <span class="text">Play Now</span>
                                                        </a>
                                                    </div>
                                                 
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

     <?php $i++; } } ?> 

                   
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!-- owl-carousel Banner End -->

   <!-- owl-carousel Videos Section-1 Start -->
   <section class="gen-section-padding-2">
      <div class="container">
         <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-6">
               <h4 class="gen-heading-title">All Time Hits</h4>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 d-none d-md-inline-block">
               <div class="gen-movie-action">
                  <div class="gen-btn-container text-right">
                     <a href="#" class="gen-button gen-button-flat">
                        <span class="text">More Videos</span>
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <div class="row mt-3">
            <div class="col-12">
               <div class="gen-style-2">
                  <div class="owl-carousel owl-loaded owl-drag" data-dots="false" data-nav="true" data-desk_num="4"
                     data-lap_num="3" data-tab_num="2" data-mob_num="1" data-mob_sm="1" data-autoplay="false"
                     data-loop="false" data-margin="30">

                                              <?php
    if(!empty($hit_video)){
                          $i=1;
                        foreach($hit_video as $key=>$row){

                      ?> 
                            <div class="item">
                                <div
                                    class="movie type-movie status-publish has-post-thumbnail hentry movie_genre-action movie_genre-adventure movie_genre-drama">
                                    <div class="gen-carousel-movies-style-3 movie-grid style-3">
                                        <div class="gen-movie-contain">
                                            <div class="gen-movie-img">
                                                <img src="<?php echo base_url(''); ?>admin/<?= $row->thumbnail; ?>"
                                                    alt="owl-carousel-video-image">
                                                <div class="gen-movie-add">
                                                    <div class="wpulike wpulike-heart">
                                                        <div class="wp_ulike_general_class wp_ulike_is_not_liked">
                                                            <button type="button"
                                                                class="wp_ulike_btn wp_ulike_put_image"></button>
                                                        </div>
                                                    </div>
                                                
                                                  
                                                </div>
                                                <div class="gen-movie-action">
                                                    <a href="<?php echo base_url('Movies/single_movie'); ?>?video_id=<?= $row->video_id; ?>" class="gen-button">
                                                        <i class="fa fa-play"></i>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="gen-info-contain">
                                                <div class="gen-movie-info">
                                                    <h3><a href="#"><?= $row->title; ?></a>
                                                    </h3>
                                                </div>
                                                <div class="gen-movie-meta-holder">
                                                    <ul>
                                                     <li><?= $row->video_duration; ?></li>
                                                        <li>
                                                            <a href="#"><span><?= $row->genre_name; ?></span></a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- #post-## -->
                            </div>
 <?php $i++; } } ?> 
                    

                    


                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!-- owl-carousel Videos Section-1 End -->

   <!-- owl-carousel Videos Section-2 Start -->
    <section class="pt-0 gen-section-padding-2">
      <div class="container">
         <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-6">
               <h4 class="gen-heading-title">Top Movies</h4>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 d-none d-md-inline-block">
               <div class="gen-movie-action">
                  <div class="gen-btn-container text-right">
                     <a href="#" class="gen-button gen-button-flat">
                        <span class="text">More Movies</span>
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <div class="row mt-3">
            <div class="col-12">
               <div class="gen-style-2">
                  <div class="owl-carousel owl-loaded owl-drag" data-dots="false" data-nav="true" data-desk_num="4"
                     data-lap_num="3" data-tab_num="2" data-mob_num="1" data-mob_sm="1" data-autoplay="false"
                     data-loop="false" data-margin="30">
                                                                 <?php
    if(!empty($movies_list)){
                          $i=1;
                        foreach($movies_list as $key=>$row){

                      ?> 
                            <div class="item">
                                <div
                                    class="movie type-movie status-publish has-post-thumbnail hentry movie_genre-action movie_genre-adventure movie_genre-drama">
                                    <div class="gen-carousel-movies-style-3 movie-grid style-3">
                                        <div class="gen-movie-contain">
                                            <div class="gen-movie-img">
                                                <img src="<?php echo base_url(''); ?>admin/<?= $row->thumbnail; ?>"
                                                    alt="owl-carousel-video-image">
                                                <div class="gen-movie-add">
                                                    <div class="wpulike wpulike-heart">
                                                        <div class="wp_ulike_general_class wp_ulike_is_not_liked">
                                                            <button type="button"
                                                                class="wp_ulike_btn wp_ulike_put_image"></button>
                                                        </div>
                                                    </div>
                                                
                                                  
                                                </div>
                                                <div class="gen-movie-action">
                                                    <a href="<?php echo base_url('Movies/single_movie'); ?>?video_id=<?= $row->video_id; ?>" class="gen-button">
                                                        <i class="fa fa-play"></i>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="gen-info-contain">
                                                <div class="gen-movie-info">
                                                    <h3><a href="#"><?= $row->title; ?></a>
                                                    </h3>
                                                </div>
                                                <div class="gen-movie-meta-holder">
                                                    <ul>
                                                     <li><?= $row->video_duration; ?></li>
                                                        <li>
                                                            <a href="#"><span><?= $row->genre_name; ?></span></a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- #post-## -->
                            </div>
 <?php $i++; } } ?> 
                    

                    

                  </div>
               </div>
            </div>
         </div>
      </div>
   </section> 
   <!-- owl-carousel Videos Section-2 End -->

   <!-- Slick Slider start -->
 <!--   <section class="gen-section-padding-2 pt-0 pb-0">
      <div class="container">
         <div class="home-singal-silder">
            <div class="gen-nav-movies gen-banner-movies">
               <div class="row">
                  <div class="col-lg-12">
                     <div class="slider slider-for">

                        <div class="slider-item" style="background: url('images/background/asset-4.jpeg')">
                           <div class="gen-slick-slider h-100">
                              <div class="gen-movie-contain h-100">
                                 <div class="container h-100">
                                    <div class="row align-items-center h-100">
                                       <div class="col-lg-6">
                                          <div class="gen-movie-info">
                                             <h3>thieve the bank</h3>
                                             <p> is a long established fact that a reader will be distracted by
                                                the readable content of a page when Teckzy at its layout Teckzy.
                                             </p>

                                          </div>
                                          <div class="gen-movie-action">
                                             <div class="gen-btn-container button-1">
                                                <a class="gen-button" href="#" tabindex="0">
                                                   <i aria-hidden="true" class="ion ion-play"></i>
                                                   <span class="text">Play Now</span>
                                                </a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="slider-item" style="background: url('images/background/asset-23.jpeg')">
                           <div class="gen-slick-slider h-100">
                              <div class="gen-movie-contain h-100">
                                 <div class="container h-100">
                                    <div class="row align-items-center h-100">
                                       <div class="col-lg-6">
                                          <div class="gen-movie-info">
                                             <h3>Love your life</h3>
                                             <p>Teckzy is a long established fact that a reader will be distracted by
                                                the readable content of a page when Teckzy at its layout Teckzy.
                                             </p>

                                          </div>
                                          <div class="gen-movie-action">
                                             <div class="gen-btn-container button-1">
                                                <a class="gen-button" href="#" tabindex="0">
                                                   <i aria-hidden="true" class="ion ion-play"></i>
                                                   <span class="text">Play Now</span>
                                                </a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="slider-item" style="background: url('images/background/asset-24.jpeg')">
                           <div class="gen-slick-slider h-100">
                              <div class="gen-movie-contain h-100">
                                 <div class="container h-100">
                                    <div class="row align-items-center h-100">
                                       <div class="col-lg-6">
                                          <div class="gen-movie-info">
                                             <h3>The Last Witness</h3>
                                             <p>Teckzy is a long established fact that a reader will be distracted by
                                                the readable content of a page when Teckzy at its layout Teckzy.
                                             </p>

                                          </div>
                                          <div class="gen-movie-action">
                                             <div class="gen-btn-container button-1">
                                                <a class="gen-button" href="#" tabindex="0">
                                                   <i aria-hidden="true" class="ion ion-play"></i>
                                                   <span class="text">Play Now</span>
                                                </a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                        <div class="slider-item" style="background: url('images/background/asset-25.jpeg')">
                           <div class="gen-slick-slider h-100">
                              <div class="gen-movie-contain h-100">
                                 <div class="container h-100">
                                    <div class="row align-items-center h-100">
                                       <div class="col-lg-6">
                                          <div class="gen-movie-info">
                                             <h3>Fight For Life</h3>
                                             <p>Teckzy is a long established fact that a reader will be distracted by
                                                the readable content of a page when Teckzy at its layout Teckzy.
                                             </p>

                                          </div>
                                          <div class="gen-movie-action">
                                             <div class="gen-btn-container button-1">
                                                <a class="gen-button" href="#" tabindex="0">
                                                   <i aria-hidden="true" class="ion ion-play"></i>
                                                   <span class="text">Play Now</span>
                                                </a>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>

                     </div>
                     <div class="slider slider-nav">
                        <div class="slider-nav-contain">
                           <div class="gen-nav-img">
                              <img src="images/background/asset-4.jpeg" alt="steamlab-image">
                           </div>
                           <div class="movie-info">
                              <h3>thieve the bank</h3>
                              <div class="gen-movie-meta-holder">
                                 <ul>
                                    <li>30mins</li>
                                    <li>
                                       <a href="#">
                                          Action </a>
                                    </li>
                                 </ul>
                              </div>
                           </div>
                        </div>
                        <div class="slider-nav-contain">
                           <div class="gen-nav-img">
                              <img src="images/background/asset-23.jpeg" alt="Teckzy-image">
                           </div>
                           <div class="movie-info">
                              <h3>Love your life</h3>
                              <div class="gen-movie-meta-holder">
                                 <ul>
                                    <li>1hr 46mins</li>
                                    <li>
                                       <a href="#">
                                          Action </a>
                                    </li>
                                 </ul>
                              </div>
                           </div>
                        </div>
                        <div class="slider-nav-contain">
                           <div class="gen-nav-img">
                              <img src="images/background/asset-24.jpeg" alt="Teckzy-image">
                           </div>
                           <div class="movie-info">
                              <h3>The Last Witness</h3>
                              <div class="gen-movie-meta-holder">
                                 <ul>
                                    <li>1hr 37 mins</li>
                                    <li>
                                       <a href="#">
                                          Action </a>
                                    </li>
                                 </ul>
                              </div>
                           </div>
                        </div>
                        <div class="slider-nav-contain">
                           <div class="gen-nav-img">
                              <img src="images/background/asset-25.jpeg" alt="Teckzy-image">
                           </div>
                           <div class="movie-info">
                              <h3>Fight For Life</h3>
                              <div class="gen-movie-meta-holder">
                                 <ul>
                                    <li>2hr 25 mins</li>
                                    <li>
                                       <a href="#">
                                          Action </a>
                                    </li>
                                 </ul>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section> -->
   <!-- Slick Slider End -->

   <!-- owl-carousel Videos Section-3 Start -->
   <section class="pt-0 gen-section-padding-2">
      <div class="container">
         <div class="row">
            <div class="col-xl-6 col-lg-6 col-md-6">
               <h4 class="gen-heading-title">Top Series</h4>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 d-none d-md-inline-block">
               <div class="gen-movie-action">
                  <div class="gen-btn-container text-right">
                     <a href="#" class="gen-button gen-button-flat">
                        <span class="text">More Series</span>
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <div class="row mt-3">
            <div class="col-12">
               <div class="gen-style-2">
                  <div class="owl-carousel owl-loaded owl-drag" data-dots="false" data-nav="true" data-desk_num="4"
                     data-lap_num="3" data-tab_num="2" data-mob_num="1" data-mob_sm="1" data-autoplay="false"
                     data-loop="false" data-margin="30">


             
                                                              <?php
    if(!empty($series_list)){
                          $i=1;
                        foreach($series_list as $key=>$row){

                      ?> 
                            <div class="item">
                                <div
                                    class="movie type-movie status-publish has-post-thumbnail hentry movie_genre-action movie_genre-adventure movie_genre-drama">
                                    <div class="gen-carousel-movies-style-3 movie-grid style-3">
                                        <div class="gen-movie-contain">
                                            <div class="gen-movie-img">
                                                <img src="<?php echo base_url(''); ?>admin/<?= $row->thumbnail; ?>"
                                                    alt="owl-carousel-video-image">
                                                <div class="gen-movie-add">
                                                    <div class="wpulike wpulike-heart">
                                                        <div class="wp_ulike_general_class wp_ulike_is_not_liked">
                                                            <button type="button"
                                                                class="wp_ulike_btn wp_ulike_put_image"></button>
                                                        </div>
                                                    </div>
                                                
                                                  
                                                </div>
                                                <div class="gen-movie-action">
                                                    <a href="<?php echo base_url('Movies/single_movie'); ?>?video_id=<?= $row->video_id; ?>" class="gen-button">
                                                        <i class="fa fa-play"></i>
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="gen-info-contain">
                                                <div class="gen-movie-info">
                                                    <h3><a href="#"><?= $row->title; ?></a>
                                                    </h3>
                                                </div>
                                                <div class="gen-movie-meta-holder">
                                                    <ul>
                                                     <li><?= $row->video_duration; ?></li>
                                                        <li>
                                                            <a href="#"><span><?= $row->genre_name; ?></span></a>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- #post-## -->
                            </div>
 <?php $i++; } } ?> 

                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!-- owl-carousel Videos Section-3 End -->

   <!-- owl-carousel images Start -->
<!--    <section class="pt-0 gen-section-padding-2 home-singal-silder">
      <div class="container">
         <div class="row">
            <div class="col-12">
               <div class="gen-banner-movies">
                  <div class="owl-carousel owl-loaded owl-drag" data-dots="true" data-nav="false" data-desk_num="1"
                     data-lap_num="1" data-tab_num="1" data-mob_num="1" data-mob_sm="1" data-autoplay="true"
                     data-loop="true" data-margin="30">
                     <div class="item" style="background: url('images/background/asset-20.jpeg')">
                        <div class="gen-movie-contain h-100">
                           <div class="container h-100">
                              <div class="row align-items-center h-100">
                                 <div class="col-xl-6">
                                    <div class="gen-movie-info">
                                       <h3>Command in your hand</h3>
                                    </div>
                                    <div class="gen-movie-meta-holder">
                                       <ul>
                                          <li>1 Season</li>
                                          <li>3 Episode</li>
                                          <li>2013</li>
                                          <li>
                                             <a href="#"><span>Comedy</span></a>
                                          </li>
                                       </ul>
                                       <p>Teckzy is a long established fact that a reader will be distracted by the
                                          readable content of a page when Teckzy at its layout Teckzy.</p>
                                    </div>
                                    <div class="gen-movie-action">
                                       <div class="gen-btn-container">
                                          <a href="#" class="gen-button gen-button-dark">
                                             <span class="text">Play now</span>
                                          </a>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="item" style="background: url('images/background/asset-21.jpeg')">
                        <div class="gen-movie-contain h-100">
                           <div class="container  h-100">
                              <div class="row align-items-center h-100">
                                 <div class="col-xl-6">
                                    <div class="gen-movie-info">
                                       <h3>stories of the dark</h3>
                                    </div>
                                    <div class="gen-movie-meta-holder">
                                       <ul>
                                          <li>1 Season</li>
                                          <li>5 Episode</li>
                                          <li>2015 to 2016</li>
                                          <li>
                                             <a href="#"><span>Biography</span></a>
                                          </li>
                                       </ul>
                                       <p>Teckzy is a long established fact that a reader will be distracted by the
                                          readable content of a page when Teckzy at its layout Teckzy.</p>
                                    </div>
                                    <div class="gen-movie-action">
                                       <div class="gen-btn-container button-1">
                                          <a href="#" class="gen-button gen-button-dark">
                                             <span class="text">Play now</span>
                                          </a>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="item" style="background: url('images/background/asset-37.jpeg')">
                        <div class="gen-movie-contain h-100">
                           <div class="container  h-100">
                              <div class="row align-items-center h-100">
                                 <div class="col-xl-6">
                                    <div class="gen-movie-info">
                                       <h3>Against Beast</h3>
                                    </div>
                                    <div class="gen-movie-meta-holder">
                                       <ul>
                                          <li>1 Season</li>
                                          <li>1 Episode</li>
                                          <li>2017 to 2018</li>
                                          <li>
                                             <a href="#"><span>Drama</span></a>
                                          </li>
                                       </ul>
                                       <p>Teckzy is a long established fact that a reader will be distracted by the
                                          readable content of a page when Teckzy at its layout Teckzy.</p>
                                    </div>
                                    <div class="gen-movie-action">
                                       <div class="gen-btn-container button-1">
                                          <a href="#" class="gen-button gen-button-dark">
                                             <span class="text">Play now</span>
                                          </a>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section> -->
   <!-- owl-carousel images End -->

   <!-- owl-carousel Videos Section-4 Start -->

   <!-- owl-carousel Videos Section-4 End -->

   