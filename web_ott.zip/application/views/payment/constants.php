<?php
// credential
define('RAZOR_KEY_ID', 'rzp_test_2vtmfRNhITZIbF');
define('RAZOR_KEY_SECRET', 'l3ToOYZAYkx774SIaNkqye2V');
// $keyId = 'rzp_test_2vtmfRNhITZIbF';
// $keySecret = 'l3ToOYZAYkx774SIaNkqye2V';

?>
