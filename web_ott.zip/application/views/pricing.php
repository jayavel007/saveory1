  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<div class="gen-breadcrumb" style="background-image: url(&quot;images/background/asset-25.jpeg&quot;); padding-top: 117px;">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-12">
                    <nav aria-label="breadcrumb">
                        <div class="gen-breadcrumb-title">
                            <h1>
                                Pricing Table
                            </h1>
                        </div>
                        <div class="gen-breadcrumb-container">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="<?php echo base_url('home'); ?>"><i class="fas fa-home mr-2"></i>Home</a></li>
                                <li class="breadcrumb-item active">Pricing Table</li>
                            </ol>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>


    <section class="gen-section-padding-3">
        <div class="container container-2">
            <div class="row">
                <div class="col-xl-4 col-lg-4 col-md-4">
                    <div class="gen-price-block text-center">
                        <div class="gen-price-detail">
                            <span class="gen-price-title"> BASIC </span>
                            <h2 class="price">&#8377;500 </h2>
                            <p class="gen-price-duration">/ Per Month</p>
                            <div class="gen-bg-effect">
                                <img src="images/background/asset-54.jpg" alt="stream-lab-image">
                            </div>
                        </div>
                        <ul class="gen-list-info">
                            <li>
                                Number Of Screen
                            </li>
                            <li>
                                On how many device you can Download
                            </li>
                            <li>
                                Unlimited TV shows and movies
                            </li>
                            <li>
                                <del>watch on mobile and tablet</del>
                            </li>
                            <li>
                                <del>watch on laptop and tv</del>
                            </li>
                            <li>
                                <del>HD available</del>
                            </li>
                            <li>
                                <del>ultra HD available</del>
                            </li>
                        </ul>
                        <div class="gen-btn-container button-1">
                           <!--  <button class="gen-button buy_now text rzp-button1" value="500">
                                    Purchase now
                                </button> -->
                                  <form action="" method="post">
                            <input type="hidden" id="price" name="price" value="500">
                                <button class="gen-button buy_now text rzp-button1" value="500" >
                                    Purchase now
                                </button>
                        </form>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-4 mt-3 mt-md-0">
                    <div class="gen-price-block text-center active">
                        <div class="gen-price-detail">
                            <span class="gen-price-title"> Standard </span>
                            <h2 class="price">&#8377;1500 </h2>
                            <p class="gen-price-duration">3 Month</p>
                            <div class="gen-bg-effect">
                                <img src="images/background/asset-54.jpg" alt="architek-image">
                            </div>
                        </div>
                        <ul class="gen-list-info">
                            <li>
                                Number Of Screen
                            </li>
                            <li>
                                On how many device you can Download
                            </li>
                            <li>
                                Unlimited TV shows and movies
                            </li>
                            <li>
                                <del>watch on mobile and tablet</del>
                            </li>
                            <li>
                                <del>watch on laptop and tv</del>
                            </li>
                            <li>
                                <del>HD available</del>
                            </li>
                            <li>
                                <del>ultra HD available</del>
                            </li>
                        </ul>
                        <div class="gen-btn-container button-1">
                            <!--  <button class="gen-button buy_now text rzp-button1" value="1500">
                                    Purchase now
                                </button> -->
                                  <form action="" method="post">
                            <input type="hidden" id="price" name="price" value="1500">
                                <button class="gen-button buy_now text rzp-button1" value="1500" >
                                    Purchase now
                                </button>
                        </form>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-4 mt-3 mt-md-0">
                    <div class="gen-price-block text-center">
                        <div class="gen-price-detail">
                            <span class="gen-price-title"> Premium </span>
                            <h2 class="price">&#8377;5000</h2>
                            <p class="gen-price-duration">6 Per Month</p>
                            <div class="gen-bg-effect">
                                <img src="images/background/asset-54.jpg" alt="architek-image">
                            </div>
                        </div>
                        <ul class="gen-list-info">
                            <li>
                                Number Of Screen
                            </li>
                            <li>
                                On how many device you can Download
                            </li>
                            <li>
                                Unlimited TV shows and movies
                            </li>
                            <li>
                                <del>watch on mobile and tablet</del>
                            </li>
                            <li>
                                <del>watch on laptop and tv</del>
                            </li>
                            <li>
                                <del>HD available</del>
                            </li>
                            <li>
                                <del>ultra HD available</del>
                            </li>
                        </ul>
                        <div class="gen-btn-container button-1">
                       <!--      <a > -->
                        <form action="" method="post">
                            <input type="hidden" id="price" name="price" value="5000">
                                <button class="gen-button buy_now text rzp-button1" value="5000" >
                                    Purchase now
                                </button>
                        </form>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    
   