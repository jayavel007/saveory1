<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->
<script>
$(document).ready(function(){
	//alert(1);
  <?php
        $msg = $this->session->userdata('msg'); 
        if(isset($msg)){
        	$color = $this->session->userdata('color');
        ?>
        //alert(1);
           toastr.<?php echo $color; ?>('<?php echo $msg; ?>'); 
        <?php
        $this->session->unset_userdata('msg');
        //unset($_SESSION[msg]);
        }
  ?>  
  
});
$(document).ready(function(){
  $("#search_input").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
function get_supplier_name(name){
  // console.log(name);
            $.ajax({
              "url":"<?php echo base_url('get_supplier'); ?>",
              "method":"POST",
              data:{name:name},
              success:function(data){
                //console.log(name);
               $('#suplier_name').html(data);
              }
            });
          }
function get_supplier_details(val){
  // alert(val);
    $.ajax({
    "url":"<?php echo base_url('get_supplier_info'); ?>",
    "method":"POST",
    data:{val:val},
    success:function(data){
     console.log(data);
     datas = JSON.parse(data);
     $('#supplier_name').val(datas.suplier_name);
     $('#gstin').val(datas.gstin);
      //$('#finished_po_items').html(datas);
    }
    });
}
function get_raw_supplier_details(val){
  // alert(val);
    $.ajax({
    "url":"<?php echo base_url('get_supplier_info'); ?>",
    "method":"POST",
    data:{val:val},
    success:function(data){
     // console.log(data);
     datas = JSON.parse(data);
     $('#supplier_name').val(datas.suplier_name);
     $('#gst_no').val(datas.gstin);
     $('#address').val(datas.address);

      //$('#finished_po_items').html(datas);
    }
    });
}
function search_item_name(name){
  // console.log(name);
    $.ajax({
      "url":"<?php echo base_url('get_item_name'); ?>",
      "method":"POST",
      data:{name:name},
      success:function(data){
        //console.log(name);
      $('#item_name').html(data);
      }
  });
}
function search_finished_item(name){
  // console.log(name);
    $.ajax({
      "url":"<?php echo base_url('get_finished_item'); ?>",
      "method":"POST",
      data:{name:name},
      success:function(data){
        //console.log(name);
      $('#item_names').html(data);
      }
  });
}
function search_sku_name(name){
  // console.log(name);
    $.ajax({
      "url":"<?php echo base_url('get_sku_name'); ?>",
      "method":"POST",
      data:{name:name},
      success:function(data){
        console.log(data);
      $('#item_sku_name').html(data);
      }
  });
}
function get_item_details(val){
  $.ajax({
    "url":"<?php echo base_url('get_item_info'); ?>",
    "method":"POST",
    data:{val:val},
    success:function(data){
    //console.log(data);
     datas = JSON.parse(data);
    $('#item_id').val(datas.item_master_id);
    $('#item_sku_names').val(datas.item_sku_code);
    $('#price').val(datas.price);
    $('#get_per').val(datas.gst_percentage);
    $('#style_code').val(datas.style_name);
    $('#bags').val(1);
    $('#quantity').val(1);
    var gst_amt = Number(datas.price)*Number(datas.gst_percentage)/100;
    $('#gst_amt').val(gst_amt);
    var total=Number(gst_amt)+Number(datas.price);
    $('#total_amt').val(total);
    }
    });
}
function get_semi_item_details(val){
  $.ajax({
    "url":"<?php echo base_url('get_semi_item_details'); ?>",
    "method":"POST",
    data:{val:val},
    success:function(data){
    //console.log(data);
     datas = JSON.parse(data);
    $('#item_id').val(datas.item_master_id);
    $('#item_sku_name').val(datas.item_sku_code);
    $('#dia').val(datas.dia);
    $('#price').val(datas.price);
    $('#get_per').val(datas.gst_percentage);
    $('#dia').val(datas.dia);
    $('#bags').val(1);
    $('#quantity').val(1);
    var gst_amt = Number(datas.price)*Number(datas.gst_percentage)/100;
    $('#gst_amt').val(gst_amt);
    var total=Number(gst_amt)+Number(datas.price);
    $('#total_amt').val(total);
    }
    });
}
function get_sku_details(val){
  $.ajax({
    "url":"<?php echo base_url('get_sku_info'); ?>",
    "method":"POST",
    data:{val:val},
    success:function(data){
    // console.log(data);
     datas = JSON.parse(data);
     
    $('#item_names').val(datas.item_name);
    $('#item_id').val(datas.item_master_id);
    $('#item_sku_names').val(datas.item_sku_code);
    $('#price').val(datas.price);
    $('#get_per').val(datas.gst_percentage);
    $('#style_code').val(datas.style_name);
    $('#bags').val(1);
    $('#quantity').val(1);
    var gst_amt = Number(datas.price)*Number(datas.gst_percentage)/100;
    $('#gst_amt').val(gst_amt);
    var total=Number(gst_amt)+Number(datas.price);
    $('#total_amt').val(total);
    }
    });
}
$(".enter_press").keypress(function(event) {
    if (event.which == 13) {
        appendOnlclick();
        return false;
     }
});
function getPoNumbers(po){
  //console.log(po);
  $.ajax({
      "url":"<?php echo base_url('get_pos'); ?>",
      "method":"POST",
      data:{po:po},
      success:function(data){
        console.log(data);
      $('#supplier_names').html(data);
      }
  });
}
function getFinishedPoNumbers(po){
  //console.log(po);
  $.ajax({
      "url":"<?php echo base_url('get_finished_pos'); ?>",
      "method":"POST",
      data:{po:po},
      success:function(data){
        console.log(data);
      $('#supplier_names').html(data);
      }
  });
}
function getSemiPoNumbers(po){
  $.ajax({
      "url":"<?php echo base_url('get_semi_pos'); ?>",
      "method":"POST",
      data:{po:po},
      success:function(data){
        //console.log(data);
      $('#supplier_names').html(data);
      }
  });
}
function getAccPoNumbers(po){
  $.ajax({
      "url":"<?php echo base_url('get_acc_pos'); ?>",
      "method":"POST",
      data:{po:po},
      success:function(data){
        //console.log(data);
      $('#supplier_names').html(data);
      }
  });
}
function get_yarn_po_details(po_no){
   $.ajax({
      "url":"<?php echo base_url('get_yarn_pos_info'); ?>",
      "method":"POST",
      data:{po_no:po_no},
      success:function(data){
        // console.log(data);
        datas = JSON.parse(data);
        $('#supplier_name').val(datas.supplier);
        $('#gst_in').val(datas.supplier_gst);
        //console.log(datas);
        $('#inward_fields').html(datas.table);
      }
  });
}
function get_po_details(po_no){
   $.ajax({
      "url":"<?php echo base_url('get_pos_info'); ?>",
      "method":"POST",
      data:{po_no:po_no},
      success:function(data){
        // console.log(data);
        datas = JSON.parse(data);
        $('#supplier_name').val(datas.supplier);
        $('#gst_in').val(datas.supplier_gst);
        //console.log(datas);
        $('#inward_fields').html(datas.table);
      }
  });
}
function get_semi_po_details(po_no){
   $.ajax({
      "url":"<?php echo base_url('get_semi_pos_info'); ?>",
      "method":"POST",
      data:{po_no:po_no},
      success:function(data){
        // console.log(data);
        datas = JSON.parse(data);
        $('#supplier_name').val(datas.supplier);
        $('#gst_in').val(datas.supplier_gst);
        //console.log(datas);
        $('#inward_fields').html(datas.table);
      }
  });
}
function get_finish_po_details(po_no){
   $.ajax({
      "url":"<?php echo base_url('get_finish_pos_info'); ?>",
      "method":"POST",
      data:{po_no:po_no},
      success:function(data){
        // console.log(data);
        datas = JSON.parse(data);
        $('#suplier_name').val(datas.suplier_name);
        $('#gstin').val(datas.gstin);
        //console.log(datas);
        $('#finished_po_items').html(datas.table);
      }
  });
}
function get_acc_po_details(po_no){
   $.ajax({
      "url":"<?php echo base_url('get_acc_pos_info'); ?>",
      "method":"POST",
      data:{po_no:po_no},
      success:function(data){
        // console.log(data);
        datas = JSON.parse(data);
        $('#supplier_name').val(datas.supplier);
        $('#gst_in').val(datas.supplier_gst);
        //console.log(datas);
        $('#inward_fields').html(datas.table);
      }
  });
}
function changeValue(id,val){
  var actual_qty = Number($('#pending_qty_'+id).val());
  // console.log(actual_qty+'/'+val);
  if(actual_qty<val){
     toastr.error('Please Check Bag Qty'); 
     $('#qty_'+id).val('0');
      return false;
  }else{
  var price = $('#price_'+id).val();
  var gst_percentage = $('#gst_percentage_'+id).val();
  var total_amt = Number(price)*Number(val);
  var gst_amt =total_amt*gst_percentage/100;
  $('#gst_amt_'+id).val(gst_amt);
  $('#total_amt_'+id).val(Number(gst_amt)+Number(total_amt));
  
  var count = $('#total_item_count').val();
  qty=0;
  g_amt=0;
  t_amt=0;
   for(i=1;i<count;i++){
    //console.log(i);
      qty += parseInt($('.qty_'+i).val());
      g_amt += parseInt($('.gst_amt_'+i).val());
      t_amt += parseInt($('.total_amt_'+i).val());
      //console.log($('.qty_1').val());
   }
   //console.log(g_amt);
  document.getElementById("total_inward_qty_label").innerHTML = qty;
  var total_inward_qty = $('#total_inward_qty').val(qty);

  document.getElementById("total_gst_amt_label").innerHTML = g_amt;
  var total_inward_qty = $('#total_gst_amt').val(g_amt);

  document.getElementById("total_prices_label").innerHTML = t_amt;
  var total_inward_qty = $('#total_prices').val(t_amt);
  
  $('#total_received_bags').val(qty);
  $('#total_gst_price').val(g_amt);
  $('#total_amout_val').val(t_amt);
  //console.log(gst_amt);
}
} 

function checkValidation(checks,table,column,msg,id){
    // var checks = $('#size_name').val();
    // var table="size";
    // var column="size_name";
      $.ajax({
      "url":"<?php echo base_url('checking_exits'); ?>",
      "method":"POST",
      data:{checks:checks,table:table,column:column},
      success:function(data){
        //console.log(data);
         datas = JSON.parse(data);
        if(datas.res=='exits'){
           toastr.error(msg+" Already Added");
          $('#'+id).val("");
          return false;
        }
      }
    });
  }

</script>