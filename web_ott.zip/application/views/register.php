<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="keywords" content="Streamlab - Video Streaming HTML5 Template" />
    <meta name="description" content="Streamlab - Video Streaming HTML5 Template" />
    <meta name="author" content="StreamLab" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Sunshine</title>
    <!-- Favicon -->
    <link rel="shortcut icon" href="images/favicon.png">
    <!-- CSS bootstrap-->
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <!--  Style -->
    <link rel="stylesheet" href="css/style.css" />
    <!--  Responsive -->
    <link rel="stylesheet" href="css/responsive.css" />
     <script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>
</head>


<body>

    <!--=========== Loader =============-->
    <div id="gen-loading">
        <div id="gen-loading-center">
            <img src="images/logo-1.png" alt="loading">
        </div>
    </div>
    <!--=========== Loader =============-->

    <!-- register -->
    <section class="position-relative pb-0">
        <div class="gen-register-page-background" style="background-image: url('images/background/asset-3.jpeg');">
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="text-center">
                <form id="pms_register-form" class="pms-form" action="<?php echo base_url('Login/get_register') ?>" method="POST">
                            <h4>Register</h4>
                         
                            <ul class="pms-form-fields-wrapper pl-0">
                              <li class="pms-field pms-first-name-field ">
                                    <label for="pms_first_name">First Name</label>
                                    <input id="first_name"  class="alphaonly" name="first_name" type="text" value="" required>
                                </li>
                                <li class="pms-field pms-last-name-field ">
                                    <label for="last_name">Last Name</label>
                                    <input id="last_name"  class="alphaonly" name="last_name" type="text" value="" required>
                                </li>
                                <li class="pms-field pms-user-email-field ">
                                    <label for="user_email">E-mail *</label>
                                    <input id="user_email" name="user_email" type="text" value="" required>
                                </li>
                                <li class="pms-field pms-user-email-field ">
                                    <label for="user_phone">Phone Number *</label>
                                    <input id="user_phone" name="user_phone" type="text"  required
                  onkeypress="return isNumberKey(event)" minlenth="10" maxlength="10">
                                </li>
                                
                                
                                <li class="pms-field pms-pass1-field">
                                    <label for="pass1">Password *</label>
                                    <input id="pass1" name="pass1" type="password">
                                </li>
                                <li class="pms-field pms-pass2-field">
                                    <label for="pass2">Repeat Password *</label>
                                    <input id="pass2" name="pass2" type="password">
                                </li>
                                <li class="pms-field pms-pass2-field">
                                    <label for="pass2">Already have an account?<a href="<?php echo base_url('login') ?>">Login</a> </label>
                        
                                </li>
                                  <li class="pms-field pms-pass2-field">
                           <br>
                        
                                </li>
                  <!--              <div class="form__group text-center">
                <small>Already have an account? <a href="<?php echo base_url('login') ?>">Login</a></small>
              </div> -->
                            </ul>
                            <span id="pms-submit-button-loading-placeholder-text" class="d-none">Processing. Please
                                wait...</span>
                            <input  type="submit" name="submit" value="submit">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- register -->

    <!-- Back-to-Top start -->
    <div id="back-to-top">
        <a class="top" id="top" href="#top"> <i class="ion-ios-arrow-up"></i> </a>
    </div>
    <!-- Back-to-Top end -->
<script >
    function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}
$('.alphaonly').bind('keyup blur',function(){ 
    var node = $(this);
    node.val(node.val().replace(/[^a-z]/g,'') ); }
);
</script>

    <!-- js-min -->
    <script src="js/jquery-3.6.0.min.js"></script>
    <script src="js/asyncloader.min.js"></script>
    <!-- JS bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- owl-carousel -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- counter-js -->
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <!-- popper-js -->
    <script src="js/popper.min.js"></script>
    <script src="js/swiper-bundle.min.js"></script>
    <!-- Iscotop -->
    <script src="js/isotope.pkgd.min.js"></script>

    <script src="js/jquery.magnific-popup.min.js"></script>

    <script src="js/slick.min.js"></script>

    <script src="js/streamlab-core.js"></script>

    <script src="js/script.js"></script>


</body>

</html>