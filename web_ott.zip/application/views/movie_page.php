<!--    <style >
       video {
    width: 100%;
    height: 445px;
}
figure {
    position: relative;
    max-width: 1024px;
    max-width: 64rem;
    width: 100%;
    height: 100%;
    max-height: 494px;
    max-height: 30.875rem;
    margin: 20px auto;
    margin: 1.25rem auto;
    padding: 20px;
    padding: 1.051%;
    background-color: inherit !important;
}
#gen-header{
    background: #b3b3b3;
    }
    figure[data-fullscreen=true] video {
     height: 100% !important;
}
figure[data-fullscreen=true] {
    max-width: 100%;
    width: 100%;
    margin: 0;
    padding: 0;
    max-height: 100%;
    background: #fff !important;
}
figure[data-fullscreen=true] .controls {
    position: absolute;
    bottom: 2%;
    width: 100%;
    z-index: 2147483647;
    background: #fff;
}
   </style> -->

  <link href="https://unpkg.com/video.js/dist/video-js.css" rel="stylesheet">
  <script src="https://unpkg.com/video.js/dist/video.js"></script>
  <script src="https://unpkg.com/videojs-contrib-hls/dist/videojs-contrib-hls.js"></script>
<!-- <link rel="stylesheet" href="<?php echo base_url(''); ?>video_css/styles.css" /> -->
    <section class="gen-section-padding-3 gen-single-video" style="background: #ffff;">
        <div class="container">
            <div class="row no-gutters">
                <div class="col-lg-12">
                    <div class="row">
             


                                 <div class="col-lg-12">
                            <div class="gen-video-holder">
                                                              <?php
    if(!empty($movies_list_link)){
                          $i=1;
                        foreach($movies_list_link as $key=>$row){
                          $path  =$row->file_name;
                          $sid ='admin/';
$hash = ($sid);

// $file = "a.mp4";
    // $file_size = filesize($hash);
    // $fp = fopen($hash, "rb");
    // $data = fread ($fp, $file_size);
    // fclose($fp);
    // header ("Content-type: video/mp4");

    // if(md5($_SESSION["check"])=="aaa"){
    //    echo $data;
    // }else{

    // }
// $userinput = "hi.wmv";
// echo '<a href="showvideo.php?video=', urlencode($userinput), '">';


// $ctype= 'video/mp4';
// header('Content-Type: ' . $ctype);
// $file_path_name = "../your_video_folder/relax3.mp4";
// $handle = fopen($file_path_name, "rb");
// $contents = fread($handle, filesize($file_path_name));
// fclose($handle);
// echo $contents
                      ?> 
                            	<figure id="videoContainer" data-fullscreen="false">
        <video id="my_video_1" class="video-js vjs-fluid vjs-default-skin" controls preload="auto"
  data-setup='{}'>
            <source  type="application/x-mpegURL" src="<?php echo base_url(''); ?><?php echo  $hash; ?>/file_folder/movies/venky/venky1080p.m3u8"  >
            <!-- <source src="video/1122.webm" type="video/webm"> -->
         
        </video>
        <script>
var player = videojs('my_video_1');
player.play();
</script>
     <!--    <div id="video-controls" class="controls" data-state="hidden">
            <button id="playpause" type="button" data-state="play">Play/Pause</button>
            <button id="stop" type="button" data-state="stop">Stop</button>
            <div class="progress">
                <progress id="progress" value="0" min="0">
                    <span id="progress-bar"></span>
                </progress>
            </div>
            <button id="mute" type="button" data-state="mute">Mute/Unmute</button>
            <button id="volinc" type="button" data-state="volup">Vol+</button>
            <button id="voldec" type="button" data-state="voldown">Vol-</button>
            <button id="fs" type="button" data-state="go-fullscreen">Fullscreen</button>
            <button id="subtitles" type="button" data-state="subtitles">CC</button>
        </div> -->
     
    </figure>

     <?php $i++; } } ?> 

    <!-- <script src="<?php echo base_url(''); ?>video_js/video-player.js"></script> -->
</div>
</div>
</div>
</div>
</div>
</div>
</section>
