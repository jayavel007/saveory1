<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="keywords" content="Streamlab - Video Streaming HTML5 Template">
    <meta name="description" content="Streamlab - Video Streaming HTML5 Template">
    <meta name="author" content="StreamLab">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Streamlab - Video Streaming HTML5 Template</title>
    <!-- CSS bootstrap-->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- rev-slider -->
    <link rel="stylesheet" href="rev-slider/css/rs6.css">
    <!--  Style -->
    <link rel="stylesheet" href="css/style.css">
    <!--  Responsive -->
    <link rel="stylesheet" href="css/responsive.css">
<script type="text/javascript" async="" src="js/owl.carousel.min.js?ver=1.0"></script></head>

<body>

    <!--=========== Loader =============-->
    <div id="gen-loading" style="display: none;">
        <div id="gen-loading-center">
            <img src="http://gentechtree.com/themes/streamlab/intro/images/Logo-2.png" alt="loading">
        </div>
    </div>
    <!--=========== Loader =============-->

    <!--========== Header ==============-->
    <header id="gen-header" class="gen-header-style-1 gen-has-sticky gen-header-sticky animated fadeInDown animate__faster">
        <div class="gen-bottom-header">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <a class="navbar-brand" href="http://gentechtree.com/themes/streamlab/red-html/index.html" target="_blank">
                                <img class="img-fluid logo" src="http://gentechtree.com/themes/streamlab/intro/images/Logo-2.png" alt="streamlab-image">
                            </a>
                            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                <div id="gen-menu-contain" class="gen-menu-contain">
                                    <ul id="gen-main-menu" class="navbar-nav ml-auto">
                                        <li class="nav-item fixed">
                                            <a class="nav-link active" href="#layouts" aria-current="page">Main Demons</a>
                                        </li>
                                        <li class="nav-item fixed">
                                            <a class="nav-link" href="#pages" aria-current="page">Inner pages</a>
                                        </li>
                                        <li class="nav-item fixed">
                                            <a class="nav-link" href="#features" aria-current="page">Features</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="gen-header-info-box">
                                <div class="gen-btn-container">
                                    <a href="https://themeforest.net/item/streamlab-video-streaming-html5-template/31440830" class="gen-button" target="_blank">
                                        <div class="gen-button-block">
                                            <span class="gen-button-line-left"></span>
                                            <span class="gen-button-text">Purchase</span>
                                        </div>
                                    </a>
                                </div>
                            </div>
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <i class="fas fa-bars"></i>
                            </button>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!--========== Header ==============-->

  
    <!-- END REVOLUTION SLIDER -->

    <!-- Slider -->
    <div class="gen-bg-primary gen-section-padding-3 gen-slider">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="gen-client">
                        <div class="owl-carousel owl-loaded owl-drag" data-dots="false" data-nav="false" data-desk_num="5" data-lap_num="3" data-tab_num="2" data-mob_num="1" data-mob_sm="1" data-autoplay="true" data-loop="true" data-margin="10">
                            
                            
                            
                            
                            
                        <div class="owl-stage-outer"><div class="owl-stage" style="transform: translate3d(-1860px, 0px, 0px); transition: all 0.25s ease 0s; width: 3988px;"><div class="owl-item cloned" style="width: 255.8px; margin-right: 10px;"><div class="item">
                                <div class="gen-image-main">
                                    <img src="http://gentechtree.com/themes/streamlab/intro/images/clients-img-1.png" alt="streamlab-image">
                                </div>
                            </div></div><div class="owl-item cloned" style="width: 255.8px; margin-right: 10px;"><div class="item">
                                <div class="gen-image-main">
                                    <img src="http://gentechtree.com/themes/streamlab/intro/images/clients-img-2.png" alt="streamlab-image">
                                </div>
                            </div></div><div class="owl-item cloned" style="width: 255.8px; margin-right: 10px;"><div class="item">
                                <div class="gen-image-main">
                                    <img src="http://gentechtree.com/themes/streamlab/intro/images/clients-img-3.png" alt="streamlab-image">
                                </div>
                            </div></div><div class="owl-item cloned" style="width: 255.8px; margin-right: 10px;"><div class="item">
                                <div class="gen-image-main">
                                    <img src="http://gentechtree.com/themes/streamlab/intro/images/clients-img-4.png" alt="streamlab-image">
                                </div>
                            </div></div><div class="owl-item cloned" style="width: 255.8px; margin-right: 10px;"><div class="item">
                                <div class="gen-image-main">
                                    <img src="http://gentechtree.com/themes/streamlab/intro/images/clients-img-6.png" alt="streamlab-image">
                                </div>
                            </div></div><div class="owl-item" style="width: 255.8px; margin-right: 10px;"><div class="item">
                                <div class="gen-image-main">
                                    <img src="http://gentechtree.com/themes/streamlab/intro/images/clients-img-1.png" alt="streamlab-image">
                                </div>
                            </div></div><div class="owl-item" style="width: 255.8px; margin-right: 10px;"><div class="item">
                                <div class="gen-image-main">
                                    <img src="http://gentechtree.com/themes/streamlab/intro/images/clients-img-2.png" alt="streamlab-image">
                                </div>
                            </div></div><div class="owl-item active" style="width: 255.8px; margin-right: 10px;"><div class="item">
                                <div class="gen-image-main">
                                    <img src="http://gentechtree.com/themes/streamlab/intro/images/clients-img-3.png" alt="streamlab-image">
                                </div>
                            </div></div><div class="owl-item active" style="width: 255.8px; margin-right: 10px;"><div class="item">
                                <div class="gen-image-main">
                                    <img src="http://gentechtree.com/themes/streamlab/intro/images/clients-img-4.png" alt="streamlab-image">
                                </div>
                            </div></div><div class="owl-item active" style="width: 255.8px; margin-right: 10px;"><div class="item">
                                <div class="gen-image-main">
                                    <img src="http://gentechtree.com/themes/streamlab/intro/images/clients-img-6.png" alt="streamlab-image">
                                </div>
                            </div></div><div class="owl-item cloned active" style="width: 255.8px; margin-right: 10px;"><div class="item">
                                <div class="gen-image-main">
                                    <img src="http://gentechtree.com/themes/streamlab/intro/images/clients-img-1.png" alt="streamlab-image">
                                </div>
                            </div></div><div class="owl-item cloned active" style="width: 255.8px; margin-right: 10px;"><div class="item">
                                <div class="gen-image-main">
                                    <img src="http://gentechtree.com/themes/streamlab/intro/images/clients-img-2.png" alt="streamlab-image">
                                </div>
                            </div></div><div class="owl-item cloned" style="width: 255.8px; margin-right: 10px;"><div class="item">
                                <div class="gen-image-main">
                                    <img src="http://gentechtree.com/themes/streamlab/intro/images/clients-img-3.png" alt="streamlab-image">
                                </div>
                            </div></div><div class="owl-item cloned" style="width: 255.8px; margin-right: 10px;"><div class="item">
                                <div class="gen-image-main">
                                    <img src="http://gentechtree.com/themes/streamlab/intro/images/clients-img-4.png" alt="streamlab-image">
                                </div>
                            </div></div><div class="owl-item cloned" style="width: 255.8px; margin-right: 10px;"><div class="item">
                                <div class="gen-image-main">
                                    <img src="http://gentechtree.com/themes/streamlab/intro/images/clients-img-6.png" alt="streamlab-image">
                                </div>
                            </div></div></div></div><div class="owl-nav disabled"><button type="button" role="presentation" class="owl-prev"><i class="ion-ios-arrow-back"></i></button><button type="button" role="presentation" class="owl-next"><i class="ion-ios-arrow-forward"></i></button></div><div class="owl-dots disabled"></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Slider -->

    <!-- Color Varient -->
    <section id="color-varient" class="gen-section-padding-2">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="gen-section-title-main text-center">
                        <h6 class="gen-section-heading">Modern Built-In Color Demos</h6>
                        <h1 class="gen-section-heading-2">Color Variant</h1>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-md-6">
                    <div class="gen-image-box text-center">
                        <div class="gen-image-box-img">
                            <a href="http://gentechtree.com/themes/streamlab/red-html/index.html" target="_blank"><img src="images/asset-5.jpg" alt="streamlab-image"></a>
                        </div>
                        <div class="gen-image-box-content">
                            <h5 class="gen-image-box-title"><a href="http://gentechtree.com/themes/streamlab/red-html/index.html" target="_blank">Red Demo</a></h5>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 mt-5 mt-md-0">
                    <div class="gen-image-box text-center">
                        <div class="gen-image-box-img">
                            <a href="http://gentechtree.com/themes/streamlab/html" target="_blank"><img src="images/asset-6.jpg" alt="streamlab-image"></a>
                        </div>
                        <div class="gen-image-box-content">
                            <h5 class="gen-image-box-title"><a href="http://gentechtree.com/themes/streamlab/html" target="_blank">Blue Demo</a></h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- color-varient -->

    <!-- Home Pages -->
    <section id="layouts" class="gen-section-padding-2 gen-bg-black">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="gen-section-title-main text-center">
                        <h6 class="gen-section-heading">Modern Built-In Homepages</h6>
                        <h1 class="gen-section-heading-2">Awesome 3+ Home Pages</h1>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-xl-4 col-md-6">
                    <div class="gen-image-box text-center">
                        <div class="gen-image-box-img">
                            <a href="http://gentechtree.com/themes/streamlab/red-html/index.html" target="_blank"><img src="images/asset-1.jpg" alt="streamlab-image"></a>
                        </div>
                        <div class="gen-image-box-content">
                            <h5 class="gen-image-box-title"><a href="http://gentechtree.com/themes/streamlab/red-html/index.html" target="_blank">Main Home</a></h5>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6 mt-5 mt-md-0">
                    <div class="gen-image-box text-center">
                        <div class="gen-image-box-img">
                            <a href="http://gentechtree.com/themes/streamlab/red-html/movies-home.html" target="_blank"><img src="images/asset-2.jpg" alt="streamlab-image"></a>
                        </div>
                        <div class="gen-image-box-content">
                            <h5 class="gen-image-box-title"><a href="http://gentechtree.com/themes/streamlab/red-html/movies-home.html" target="_blank">Movies Home</a></h5>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6 mt-5 mt-xl-0">
                    <div class="gen-image-box text-center">
                        <div class="gen-image-box-img">
                            <a href="http://gentechtree.com/themes/streamlab/red-html/tv-shows-home.html" target="_blank"><img src="images/asset-3.jpg" alt="streamlab-image"></a>
                        </div>
                        <div class="gen-image-box-content">
                            <h5 class="gen-image-box-title"><a href="http://gentechtree.com/themes/streamlab/red-html/tv-shows-home.html" target="_blank">TV Shows Home</a></h5>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-xl-4 col-md-6">
                    <div class="gen-image-box text-center">
                        <div class="gen-image-box-img">
                            <a href="http://gentechtree.com/themes/streamlab/red-html/video-home.html" target="_blank"><img src="images/asset-4.jpg" alt="streamlab-image"></a>
                        </div>
                        <div class="gen-image-box-content">
                            <h5 class="gen-image-box-title"><a href="http://gentechtree.com/themes/streamlab/red-html/video-home.html" target="_blank">Video Home</a></h5>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6 mt-5 mt-md-0">
                    <div class="gen-image-box text-center">
                        <div class="gen-image-box-img">
                            <a href="#"><img src="images/coming-soon.png" alt="streamlab-image"></a>
                        </div>
                        <div class="gen-image-box-content">
                            <h5 class="gen-image-box-title"><a href="#">News Home</a></h5>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6 mt-5 mt-xl-0">
                    <div class="gen-image-box text-center">
                        <div class="gen-image-box-img">
                            <a href="#"><img src="images/coming-soon.png" alt="streamlab-image"></a>
                        </div>
                        <div class="gen-image-box-content">
                            <h5 class="gen-image-box-title"><a href="#">Web Shows Home</a></h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Home Pages -->

    <!-- Icon Box -->
    <section class="gen-section-padding-2 pt-0 pb-0 gen-bg-primary">
        <div class="container-fluid p-0">
            <div class="row no-gutters">
                <div class="col-xl-3 col-md-6">
                    <div class="gen-icon-box">
                        <div class="gen-icon-box-media">
                            <i aria-hidden="true" class="ion ion-ios-telephone-outline"></i>
                        </div>
                        <div class="gen-icon-box-content">
                            <h4 class="gen-icon-box-title">
                                <span>Customer Support</span>
                            </h4>
                            <p class="gen-icon-box-description text-white">Our five star Customer support help you solve
                                problems</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="gen-icon-box">
                        <div class="gen-icon-box-media">
                            <i aria-hidden="true" class="ion ion-ios-cloud-download-outline"></i>
                        </div>
                        <div class="gen-icon-box-content">
                            <h4 class="gen-icon-box-title">
                                <span>Regular Update</span>
                            </h4>
                            <p class="gen-icon-box-description text-white">Free Lifetime Updates That Contain Template
                                Improvement</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="gen-icon-box">
                        <div class="gen-icon-box-media">
                            <i aria-hidden="true" class="ion ion-ios-paper-outline"></i>
                        </div>
                        <div class="gen-icon-box-content">
                            <h4 class="gen-icon-box-title">
                                <span>Well Documented</span>
                            </h4>
                            <p class="gen-icon-box-description text-white">We created for you useful documentation for
                                easy work.</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6">
                    <div class="gen-icon-box border-0">
                        <div class="gen-icon-box-media">
                            <i aria-hidden="true" class="ion ion-ios-gear-outline"></i>
                        </div>
                        <div class="gen-icon-box-content">
                            <h4 class="gen-icon-box-title">
                                <span>The Perfect Template</span>
                            </h4>
                            <p class="gen-icon-box-description text-white">Clean Layouts with Standard valid code and a
                                more powerful control panel.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Icon Box -->

    <!-- Inner Page -->
<!--     <section id="pages" class="gen-section-padding-2 gen-bg-dark position-relative">
        <div class="gen-bg-overley gen-opacity-1" style="background: url('images/asset-54.jpg');"></div>
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="gen-section-title-main text-center">
                        <h6 class="gen-section-heading">Creative Inner Pages</h6>
                        <h1 class="gen-section-heading-2">Awesome Inner Pages</h1>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-xl-4 col-md-6">
                    <div class="gen-image-box text-center">
                        <div class="gen-image-box-img">
                            <a href="http://gentechtree.com/themes/streamlab/red-html/log-in.html" target="_blank"><img src="images/asset-7.jpg" alt="streamlab-image"></a>
                        </div>
                        <div class="gen-image-box-content">
                            <h3 class="gen-image-box-title"><a href="http://gentechtree.com/themes/streamlab/red-html/log-in.html" target="_blank">Login</a></h3>
                            <p class="gen-image-box-description">Users, on login, are provided with a list of videos
                                that matches their subscription level.</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6 mt-5 mt-md-0">
                    <div class="gen-image-box text-center">
                        <div class="gen-image-box-img">
                            <a href="http://gentechtree.com/themes/streamlab/red-html/register.html" target="_blank"><img src="images/asset-8.jpg" alt="streamlab-image"></a>
                        </div>
                        <div class="gen-image-box-content">
                            <h3 class="gen-image-box-title"><a href="http://gentechtree.com/themes/streamlab/red-html/register.html" target="_blank">register</a></h3>
                            <p class="gen-image-box-description">Users, on register provided with some free resources
                                and some extended features.</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6 mt-5 mt-xl-0">
                    <div class="gen-image-box text-center">
                        <div class="gen-image-box-img">
                            <a href="http://gentechtree.com/themes/streamlab/red-html/recover-password.html" target="_blank"><img src="images/asset-9.jpg" alt="streamlab-image"></a>
                        </div>
                        <div class="gen-image-box-content">
                            <h3 class="gen-image-box-title"><a href="http://gentechtree.com/themes/streamlab/red-html/recover-password.html" target="_blank">Recover Password</a></h3>
                            <p class="gen-image-box-description">Users, On recover password can get account password.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-xl-4 col-md-6">
                    <div class="gen-image-box text-center">
                        <div class="gen-image-box-img">
                            <a href="http://gentechtree.com/themes/streamlab/red-html/pricing-style-2.html" target="_blank"><img src="images/asset-10.jpg" alt="streamlab-image"></a>
                        </div>
                        <div class="gen-image-box-content">
                            <h3 class="gen-image-box-title"><a href="http://gentechtree.com/themes/streamlab/red-html/pricing-style-2.html" target="_blank">Pricing Page</a></h3>
                            <p class="gen-image-box-description">Users on pricing page can choose subscription according
                                his/her requirement</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6 mt-5 mt-md-0">
                    <div class="gen-image-box text-center">
                        <div class="gen-image-box-img">
                            <a href="http://gentechtree.com/themes/streamlab/red-html/pricing-style-1.html" target="_blank"><img src="images/asset-11.jpg" alt="streamlab-image"></a>
                        </div>
                        <div class="gen-image-box-content">
                            <h3 class="gen-image-box-title"><a href="http://gentechtree.com/themes/streamlab/red-html/pricing-style-1.html" target="_blank">Pricing Page 2</a></h3>
                            <p class="gen-image-box-description">Users on pricing page can choose subscription according
                                his/her requirement</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6 mt-5 mt-xl-0">
                    <div class="gen-image-box text-center">
                        <div class="gen-image-box-img">
                            <a href="http://gentechtree.com/themes/streamlab/red-html/contact-us.html" target="_blank"><img src="images/asset-12.jpg" alt="streamlab-image"></a>
                        </div>
                        <div class="gen-image-box-content">
                            <h3 class="gen-image-box-title"><a href="http://gentechtree.com/themes/streamlab/red-html/contact-us.html" target="_blank">Contact Us</a></h3>
                            <p class="gen-image-box-description">Users , on contact page can directly engage with site
                                owners.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- Inner Page -->

    <!-- features -->
<!--     <section class="gen-section-padding-2">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="gen-section-title-main text-center">
                        <h6 class="gen-section-heading">Quick Getting Started</h6>
                        <h1 class="gen-section-heading-2">Some Breathtaking Features</h1>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-xl-4 col-md-6">
                    <div class="gen-icon-box-style-2 text-center">
                        <div class="gen-icon-box-icon">
                            <i class="far fa-user" aria-hidden="true"></i>
                        </div>
                        <div class="gen-icon-box-content">
                            <h5 class="gen-icon-box-title">Membership Platform With Subscriptions</h5>
                            <p class="gen-icon-box-description">Restricts the content that are only available if user
                                match required criteria.</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6 mt-5 mt-md-0">
                    <div class="gen-icon-box-style-2 text-center">
                        <div class="gen-icon-box-icon">
                            <i class="fas fa-images" aria-hidden="true"></i>
                        </div>
                        <div class="gen-icon-box-content">
                            <h5 class="gen-icon-box-title">6+ Banner style in Movies , Tv show ,videos</h5>
                            <p class="gen-icon-box-description">Six plus eye catching banner style that increase site
                                visuality.</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-12 mt-5 mt-xl-0">
                    <div class="gen-icon-box-style-2 text-center">
                        <div class="gen-icon-box-icon">
                            <i class="fas fa-video" aria-hidden="true"></i>
                        </div>
                        <div class="gen-icon-box-content">
                            <h5 class="gen-icon-box-title">3+ video Preview Thumbnails Style </h5>
                            <p class="gen-icon-box-description">Three plus video box styles that is you can choos for
                                your site. Or you can use multiple.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-xl-4 col-md-6">
                    <div class="gen-icon-box-style-2 text-center">
                        <div class="gen-icon-box-icon">
                            <i class="fas fa-exchange-alt" aria-hidden="true"></i>
                        </div>
                        <div class="gen-icon-box-content">
                            <h5 class="gen-icon-box-title">Pagination</h5>
                            <p class="gen-icon-box-description">Allows your user to page back and forth through multiple
                                pages of content.</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6 mt-5 mt-md-0">
                    <div class="gen-icon-box-style-2 text-center">
                        <div class="gen-icon-box-icon">
                            <i class="fas fa-arrow-circle-down" aria-hidden="true"></i>
                        </div>
                        <div class="gen-icon-box-content">
                            <h5 class="gen-icon-box-title">Loadmore</h5>
                            <p class="gen-icon-box-description">Allows your user to load all videos on a single page
                                without leaving the page.</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-12 mt-5 mt-xl-0">
                    <div class="gen-icon-box-style-2 text-center">
                        <div class="gen-icon-box-icon">
                            <i class="fas fa-spinner" aria-hidden="true"></i>
                        </div>
                        <div class="gen-icon-box-content">
                            <h5 class="gen-icon-box-title">Infinity Scroll</h5>
                            <p class="gen-icon-box-description">Allows user to load all video on sinlge page by
                                infinitely scroll till last video.</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-xl-4 col-md-6">
                    <div class="gen-icon-box-style-2 text-center">
                        <div class="gen-icon-box-icon">
                            <i class="fas fa-play-circle" aria-hidden="true"></i>
                        </div>
                        <div class="gen-icon-box-content">
                            <h5 class="gen-icon-box-title">Movie Playlists</h5>
                            <p class="gen-icon-box-description">Allow Your user to create his personal movie playlists.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6 mt-5 mt-md-0">
                    <div class="gen-icon-box-style-2 text-center">
                        <div class="gen-icon-box-icon">
                            <i class="fas fa-play-circle" aria-hidden="true"></i>
                        </div>
                        <div class="gen-icon-box-content">
                            <h5 class="gen-icon-box-title">Tv show Playlists</h5>
                            <p class="gen-icon-box-description">Allow Your user to create his personal movie playlists.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-12 mt-5 mt-xl-0">
                    <div class="gen-icon-box-style-2 text-center">
                        <div class="gen-icon-box-icon">
                            <i class="far fa-play-circle" aria-hidden="true"></i>
                        </div>
                        <div class="gen-icon-box-content">
                            <h5 class="gen-icon-box-title">Video Playlist</h5>
                            <p class="gen-icon-box-description">Allow Your user to create his personal video playlist.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-xl-4 col-md-6">
                    <div class="gen-icon-box-style-2 text-center">
                        <div class="gen-icon-box-icon">
                            <i class="fas fa-video" aria-hidden="true"></i>
                        </div>
                        <div class="gen-icon-box-content">
                            <h5 class="gen-icon-box-title">Videos </h5>
                            <p class="gen-icon-box-description">Allow your user see his uploaded videos where he/she can
                                manage own uploaded videos.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6 mt-5 mt-md-0">
                    <div class="gen-icon-box-style-2 text-center">
                        <div class="gen-icon-box-icon">
                            <i class="fas fa-user-edit" aria-hidden="true"></i>
                        </div>
                        <div class="gen-icon-box-content">
                            <h5 class="gen-icon-box-title">Account Details</h5>
                            <p class="gen-icon-box-description">Allow your users to manage his account where he/she can
                                change password other personal information.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-12 mt-5 mt-xl-0">
                    <div class="gen-icon-box-style-2 text-center">
                        <div class="gen-icon-box-icon">
                            <i class="far fa-times-circle" aria-hidden="true"></i>
                        </div>
                        <div class="gen-icon-box-content">
                            <h5 class="gen-icon-box-title">Abandon subscription</h5>
                            <p class="gen-icon-box-description">Allow Your user to abandoned his subscription plan
                                anytime with ease.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    <!-- features -->

    <!-- Responsive Section -->
    <section class="gen-section-padding-2 gen-bg-black">
        <div class="container">
            <div class="row">
                <div class="col-xl-6 col-md-12 d-flex align-items-center">
                    <div class="gen-section-title-main text-xl-left text-center pr-xl-5">
                        <h6 class="gen-section-heading">Themes Responsiveness.</h6>
                        <h1 class="gen-section-heading-2 mb-4">Fully Responsive and Retina Ready.</h1>
                        <p class="gen-sectin-desription">Get an optional viewing experience across all major devices
                            like desktop and mobile. streamlab is fully responsive and the images, videos, text will
                            scale down for the smaller devices.</p>
                    </div>
                </div>
                <div class="col-xl-6 col-md-12">
                    <div class="gen-image-main">
                        <img class="img-fluid" src="images/Responsive-1.png" alt="streamlab-img">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Responsive Section -->

    <!-- Blog -->
    <section class="gen-section-padding-2 gen-blog">
        <div class="container">
            <div class="row">
                <div class="col-xl-6 col-md-12 d-flex align-items-center">
                    <div class="gen-section-title-main">
                        <h1 class="gen-section-heading-2 mb-4">All a Modern Blog Can Ever Need.</h1>
                        <p>StreamLab includes a terrific collection of customizable blog templates. allowing you to keep
                            your audience up to date with your latest projects and ideas.About Blog Explore StreamLab
                            series, TV shows, and movie reviews online. Check release date, trailers, and star cast name
                            on Pakaoo.</p>
                        <div class="gen-btn-container">
                            <a href="http://gentechtree.com/themes/streamlab/red-html/blog-left-sidebar.html" target="_blank" class="gen-button">
                                <div class="gen-button-block">
                                    <span class="gen-button-line-left"></span>
                                    <span class="gen-button-text">Read More</span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6 col-md-12 mt-5 mt-xl-0">
                    <div class="gen-image-main">
                        <img src="images/blog-img-2.jpg" class="gen-blog-1" alt="streamlab-image">
                        <img src="images/blog-img-3.jpg" class="gen-blog-2" alt="streamlab-image">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Blog -->

    <!-- Support -->
    <section class="gen-section-padding-3 gen-bg-primary">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="text-center">
                        <h1 class="gen-singal-title">24/7 Effective And Friendly Premium Support</h1>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Support -->

    <!-- Core Feature -->
    <section id="features" class="gen-section-padding-2">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="gen-section-title-main text-center">
                        <h6 class="gen-section-heading">Quick Getting Started</h6>
                        <h1 class="gen-section-heading-2">Our Core Feature</h1>
                    </div>
                </div>
            </div>
            <div class="row mt-5">
                <div class="col-xl-2 col-md-6">
                    <div class="gen-icon-box-style-3">
                        <div class="gen-icon-box-media">
                            <img src="images/1.png" alt="streamlab-img">
                        </div>
                        <div class="gen-icon-box-content">
                            <h6 class="gen-icon-box-title">Translation Ready</h6>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-md-6 mt-4 mt-md-0">
                    <div class="gen-icon-box-style-3">
                        <div class="gen-icon-box-media">
                            <img src="images/W3c_landing.png" alt="streamlab-img">
                        </div>
                        <div class="gen-icon-box-content">
                            <h6 class="gen-icon-box-title">W3C Validation</h6>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-md-6 mt-4 mt-xl-0">
                    <div class="gen-icon-box-style-3">
                        <div class="gen-icon-box-media">
                            <img src="images/3.png" alt="streamlab-img">
                        </div>
                        <div class="gen-icon-box-content">
                            <h6 class="gen-icon-box-title">Unlimited Color</h6>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-md-6 mt-4 mt-xl-0">
                    <div class="gen-icon-box-style-3">
                        <div class="gen-icon-box-media">
                            <img src="images/4.png" alt="streamlab-img">
                        </div>
                        <div class="gen-icon-box-content">
                            <h6 class="gen-icon-box-title">Quick View</h6>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-md-6 mt-4 mt-xl-0">
                    <div class="gen-icon-box-style-3">
                        <div class="gen-icon-box-media">
                            <img src="images/5.png" alt="streamlab-img">
                        </div>
                        <div class="gen-icon-box-content">
                            <h6 class="gen-icon-box-title">Bootstrap V4</h6>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-md-6 mt-4 mt-xl-0">
                    <div class="gen-icon-box-style-3">
                        <div class="gen-icon-box-media">
                            <img src="images/6.png" alt="streamlab-img">
                        </div>
                        <div class="gen-icon-box-content">
                            <h6 class="gen-icon-box-title">Flat Icon</h6>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-xl-2 col-md-6">
                    <div class="gen-icon-box-style-3">
                        <div class="gen-icon-box-media">
                            <img src="images/7.png" alt="streamlab-img">
                        </div>
                        <div class="gen-icon-box-content">
                            <h6 class="gen-icon-box-title">Fontawesome Icon</h6>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-md-6 mt-4 mt-md-0">
                    <div class="gen-icon-box-style-3">
                        <div class="gen-icon-box-media">
                            <img src="images/8.png" alt="streamlab-img">
                        </div>
                        <div class="gen-icon-box-content">
                            <h6 class="gen-icon-box-title">Revolution Slider</h6>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-md-6 mt-4 mt-xl-0">
                    <div class="gen-icon-box-style-3">
                        <div class="gen-icon-box-media">
                            <img src="images/c7_landing.png" alt="streamlab-img">
                        </div>
                        <div class="gen-icon-box-content">
                            <h6 class="gen-icon-box-title">Contect Form</h6>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-md-6 mt-4 mt-xl-0">
                    <div class="gen-icon-box-style-3">
                        <div class="gen-icon-box-media">
                            <img src="images/10.png" alt="streamlab-img">
                        </div>
                        <div class="gen-icon-box-content">
                            <h6 class="gen-icon-box-title">Fully Responsive</h6>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-md-6 mt-4 mt-xl-0">
                    <div class="gen-icon-box-style-3">
                        <div class="gen-icon-box-media">
                            <img src="images/11.png" alt="streamlab-img">
                        </div>
                        <div class="gen-icon-box-content">
                            <h6 class="gen-icon-box-title">Google Font</h6>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-md-6 mt-4 mt-xl-0">
                    <div class="gen-icon-box-style-3">
                        <div class="gen-icon-box-media">
                            <img src="images/12.png" alt="streamlab-img">
                        </div>
                        <div class="gen-icon-box-content">
                            <h6 class="gen-icon-box-title">Speed Optimized</h6>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-4">
                <div class="col-xl-2 col-md-6">
                    <div class="gen-icon-box-style-3">
                        <div class="gen-icon-box-media">
                            <img src="images/13.png" alt="streamlab-img">
                        </div>
                        <div class="gen-icon-box-content">
                            <h6 class="gen-icon-box-title">Well Documented</h6>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-md-6 mt-4 mt-md-0">
                    <div class="gen-icon-box-style-3">
                        <div class="gen-icon-box-media">
                            <img src="images/14.png" alt="streamlab-img">
                        </div>
                        <div class="gen-icon-box-content">
                            <h6 class="gen-icon-box-title">Free Update</h6>
                        </div>
                    </div>
                </div>
                <div class="col-xl-2 col-md-6 mt-4 mt-xl-0">
                    <div class="gen-icon-box-style-3">
                        <div class="gen-icon-box-media">
                            <img src="images/15.png" alt="streamlab-img">
                        </div>
                        <div class="gen-icon-box-content">
                            <h6 class="gen-icon-box-title">24/7 Support</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Core Feature -->

    <!-- Purchase -->
    <section id="purchase" class="gen-purchase gen-bg-primary position-relative">
        <div class="gen-bg-overley gen-opacity-1" style="background: url('images/asset-54.jpg');"></div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="gen-section-title-main text-center">
                        <h6 class="gen-section-heading">Get All The Demo Templates, Features, And Lifetime Updates.</h6>
                        <h1 class="gen-section-heading-2">Get Streamlab And Set Up Your Website Today.</h1>
                    </div>
                    <div class="gen-btn-container text-center">
                        <a class="gen-button" href="https://themeforest.net/item/streamlab-video-streaming-html5-template/31440830" target="_blank">
                            <i aria-hidden="true" class="fas fa-shopping-cart"></i><span class="text">Purchase
                                Now</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Purchase -->

    <!-- Back-to-Top start -->
    <div id="back-to-top" style="">
        <a class="top" id="top" href="#top"> <i class="ion-ios-arrow-up"></i> </a>
    </div>
    <!-- Back-to-Top end -->

    <!-- js-min -->
   <script src="js/jquery-3.5.1.min.js"></script>
   <script src="js/asyncloader.min.js"></script>
   <!-- JS bootstrap -->
   <script src="js/bootstrap.min.js"></script>
   <!-- owl-carousel -->
   <script src="js/owl.carousel.min.js"></script>
   <!-- counter-js -->
   <script src="js/jquery.waypoints.min.js"></script>
   <script src="js/jquery.counterup.min.js"></script>
   <!-- popper-js -->
   <script src="js/popper.min.js"></script>
   <script src="js/swiper-bundle.min.js"></script>
   <!-- Iscotop -->
   <script src="js/isotope.pkgd.min.js"></script>

   <script src="js/slick.min.js"></script>

   <!-- rev-slider -->
   <script src="rev-slider/js/rbtools.min.js"></script>
   <script src="rev-slider/js/rs6.min.js"></script>

   <!-- rev-custom -->
   <script src="js/rev-custom.js"></script>

   <script src="js/streamlab-core.js"></script>

   <script src="js/script.js"></script>

   <script src="js/rev-custom.js"></script>




</body></html>