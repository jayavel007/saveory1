   <style >
       video {
    width: 100%;
    height: 445px;
}
figure {
    position: relative;
    max-width: 1024px;
    max-width: 64rem;
    width: 100%;
    height: 100%;
    max-height: 494px;
    max-height: 30.875rem;
    margin: 20px auto;
    margin: 1.25rem auto;
    padding: 20px;
    padding: 1.051%;
    background-color: inherit !important;
}
  /* figure[data-fullscreen=true] video {
     height: 100% !important;
}
figure[data-fullscreen=true] {
    max-width: 100%;
    width: 100%;
    margin: 0;
    padding: 0;
    max-height: 100%;
    background: #fff !important;
}*/
   </style>
    <!--========== Header ==============-->
<link rel="stylesheet" href="video_css/styles.css" />
    <!-- Single Video Start -->
    <section class="gen-section-padding-3 gen-single-video">
        <div class="container">
            <div class="row no-gutters">
                <div class="col-lg-12">
                    <div class="row">
             
    <?php
    if(!empty($movies_list)){
                          $i=1;
                        foreach($movies_list as $key=>$row){

                      ?> 

                                 <div class="col-lg-12">
                            <div class="gen-video-holder">
   
  

            <img src="<?php echo base_url(''); ?>admin/<?= $row->thumbnail; ?>"
                                                    alt="owl-carousel-video-image" style="width: 100%;    height: 530px;">
                      
<!-- <div id="video_demo">

         <video autoplay muted loop playsinline preload="metadata"  >
      <source src="<?= $row->thumbnail; ?>" type="video/mp4" >

  </video> -->


    <center class="flyout hidden">
  <a href="<?php echo base_url('Movies/single_movie_link'); ?>?video_id=<?= $row->video_id; ?>" style="position: absolute;
    margin-top: -30%;
    margin-left: -10%;" class="playBut">
         
    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="213.7px" height="213.7px" viewBox="0 0 213.7 213.7" enable-background="new 0 0 213.7 213.7" xml:space="preserve">
    <polygon class="triangle" id="XMLID_20_" fill="none" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="
                                                     73.5,62.5 148.5,105.8 73.5,149.1 "></polygon>
    <circle class="circle" id="XMLID_19_" fill="none" stroke-width="7" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" cx="106.8" cy="106.8" r="103.3"></circle>
                                                    </svg>
                                       
                                                </a>
                                            </center>
</div>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>
<script >
           $("#video_demo").hover(function() {
  $('.flyout').removeClass('hidden');
}, function() {
  $('.flyout').addClass('hidden');
});</script>


    <script src="video_js/video-player.js"></script>
        <script >
        $("#video")[0].autoplay = true;
    </script>
                            </div>
                        </div>

                       
                        <div class="col-lg-12">
                            <div class="single-video">
                                <div class="gen-single-video-info">
                                    <h2 class="gen-title"><?= $row->title; ?></h2>
                                    <div class="gen-single-meta-holder">
                                        <ul>
                                            <li>2 years</li>
                                            <li>
                                                <a href="#"><span>Tennis</span></a>
                                            </li>
                                            <li>
                                                <i class="fas fa-eye">
                                                </i>
                                                <span>225 Views</span>
                                            </li>
                                        </ul>
                                    </div>
                                    <p>Streamlab is a long established fact that a reader will be distracted by the
                                        readable
                                        content of a page when Streamlab at its layout. The point of using Lorem
                                        Streamlab
                                        is that it has a more-or-less normal distribution of Streamlab as opposed
                                        Streamlab.
                                    </p>
                                    <div class="gen-socail-share mt-0">
                                        <h4 class="align-self-center">Social Share :</h4>
                                        <ul class="social-inner">
                                            <li><a href="#" class="facebook"><i class="fab fa-facebook-f"></i></a></li>
                                            <li><a href="#" class="facebook"><i class="fab fa-instagram"></i></a></li>
                                            <li><a href="#" class="facebook"><i class="fab fa-twitter"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                             <?php $i++; } } ?> 
                        <div class="col-lg-12">
                            <div class="pm-inner">
                                <div class="gen-more-like">
                                    <h5 class="gen-more-title">More Like This</h5>
                                    <div class="row post-loadmore-wrapper">
                                        <div class="col-xl-3 col-lg-4 col-md-6">
                                            <div class="gen-carousel-movies-style-3 movie-grid style-3">
                                                <div class="gen-movie-contain">
                                                    <div class="gen-movie-img">
                                                        <img src="images/background/asset-41.jpg"
                                                            alt="single-video-image">
                                                        <div class="gen-movie-add">
                                                            <div class="wpulike wpulike-heart">
                                                                <div class="wp_ulike_general_class">
                                                                    <a href="#" class="sl-button text-white"><i
                                                                            class="far fa-heart"></i></a>
                                                                </div>
                                                            </div>
                                                            <ul class="menu bottomRight">
                                                                <li class="share top">
                                                                    <i class="fa fa-share-alt"></i>
                                                                    <ul class="submenu">
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-facebook-f"></i></a>
                                                                        </li>
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-instagram"></i></a>
                                                                        </li>
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-twitter"></i></a></li>
                                                                    </ul>
                                                                </li>
                                                            </ul>
                                                            <div class="video-actions--link_add-to-playlist dropdown">
                                                                <a class="dropdown-toggle" href="#"
                                                                    data-toggle="dropdown"><i
                                                                        class="fa fa-plus"></i></a>
                                                                <div class="dropdown-menu">
                                                                    <a class="login-link" href="#">Sign in to add
                                                                        this video to a playlist.</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="gen-movie-action">
                                                            <a href="#" class="gen-button">
                                                                <i class="fa fa-play"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div class="gen-info-contain">
                                                        <div class="gen-movie-info">
                                                            <h3><a href="#">sefozie world</a></h3>
                                                        </div>
                                                        <div class="gen-movie-meta-holder">
                                                            <ul>
                                                                <li>2 weeks</li>
                                                                <li>
                                                                    <a href="#"><span>Adventure</span></a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-lg-4 col-md-6">
                                            <div class="gen-carousel-movies-style-3 movie-grid style-3">
                                                <div class="gen-movie-contain">
                                                    <div class="gen-movie-img">
                                                        <img src="images/background/asset-36.jpg"
                                                            alt="single-video-image">
                                                        <div class="gen-movie-add">
                                                            <div class="wpulike wpulike-heart">
                                                                <div class="wp_ulike_general_class">
                                                                    <a href="#" class="sl-button text-white"><i
                                                                            class="far fa-heart"></i></a>
                                                                </div>
                                                            </div>
                                                            <ul class="menu bottomRight">
                                                                <li class="share top">
                                                                    <i class="fa fa-share-alt"></i>
                                                                    <ul class="submenu">
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-facebook-f"></i></a>
                                                                        </li>
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-instagram"></i></a>
                                                                        </li>
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-twitter"></i></a></li>
                                                                    </ul>
                                                                </li>
                                                            </ul>
                                                            <div class="video-actions--link_add-to-playlist dropdown">
                                                                <a class="dropdown-toggle" href="#"
                                                                    data-toggle="dropdown"><i
                                                                        class="fa fa-plus"></i></a>
                                                                <div class="dropdown-menu">
                                                                    <a class="login-link" href="#">Sign in to add
                                                                        this video to a playlist.</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="gen-movie-action">
                                                            <a href="#" class="gen-button">
                                                                <i class="fa fa-play"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div class="gen-info-contain">
                                                        <div class="gen-movie-info">
                                                            <h3><a href="#">War Hands</a></h3>
                                                        </div>
                                                        <div class="gen-movie-meta-holder">
                                                            <ul>
                                                                <li>2 weeks</li>
                                                                <li>
                                                                    <a href="#"><span>Animation</span></a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-lg-4 col-md-6">
                                            <div class="gen-carousel-movies-style-3 movie-grid style-3">
                                                <div class="gen-movie-contain">
                                                    <div class="gen-movie-img">
                                                        <img src="images/background/asset-38.jpg"
                                                            alt="single-video-image">
                                                        <div class="gen-movie-add">
                                                            <div class="wpulike wpulike-heart">
                                                                <div class="wp_ulike_general_class">
                                                                    <a href="#" class="sl-button text-white"><i
                                                                            class="far fa-heart"></i></a>
                                                                </div>
                                                            </div>
                                                            <ul class="menu bottomRight">
                                                                <li class="share top">
                                                                    <i class="fa fa-share-alt"></i>
                                                                    <ul class="submenu">
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-facebook-f"></i></a>
                                                                        </li>
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-instagram"></i></a>
                                                                        </li>
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-twitter"></i></a></li>
                                                                    </ul>
                                                                </li>
                                                            </ul>
                                                            <div class="video-actions--link_add-to-playlist dropdown">
                                                                <a class="dropdown-toggle" href="#"
                                                                    data-toggle="dropdown"><i
                                                                        class="fa fa-plus"></i></a>
                                                                <div class="dropdown-menu">
                                                                    <a class="login-link" href="#">Sign in to add
                                                                        this video to a playlist.</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="gen-movie-action">
                                                            <a href="#" class="gen-button">
                                                                <i class="fa fa-play"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div class="gen-info-contain">
                                                        <div class="gen-movie-info">
                                                            <h3><a href="#">MGX-Fighter</a></h3>
                                                        </div>
                                                        <div class="gen-movie-meta-holder">
                                                            <ul>
                                                                <li>2 weeks</li>
                                                                <li>
                                                                    <a href="#"><span>Adventure</span></a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-lg-4 col-md-6">
                                            <div class="gen-carousel-movies-style-3 movie-grid style-3">
                                                <div class="gen-movie-contain">
                                                    <div class="gen-movie-img">
                                                        <img src="images/background/asset-43.jpg"
                                                            alt="single-video-image">
                                                        <div class="gen-movie-add">
                                                            <div class="wpulike wpulike-heart">
                                                                <div class="wp_ulike_general_class">
                                                                    <a href="#" class="sl-button text-white"><i
                                                                            class="far fa-heart"></i></a>
                                                                </div>
                                                            </div>
                                                            <ul class="menu bottomRight">
                                                                <li class="share top">
                                                                    <i class="fa fa-share-alt"></i>
                                                                    <ul class="submenu">
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-facebook-f"></i></a>
                                                                        </li>
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-instagram"></i></a>
                                                                        </li>
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-twitter"></i></a></li>
                                                                    </ul>
                                                                </li>
                                                            </ul>
                                                            <div class="video-actions--link_add-to-playlist dropdown">
                                                                <a class="dropdown-toggle" href="#"
                                                                    data-toggle="dropdown"><i
                                                                        class="fa fa-plus"></i></a>
                                                                <div class="dropdown-menu">
                                                                    <a class="login-link" href="#">Sign in to add
                                                                        this video to a playlist.</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="gen-movie-action">
                                                            <a href="#" class="gen-button">
                                                                <i class="fa fa-play"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div class="gen-info-contain">
                                                        <div class="gen-movie-info">
                                                            <h3><a href="#">Voho The Skull Land</a></h3>
                                                        </div>
                                                        <div class="gen-movie-meta-holder">
                                                            <ul>
                                                                <li>2 weeks</li>
                                                                <li>
                                                                    <a href="#"><span>Horror</span></a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-lg-4 col-md-6">
                                            <div class="gen-carousel-movies-style-3 movie-grid style-3">
                                                <div class="gen-movie-contain">
                                                    <div class="gen-movie-img">
                                                        <img src="images/background/asset-37.jpeg"
                                                            alt="single-video-image">
                                                        <div class="gen-movie-add">
                                                            <div class="wpulike wpulike-heart">
                                                                <div class="wp_ulike_general_class">
                                                                    <a href="#" class="sl-button text-white"><i
                                                                            class="far fa-heart"></i></a>
                                                                </div>
                                                            </div>
                                                            <ul class="menu bottomRight">
                                                                <li class="share top">
                                                                    <i class="fa fa-share-alt"></i>
                                                                    <ul class="submenu">
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-facebook-f"></i></a>
                                                                        </li>
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-instagram"></i></a>
                                                                        </li>
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-twitter"></i></a></li>
                                                                    </ul>
                                                                </li>
                                                            </ul>
                                                            <div class="video-actions--link_add-to-playlist dropdown">
                                                                <a class="dropdown-toggle" href="#"
                                                                    data-toggle="dropdown"><i
                                                                        class="fa fa-plus"></i></a>
                                                                <div class="dropdown-menu">
                                                                    <a class="login-link" href="#">Sign in to add
                                                                        this video to a playlist.</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="gen-movie-action">
                                                            <a href="#" class="gen-button">
                                                                <i class="fa fa-play"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div class="gen-info-contain">
                                                        <div class="gen-movie-info">
                                                            <h3><a href="#">Bigfoot Silva</a></h3>
                                                        </div>
                                                        <div class="gen-movie-meta-holder">
                                                            <ul>
                                                                <li>2 weeks</li>
                                                                <li>
                                                                    <a href="#"><span>Action</span></a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-lg-4 col-md-6">
                                            <div class="gen-carousel-movies-style-3 movie-grid style-3">
                                                <div class="gen-movie-contain">
                                                    <div class="gen-movie-img">
                                                        <img src="images/background/asset-35.jpg"
                                                            alt="single-video-image">
                                                        <div class="gen-movie-add">
                                                            <div class="wpulike wpulike-heart">
                                                                <div class="wp_ulike_general_class">
                                                                    <a href="#" class="sl-button text-white"><i
                                                                            class="far fa-heart"></i></a>
                                                                </div>
                                                            </div>
                                                            <ul class="menu bottomRight">
                                                                <li class="share top">
                                                                    <i class="fa fa-share-alt"></i>
                                                                    <ul class="submenu">
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-facebook-f"></i></a>
                                                                        </li>
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-instagram"></i></a>
                                                                        </li>
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-twitter"></i></a></li>
                                                                    </ul>
                                                                </li>
                                                            </ul>
                                                            <div class="video-actions--link_add-to-playlist dropdown">
                                                                <a class="dropdown-toggle" href="#"
                                                                    data-toggle="dropdown"><i
                                                                        class="fa fa-plus"></i></a>
                                                                <div class="dropdown-menu">
                                                                    <a class="login-link" href="#">Sign in to add
                                                                        this video to a playlist.</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="gen-movie-action">
                                                            <a href="#" class="gen-button">
                                                                <i class="fa fa-play"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div class="gen-info-contain">
                                                        <div class="gen-movie-info">
                                                            <h3><a href="#">Robot War</a></h3>
                                                        </div>
                                                        <div class="gen-movie-meta-holder">
                                                            <ul>
                                                                <li>2 weeks</li>
                                                                <li>
                                                                    <a href="#"><span>Tennis</span></a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-lg-4 col-md-6">
                                            <div class="gen-carousel-movies-style-3 movie-grid style-3">
                                                <div class="gen-movie-contain">
                                                    <div class="gen-movie-img">
                                                        <img src="images/background/asset-2.jpg"
                                                            alt="single-video-image">
                                                        <div class="gen-movie-add">
                                                            <div class="wpulike wpulike-heart">
                                                                <div class="wp_ulike_general_class">
                                                                    <a href="#" class="sl-button text-white"><i
                                                                            class="far fa-heart"></i></a>
                                                                </div>
                                                            </div>
                                                            <ul class="menu bottomRight">
                                                                <li class="share top">
                                                                    <i class="fa fa-share-alt"></i>
                                                                    <ul class="submenu">
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-facebook-f"></i></a>
                                                                        </li>
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-instagram"></i></a>
                                                                        </li>
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-twitter"></i></a></li>
                                                                    </ul>
                                                                </li>
                                                            </ul>
                                                            <div class="video-actions--link_add-to-playlist dropdown">
                                                                <a class="dropdown-toggle" href="#"
                                                                    data-toggle="dropdown"><i
                                                                        class="fa fa-plus"></i></a>
                                                                <div class="dropdown-menu">
                                                                    <a class="login-link" href="#">Sign in to add
                                                                        this video to a playlist.</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="gen-movie-action">
                                                            <a href="#" class="gen-button">
                                                                <i class="fa fa-play"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div class="gen-info-contain">
                                                        <div class="gen-movie-info">
                                                            <h3><a href="#">Nature World</a></h3>
                                                        </div>
                                                        <div class="gen-movie-meta-holder">
                                                            <ul>
                                                                <li>2 weeks</li>
                                                                <li>
                                                                    <a href="#"><span>Traveling</span></a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-lg-4 col-md-6">
                                            <div class="gen-carousel-movies-style-3 movie-grid style-3">
                                                <div class="gen-movie-contain">
                                                    <div class="gen-movie-img">
                                                        <img src="images/background/asset-39.jpg"
                                                            alt="single-video-image">
                                                        <div class="gen-movie-add">
                                                            <div class="wpulike wpulike-heart">
                                                                <div class="wp_ulike_general_class">
                                                                    <a href="#" class="sl-button text-white"><i
                                                                            class="far fa-heart"></i></a>
                                                                </div>
                                                            </div>
                                                            <ul class="menu bottomRight">
                                                                <li class="share top">
                                                                    <i class="fa fa-share-alt"></i>
                                                                    <ul class="submenu">
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-facebook-f"></i></a>
                                                                        </li>
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-instagram"></i></a>
                                                                        </li>
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-twitter"></i></a></li>
                                                                    </ul>
                                                                </li>
                                                            </ul>
                                                            <div class="video-actions--link_add-to-playlist dropdown">
                                                                <a class="dropdown-toggle" href="#"
                                                                    data-toggle="dropdown"><i
                                                                        class="fa fa-plus"></i></a>
                                                                <div class="dropdown-menu">
                                                                    <a class="login-link" href="#">Sign in to add
                                                                        this video to a playlist.</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="gen-movie-action">
                                                            <a href="#" class="gen-button">
                                                                <i class="fa fa-play"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div class="gen-info-contain">
                                                        <div class="gen-movie-info">
                                                            <h3><a href="#">AI:world</a></h3>
                                                        </div>
                                                        <div class="gen-movie-meta-holder">
                                                            <ul>
                                                                <li>2 weeks</li>
                                                                <li>
                                                                    <a href="action.html"><span>cricket</span></a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-lg-4 col-md-6">
                                            <div class="gen-carousel-movies-style-3 movie-grid style-3">
                                                <div class="gen-movie-contain">
                                                    <div class="gen-movie-img">
                                                        <img src="images/background/asset-5.jpeg"
                                                            alt="single-video-image">
                                                        <div class="gen-movie-add">
                                                            <div class="wpulike wpulike-heart">
                                                                <div class="wp_ulike_general_class">
                                                                    <a href="#" class="sl-button text-white"><i
                                                                            class="far fa-heart"></i></a>
                                                                </div>
                                                            </div>
                                                            <ul class="menu bottomRight">
                                                                <li class="share top">
                                                                    <i class="fa fa-share-alt"></i>
                                                                    <ul class="submenu">
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-facebook-f"></i></a>
                                                                        </li>
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-instagram"></i></a>
                                                                        </li>
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-twitter"></i></a></li>
                                                                    </ul>
                                                                </li>
                                                            </ul>
                                                            <div class="video-actions--link_add-to-playlist dropdown">
                                                                <a class="dropdown-toggle" href="#"
                                                                    data-toggle="dropdown"><i
                                                                        class="fa fa-plus"></i></a>
                                                                <div class="dropdown-menu">
                                                                    <a class="login-link" href="#">Sign in to add
                                                                        this video to a playlist.</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="gen-movie-action">
                                                            <a href="video-home.html" class="gen-button">
                                                                <i class="fa fa-play"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div class="gen-info-contain">
                                                        <div class="gen-movie-info">
                                                            <h3><a href="video-home.html">Horse Ride</a></h3>
                                                        </div>
                                                        <div class="gen-movie-meta-holder">
                                                            <ul>
                                                                <li>2 weeks</li>
                                                                <li>
                                                                    <a href="tennis.html"><span>Tennis</span></a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-xl-3 col-lg-4 col-md-6">
                                            <div class="gen-carousel-movies-style-3 movie-grid style-3">
                                                <div class="gen-movie-contain">
                                                    <div class="gen-movie-img">
                                                        <img src="images/background/asset-11.jpeg"
                                                            alt="single-video-image">
                                                        <div class="gen-movie-add">
                                                            <div class="wpulike wpulike-heart">
                                                                <div class="wp_ulike_general_class">
                                                                    <a href="#" class="sl-button text-white"><i
                                                                            class="far fa-heart"></i></a>
                                                                </div>
                                                            </div>
                                                            <ul class="menu bottomRight">
                                                                <li class="share top">
                                                                    <i class="fa fa-share-alt"></i>
                                                                    <ul class="submenu">
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-facebook-f"></i></a>
                                                                        </li>
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-instagram"></i></a>
                                                                        </li>
                                                                        <li><a href="#" class="facebook"><i
                                                                                    class="fab fa-twitter"></i></a></li>
                                                                    </ul>
                                                                </li>
                                                            </ul>
                                                            <div class="video-actions--link_add-to-playlist dropdown">
                                                                <a class="dropdown-toggle" href="#"
                                                                    data-toggle="dropdown"><i
                                                                        class="fa fa-plus"></i></a>
                                                                <div class="dropdown-menu">
                                                                    <a class="login-link" href="#">Sign in to add
                                                                        this video to a playlist.</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="gen-movie-action">
                                                            <a href="video-home.html" class="gen-button">
                                                                <i class="fa fa-play"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <div class="gen-info-contain">
                                                        <div class="gen-movie-info">
                                                            <h3><a href="video-home.html">Big Machine</a></h3>
                                                        </div>
                                                        <div class="gen-movie-meta-holder">
                                                            <ul>
                                                                <li>2 weeks</li>
                                                                <li>
                                                                    <a href="traveling.html"><span>Traveling</span></a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="gen-load-more-button">
                                                <div class="gen-btn-container">
                                                    <a class="gen-button gen-button-loadmore" href="#">
                                                        <span class="button-text">Load More</span>
                                                        <span class="loadmore-icon" style="display: none;"><i
                                                                class="fa fa-spinner fa-spin"></i></span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Single Video End -->
