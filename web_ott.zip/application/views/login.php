<?php 
$check_success = $this->session->userdata('user_id');
  // $check_success = $this->uri->segment(3);
  if($check_success == "success"){
?>
    <script type="text/javascript">
       $(document).ready(function(){
        $.notify({
            icon: 'fa fa-check-circle',
            message: "Success <b>Entry Database</b>."

        },{
            type: 'info',
            timer: 4000
        });

     });
   </script>
<?php 
  };
?>
<!DOCTYPE html>
<html lang="en">



<head>
    <meta charset="utf-8">
    <meta name="keywords" content="Streamlab - Video Streaming HTML5 Template" />
    <meta name="description" content="Streamlab - Video Streaming HTML5 Template" />
    <meta name="author" content="StreamLab" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Sunshine</title>
    <!-- Favicon -->
    <link rel="shortcut icon" href="images/favicon.png">
    <!-- CSS bootstrap-->
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <!--  Style -->
    <link rel="stylesheet" href="css/style.css" />
    <!--  Responsive -->
    <link rel="stylesheet" href="css/responsive.css" />
        <script src="http://code.jquery.com/jquery-1.9.1.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>
</head>

<body>

    <!--=========== Loader =============-->
    <div id="gen-loading">
        <div id="gen-loading-center">
            <img src="images/logo-1.png" alt="loading">
        </div>
    </div>
    <!--=========== Loader =============-->

    <!-- Log-in  -->
    <section class="position-relative pb-0">
        <div class="gen-login-page-background" style="background-image: url('images/background/asset-54.jpg');"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="text-center">
                        <form action="<?php echo base_url('check_login'); ?>" onsubmit = "return validation()" method = "POST" name="f1" id="pms_login">
                            <h4>Sign In</h4>
                            <p class="login-username">
                                <label for="user_login">Username or Email Address</label>
                                <input type="text" name="user_login" id="user_login" class="input" value="" size="20">
                            </p>
                            <p class="login-password">
                                <label for="user_pass">Password</label>
                                <input type="password" name="user_pass" id="user_pass" class="input" value="" size="20">
                            </p>
                            <p class="login-remember">
                                <label>
                                    <input name="rememberme" type="checkbox" id="rememberme" value="forever"> Remember
                                    Me </label>
                            </p>
                            <style>
                                .skip{
                                        padding: 12px 30px;
    font-family: var(--title-fonts);
    font-size: 16px;
    background: var(--primary-color);
    color: var(--white-color);
    text-transform: capitalize;
    color: var(--white-color) !important;
    display: inline-block;
    border: none;
    width: auto;
    height: auto;
    line-height: 2;
    text-transform: uppercase;
    -webkit-border-radius: 0px;
    -moz-border-radius: 0px;
    border-radius: 0px;
    transition: all 0.5s ease-in-out;
    transition: all 0.5s ease-in-out;
    -moz-transition: all 0.5s ease-in-out;
    -ms-transition: all 0.5s ease-in-out;
    -o-transition: all 0.5s ease-in-out;
    -webkit-transition: all 0.5s ease-in-out;
}
                                }
                            </style>
                            <p class="login-submit">
                                <input type="submit" name="wp-submit" id="wp-submit" class="button button-primary" value="Log In">
                               <!--  <button class="button button-primary skip" style="margin-left: 5px;"><a href="<?php echo base_url('home'); ?>" style="color: #fff;">SKIP</a></button> -->

                                  
                                <input type="hidden" name="redirect_to">
                            </p>

                          <!--     <a  style="padding: 7px 30px;
    font-family: var(--title-fonts);
    font-size: 18px;
    background: var(--primary-color);
    color: #fff;" href="<?php echo base_url('home'); ?>">Skip</a><br> -->
                            <input type="hidden" name="pms_login" value="1"><input type="hidden" name="pms_redirect">
                            <a
                                href="<?php echo base_url('register'); ?>">Register</a> 
                             <!--    | <a href="#">Lost your
                                password?</a>
 -->
                                
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Log-in  -->

    <!-- Back-to-Top start -->
    <div id="back-to-top">
        <a class="top" id="top" href="#top"> <i class="ion-ios-arrow-up"></i> </a>
    </div>
    <!-- Back-to-Top end -->

    <!-- js-min -->
    <script src="js/jquery-3.6.0.min.js"></script>
    <script src="js/asyncloader.min.js"></script>
    <!-- JS bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- owl-carousel -->
    <script src="js/owl.carousel.min.js"></script>
    <!-- counter-js -->
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.counterup.min.js"></script>
    <!-- popper-js -->
    <script src="js/popper.min.js"></script>
    <script src="js/swiper-bundle.min.js"></script>
    <!-- Iscotop -->
    <script src="js/isotope.pkgd.min.js"></script>

    <script src="js/jquery.magnific-popup.min.js"></script>

    <script src="js/slick.min.js"></script>

    <script src="js/streamlab-core.js"></script>

    <script src="js/script.js"></script>

<script>  
    function validation(){  
        var id=document.f1.user_login.value;  
        var ps=document.f1.user_pass.value;  
        if(id.length=="") {  
            //alert("User Name and Password fields are empty");
            toastr.error('Please Enter the Email Id');   
            return false;  
        }else if(ps.length=="") {  
            toastr.error('Please Enter Password');  
            return false;    
        }                             
    }  
</script>  
</body>

</html>